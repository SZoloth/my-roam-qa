→ 1974 - Born in Delhi, India

→ 1985 - Age 9 - Moved from New Delhi to Queens, NY

→ 1989 - Age 14 - Attended Stuyvesant High School

→ 1995 - Age 21 - Graduated Dartmouth (studied computer science and economics)

→ 1999 - Age 25 - Founder/CEO of Epinions

→ 2001 - Age 27 - Venture Partner at August Capital

→ 2003 - Age 29 - Founder of Vast.com, a classified ad marketplace

→ 2005 - Age 30 - Is called “Radioactive Mud” in Silicon Valley

→ 2007 - Age 32 - Founded Hit Forge, a small VC fund originally conceived as an incubator

→ 2007 - Age 32 - Launched VentureHacks blog

→ 2010 - Age 34 - Launched AngelList

→ 2010 - Age 34 - Invested in Uber

→ 2012 - Age 36 - Lobbied Congress to get the JOBS Act passed

→ 2018 - Age 43 - Is named “Angel Investor of the Year”

