[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Prep the [[[[Google Ads]] for #ADK]] ad concepts for [[maggie o'connor]] #/

{{{[[DONE]]}}}} Quick check in on [[[[Sleeping Dog Properties]] Marketing Strategy]] [[Sleeping Dog Properties]] blog analytics

{{{[[DONE]]}}} Prep for [[Cambridge Associates]]

Background about me

Making sure the site is built for success from a digital marketing front and then making sure your marketing team has what you need to knock down your target KPIs.

My team collaborates with the user research and strategy team to pull out the key [[insight]]s and concepts that should be [[translate]]d to your customer facing touchpoints. 

Activating that research 

This is primarily through SEO, custom analytics, conversion rate optimization, and a thoughtful content strategy that takes into account competitive landscapes .

To that end I work on things like technical site audits, user research, competitive research, content planning, mapping and coordinating customer touchpoints, conversion optimization, and customizing analytics.

Post launch, I've also worked with our partners marketing teams to create SEO/content strategies that they can execute going forward - coaching on the basics and beyond.

How do we map out content to make it frictionless for users, and easy for search engines to find your site?

About CA

This is likely not a lead gen site

it's about engendering trust, solidifying expertise by properly capitalizing an extensive thought leadership program

"an integrated digital marketing strategy that considers customers from first touch to the point of established loyalty and referrals."

"crucial that our site speaks to our value propositions between Pensions, Private Client, and Endowments/Foundations with equal clarity."

thought leadership to contact with as little friction as possible

"clearly communicate our value prop and what differentiates us" --> what is this?

ideal audience: "A US corporate pension plan wanting OCIO services  they are convinced we are a unique provider of services that is somewhat of a disruptor in the staid world of Nercer/Towers/Aon. We understand pension mechanics and we are superior in alternative assets which will result in a higher return and ability to close theIt pension funding  gap ( a similar scenario for all segments with slight tweaks "

A family office consultant and they think “wow every family I work with needs to hire CA – they are better than all the other players out there!”

{{{[[DONE]]}}}} [[form health]] question from [[jess lopez mora]]

{{{[[DONE]]}}}} Re-write the [[Museum of Science]] landing page

{{{[[DONE]]}}}} Map out a blog charter: topic, bullet points about our unique POV, quotes to use #[[[[hiring]] a copywriter]]

How to write an effective RFP

https://docs.google.com/document/d/1QJQVxhqa27HB8Vnd0u2SXxqBLpSTs1S0ybxLvehL6zA/edit?usp=sharing

How to Make Your App FDA Compliant (fda mobile medical apps)

When does an app need to be FDA compliant?

What does it mean to be FDA compliant?

Can you give a little background on GTI?

What was our process for making GTI FDA compliant?

What was the hardest part? 

Now that GTI is FDA compliant what opportunities are unlocked?

How to Design User Surveys that Improve Your Product

What are the steps to designing a user survey? Please provide a 1-3 sentences of detail for each step.

What makes a survey bad - what are the most common mistakes or traps?

What elements should every survey contain? Are there any universal principles or rules for designing a strong user survey? Please provide a 1-3 sentences of detail for each rule or element. 

Are there any questions that every survey should contain?

The Most Efficient Way to Conduct User Testing

{{{[[DONE]]}}}} Find one example and do a deep dive on what makes it good for #[[[[hiring]] a copywriter]]

{{{[[DONE]]}}}} Answer the [[ICP]] question from [[refine labs]]

{{[[DONE]]}} Two big focus areas  #//

Content Strategy

Project Management

Process for Marketing Engagements

Eg - [[Museum of Science]]

Also look at framework of [[thesis testing]]

Questions to ask

Why did you create this product?

{{{[[DONE]]}}}} connect with [[darci nevitt]] around link building

[[Meetings]]: [[Cambridge Associates]] sales pitch

Attendees::

Time:: 13:02

Summary::

**KPI goal to make pipeline 25% proactive (non-referral)**

Notes::

Major questions

What does partnership look like with ADK? #[[Inspiration for ADK]]

What is the strategic thinking / value add that we bring to the table? #[[Inspiration for ADK]]

Other questions

can we see an example of user research #[[Inspiration for ADK]]

about our project teams #[[Inspiration for ADK]]

Pain point in current relationship

PM [[scope]] was punted to client, wants PM to own

Looking for

strategic thinking about prioritization and balance of different workstreams and [[Goals]]

How do you effectively balance the [[Goals]] of multiple stakeholders? #[[Inspiration for ADK]]

how do you build [[Focus[[*]]]] into your organization? #[[Inspiration for ADK]]

keeping [[Goals]] in mind, without getting distracted by the new shiny thing

how do you build [[Focus[[*]]]] into your organization? #[[Inspiration for ADK]]

alignment on [[Goals]] and being crystal clear about it

validate [[Goals]] and keep team in check

how to collaborate on a strategy with an external partner #[[Inspiration for ADK]]

documenting decisions has been difficult

Our process for documenting decisions #[[Inspiration for ADK]]

[[deirdre nectow]] oversee global business dev

content presentation and accessibility

[[sam wallace]] Site to become center spoke for digital marketing ecosystem

[[carol dunn]] Looking to think strategically about how to tell the story and bring it to life online

[[nora [[Cambridge Associates]]]] telling a story, pushes back, teaches, pushes back

private client marketing

[[krista matthews]] like data and numbers

95% of business is referral-based

but this is evolving and changing

**KPI goal to make pipeline 25% proactive (non-referral)**

from 5% over 3 years

double organic growth immediately

Well defined: core business and verticals

How to turn an established brand into a digital experience #[[Inspiration for ADK]]

storytelling

voice and tone

Blog architecture

topics: a content strategy that balances SEO value (keyword research), value to your brand, and value to your customers

content is an extension of the product or service you're providing

editorial lines and transactional pages

actual architecture: whats the appropriate message to hit the customer with next to encourage them to stay engaged?

splitting into: top level acquisition metrics, engagement metrics, and the most important: conversion metrics

[[Meetings]]: [[refine labs]]

Attendees:: [[chris walker]], [[angelica taylor]], [[megan bowen]], [[alex fedorov]], [[ben kaplan]]

Time:: 16:03

Notes::

 [[Goals]]

Break out of Boston within next 6 months

$75m in revenue

Got $3m grant from NIH to build at-home testing for Alzheimers via an app

High end and expensive

What's unique about ADK

We're a complete package - full service product development

Lead projects entirely in the US

We have an offshore office in Medellin that we know work

Have cracked the code on quality control with process

Socially conscious, integrity, and philanthropy

How we opened our office in Medellin #[[Inspiration for ADK]]

Ask clients about prices - why do you think they're charging so much less?

Produce an hour long video podcast

Identifying: 1-2 lead personal profiles 

Build a content library of these personal profiles being recorded

[thread by @GoodMarketingHQ](https://twitter.com/@GoodMarketingHQ/status/1298668364026589184)︎ #[[twitter thread]]

Carrie Rose is a PR genius

THREAD...

1/ Carrie's the co-founder of Rise at Seven, a creative SEO agency.

A friend told me about her last year.

Ever since I’ve been consistently blown away by how easy she makes getting press look.

2/ And it’s not press for press's sake.

The reward is high quality backlinks which help her clients rank for ultra-competitive search terms.

Let me give you an example...

3/ Missguided is a fashion retailer who started working with Rise last year.

Carrie looked at their site for 5 minutes, saw they sold dog jumpers, and knew there was a story there.

So she found some similar looking regular jumpers, and wrote the headline...

4/ “Missguided launch matching jumpers for you and your dog this winter”

The media loved it. And Missguided soared from #30 to #1 for the search “dog jumpers”.

No big budget or photoshoot. Just the idea to link two pre-existing products with a clever headline. [pic.twitter.com/QwaJdepltD](https://twitter.com/GoodMarketingHQ/status/1298668369453953025/photo/1)

5/ Another example.

November 2019, Game came to Rise.

They'd just launched a new webpage full of gaming chairs. The challenge was to rank this page in time for Christmas.

6/ But, getting press to link to a bunch of gaming chairs is near impossible.

So, instead, Carrie dreamt up “The Christmas Tinner”.

A 3-course meal in a tin for hardcore gamers. And it was this page that then linked to their gaming chairs. [pic.twitter.com/l3FlCd3I3N](https://twitter.com/GoodMarketingHQ/status/1298668373040148487/photo/1)

7/ The Christmas Tinner went viral.

“SEO juice” passed down. And within 3 weeks Game's gaming chair page was ranking for over 400 keywords. [pic.twitter.com/z0q6NicgY7](https://twitter.com/GoodMarketingHQ/status/1298668375086948354/photo/1)

8/ Honestly, I could tell a dozen more stories like this.

But it’s more important to try and understand the process.

Carrie tells me the trick is *learning to think in headlines*.

9/ For example, last Easter she worked with a sex toy startup. The first thing they do is work out the headline:

“The world’s first Easter egg with a sex toy inside”

Then they work backwards until it becomes reality. [pic.twitter.com/3FNHlYsYEt](https://twitter.com/GoodMarketingHQ/status/1298668379339988992/photo/1)

10/ Once you've got your story the final step is pitching it.

Here's Carrie's crash course:

Journalists are busy. Make their life easy

They start at 8:30. So send outreach at 8

The email subject is my headline. Then I sell the article. And embed my best image [pic.twitter.com/5oFtkha7Ci](https://twitter.com/GoodMarketingHQ/status/1298668381411966980/photo/1)

11/ 14 months ago Rise launched with one client at £2k / mo.

Today revenue is £2M / yr. And yes, that is crazy!

It reminds me that nothing moves the needle like genuine creativity.

One 5 minute idea can have more impact than 100 guest posts.

12/ That's all I got.

Thanks to Carrie ([@CarrieRosePR](https://twitter.com/CarrieRosePR)) for sharing her wizardry. Go check her out.

She tells me I've given her too much credit, and it's really the team at Rise which make it happen.

[A crash course in getting press to build backlinks](https://marketingexamples.com/seo/press)

13/ Thanks for reading.

If you enjoyed it you might like my newsletter. I write up a new marketing case study (like this one) every week.

Over and out — Harry

[Join 30k marketers getting one practical case study each week](https://marketingexamples.com/subscribe)

## To get a better idea of the writing we're looking for: #[[[[Grow and Convert]] Content Strategy]]

### Examples from us

The following articles do an effective job of taking information from a subject matter expert and presenting it in an interesting narrative.

https://www.adkgroup.com/case-studies/cambridge-savings-bank-website/

https://www.adkgroup.com/blog/react-native-development-company/

https://www.adkgroup.com/blog/technology-adoption-strategy-ALKU/

https://www.adkgroup.com/blog/expert-opinion-promise-and-reality-manufacturing-iot/

### Examples from external sources

These break down a relatively complex mental [[model]] into something easily digestible and provides examples and questions for the reader to take home with them.

https://brianbalfour.com/quick-takes/universal-growth-loop

https://futureblind.com/2019/08/03/advantage-flywheels/

https://www.screenshotessays.com/

This (and all of Firstround's content) take interviews with influential SMEs and turn them into actionable guides.

https://firstround.com/review/the-ultimate-guide-to-the-founding-designer-role/

These make traditionally dry topics engaging and filled with personality.

https://www.bloomberg.com/opinion/articles/2020-08-11/goldman-loves-a-good-crisis

https://notboring.substack.com/p/shopify-and-the-hard-thing-about-a05

Targeted firmly at company leadership.

https://www.nfx.com/post/how-ceos-think-mental-models-shift-founder-to-ceo

Data or research-backed and coining a new concept.

https://andrewchen.co/the-law-of-shitty-clickthroughs/

