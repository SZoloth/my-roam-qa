**Metadata**

**Tags:** #organic, #[[Growth marketing[[*]]]], #[[✍️ blog-post]], #[[✍️ blog-post]],[[marketing]], #SEO, [[social media]], #retargeting, 

**Status:** #draft of #Articles

In response to the question: "how do we drive blog traffic to landing pages?" from [[Marcus Svensson]] of [[Albacross]]

**The intent of your target keywords**: a lot of what you rank for is pretty high in the #funnel. It defines a topic like “lead nurturing” which is **awesome** for driving traffic, but you’re going to get a lot of unqualified traffic. People searching for that term are looking for information (and are likely relatively junior). Getting down to the keywords your target audience would be searching closer to when they’re making a buy or try decision would help this.

**Measuring the value of organic traffic**: It’s possible (likely) that some of your leads have their first touch on a blog post then come back later to convert, maybe via another channel (direct, retargeting, etc.) Attribution is really difficult but worth taking a look at via the Google Analytics Assisted Conversion view (it’s never going to be exact, but is helpful directionally).

**Building out nurture campaigns**: Instead of pushing someone from a low intent blog like “what is lead nurturing” directly to a trial, is there a [[lead gen]] PDF you could offer up in exchange for their email as an intermediate step? Then you could drip new content to them until they’re ready to convert. This is the #Hubspot playbook, basically. You could also make it easier to subscribe to the blog.

**Are you trying to make landing pages act as your “#pillar” pages?** If you have topic-specific landing pages (maybe one that positions Albacross as a lead #nurturing tool if relevant) then you could ensure you’re linking to that specific landing page from __all__ blog posts related to “lead nurturing.”

**Retarget people that viewed your blog posts**: Similar to a nurture campaign --> for people that visited the “what is inbound marketing?” blog you could create an “Inbound Marketing Strategy Template” as a downloadable via FB/IG/LI ads to capture their email. Or you could try pushing them directly to the landing page, that __may __work too!

#[[social media]]

