Quote #[[Inspiration for ADK]]: 

[Post from Daniel J Murphy](https://www.linkedin.com/posts/-danieljmurphy_brand-activity-6681938658502692865-3bBH) of #Privy

Your brand ≠ what's on your homepage.

Yesterday we relaunched Privy’s website. When I joined Privy in January one of my team's big objectives was to relaunch the *brand*.

But we waited 6 months to relaunch the *website*.

Isn’t your website the most logical place to start if you’re going to be relaunching a brand?

No.

Because your brand isn’t just what’s on the surface level!

Your brand is the experiences you create for people that interact with your business.

For us the experience we wanted to create was: "Damn, those folks at Privy taught me ecommerce marketing for FREE. Now I know what I need to do to grow."

So we…
- launched a free podcast so you can learn from ecomm experts about how they grew their businesses from $0-$1M in sales

- made our blog the learning hub for ecommerce marketing so you can learn about the marketing plays that will increase sales. nothing gated.

- launched Privy Masterclass where we run weekly classes with the experts who will teach you ecommerce marketing (yes, also free)

Privy = the people that teach you how to do ecommerce marketing.

We didn’t need a new website to build that brand.

Use some for [[ADK content]]

IBMix and IBM garage #[[Inspiration for ADK]]

For [[shawna parker]] / [[CASE Marketing]]

Clubhouse as starting point for podcasts (think: digital panel conversations)

Resource hubs

growth.segment.com & stripe.com/atlas

Communities / networks

[Underscore collective](https://www.underscore.vc/core-collective-series)

First Round Review interviews

[Events](https://firstmarkcap.com/events/)

Exclusive 

Executive Summits

"Guilds"

Public

Promoting "non-core" services

HRaaS

[[webinar]]s

[Example of SME [[webinar]] from thoughtbot](https://thoughtbot.com/events/digital-health-startup-event) [[Inspiration for ADK]]

Customer interviews and research

Recommended tech stacks by vertical

Profitwell media

Conversational teardowns #[[Inspiration for ADK]]

https://www.freshtilledsoil.com/a-little-experiment-in-banking-uxui-redesign/

Similar to [[profitwell]] and [[Patrick Campbell]]

Could do conversational teardowns

https://builtformars.co.uk/studies/

Other examples: growth.design

Automating outbound touches to site visitors based on firmographic profiles #[[Inspiration for ADK]]

The basic premise is to use an IP revealer tool to turn site visitors into company profiles, compare that profile to defined target criteria, find a decision maker, populate an email template based on the visitor's firmographics (role, industry, etc.), and send that email -- all automatically. The visitor would then be in a drip campaign until they respond, at which point a sales rep will be able to "take control of the wheel."

