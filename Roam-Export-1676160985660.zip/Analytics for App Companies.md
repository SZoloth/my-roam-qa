## Google Tag Manager (GTM)

Benefits

Free

Low code

Works with everything

Drawbacks

Repetitive - need a new tag per channel or tool

If triggers are based on HTML, possible engineers may break them without realizing

Requires some very basic knowledge of coding

Good for

small teams with a small/simple website

teams w/ low engineering resources

## Segment

Benefits

Low code

Fewer tags required to track the same number of interactions across the same number of tools

Less time and repetition

Drawbacks

Costs money

Only works with tools it integrates with

Eg - no Snapchat integration right now

Good for

Complex sites or apps where you're tracking lots of events and data

Uses

Logs events

Logs user data

Basic process

Engineers add all the events we've specced using Segment code

Configure Segment to integrate with every tracking tool we need

Definitions

Sources

Example: a website

Where events and user data takes place; a codebase

Destinations

Example: a tool like Facebook Ads

Where we send events and user data; third party tools and platforms we want added to the site/app

Segment automatically sends every event to Google Analytics

