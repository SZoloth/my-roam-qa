Similar to #self-development

