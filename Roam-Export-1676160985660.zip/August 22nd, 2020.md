[[Morning Pages]] 

{{word-count}}

Woke up today, scrolled twitter. It wasn't a doom scroll because I stumbled onto some tweets about Roam. 

Whoah that sentence was difficult to get out - even after a [[neuromint]] (but not coffee), my brain feels a little foggy. I guess I didn't sleep that well, though I don't feel exhausted. I feel ready.

I also saw a [thread](https://twitter.com/TurnerNovak/status/1297023704543698944?s=20) about [[Stitch Fix]] and it pretty immediately clicked with [[Drawbridge]]. Stitch Fix is sort of a permutation of what Drawbridge could be. It is: Membership based & Vertical/industry specific ([[Stitch Fix]] is only focused on clothes, for now)

Could there be a niche for [[Drawbridge]] to start out in? Some thoughts below:

Make up

Video game add-ons

Sneaker drops (get early access)

Issue with this is that [[Drawbridge]] wouldn't be solving anything for the supplier

Another random thought is there's a tension between: optimizing, learning, and doing.

You can't do two at a time __well__

Semi-related to [[Drawbridge]] is the lack of an ad channel that allows targeting by __both__ demographics (like [[facebook]]) and intent (like [[Google Ads]])

Theoretically [[Drawbridge]] may be able to do just that

How __do__ people line up demographic and intent-based targeting these days?

One could argue that very specific keyword targeting could do it in [[Google Ads]]

But that's not really consistent enough.

Also am feeling #Gratitude for grocery delivery. I shouldn't underestimate how good it feels to have options for tasty, healthy, food available.

And am feeling #Gratitude for this [[Roam]] theme, funnily enough. The soft orange and greys are very pleasing to look at. 

The core idea in the [[Zettelkasten]] is that every time you read something worthwhile, you write up each idea in your own words -- and link those ideas to the other notes that are related

Teladoc + Livongo: what it means, with [[insight]] from [[brian mullen]] and [[Dan Tatar]] #[[Inspiration for ADK]]

[[Berkshires]]

Tanglewood music hall

Berkshire Botanical Gardens

Hiking

Appalachaian Trail and Mt. Greylock

MA's highest peak

Kennedy Park

Pleasant Valley Wildlife Sanctuary

Hummingbird garden

Beaver ponds

Natural areas

Close to Seven Hills

Edith Wharton Park

Laurel Lake

Gould Meadows

Stockbridge Bowl

october mountain state forest

Misc

Tom Fiorini Sculpture Yard

Picnic from Nejaime's Wine Cellars

Naumkeag estate

Balderdash Cellars

How to assess ad channels [[Insp]]

[[[[Grow and Convert]] Content Strategy]]

By [[Benji Hyam]] and [[Devesh Khanal]] of [[Grow and Convert]]

About [[Mirage Content]]

[source](https://growandconvert.com/content-marketing/mirage-content/)

Similar to clickbait, where the title overpromises and the unoriginal content underwhelms; it's just fluff.

Common symptoms of [[Mirage Content]]

Content looks good but no traffic

Writing about the same traffic as competitors, but no links

Getting some traffic but no conversions

Common causes of [[Mirage Content]]

A writer not having enough experience to write in-depth about a subject

To get around this, either:

Use a writer with experience in the subject area. This is usually an employee, though, and employees don't often have enough time and are often not great writers.

Hire a journalist who can interview a subject matter expert and turn that into a great post.

The article not having specific details and examples

 Trying to tackle too broad of a topic

Not understanding your customers in depth: who they are and what their pain points are. (a symptom of not conducting user research before ideating on topics).

You need to think of your content from your __specific customer's perspective__ - would they find it valuable? Not just the perspective of, "would this be valuable to anyone interested in the topic?"

The real danger is that even if it does attract the right audience, it dramatically undersells your expertise.

If you're not sharing expertise then there's no reason to share because people don't want to hire amateurs.

How to stand out against [[Mirage Content]]

Use a real example with real metrics.

When you use a real example, show the reader a behind the scenes look at how they achieved it.

The basic premise here is: "Here's someone who achieved the goal you're targeting (and then some). I'll show you how they did it so you can, too."

Because you're being judged by the quality of your content.

Beginner content is fine **if**

Beginner level questions are real questions or prospects that your audience has

Write an article about a specific topic unless you're writing a pillar

#[[Quick Capture]]

flip side to [[Drawbridge]] is that it’s basically just email ads but worse 

