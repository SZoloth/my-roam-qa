[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} #ADK Marketing Plan #//

{{[[DONE]]}} Schedule some time with [[Dan Tatar]] and [[chris baker]] to propose next round of investments (Summer Campaign) #Inbox

Internal / Lifecycle Marketing

Referrals, upsells, email marketing, staying in front of current partners

Notes: Brand-building, awareness, 2x or 3x our content

What works in sales? Taking over legacy technology about 6-12 months before they're ready to build the new thing #[[Inspiration for ADK]] #[[Selling ADK Group]]

((SPxOIXLdj))

{{{[[DONE]]}}}} What to do with new [[ADK Marketing Assets]] from [[Dan Tatar]] #//

Inspiration - study and ask

**[EPAM](https://www.epam.com/)**

**[Ness Engineering](https://www.ness.com/)**

[[ADK Website Rebuild]] #Inbox

{{[[DONE]]}} for [[ADK Website Rebuild]] The content priority right now is determining the shape of industries v. “tech solutions” — and how we want to handle conceptually. ([ticket link](https://adkgroup.atlassian.net/browse/ADKWPW-31))

{{[[DONE]]}} Strategize and brainstorm for [[ADK Website Rebuild]] around:

[[feedback]] from [[charlie carmichael]] of [[National Speed]]

Vehicle page

Pillar style

Page builder

Performance packages

Individual upgrades

Warranty

Proven Process

Accolades

Related projects

Performance packages contain a lot of information

Tag CTAs with unique IDs

{{[[DONE]]}} [[July 8th, 2020]] Connecting Segment and GA for [[From Health]]

Segment

GA

:hiccup [:hr]

[[Meetings]]: Check in with [[darci nevitt]]

Attendees:: [[darci nevitt]]

Time:: 12:20pm - 12:30pm

Notes::

Regarding [[Neil Tatar]] website

[[Meetings]]: Sales for [[Putnam Associates]]

Attendees:: [[ben kaplan]], [[Dan Tatar]], [[Klam Olaogun]]

Time:: 3:00pm - 

Notes::

Putnam acquired by a healthcare firm out of the EU

Want at least a small upgrade to present to incoming recruiting class in September

Has 3 areas of focus

Recruiting

Business development

Telling our story - branding

Global presence

EU, both coasts, London

Serving the top 19/20 biopharma companies in the world

Integrated with Workday

Budget - not defined

Interested in a [[webinar]] platform for:

Recruits

Internal team

Prospects/Leads

Next steps:

{{[[DONE]]}}  Run through [current site](https://www.putassoc.com/) and take note of quick wins on [[July 8th, 2020]] #Inbox

Due by [[July 10th, 2020]]

[Client notes](https://docs.google.com/spreadsheets/d/1vHGQ89GEre2JNYLtbcwnqhwLWTUGf2te1mq4eKj5LNU/edit?usp=sharing) (PIE spreadsheet)

Send over references and examples

[[Meetings]]: [[Getting buy in from leadership]]

Attendees:: [[jayne hetherington]]

Time:: 3:40pm - 4:06pm

Notes::

Richard = typical CEO

Producer. Doesn't care about details

Asks: "how long and how much?"

Don't come with problems. Come with a solution.

Googling and researching to get to a potential solution. Explaining logic.

Frame the ask as specifically as possible to say yes or no

If it's open ended they'll say no

Really, genuinely value their time

Seek to take things off a higher ups plate. Delegate elsewhere if necessary

[[Meetings]]: [[Getting buy in from leadership]]

Attendees:: [[ben kaplan]]

Time:: 4:25pm -

Notes::

Comes from a place of deep fear

Needed to shape his life around managing up

Try to need leadership as little as possible

Only when bringing something to the table

When making an ask, make sure it has structure

Know what you're asking

Make it clear that they're the decider

Who are the people around the decision maker that the DM talks to

Build consensus __before__ approaching the DM

Before his meeting with Dan, had calls with Chris and Jon to ask for advice

Asking someone for advice is the best way to ingratiate them

Recruit a designer (Sean Riley) to [create the presentation](https://docs.google.com/presentation/d/1JcgxI--Uw16RpreDPCMm0G6RvKYFvwtI7JHSoLpyEj8/edit?usp=sharing)

[[Meetings]]: [[Selling ADK Group]]

Attendees:: [[ben kaplan]] [[chris baker]]

Time:: 4:00pm - 4:26pm

Notes::

Clear, specific, low-asks to impact ADK marketing

Help me tell my story and in the process tell ADK's story

"Jayne, last time Ben posted he got 5 likes. You two are responsible for getting his next post to 10 likes"

ADK profile tags and questions people

they share and respond

Quiz or survey

Give us one piece of [[feedback]] about our own LinkedIn profile

[[Personal Task Management]]

{{[[DONE]]}} Cancel BSC

{{[[DONE]]}} Bills

{{[[DONE]]}} Chase bank?

{{[[DONE]]}} WSJ?

