[[feedback]]

{{[[DONE]]}} [[ADK Marketing Priorities]] 

Get the most out of the [[ADK Drupal Campaigns]]

Case studies #[[[[ADK]] case studies]]

Enterprise #[[ADK enterprise campaign]] #[[ben kaplan]]

[[Dan Tatar]]s ask around an "app campaign" version of the [[ADK Drupal Campaigns]] = "how do we move the needle on that?

Hand off [[National Speed]] to [[darci nevitt]]

What is our [[ADK SEO Process]] ?

How do we manage multiple complex multi-audience campaigns at once?

What works in sales? Taking over legacy technology about 6-12 months before they're ready to build the new thing #[[Inspiration for ADK]] #[[Selling ADK Group]]

Display what can we do with varying levels of internal resources?

eg, the Drupal campaign

Can we start to shift resources to next campaign

Can we pull [[Jessica Hodgkin]] in as PM for ADK marketing

Pull together tasks/tactics/strategies

What are [[Goals]] over next 2 months? 

By July 1, 3 campaigns in market: Drupal, X, and Y

1:1 notes in gdocs

{{iframe:https://docs.google.com/document/u/1/d/1H_pPnrdIP8Rc0Q0JcoBTIY7vpzI2CcthqFohBCOUFIg/edit}}

A risk of tying opportunities to location means that your talented people who value working remote are likely to look elsewhere [[WFH/work from home]]

[[[[Big Game Hunting]] Content]] for [[Kate Payne]]

