Yelp/Clutch for med device companies

Morning Brew for health tech

what can facilitate [[esports]]

AR recordings of past games

AR livestreams



what can facilitate [[businesses on youtube]]

like unboxing

kid-friendly?

DTC

Toilet paper?

Bathroom cleaners

Think: AR for AIS (see inside things) and AR for air traffic control (far away things with more details + data visualization)

