Author:: [[Nathan Baschez]]

URL:: https://divinations.substack.com/p/healthos

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

In order to judge whether it’ll work, it’s important to always return to the basics from the “Finding Power” framework: what is the job to be done? What’s not good enough? In other words, what is the basis of competition? What layers of the value chain do you need to control in order to win? 

