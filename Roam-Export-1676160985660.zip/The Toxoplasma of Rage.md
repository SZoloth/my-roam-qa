Author:: [[web.archive.org]]

URL:: https://web.archive.org/web/20200111054622/https://slatestarcodex.com/2014/12/17/the-toxoplasma-of-rage/

Recommended By::

Tags:: #Articles #Inbox #Readwise

# Notes

When signaling, the more expensive and useless the item is, the more effective it is as a signal. Although eyeglasses are expensive, they’re a poor way to signal wealth because they’re very useful; a person might get them not because they are very rich but because they really needs glasses. On the other hand, a large diamond is an excellent signal; no one needs a large diamond, so anybody who gets one anyway must have money to burn. 

But in the more general case, people can use moral decisions to signal how moral they are. In this case, they choose a disastrous decision based on some moral principle. The more suffering and destruction they support, and the more obscure a principle it is, the more obviously it shows their commitment to following their moral principles absolutely 

A moral action that can be taken just as well by an outgroup member as an ingroup member is crappy signaling and crappy identity politics. 

