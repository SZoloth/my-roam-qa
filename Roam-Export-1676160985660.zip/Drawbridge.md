Does it fit in better with the [[passion economy]]?

like as an etsy or substack companion

