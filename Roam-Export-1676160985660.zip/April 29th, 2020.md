Had some [[feedback]] for [[chris baker]] regarding the meeting on [[April 28th, 2020]] with [[ben kaplan]]

Wanted to share with you that the meeting with Ben didn't feel great. Theoretically, he was brought in to help PM, but that wasn't discussed at all and instead we did a version of onboarding and spent ~80% rehashing/reproducing what exists on the document I spent time producing. The ~20% that felt like it resulted in new progress was focusing on the persona. Which wasn't materially different from what I would have recommended.

My pain points are not a lack of ideas. It's a lack of process. Lack of support. Lack of resources, structure, deadlines, etc. Similarly, if the issue is that nothing's launched, my pain points align well with the blockers there. Incentives should be aligned to removing those, but I feel as though they aren't for whatever reason.

Fresh eyes can help, but can also be as much "the enemy of done" as "perfect" is. I'm sensitive to this also because at ADK Group it seems like most people think they know what's right for marketing and think they can get involved in ways that would never occur for development.

In general, in my experience, people tend to underestimate the skill/effort/time/knack or whatever to do good marketing. So when someone says they’ve done it before, it can mean a range of things. And bringing in PMs to do marketing work (eg - Jessica) just hasn’t worked that I’ve seen. And it confuses me, because you would never bring in a PM to do a devs work. But we toss marketing work — no matter the [[scope]] or client — to junior or non-marketers alike.

Ultimately, it felt like being given way too vague an ask with unclear priorities. Then being given training wheels (which feels like a result of messing something up - though nothing was clearly identified).

Not sure if that's just me overthinking or not. But wanted to share as some [[feedback]].

[[🏔ADK [[Task Management]]]]

[[ADK Drupal Campaigns]]

[[ADK Marketing Needs]] #[[ADK enterprise campaign]]

[[ADK content]]

[[ADK React Blog]]

[[ADK Alku Blog]]

[[ADK adapting to telemed blog]]

[[ADK SBIR Blog]]

[[ADK pillar: How to Build Competitive Advantage Through Custom Applications]]

Link to: ALKU (expansion), HNRG (CX and process), Span Tech (internal process optimization / sales)

[[Drupal 7 to 8 upgrade blog]]

[[ADK What is Feature Backlog? Why Should I Have One? How to Start One Blog]] #[[backlog of features]]

[[ADK Website Rebuild]]

Stakeholder interviews

What is our differentiating factor?

What few things do we do really well?

We're partners - we bring our smarts and your smarts and mix them together. Technical + subject matter expertise

Process may be more important for apps vs. websites

important for differentiating against creative agencies

We win because we can deliver faster and tighter than creative agencies

How does someone know our process is better than anothers?

FTS

How do we position FTS?

Design

FTS

UX/UI ADK

How do we position national v. regional?

How do we position industries?

How do we position against competitors?

Casual vibe but serious work.

>50% of our business is healthcare

<<<<1% is legal services

[[Intro to Rick Meeting with Wasabi]] #Wasabi #[[Rick Kellstrom]]

Brand, consistency

RCS CTA UX

Homepage reduced conversion rates

Rick & Sam: campaign landing pages

