Tags::

#[[Sleeping Dog Properties]] #[[Sleeping Dog Properties]] #[[[[Sleeping Dog Properties]] Marketing Strategy]]

#facebook

Reports

[[June 9th, 2020]]

Total spent: $1,991.57

Total remaining: $3,008.43

Impressions: 192,889

Reach: 82,037 people

Total clicks: 2,954

Cost per click: $0.67

Views of blog post: 2,689

Prospecting:

Sweet spot for age is 45+

Women-dominated

Most occurred in the Boston (Manchester) DMA, which includes the counties:

Barnstable

Dukes

Essex

Middlesex

Nantucket

Norfolk

Plymouth

Suffolk

Worcester

Devices: iphones + iPads (some Androids)

Mostly on the mobile app Facebook news feed

Times of day:

7-9am

12-1pm

4-7pm

**8-11pm**

Creative

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2F48WxOAd6aY.png?alt=media&token=b0927fb8-1b79-42ed-8ef5-b18a0726c57b)

Retargeting:

Sweet spot for age is 45+

Women-dominated

Most occurred in the Boston (Manchester) DMA, which includes the counties:

Devices: iphones + iPads (some Androids)

Mostly on the mobile app Facebook news feed

Creative:

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FiezakEriZ5.png?alt=media&token=5e443d37-d195-4816-a923-f7f59b7b32e7)

Recommendations

Refine targeting based on findings

Pause low-performing prospecting videos; test them on retargeting

Test new retargeting value props

