[[🏔ADK [[Task Management]]]]

{{[[DONE]]}}  Run through [current site](https://www.putassoc.com/) and take note of quick wins on [[July 8th, 2020]] #Inbox

Primary/immediate area of focus: incoming recruiting class ([[[[career]]s]])

Questions for Klam

What is the recruitment process? How do you normally get your recruits?

What's the decision process like?

What are the priority focuses

Attracting new recruits

Retaining and engaging current recruits

From client

Elegant + concise

Core values

Story

Job descriptions

Events/Programs

Virtual office tours

[[webinar]]s series

**Braindump**

"We're hiring" badge on [[[[career]]s]] links to make them more prominent

What are the [[jtbd]]?

Is this an interesting place?

Is it right for me?

What's the application process like? How do I do it?

Ok I'm ready to submit

On **homepage**

Updating hero slide on homepage

Focus on values/story

Re-write the "join our team" section on homepage

Value first: Hone your expertise in life sciences. Create long-lasting relationships.

Increase text contrast

**General content**

Meet the team

What's the process like?

Connect on social

How we're responding to COVID

[[[[career]]s]] pages

Why Putnam is a dead-end

Only spotlighting one person (and same person on all subpages)

Professional development is another version of "Why Putnam"

**Recommendations for [[[[career]]s]] page**

Combine Why Putnam + Professional Development content

Include info about different offices and what makes them unique

Highlight core values + story

Higher quality/quantity "meet the team" module

Make "recruiting events" a module (eg - pull in a group of ~3-5 most recent, plus link out to list page)

Although these are just information about different on-campus events

Might be better as a calendar where you can filter by school?

Choose your school to see upcoming recruitment events

Hero CTA to see all open positions

Any awards/facts to highlight?

Make open positions tagged and filterable

Solid references

https://www.hubspot.com/[[[[career]]s]]

Find references and examples

https://www.brainsell.net/

https://retail.usa.sika.com/en

https://www.privafy.com/

https://www.woodfordreserve.com/

https://www.sonomacutrer.com/

https://www.massmen.org/

https://www.hungertohealthcollaboratory.org/

https://www.serestherapeutics.com/about-us/

https://www.readcoor.com/

{{[[DONE]]}}  Write up a proposal for [[Museum of Science]] (see Slack chat with [[chris baker]])

{{[[DONE]]}} #ADK Marketing Plan #//

{{[[DONE]]}} Work on IA/Flow/Order of homepage (from the Invision page) for #[[ADK Website Rebuild]] #/

[[Dan Tatar]] wants a benchmark of where we are and think about an adwords campaign

:hiccup [:hr]

[[Meetings]]: Marquis Design sales

Attendees:: [[Dan Tatar]] [[Julie Vail]]

Time:: 1:00 - 

Notes::

Has a project at hand

Been in business 17 years

Used 2-3 person company, but they're small with low bandwidth

Start

Put on part time work after 9/11

Began freelancing

Became more busy on her own

Made the switch a year into freelancing

Needs more partnerships

Marquis = branding and design

Typically doesn't do website or apps unless they've developed the brand

Starts with brand

Then marketing materials

Capabilities

Design, IA, copywriting

What's your sweet spot?

More generalists than specialists

Healthcare, tech, nonprofit, consumer products, ecomm

Small-middle market is mostly

Also works with global (60k employees in America alone)

And a startup vodka in Houston, TX

Team

Julie = creative direction

2 designers on staff

augments with freelancer

2 on staff writers

augments

Marketing strategist on a contract basis

Wants to get out of maintenance aspect after launch

What's our target budget/typical range?

Came via networking at [[The Boston Club]]

New office is in Eastie, where she lives

For new project

Very beginning stages of quoting

Can't get a budget out of the client

Their clients are hospitals, clinics, healthcare end-users

Membership org with small admin team that runs it

Based on membership fees and sponsorships

They need brochure on the front hooked up to "Member Clicks"

Price is for the main brochure site with a link to a "Member Clicks" site

Current site is built entirely in MemberClicks, but they want to move to WP

SMI supply chain

Charged $50k for brand

Looking for $20-30k for her redesign

Trying to de-risk

[[Meetings]]: [[Putnam Associates]] internal review

Attendees:: [[ben kaplan]] [[Dan Tatar]]

Time:: 

Notes::

Going to present: redesigned system + that applied to a [[[[career]]s]] focused landings page

[[Meetings]]: [[ADK Website Rebuild]]

Attendees:: [[maggie o'connor]] [[jenna bantjes]] [[jayne hetherington]] [[shae allison]]

Time:: 3:00pm - 

Notes::

Logos - is there something like more of a cloud/amorphous shape we can do?

[[Meetings]]: [[MIT PEL]] analytics

Attendees:: [[darci nevitt]]

Time:: 3:30 - 4:00pm

Notes::

Handled with Shively

:hiccup [:hr]


[[Personal Task Management]]

{{[[DONE]]}} Set up AC

{{[[DONE]]}} Unpack

{{[[DONE]]}} Laundry?

{{[[DONE]]}} Groceries

{{[[DONE]]}} Food

