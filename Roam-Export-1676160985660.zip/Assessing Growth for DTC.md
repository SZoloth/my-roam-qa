[[Investing Notes - Growth / Marketing]]

# [[qualitative]] Questions

Who are your competitors

Any major fluctuations? Why?

For LGTC: What happened during September - October 2019 that caused plummet in organic traffic?

Guess = Google Core Algorithm updates ([note](https://www.gsqi.com/marketing-blog/september-2019-google-core-algorithm-update/))

What do you own that's proprietary?

How are you using that? 

For LGTC: aggregated, anonymized, proprietary data

Why is your product/service significantly better than alternatives?

What is your revenue [[model]] or growth equation?

What is your [[funnel]]? 

Talk to us about experimentation

Who runs it, how frequently are they run, what are your biggest learnings?

What are your recurring revenue opportunities?

Or repeat purchase behavior?

What is your marketing org chart?

How are you incentivizing / building in referrals and WoM?

What are your primary acquisition channels?

Paid, organic, nurture?

Look at orders broken down by channels over time

Looking for: sustainable, low-risk dominant channels 

# Metrics

Important to look at these sliced by different segments or **cohorts**:

Demographics (geography, age, etc.)

Acquisition source

Order or purchase type

Monthly

**Conversion rates** of [[funnel]] steps by cohorts

Eg for paid marketing: Budget used to buy ad -> new users click on ad -> % click add to cart -> %create account -> %add shipping info -> %place order -> budget used to buy ad (repeats)

Additional cohorts include: device type

**Engagement** example: emails

volume, triggers (company initiated vs. UGC), CTR decay over time 

Important **acquisition** metrics to know:

**CAC** = cost per ad / number of people who completed purchase)

**AOV** = total dollars spent by a __cohort__ of users, divided by the number of __orders__ (not customers)

**Contribution margin** = (AOV - Total cost of sales - average discount)/AOV

Important **retention** metrics to know:

**monthly order retention** = number of orders per month for a cohort

**payback period** = time it takes for a cohort to payback in **contribution dollars** the amount it cost to acquire that cohort. To calculate you need:

Orders per month for a cohort

Cost to acquire that cohort

Revenue per month for a cohort

Contribution dollars for a cohort

**LTV** = cumulative contribution dollars over the course of an entire relationship with a customer

**Net revenue** & **net revenue retention**

Goal: NRR > 100%

**Net profit per member per cohort** = difference in LTV per customer per month

# Access to accounts

## Analytics

Eg: Google Analytics, Hotjar

## Payments

Eg: Stripe

## Database

Eg: BigQuery

## Acquisition

Eg: Facebook, Google Ads, Google Search Console, [[ahrefs]], Moz, Criteo, etc.

## Engagement

Eg: Intercom, HubSpot, MailChimp

