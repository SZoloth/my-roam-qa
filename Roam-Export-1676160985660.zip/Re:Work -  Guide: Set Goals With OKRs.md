Author:: [[rework.withgoogle.com]]

URL:: https://rework.withgoogle.com/guides/set-[[Goals]]-with-okrs/steps/set-objectives-and-develop-key-results/

Recommended By::

Tags:: #Articles #Inbox #Readwise #OKR #[[management]] #self-development #team-development #[[High Output Management]]

Tips for setting **objectives**: #OKR

**Pick just three to five objectives** - more can lead to over-extended teams and a diffusion of effort.

**Avoid expressions that don’t push for new achievements**, e.g., “keep hiring,” “maintain market position,” “continue doing X.”

Use expressions that **convey [[endpoint]]s and states**, e.g., “climb the mountain,” “eat 5 pies,” “ship feature Y.”

Use tangible, objective, and unambiguous terms. **It should be obvious to an observer whether or not an objective has been achieved**. Research shows more specific [[Goals]] can result in higher performance and goal attainment. 

Tips for developing **key results**: #OKR

Determine around **three key results per objective**.

**Key results express measurable milestones which, if achieved, will directly advance the objective**.

**Key results should describe [[outcome]]s, not activities. If the KRs include words like “consult,” “help,” “analyze,” “participate,” they’re describing activities.** Instead, describe the impact of these activities, e.g., “publish customer service satisfaction levels by March 7th” rather than “assess customer service satisfaction.”

**Measurable milestones should include evidence of completion** and this evidence should be available, credible, and easily discoverable. 

Author:: [[rework.withgoogle.com]]

URL:: https://rework.withgoogle.com/guides/set-[[Goals]]-with-okrs/steps/develop-team-OKRs/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

One thing OKRs are not is a checklist. They are not intended to be a master task list of all the things the teams will work on in a quarter. If a team treats this as a shared to-do list it may result in getting overly prescriptive about what the team wants done, rather than what the team wants to achieve. #[[OKR]]

