Author:: [[theguardian.com]]

URL:: http://www.theguardian.com/film/2020/jul/13/spaceship-earth-arizona-biosphere-2-lockdown

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

In 1975, they even decided to build a ship. Their chief designer was a 19-year-old student with no experience of boatbuilding, but it proved perfectly seaworthy. They sailed around the world for several years, researching the Earth’s ecosystems. 

A month later, though, out of the blue, Ed Bass decided on a mass purge. The purpose was to make the project more businesslike, it seems. Allen and his team were swiftly ejected and a new CEO was literally helicoptered in: Steve Bannon. Yes, that Steve Bannon. Investment banker, future right-wing operator and Donald Trump strategist. 

