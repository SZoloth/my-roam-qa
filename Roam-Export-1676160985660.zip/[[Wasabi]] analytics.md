[[Wasabi meeting]]s about [[[[Wasabi]] analytics]] #analytics

[[Wasabi analytics: 4/17/20 - 4/30/20]]

**Metadata**

Hours:: 9am - 11:03 am (2 hours) [[ADK Hours]]

Date range:: 4/17/20 - 4/30/20

**Top level**: down

Users: -1.38%

Sessions: -1.09%

Number of sessions / user: +0.3%

Pageviews: -3.33%

Pages / session: -2.27%

Avg session duration: -4.6%

Bounce rate: +0.43%

**Questions**

Negative top line performance b/c higher percentage of traffic is paid?

Nope - paid acquisition decreased while organic and direct increased (their shares of total traffic)

**Notes**

**Conversions**

Partner submits increased (+66.7%)

PDF downloads increased (+39.6%)

Leads (sales + trials) decreased (-8.7%)

Sales (-17%)

Trials (-7.3%)

/Managed-cloud-services-providers saw 13 free trials, a 112.5% increase

**Channels**

Organic social, which drove 1,754 users, increased 439.7% during this review period

**Organic**

Impressions, Clicks, CTR dropped

BUT - sessions, conversions, and conversion rate increased

**SEO**

The "s3 compatible" page was removed, but is back. Have recommended we improve page speed.

International drove more than 50% of leads (907 vs. 609), and was driven primarily by organic search (41% of all traffic vs. 20.8% of all traffic for US). 

would be curious about paid breakdown of international targeting, since not all happens on the website.

keywords

petabyte cloud storage, #6 for pricing page (new, target)

lost "amazon cloud storage pricing" -> need comparison pages

gained "wasabi vs backblaze" for [the SMB PDF](https://assets.wasabi.com/wp-content/uploads/2018/04/Tech-Brief-Consumers-and-Small-Businesses-18.pdf?x55444)

1pb storage, #5 for https://wasabi.com/blog/on-premises-vs-cloud-storage/



**RCS**

Since launch of RCS, the "Try it free" conversion rate has gone down by 1.63%

However, the launch of RCS also came with increased media spend compared to relatively little before, which compensated for lower conversion rates with volume (+14.53% increase in users). 

This led to an increase in the absolute number of free trial submissions (+15.34%)

However, if the conversion rate had been maintained at 3.75%

174611 sessions

6,444 conversions

6,548 conversions

104 more conversions or an increase of 17% (instead of 15%)

**Demographics**

25-44 y/o's account for 50% of free trial conversions

Top states for free trial conversions

California (14%)

Virginia (8%)

Texas (7%)

New York (6%)

Florida (5.6%)

[[Wasabi analytics: 5/1/20 - 5/14/20]]

**Metadata**

Hours:: 9am -  11am (2 hours) [[ADK Hours]]

Date range:: 5/1/20 - 5/14/20

**Top level:**

Users: +6.3%

Sessions: +6.3%

Number of sessions / user: -0.4%

Pageviews: +5.32%

Pages / session: -0.86%

Avg session duration: -4.6%

Bounce rate: +0.26%

Commentary:

A surge in social traffic drove growth this period, while the usual suspects (paid acquisition, organic search, direct, referral all dipped slightly)

**Notes**:

Conversions

Partner form: -33% (10)

PDF downloads: -16.5% (197)

Leads (sales + trials): +10.4%

Sales: +21.2%

Trials: +8.6%

Commentary

RCS has far and away the most sales contacts (important to remember that's the only available conversion path) at 105 vs. 43 (homepage)

Free trials

Referral traffic had the highest conversion rate (3.63%) followed by Organic (3.12%) then Direct (2.17%)

Most Referral free trials are coming from https://www.offers.com/wasabi/

Organic had the most free trials at 342 followed by Direct (166) then Paid Acquisition (125)

Contact sales

Paid social drove the most sales contacts (85) followed by Paid Acquisition (41) then Organic (30)

Organic

Organic sessions dropped by 0.87%

There was a 14% drop in searches for branded terms

**Summary / Recommendations**

**Summary**

Macro performance of organic is still strong: +5% MoM

Conversions primarily occur on high intent pages or pages people return to (vs. have their first visit on)

Home (high intent)

Pricing (high intent)

Help and Help/Docs (repeat)

Pricing/FAQs (repeat)

About (repeat)

Help/Downloads (repeat)

What is Wasabi (repeat)

Resources (repeat)

How Cloud Storage (repeat)

**Conclusion** from above: this conversion is high consideration

Where the above does not hold true is on the Backup and Recovery page and the S3 Compatible Storage page

People don't talk to sales unless forced to (RCS)

People review documentation before converting

[PDF download page (on prem vs cloud "break free from the herd")](https://wasabi.com/on-prem-storage-vs-cloud-storage/) performed surprisingly well for free trials

[Get 30 days wasabi free](https://wasabi.com/get-30-days-wasabi-free/) CRUSHED[ hot cloud storage offer](https://wasabi.com/hot-cloud-storage-offer/). Some features:

Animated hero

More data in hero

Action-oriented and solution-focused copy (vs a feature, like price)

Single CTA and action throughout page

Same footer CTA

Use cases that are being sought out: Backup and Recovery, Content Delivery

Press Releases had relatively high conversion rates

Unlimited free egress pricing plan

1st European data center

Launch

Partners pages have relatively high conversion rates (cloudberry, packet, cloudflare, veeam)

**Recommendations**

Give people a focused experience while presenting important information clearly

People care about:

Pricing

Documentation

Solutions

Backup and recovery

Content delivery

S3 compatibility

Mac/Windows compatibility

What Wasabi is

Partners

Connectivity options

Animations

Table of contents/interior nav bar

People don't care about:

Sales form

Create solutions-oriented landing pages (compared to SEO-focused pillar pages, which also need attention)

Highlight popular use cases like backup and recovery

Improve the UX of the documentation / knowledgebase

Improve the partner pages (underway)

**Notes from meeting**



[[Wasabi analytics: 5/15/20 - 5/28/20]]

Metadata::

Pomos::

{{POMO}}

{{POMO}}

{{POMO}}

Top level::

Users: -1.77%

Sessions: -4.52%

Number of sessions / user: -2.80%

Pageviews: -3.18%

Pages / session: -2.27%

Avg session duration: +0.15%

Bounce rate: -0.75%

Analytics sections::

Conversions::

Partner form submits increased by +30% to 13

PDF downloads decreased by -57.4% to 84

Total leads decreased by -5.9% to 868

Free trials decreased by -7.4% to 679

Contact sales remained at 189

Multi-channel assists

Organic only: 177

Organic + Direct: 123

Direct only: 217

Paid + direct: 37

Paid + organic: 6

Paid only: 73

Assist breakdown for trials:

Direct: Final

Organic: Roughly equal between final and assist

Paid: Roughly equal between final and assist

Email: Assist

Referral: Final

Paths breakdown for trials with a 90-day attribution window:

Organic: 25%

Direct: 15.56%

Organic search -> Direct: 9.72%

Paid: 9.08%

Direct -> Direct: 4.7%

Referral: 3.73%

Organic -> Direct -> Direct: 2.27%

Organic -> Direct -> Direct -> Direct: 1.94%

Paid acquisition -> Direct: 1.78%

Directx4: 1.13%

Touch position (attribution [[model]]s):

Last touch:

Direct: 51.38%

Organic: 27.71%

Paid: 12.48%

Referral: 6.65%

First touch:

Organic: 46.03%

Direct: 28.53%

Paid: 17.18%

Referral: 6.16%

Time lag:

0 days: 73%

1 day: 3.08%

2 days: 1.94%

3 days: 1.62%

4 days: 1.78%

12-30: 6.32%

**Organic**

Traffic

Users dropped by -6.7% to 6,168

Sessions dropped by -9.71% to 8,938

Highest sessions 

Conversions still 2-3x other channels

Some fluctuation in "wasabi" and other branded term ranking, impressions, clicks, etc. likely due to holiday

Non-branded clicks actually increased

Solutions: IoT and CDN

Cloud storage pricing comparison + cloud cost comparison calculator

Split between wasabi pricing and cloud storage pricing pages

About 2x as strong in America as the UK

UK site is just an iframe - hurts SEO

RCS

Analytics summary::

Can we ensure any existing links to /pricing or sub pages (like /pricing/pricing-faqs) are updated to /cloud-storage-pricing? Primary sources: email + ads

`https://wasabi.com/mac-and-windows` seems to have been taken down without a redirect

Videos

Top starts:

Quick start tutorial: 148

RCS: 44

Wasabi + Veeam: 36

Top finishes:

Quick start: 43

RCS: 22

Wasabi + Veeam: 15

[[Wasabi analytics: 5/29/20 - 6/11/20]]

[[Wasabi analytics: 6/12/20 - 6/25/20]]

[[Wasabi analytics: 7/10/20 - 7/23/20]]

[[Wasabi analytics: 8/7/20 - 8/20/20]]

[[Wasabi analytics: 9/4/20 - 9/17/20]]

[[Wasabi analytics: 9/18/20 - 10/1/20]]

[[Wasabi analytics: 10/2/20 - 10/15/20]]

[[Wasabi analytics: 10/16/20 - 10/29/20]]

Wasabi organic opportunities

Keywords

cloud storage pricing

s3 calculator

s3 storage costs

cloud storage pricing comparison

object storage cloud

immutable

cloud migration tools

cloud storage comparison

google cloud storage pricing

data storage support

cloud storage for video production

offsite data storage pricing

healthcare data storage

msp backup software

pay as you go cloud

hybrid storage solutions

cloud storage for education

multicloud storage

cloud object storage providers

video content delivery

buy cloud storage

petabyte

immutable storage

storage for the public sector

cloud object storage

access key

on premise storage

durability vs availability

veeam partner

government cloud storage

managed backup pricing

cloud migration tools

multi cloud storage

managed cloud service providers

cheapest cloud storage

hybrid cloud storage vendors

video content delivery

cold storage cloud

how much does a petabyte cost?

what is a petabyte?

what is an exabyte?

what are api tools?

what is access key?

how much does cloud storage cost?

what is cloud lock?

what is direct connect?

what is backup as a service?

how much does s3 really cost?

How much does a petabyte cost

How much does cloud storage cost

What is direct connect

How many gb in a tb

What is cloudlock

What is backup as a service

How to migrate to cloud

What is data egress

What is ingress and egress in AWS

Internationalization (UK) audit

