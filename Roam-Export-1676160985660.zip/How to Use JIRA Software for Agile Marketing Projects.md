Author:: [[inbound.human.marketing]]

URL:: https://inbound.human.marketing/how-to-use-jira-software-for-agile-marketing-projects

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[October 4th, 2020]]

You can't have [[agile]] project management without scrum boards, sprints and stories. Understanding the power of [[agile]], we chose to use JIRA Scrum Software Development Projects for all of our marketing and software development projects, alike. 

How We Set Up JIRA Marketing Projects:

Sprints span 2 weeks
Epics are defined as months of the year
Versions are defined as quarters of the year 

In the JIRA Backlog, we create Sprints for each week of the month, plan them in advance and budget time accordingly. We define Epics as months of the year to be able to plan the number of hours we're spending on each project. Assigning every task to an Epic helps us keep track of which tasks have been moving from Sprint to Sprint; these tasks are either projects that end up taking longer than a week or projects that have hit a roadblock that needs to be cleared up. 

Author:: [[inbound.human.marketing]]

URL:: https://inbound.human.marketing/how-to-use-jira-software-for-agile-marketing-projects

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[November 2nd, 2020]]

You can't have [[agile]] project management without scrum boards, sprints and stories. Understanding the power of [[agile]], we chose to use JIRA Scrum Software Development Projects for all of our marketing and software development projects, alike. 

How We Set Up JIRA Marketing Projects:

Sprints span 2 weeks
Epics are defined as months of the year
Versions are defined as quarters of the year 

In the JIRA Backlog, we create Sprints for each week of the month, plan them in advance and budget time accordingly. We define Epics as months of the year to be able to plan the number of hours we're spending on each project. Assigning every task to an Epic helps us keep track of which tasks have been moving from Sprint to Sprint; these tasks are either projects that end up taking longer than a week or projects that have hit a roadblock that needs to be cleared up. 

