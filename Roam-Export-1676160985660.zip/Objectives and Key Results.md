Author:: [[about.gitlab.com]]

URL:: https://about.gitlab.com/company/okrs/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 22nd, 2020]]

They lay out our plan to execute our strategy and help make sure our [[Goals]] and how to achieve that are clearly defined and aligned throughout the organization. 

The Objectives help us understand what we're aiming to do,
and the Key Results help paint the picture of how we'll measure success of the objective.
You can use the phrase “We will achieve a certain OBJECTIVE as measured by the following KEY RESULTS…” to know if your OKR makes sense.
 

OKRs should be ambitious but achievable. If you achieve less than 70% of your KR, it may have not been achievable. If you are regularly achieving 100% of your KRs, your [[Goals]] may not be ambitious enough.
 

