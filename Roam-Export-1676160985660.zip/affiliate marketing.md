Tags: #[[affiliate marketing]], #referral, #[[link building]]

Start an #[[affiliate marketing]] program

Identify who you want to partner with / get links from

Create a "top list" blog post that recognizes them for high quality content

Create series of blog posts: "Top # [topic] Blogs"

Reach out to each featured blog owner

Ask for their consideration about sharing the list

 Recommendations on other blogs to add

Follow up with a pitch to the affiliate program

Track with UTM codes and datastudios

Provide affiliates with tools they need to be successful

Pre-written blog posts

Best practices around creative (what works for your company when you write about your product?)

Examples of high converting headlines

Important data points around your company

Press pieces that mention your company

Examples of blog posts from successful affiliates

Set up a kick-off call where you can brainstorm ideas together

Increase the rates for people that have been dormant



