Packing

Morning

{{[[TODO]]}} Toothbrush

{{[[TODO]]}} Food



Ally

{{[[DONE]]}} Sit upon

{{[[DONE]]}} Toilet paper

{{[[DONE]]}} Garbage bags

{{[[DONE]]}} Paper towels

{{[[DONE]]}} Bug spray

{{[[DONE]]}} Sunscreen

Misc

{{[[DONE]]}} Drizly

{{[[DONE]]}} Ice

{{[[DONE]]}} Booze

{{[[TODO]]}} Coffee drinks

{{[[DONE]]}} Lighter

{{[[TODO]]}} Pasta dinner

Packing

{{[[DONE]]}} Pick up car

Me

{{[[DONE]]}} Clothes

Bathing suit

{{[[DONE]]}} Books

{{[[DONE]]}} Face wash

{{[[DONE]]}} Shoes

Water

Hike

{{[[DONE]]}} Coal

{{[[DONE]]}} Chimney

{{[[DONE]]}} Games - Monopoly Deal + 

{{[[DONE]]}} Beach chair?

{{[[DONE]]}} Wood

{{[[DONE]]}} Paper plates + silverware

{{[[DONE]]}} Dr. Bronners

{{[[DONE]]}} Picnic throw

{{[[DONE]]}} Lighterz

{{[[DONE]]}} More coffee

{{[[DONE]]}} Pan

To do

Presidential Trail Rail

Warming pool

Swimming area

Perkins Path

Berry Farm Road

