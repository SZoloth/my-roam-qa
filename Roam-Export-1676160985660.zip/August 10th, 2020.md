[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Review [[alex fedorov]] MVP design blog draft #///

**Designing an MVP** -- [[alex fedorov]]

[Link to draft](https://docs.google.com/document/d/1I7e56X7YB0Fs7id0QX8biao1fUpx3SH6PK6FNpzpZg4/edit?ts=5f2d8e71)

{{{[[DONE]]}}}} Review [[nick watkins]] B2B Marketing [[funnel]] draft #///

[Link to draft](https://docs.google.com/document/d/1bTHZJfDOoCR7zHQvS90LnpjCXcaqMqDqDmTJ1kFQHSU/edit)

{{{[[DONE]]}}}} Review [[darci nevitt]] link building for drupal materials #//

{{{[[DONE]]}}}} Update COVID blog and email #/

Check slack from [[Dan Tatar]]

Finalize [this draft](https://docs.google.com/document/d/13FtPEtzPE6lXhoKapTk8FXnPwqTM7ic4fCiv0fFR6Tc/edit#)

{{{[[DONE]]}}}} Review [[Wasabi]] homepage design from [[Michelle Smith]]

{{{[[DONE]]}}}} Update Google Ads with new campaign structure: #/

[[Meetings]]: [[Museum of Science]] EiE channel strat

Attendees:: [[darci nevitt]]

Time:: 2:30pm

Notes::

Questions:

What are competitors doing?

What have they done in the past?

What did they ask for

How should we target?

What channels support the type of targeting we need?

Notes

email

cold outreach

up sell

leads

