Author:: [[northcutt.com]]

URL:: https://northcutt.com/saas-marketing/competitor-comparison-pages/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

When you build out competitor pages the goal is to rank for the branded queries (these queries have less competition) of your competitors, such as "competitor + alternative" or "brand vs brand." 

As of today, this URL is ranking on 228 keywords and ranks on variations like "SEMrush alternative free," "spyfu vs semrush," "tools like SEMrush" etc. 

Podia is a great example of building a hub of competitor comparison pages. 

You have to research the pain points of these users. Why are they [[churn]]ing from your competitors? Missing features? Limits? Shoddy business practices? 

During the research phase for the SEMrush comparison page, we identified a few major pain points as we combed through thousands of reviews: 

