[[🏔ADK [[Task Management]]]]

[[Meetings]]: [[ADK Marketing Strategy]]

Attendees:: [[chris baker]]

Time:: 9:30am

Next steps::

{{{[[DONE]]}}}} Write 1-3 bylines that develop the [[[[problem]] statement]] of the narratives #/

Narratives

david v. goliath

caliber of mckinsey/[[Deloitte]] without bloat

buy one / give one

social impact

offering opportunities to neurodiverse individuals

Accessible engineering or product without pain

ADK got started in dev by non-devs because devs had a bad rap

stereotypes of engineering personalities

painful communication

product without pain

instead of building out a product team

instead of hiring a pure dev shop (no strategy, GTM, growth, design)

instead of hiring a marketing org with no real dev shops

do engineers and engineering teams have enough of a bad rap?

engineers + process are built differently

**need:** input from tech team

gap between [[language]] and cultures of engineering

Took a lot of 

Focus on understanding: humility (vs. prescriptive)

Notes::

During the meeting

Focus on brand

For ADK

Brand principles

unique

new narrative / positioning

old game vs. new game

us vs. them

Narratives

david v. goliath

caliber of mckinsey/[[Deloitte]] without bloat

buy one / give one

social impact

offering opportunities to neurodiverse individuals

Accessible engineering or product without pain

ADK got started in dev by non-devs because devs had a bad rap

stereotypes of engineering personalities

painful communication

product without pain

instead of building out a product team

instead of hiring a pure dev shop (no strategy, GTM, growth, design)

instead of hiring a marketing org with no real dev shops

do engineers and engineering teams have enough of a bad rap?

engineers + process are built differently

**need:** input from tech team

gap between [[language]] and cultures of engineering

Focus on understanding: humility (vs. prescriptive)

**__Next steps:__**

Write 1-3 bylines that develop the [[[[problem]] statement]] 

Naming

For team/individuals

Dan Tatar

High cold outreach hit rate, b/c

CEO

Method of outreach:

For CEO of Liberty Mutual: finding common ground with neurodiversity, which as a concept is

neurodiversity

opinion on Livongo + Teladoc

Opportunities

{{{[[DONE]]}}}} ADK Brand campaign #/

From a conversation with #[[chris baker]]

Worth ideating on what we could do that could be somewhat viral or could really drive visibility with decision makers, even if not directly related to our areas of focus.

I think we could get away with it if we focused on the Comcasts/Verizons of the world. [BadUX.blog](http://badux.blog/)

"A not-so-carefully curated collection of broken products from companies bigger than yours. We hope it makes you feel better about your own broken products, like it does for us. Curated by the product engineers and designers at @adkgroup."

Size of QA teams?

Steps:

Refine idea

Concept

Name

Purchase domain + social handles

Collect content

Loop in designer

{{{[[DONE]]}}}} What to do with new [[ADK Marketing Assets]] from [[Dan Tatar]] #//

Slack support group

MSCHF

Ever have trouble doing something? It's not your fault

[[ADK content]]

Team-Based Strategy for #ADK [[ADK content]]

Nick

Alex

[UX Audit eBook](https://docs.google.com/document/d/1j1MvqMLn9djLLT4ZHPxTB2QO0oaoM8U666zSIemngys/edit) [[ADK content]]

Using [[Inspiration for ADK]]

{{{[[DONE]]}}}} Conceptualize a COVID-themed content campaign #//

{{{[[DONE]]}}}} Update COVID blog and email #/

[[Article: Creating a Glossary for SEO]]

[[[[ADK]] case studies]]

{{{[[DONE]]}}}} find replacement for [[Sanjay Salomon]] #//

{{{[[DONE]]}}}} Marketing for ADK - Filling lead [[funnel]] #//

Who is looking for Drupal sites?

Look at Drupal built with data

Schools

Bose, BJs

Higher education

What services are they looking for?

Drupal redesign, update, upgrade

Marketing?

Web apps?

Campaign ideas #[[Google Ads Optimization]]

Idea 1 - awareness: case studies #//

Audience: retarget + custom audience + industry-based

roles? CPO, CEO, director of marketing, CMO

Creative:

Clients & projects (case studies)

All: retargeting + custom

HNRG

Sales

Process automation

Harvard - JDA

Data throughput

Harvard - Asia Center

???

Cambridge Savings Bank

Accessibility

Vyaire

???

SIKA

???

Boston School Finder

App functionality

Major Decision

App functionality

Beyond Insurance

App functionality

EBH and Wynn [[[[career]]s]]

Harvard - RIJS

Signs of Suicide - SMH

FireKing

Mountain One

ANET ??

Harvard-Yenching Institute

Harvard - HJAS

Spaulding

CEC

Ivy Bank

Year Up

STEM-Act

BWH Surgery Finance

MIT - PEL

MIT - UPOP

Constitutional Revision

[[assumption]] College

Wise Construction

Breakaway

PDFs

[HIPPA](https://www.adkgroup.com/articles/understanding-digital-hipaa-compliance-modern-tech/)

retargeting + custom?

[Drupal](https://www.adkgroup.com/articles/power-drupal-unlocking-hidden-potential-your-cms/)

retargeting

[Smart manufacturing](https://www.adkgroup.com/articles/smart-manufacturing-how-leverage-industrial-iot/)

retargeting + custom

[B2B Sales [[funnel]]](https://www.adkgroup.com/articles/modern-day-b2b-sales-[[funnel]]-influencing-b2b-buyers-through-b2c-strategies/)

retargeting + custom

[[product]] [[road[[map]]]] (https://www.dropbox.com/s/sgz01ip2yp6dqvj/Deciding%20What's%20Next.pdf?dl=0)

retargeting for FTS / design ads

[Enterprise design sprint facilitation](https://www.freshtilledsoil.com/downloads/the-enterprise-design-sprints-facilitation-guide.pdf)

{{{[[DONE]]}}}} Idea 2

Google Ads

MA/KY

Day and time of day part

Focus on agency, service, group, firm

Ad groups

Web design

Web developer

Hosting & maintenance

App design

App developer

Product design

[[[[product]] [[strategy]]]]

Software design

Software development

Digital agency

Awareness campaigns

~~Industry-based ad groups in Google Ads?~~

Too niche

Industry-based LinkedIn ads

How the top {{or: colleges|enterprise|financial institutions}} use ~~Drupal~~ their website to {{or: grow|differentiate|improve customer experience}}

Retargeting visits to

any URL with drupal in it + any case study about Drupal

Lead gen

How the top {{or: colleges|enterprise|financial institutions}} use ~~Drupal~~ their website to {{or: grow|differentiate|improve customer experience}}

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FnIhBD54IRp.png?alt=media&token=3e988b67-1179-4eb9-8cd4-d0abf278d236)

Need to sketch out: 

ads

landing pages

[[Google Ads Optimization]]

{{[[DONE]]}} #ADK Marketing Plan #//

Develop the process:

{{[[DONE]]}} Build the marketing team and process #///

{{{[[DONE]]}}}} Should I set up JIRA for [[ADK Marketing Project Management]] #[[🏔ADK [[Task Management]]]] #///

{{{[[DONE]]}}}} [[sam zoloth]] to **Create campaign kick off template/plan** #Inbox #///

{{{[[DONE]]}}}} Google Ads report for #[[Dan Tatar]] #[[Google Ads Report]]

Previously, we had gotten maybe 1 or 2 small leads (RandWhitney site replatform and tintedhealth website). Though whether these have/will result in anything real is up in the air (I have doubts).  

So on Monday [[August 10th, 2020]]:

I restructured the campaign to:

target larger, lower in the [[funnel]], more serious searches

eg: removing "website developer" to focus on "website development agency"

the thinking is that searches for agencies, firms, and companies are more likely to be B2B vs. lone founder/passion project

target just MA & KY and surrounding states

run only between 6am and 11pm

With the changes we can expect a lower volume, but higher quality

Since the change was made the metrics are:

Clicks: 27

Impressions: 674

Conversions: 0

Spend: $233

Avg click through rate: 4%

Avg cost per click: $8.62

[[Meetings]]: [[Wasabi]] meeting

Attendees:: [[brooke kwasny]] [[mary mccarthy]] [[julie barry]] [[chelsea rodgers]]

Time::

Notes::

Brooke background

HubSpot and inbound

nurture

From [[mary mccarthy]]

7/27 week interactions with calculator dropped

From Sam

About ADK

What we're doing now

Analytics

Dashboard

A/B testing & CRO

home page

pricing page

UX & Site enhancements

Organic

SEO landing pages

historical success with things like "s3 compatible storage" and "cloud storage pricing"

very recent unlocks with terms like "exabyte" and "petabyte"

comparison / competitor pages

glossary

Content optimizations

Technical

{{{[[DONE]]}}}} Write brand narrative for {{or: purpose/social good | david vs. goliath | friendly engineers}} by [[August 18th, 2020]] #/

We're built on purpose

Like tom's buy-one-give-one?

We build apps on __purpose__

How can technology better serve {{or: the education system|our mental health}}

Social technology that fosters connections, not divides.

Campaigns end, purpose doesn't.

What's your purpose? 

We believe in mission-driven organizations. And want to share yours with the world. 

Resources for nonprofits

Our partners are champions of social good

BSF

SMH

something like https://slashpurpose.org/

An ADK scholarship

Mentorship or support for orgs like Girls who Code

A collection of resources for hiring and empowering neurodiverse individuals in the office 

[[Personal Knowledge Management]]

#flashcard #rhetoric

alliteration

diacope

antithesis

parallelism

epanalepsis

anadiplosis

epistrophe/epiphora

assonance

transferred epithet

anaphora

personification

assonant rhyme

consonant rhyme

synaesthesia

oxymoron

polyptoton

onomatopoeia

syllepsis (pun)

polysyndeton

hyperbole

adynaton

metaphor

simile

antanaclasis (pun)

asyndeton

tricolon

merism

consonance

[[Personal Task Management]]

{{[[DONE]]}} Transfer from instapaper to my mind :) #/

{{{[[DONE]]}}}} Email for Kicker and Brett #/

{{{[[DONE]]}}}} Absentee balot #/

