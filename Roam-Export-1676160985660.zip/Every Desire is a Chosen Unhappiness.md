I think the most common mistake for humanity is believing you’re going to be made happy because of some external circumstance. I know that’s not original. That’s not new. It’s fundamental Buddhist wisdom—I’m not taking credit for it. I think I really just recognize it on a fundamental level, including in myself.

We bought a new car. Now, I’m waiting for the new car to arrive. Of course, every night, I’m on the forums reading about the car. Why? It’s a silly object. It’s a silly car. It’s not going to change my life much or at all. I know the instant the car arrives I won’t care about it anymore. The thing is, I’m addicted to the desiring. I’m addicted to the idea of this external thing bringing me some kind of happiness and joy, and this is completely delusional.

Looking outside yourself for anything is the fundamental delusion. Not to say you shouldn’t do things on the outside. You absolutely should. You’re a living creature. There are things you do. You locally reverse entropy. That’s why you’re here.

You’re meant to do something. You’re not just meant to lie there in the sand and meditate all day long. You should self-actualize. You should do what you are meant to do.

The idea you’re going to change something in the outside world, and that is going to bring you the peace, everlasting joy, and happiness you deserve, is a fundamental delusion we all suffer from, including me. The mistake over and over and over is to say, “Oh, I’ll be happy when I get that thing,” whatever it is. That is the fundamental mistake we all make, 24/7, all day long. [4]

[4] Ravikant, [[Naval Ravikant]] and Shane Parrish. “Naval Ravikant: The Angel Philosopher.” Farnam Street, 2019. https://fs.blog/naval-ravikant/.

__The fundamental delusion: There is something out there that will make me happy and fulfilled forever.__

Desire is a contract you make with yourself to be unhappy until you get what you want. I don’t think most of us realize that’s what it is. I think we go about desiring things all day long and then wonder why we’re unhappy. I like to stay aware of it, because then I can choose my desires very carefully. I try not to have more than one big desire in my life at any given time, and I also recognize it as the axis of my suffering. I realize the area where I’ve chosen to be unhappy. [5]

[5] [[Tim Ferriss]]. __Tools of Titans: The Tactics, Routines, and Habits of Billionaires, Icons, and World-Class Performers__. New York: Houghton Mifflin Harcourt, 2016.

__Desire is a contract you make with yourself to be unhappy until you get what you want.__

One thing I’ve learned recently: it’s way more important to perfect your desires than to try to do something you don’t 100 percent desire. [1]

[1] [[Naval Ravikant]]. “[[Naval Ravikant]] Was Live.” __Peri[[scope]]__, January 20, 2018. https://www.pscp.tv/w/1eaKbqrWloRxX.

When you’re young and healthy, you can do more. By doing more, you’re actually taking on more and more desires. You don’t realize this is slowly destroying your happiness. I find younger people are less happy but more healthy. Older people are more happy but less healthy.

When you’re young, you have time. You have health, but you have no money. When you’re middle-aged, you have money and you have health, but you have no time. When you’re old, you have money and you have time, but you have no health. So the trifecta is trying to get all three at once.

By the time people realize they have enough money, they’ve lost their time and their health. [8]

[8] __Killing Buddha__ Interviews. “Chief Executive Philosopher: [[Naval Ravikant]] On Suffering and Acceptance.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/7/naval-ravikant-ceo-of-angellist; “Chief Executive Philosopher: Naval Ravikant On the Skill of Happiness.” __Killing Buddha,__ 2016. http://www.killingbuddha.co/blog/2016/2/10/chief-executive-philosopher-naval-onhappiness-as-peace-and-choosing-your-desires-carefully; “Chief Executive Philosopher: Naval Ravikant On Who He Admires.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/19/naval-ravikant-on-who-he-admires; “Chief Executive Philosopher: Naval Ravikant On the Give and Take of the Modern World.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/23/old-bodies-in-a-new-world; “Chief Executive Philosopher: Naval Ravikant On Travelling Lightly.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/9/19/naval-ravikant-on-travelling-lightly; “Naval Ravikant on Wim Hof, His Advice to His Children, and How He Wants to Look Back on His Life.” __Killing Buddha,__ 2016. http://www.killingbuddha.co/blog/2016/12/28/naval-ravikant-on-advice-to-his-children.

