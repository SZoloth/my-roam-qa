Tags:: #[[Sleeping Dog Properties]] #[[[[Sleeping Dog Properties]] Marketing Strategy]]

Topics

teardowns

new homes

mansions

luxury (home contractor)

what makes a house luxurious?

UV lights into ducts / HVAC system purifiers

architects

how to hire the right architect

how to find the right architect

best architects in Boston // best Boston architects

https://www.bostonarchitects.org/best-residential-general-contractors-boston/

https://www.enr.com/New-England/Toplists/2018-Top-Contractors

glossary of terms

second homes

buying a second home

tax deductions

investment properties

home gyms

trends

materials

garage conversions

home studios

man caves

she sheds

basement apartments

**Education division**

Every Summer every university has a volume of money to dump

Decision gets made every February

Harvard, MIT, Boston University

Allen G Scaffold? Lanco?

Union carpenter

Has a ton of work from Harvard

Who do we reach at schools?

**Cold outreach for private universities via email**

Target 2021 or Christmas

Sent to 55 people

18 open - 32%

1 click - 5.5%

**Medical division**

Like commercial space

Medical cabinetry = 60% upcharge on regular cabinetry

attic apartments

greenhouse

licensing

building permits

How to stage a picture [[[[Sleeping Dog Properties]] blog]]

How homes look so good in magazines

condo associations

Difference between condo association and home owners association

Guide to condo associations

How to price work based on design [[[[Sleeping Dog Properties]] blog]]

Seeing something in a magazine to 

"how much to make my house look like that"

How to look at magazines 

contractors

how to find the best contractor

how to hire the best contractor

https://digg.com/video/heres-how-they-created-the-mansion-in-parasite

Localization / near me

local surveys

vote on the best homes in {{city}}

Blog posts #[[[[Sleeping Dog Properties]] blog]]

**Moving/Building in Cambridge**

Cambridge MA building department

Cambridge MA property tax

Cambridge MA building permit

Living in Cambridge

Guide to neighborhoods

Services

**Cambridge MA architects**

**general contractor cambridge ma**

~~home design cambridge ma~~ interior design cambridge

construction cambridge ma

new construction cambridge ma

**general contractors cambridge ma**

**kitchen re[[model]]ing cambridge ma**

