Tags: #SEO, #blogging, #content

From: #ahrefs

Link: https://[[ahrefs]].com/academy/blogging-for-business/lesson-1-1#

Notes

Traffic is one of many vanity #metric

Primary goal is: acquiring new customers

Focus on bringing highly targeted audience

Vanity #metric

Articles published per week

Blog visitors per month

Email subscribers per month

Better metric is: Number of orders or sales per month

Treat blog as customer acquisition channel, not traffic channel

Three main customer acquisition channels

How people **discover products** to buy

Word of mouth

Search

Advertising

SimilarWeb - shows advertising

If content marketing efforts don't add up over time, you're doing it wrong

Passive consistent traffic is the key

Thought: your target audience should be the influencers of your target audience

Write content that appeals to them and is more shareable for them

Two strategies of growing a blog

Viral traffic

Need to create content that is sticky - that resonates with your audience

You need to pitch influencers

You need to publish regularly

SEO traffic

Content needs to be very useful

You **need** backlinks

You **don't** have to publish regularly

Goal:

Create content around specific keywords

Make content rank higher

How to convert visitors into subscribers

Audience is biggest assets - start building it

How to analyze traffic potential for topics + keywords

Determine traffic potential of keyword

Top 3 positions = 30%, 15%, 10% of searches

Steps

Look at keywords

Look at SERP

Look at total search traffic of the top ranking websites for that keyword 

Click on "kw"s to see what all the keywords that site is ranking for are

Filter for top 3 positions

How to find the best keyword to target

search your topics - look at the SERP to see what results get the most traffic

Brainstorm your topics in whatever [[language]] makes sense to you (but probably best to still guess keywords)

Review SERPs for the pages that receive the most traffic

Look at their top keyword

Save the best performing articles in a document

Find the articles with the most traffic and least back links

How to determine your chances to rank in Google

on page factors needed

relevant content that helps searchers

loads fast

optimize for mobile

great ui/ux and visuals

Behavioral factors - how long do people stay? do they browse deeper? 



