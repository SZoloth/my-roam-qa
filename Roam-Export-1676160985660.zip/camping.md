[[Moose Brook State Park]]

