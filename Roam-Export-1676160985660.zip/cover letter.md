[[Parsley Health/Product Marketing Manager]]

Notes

Story of Wasabi's pricing calc --> quiz & migration plan

But before that, I had to introduce the concept of growth marketing and conversion rate optimization. Framework for growth:

Introduce and sell the concept to build understanding of the value and get buy in

Create an intuitive framework that the clients web team could pick up and run with

Repeatedly demonstrate value by making tests and learnings as public and valuable as possible - slowly include more and more of the team. 

Fit in to their workflow (we use Wrike / Atlassian while the client used Asana)

The type of work for Wasabi presented itself again with Form Health

Onboarding [[funnel]] for Form Health & go to market (testing pricing points, value props on facebook creative, etc.)

While gathering inspiration for FH, found PH and was intrigued. At first it was the branding and web experience. 

Recently did an exercise taking stock of where I want to be and where I want to go. I realized the type of work that played into my strengths the best was what I had been doing for Wasabi + Form Health. And only my experiences working with healthcare companies like Wellist, Firefly Health, Vyaire Medical and Form Health gave me a blend of fulfillment and energy. 

So when I saw my friend highlight a post from Nicole Bocskocsky about open positions I looked into it. 

PH

97% of Members see an improvement in their symptoms.

Parsley Health helps most members reduce prescription drug usage by 66% over one year

Personalized and functional care

Draft (OLD)

I've spent the last 5+ years tailoring data-driven growth marketing strategies to help companies acquire, convert and engage their customers. These companies have almost all been startups or scale ups, and most of them have been in healthcare. I'd love to bring this experience and enthusiasm to your marketing team. 

I recently hired a teammate so I know a bit about what it's like to read a lot of these. With that in mind, here are some reasons you might want to hire me.

I approach growth marketing and [[funnel]] optimization systematically, using a flexible framework I developed to support a recently launched startup, Wasabi, as it scaled to a multi-million dollar enterprise in a few short years. In short, I first introduced the concept of growth marketing and conversion rate optimization to the CMO after seeing the digital team get jerked around by the whims of the CEO. 

The CMO was intrigued, but not bought in. So I developed a system that publicly tracked hypotheses, proposals, progress, and results. It included a method for prioritizing tests, project briefs for ensuring tests were focused and well-understood, and regular presentations of results to ensure what we learned got shared with the broader team. 

Eventually, the team was able to increase conversion rate for free trial sign ups by 63%. This type of win helped build [[funnel]] optimization into a __habit__ for our clients team - eventually building a team around it. After analytics I set up revealed a correlation between engagement with a pricing calculator and signing up, we're currently in the process of creating a enhanced version of the calculator that also captures leads.

I recently got the opportunity to apply this same framework to Form Health, a digital health subscription service. Starting from scratch, I worked with the CEO and CTO to architect Segment, [[Amplitude]], HotJar and Google Optimize. With that tech stack, I collected [[qualitative]] and quantitative data to highlight areas of high friction in the onboarding [[funnel]] and come up with resolutions that led to the sign up conversion rate to more than double. I applied the same fundamentals to help the CEO hone in on his positioning - creating Facebook Ads and landing pages to test multiple value propositions to different audience segments. More than seeing metrics improve, getting to read how the company was improving more and more lives provided my motivation. 

After seeing a post from Nicole Bocskocsky about open positions, I took a look into Parsley Health and was impressed by similar reviews your service has gotten from members whose lives had been markedly improved. Parsley Health's mission is energizing and your team is inspiring. I would be thrilled--and proud--to help Parsley Health deliver the future of healthcare as a Product Marketing Manager. 

