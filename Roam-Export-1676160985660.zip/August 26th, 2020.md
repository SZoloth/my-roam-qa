[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Prep for the Interview (content strategy) #/ #[[ADK Hiring]] #[[[[hiring]] a copywriter]]

[[questions to [[interview]] someone]] for [[[[hiring]] a copywriter]] round 1

What interested you about this opportunity?

Walk me through your experience.

In _____ experience, who were the stakeholders you were working with and how did you get the information you needed?

Do you have experience writing about complex and/or technical topics? What was your process for delivering the content in an engaging way?

What’s your approach for writing about topics that you don’t have extensive experience in?

What digital marketing related content do you find most difficult to produce and why?

How do you keep an authentic and consistent brand voice while catering content to varying audiences?

Did you have a chance to look at any of our website content (more specifically, our blogs and case studies)? What do you like about it? How would you improve it?

Do you have examples of complex topics that you have [[translate]]d into engaging long-form content? (for us to review after call)

Do you have a sense for how much you’d like to be paid per hour?

[[questions to [[interview]] someone]] for [[[[hiring]] a copywriter]] round 2

Fuseideas thought leadership program - interested in learning more about that - what was hardest part?

Interested in the case study spotlights for universities for the ed tech company

How do you define what a "must mention" is?

Where do you go for inspiration?

{{{[[DONE]]}}}} Get the [homepage story arc](https://docs.google.com/document/d/1SHH4JhrJ75k8uo3mDKChvnpFxXSeMWEtiPffigVt0hg/edit?ts=5f3ece84) details into the #hiring [freelance copywriter evaluation](https://docs.google.com/document/d/1ysq67G2CccNlzLuqjSnx_-z_i_P3QZsH6Ij18V5JIDs/edit#heading=h.eq6gmeqfth9o) #[[ADK Hiring]] #[[[[hiring]] a copywriter]]

{{{[[DONE]]}}}} [[Wasabi]] GDPR/CCPA research. #//

{{{[[DONE]]}}}} Re-write the [[Museum of Science]] landing page

{{{[[DONE]]}}}} Quick check in on [[[[Sleeping Dog Properties]] Marketing Strategy]] [[Sleeping Dog Properties]] blog analytics

Which blog posts do we tackle next? [[[[Sleeping Dog Properties]] blog]]

How much does it cost to add a bathroom

How much does a general contractor charge per hour

Garage re[[model]]

General contractor agreement

Boston architecture

Performance

14% increase in organic traffic Q3 to date vs. Q2

14% increase in new users and sessions as well

18% increase in pageviews

19% increase in average session duration to over a minute

-2.56% bounce rate

During COVID, organic traffic increased from ~1,800 / month to up to 2,700 / month in July

Keywords

Position 3 for "home builders contractor" (500 searches / month)

1 for "architect vs builder" (40)

14 for condominiums design (250)

1 for "timeless home designs"

2 for "custom condos"

11 for luxury construction

14 for kitchen re[[model]]ing boston

12 for design build boston

2020 to date has seen 71 contact page conversions

30 (or 42% came from direct traffic)

24 (or 33.8% came from organic traffic)

