Focus areas from the [[[[product]] [[strategy]]]] team off site [[October 25th, 2022]] 

Here are Darci’s votes for how she can contribute to high-performing teams:

Take initiative to define ideal project role that utilizes strengths

Workshop role definition w/ other strategy team members

“What you should know about me... What I need from you... ”

**Comfort with long-term goals and strategic thinking**

^^[[Questions for [[1:1s]]]]^^

**Identify:** These questions focus on what really matters for your report and what topics are worth spending more time on:

What's top of mind for you right now?

What priorities are you thinking about this week?

What's the best use of our time today?

**Understand:** These get at the root of any problems of the decided topic:

What does your ideal [[outcome]] look like?

What's hard for you getting to that [[outcome]]?

What do you really care about?

What do you think is the best course of action?

What's the worst-case scenario you're worried about?

**Support:** These zero in on how you can be of service to your report:

How can I help you?

What can I do to make you more successful?

What was the most/least useful part of our conversation today?

Mini, immediate [[debrief]] s

