Author:: [[sparktoro.com]]

URL:: https://sparktoro.com/blog/content-marketing-superpower-small-invite-only-amplifier-groups/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

STEP 1: Craft content that helps amplifiers earn engagement when they share 

STEP 2: Identify a list of potential amplifiers that reach your target audience 

STEP 3: Build Relationships Personally 

