Tags:: #Recipes #pasta

Ingredients::

12 oz. of [[spaghetti]] or [[linguine]]

1 medium [[onion]], finely sliced

2 cups of [[cherry tomatoes]], halved

2 cups of tender, seasonal vegetables like [[peppers]], [[spinach]] or [[kale]]

Select tender vegetables that can cook in about ten minutes. [[Summer squash]], [[cauliflower]], [[baby greens]], [[bell peppers]], [[asparagus]], [[broccoli]], [[mushrooms]], and [[eggplant]] are all great options.

2 cloves of [[garlic]], minced

2 tbsp of [[EVOO]]

1 cup of [[dry white wine]]

1 tbsp of [[white wine vinegar]]

1/2 cups of shredded [[basil]]

1 1/2 tsp [[salt]] and fresh cracked [[pepper]] to taste

1/2 tsp of [[red pepper flakes]]

Tools:: [[Pot]], [[Pan]], [[Knife]], [[Cutting board]]

Source:: https://equalparts.com/blog/one-pot-pasta/

:hiccup [:hr]

STEP 1

Start by adding all of your ingredients except cheese into a pan or pot. Add just enough water to cover your pasta and vegetables – remember you won’t drain the pasta so be careful not to over do it with liquids.

STEP 2

Cover your pot or pan with a lid as you bring the mixture to a boil. Uncover and boil for 7-9 more minutes, stirring often with a slotted spoon to make sure the pasta doesn’t stick to the bottom. Your tomatoes will start to break down and create a tasty sauce with the starchy pasta water.

STEP 3

Once the pasta is al dente and most of the water has been absorbed or evaporated, add a generous helping of freshly grated parmesan cheese (optional). Serve and enjoy!

