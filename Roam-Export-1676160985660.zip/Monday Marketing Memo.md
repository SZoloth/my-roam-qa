Tags:: #[[ADK MFG]], #[[ADK content]], #ADK/blogging, #[[ADK Drupal Campaigns]]

Memos

[[Monday Marketing Memo 1: 5/12/2020]] #sent

[[Monday Marketing Memo 1.5 ]] #sent

[[Monday Marketing Memo 2: 5/25/2020]] 

[[Monday Marketing Memo 3: 6/8/2020]]

[[Monday Marketing Memo 4: 6/22/2020]]

[[feedback]] 

From [[chris baker]] on the [[Monday Marketing Memo 1: 5/12/2020]] draft:

For work completed, no need to mention things you did for the Drupal campaign that aren't live yet in separate bullets, there's an understanding that it takes many steps, just hit that at a high level. For any work completed that they can see, link to it, whether it's a draft b[[Log in]] docs or a new page that's live on the website.

For currently working on - include target launch/milestone dates for each item to drive accountability.

For on the horizon, I'd suggest adding a sub-bullet with a bit of color commentary there. Not everyone receiving may understand what the enterprise campaign is for example. Hypothesis, proposed plan, etc. Definitely true for the last bullet point since the audience is non-marketers. These should each be explained at a high level, 1-2 sentences max.

