Author:: [[ftf.agency]]

URL:: https://ftf.agency/keyword-research-now/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

Click the “View all” link under the far left column titled “Having same terms” 

sort descending by Clicks: 

I’m not interested in any keywords with less than 100 clicks/month, so by page 3 of results I’m out of the terms I want to grab data on (for now). 

when you go to export your results make sure you select Custom under “Number of rows” (and set the number of rows that meet your click threshold, so for me in this case it’s 150) – and then check the box for “Include SERPs.” 

We also have some column cruft we want to dump (delete), so you can remove: 

Country 

Backlinks 

URL Rating 

Top Keyword 

Top Keyword Volume 

The easiest way to do this is to select Row 1, then click Data > Create a Filter, then click the filter in Column B > Filter by Value > Clear > select “Blanks,” 

