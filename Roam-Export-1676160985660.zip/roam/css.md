Blank

Hide query title

```css
.rm-query .rm-query-title {
  display: none;
}```

Delegate CSS Tag

```css
span.rm-page-ref[data-tag="Delegated"] {
    background: #CECECE !important;
    color: #555555 !important;
    padding: 2px 0px 2px 5px;
    font-size: 13px;
    line-height: 1em;
    font-weight: 500;
    border-radius: 3px 0 0 3px;
    position:relative;
}

span.rm-page-ref[data-tag="Delegated"] + span[data-link-title] {
    background: #E3E3E3 !important;
    color: #9E9E9E !important;
    padding: 2px 5px 2px 15px;
    font-size: 13px;
    line-height: 1em;
    font-weight: 400;
    border-radius: 0 3px 3px 0;
    margin-left: -5px;
}

span.rm-page-ref[data-tag="Delegated"]:after, span.rm-page-ref[data-tag="Delegated"]:before {
    left: 100%;
    top: 50%;
    border: solid transparent;
    content: " ";
    height: 0;
    width: 0;
    position: absolute;
    pointer-events: none;
}

span.rm-page-ref[data-tag="Delegated"]:after {
    border-color: rgba(136, 183, 213, 0);
    border-left-color: #CECECE;
    border-width: 10px;
    margin-top: -10px;
}

span.rm-page-ref[data-tag="Delegated"]:before {
    border-color: rgba(194, 225, 245, 0);
    border-left-color: #FFFFFF;
    border-width: 12px;
    margin-top: -12px;
}```

Individual stylings for individual # tags

```css
/* Custom data tags */
span.rm-page-ref[data-tag="Tweets"] {
    background: #2980b9 !important;
    color: white !important;
    padding: 3px 7px;
    line-height: 2em;
    font-weight: 500;
}

span.rm-page-ref[data-tag="Projects"] {
    background: #2980b9 !important;
    color: white !important;
    padding: 3px 7px;
    line-height: 2em;
    font-weight: 500;
}

span.rm-page-ref[data-tag="Books"] {
    background: #8e44ad !important;
    color: white !important;
    padding: 3px 7px;
    font-weight: 500;
    line-height: 2em;
}

span.rm-page-ref[data-tag="People"] {
    background: #8e44ad !important;
    color: white !important;
    padding: 3px 7px;
    font-weight: 500;
    line-height: 2em;
}

span.rm-page-ref[data-tag="Ideas"] {
    background: #e67e22 !important;
    color: white !important;
    padding: 3px 7px;
    font-weight: 500;
    line-height: 2em;
}

span.rm-page-ref[data-tag="Recipes"] {
    background: #e67e22 !important;
    color: white !important;
    padding: 3px 7px;
    font-weight: 500;
    line-height: 2em;
}

span.rm-page-ref[data-tag="Videos"] {
    background: #f1c40f !important;
    color: white !important;
    padding: 3px 7px;
    font-weight: 500;
    line-height: 2em;
}

span.rm-page-ref[data-tag="Articles"] {
    background: #27ae60;
    color: #fff;
    padding: 3px 7px;
    line-height: 2em;
    font-weight: 500;
}

span.rm-page-ref[data-tag="Goals"] {
    background: #27ae60;
    color: #fff;
    padding: 3px 7px;
    line-height: 2em;
    font-weight: 500;
}

span.rm-page-ref[data-tag="Podcasts"] {
    background: #7f8c8d;
    color: #fff;
    padding: 3px 7px;
    line-height: 2em;
    font-weight: 500;
}

span.rm-page-ref[data-tag="Waiting"] {
    background: #f39c12;
    color: #fff;
    padding: 3px 7px;
    line-height: 2em;
    font-weight: 500;
}

span.rm-page-ref[data-tag="Inbox"] {
    background: #e74c3c;
    color: #fff;
    padding: 3px 7px;
    line-height: 2em;
    font-weight: 500;
}

span.rm-page-ref[data-tag="Blocked"] {
    background: #e74c3c;
    color: #fff;
    padding: 3px 7px;
    line-height: 2em;
    font-weight: 500;
}```

Hide the gray box on videos

```css
.rm-video-player__comment-button {
  opacity:0;
}
.rm-video-player__comment-button:hover {
  opacity:.3;
}```

[c3founder Roam Enhancement](https://github.com/c3founder/Roam-Enhancement)

PDF

```css
@import url('https://c3founder.github.io/Roam-Enhancement/enhancedPDF.css');```

Youtube

```css
@import url('https://c3founder.github.io/Roam-Enhancement/enhancedYouTube.css');```

