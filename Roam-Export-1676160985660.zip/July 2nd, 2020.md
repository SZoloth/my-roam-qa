[[Meetings]]: [[Sleeping Dog Properties]] client check in

Attendees:: [[matt rapczynski]] [[toy prayoonrat]]

Time:: 10:00am - 10:45am

Notes::

**Summary**:

Can we have the 3 blogs ready for review EoD today?

SDP wants to target Cambridge instead of Swampscott

2 additional blog posts / month (+$1,500)

{{[[DONE]]}} Need to come back with POV on best strategy for targeting Cambridge [[Sleeping Dog Properties]] [[[[Sleeping Dog Properties]] Marketing Strategy]]

Eg - steady post of 2 blogs / month or front load blogs for a couple of months, then downshift and focus on optimizing and promoting

Optimizing: URLs, GMB, 3rd party profiles, etc.

https://homeguide.com/ma/cambridge/general-contractors/

https://www.homebuilderdigest.com/rankings

Promoting: backlinks

https://www.cambridgechamber.org/list/category/general-contractors-1483

Content

Blog posts #[[[[Sleeping Dog Properties]] blog]]

**Moving/Building in Cambridge**

Cambridge MA building department

Cambridge MA property tax

Cambridge MA building permit

Living in Cambridge

Guide to neighborhoods

Services

**Cambridge MA architects**

**general contractor cambridge ma**

~~home design cambridge ma~~ interior design cambridge

construction cambridge ma

new construction cambridge ma

**general contractors cambridge ma**

**kitchen re[[model]]ing cambridge ma**

Need from client

List of architects in Cambridge (based in or do work in)

Projects in Cambridge + resources

List of interior designers in Cambridge (based in or do work in)

About Cambridge

Has done work there before - need assets from these

Works with Dee Elms (Elms Interior Design) frequently in Cambridge

There are tons of architects in Cambridge

Eg - Mary Anne (sp?) Architects

Also interested in commercial work

This is nascent

Focus would be on Medical + Higher Ed

Ran a cold outreach campaign to 55 higher ed targets

18 opens (32%)

1 click (5.5%)

Misc. blog ideas that came up

How magazines make interiors look so good

How to estimate the price of a de[[Sign in]] a magazine shot

3 blogs will be ready for review EoD today

Waiting on Swampscott decision for July

$1500 * 3 to $18,000

Osterville got nothing after 2 years

Everyone wants Newton/Weston/Wellesley

Fall is risky - b/c resurgence of COVID will make Boston harder to work

**Backed into Cambridge instead of Swampscott**

In addition to the monthly budget - $1500 for 2 blog posts 

**Potentially interested in link building to accelerate**

Start with more blogs now then shift into promotion and optimization?

Targeting Fall

Have done work before

Dee Elms - Elms Interior Design

Maybe some peripheral Somerville 

Anything on the Cambridge line

Ton of architects in Cambridge

Mary Anne Architects is prime

How to stage a picture [[[[Sleeping Dog Properties]] blog]]

How homes look so good in magazines

How to price work based on design [[[[Sleeping Dog Properties]] blog]]

Seeing something in a magazine to 

"how much to make my house look like that"

How to look at magazines 

**Commercial** #[[[[Sleeping Dog Properties]] blog]]

**Medical division**

Like commercial space

Medical cabinetry = 60% upcharge on regular cabinetry

**Education division**

Every Summer every university has a volume of money to dump

Decision gets made every February

Harvard, MIT, Boston University

Allen G Scaffold? Lanco?

Union carpenter

Has a ton of work from Harvard

Who do we reach at schools?

**Cold outreach for private universities via email**

Target 2021 or Christmas

Sent to 55 people

18 open - 32%

1 click - 5.5%

Influencer campaign from [[toy prayoonrat]]

Want to get more than 10k followers

[[Meetings]]: [[National Speed]] check in

Attendees:: [[Fiana Avergon]] [[sean riley]] [[andrew creek]] [[alex fedorov]] [[charlie carmichael]]

Time:: 11:00am - 11:10am

Notes::

Client ([[charlie carmichael]]) never showed

[[Meetings]]: [[National Speed]] check in

Attendees:: [[Fiana Avergon]] [[sean riley]] [[alex fedorov]] [[charlie carmichael]]

Time:: 2:30pm - 2:45pm

Notes::

Client ([[charlie carmichael]]) never showed

[[Meetings]]: [[Meetings with [[chris baker]]]] about [[ADK Marketing Priorities]]

Attendees:: [[chris baker]]

Time:: 12:30pm - 1:05pm

Notes::

Should we focus on internal (lifecycle) marketing

Referral

Up sells

Email marketing

Staying in front of current partners

Management stuff

Define the barriers to success for ICs

Make plans to knock them down

Team make-up

Me focus on ADK with a leader taking client

Me focus on client with support for ADK

Fractional resources (like Michael Gaudet)

Fractional CMO guy: https://www.linkedin.com/in/michaelcgaudet/

Asked: what does it cost to close a deal?

Hire in a focus on brand-focused person

Creating a connection

Matt Bernstein

[[Meetings]]: check in with [[ben kaplan]]

Attendees:: [[ben kaplan]]

Time:: 11:15am - 11:30am

Notes::

Upgrading docusign to proposify

One type of proposal that Proposify helps with are RFP responses

Provided case studies

[Selling the ADK with Nick and Darci](https://docs.google.com/document/d/1XVN-ApvlxcaXo3YZ9f1Mj9AgLczqXexqqStLLGI8adc/edit?ts=5efa1e5b#)

Ideas

Content team produces long form blogs ghost written for ADK experts

ADK experts promote and share

What about 

non-ADK content?

other media

video

audio

meme

presentation

shorter-form content - hot takes in reaction to news

Need to define

What is the responsibility of the experts vs. us

[[Meetings]]: [[feedback]] for case studies for [[ADK Website Rebuild]]

Attendees:: [[maggie o'connor]] [[jayne hetherington]]

Time:: 2:00pm - 2:30pm

Notes::

Going over [[feedback]]

[[Meetings]]: check in with [[darci nevitt]]

Attendees:: [[darci nevitt]]

Time:: 3:40pm - 3:50pm

Notes::

Neil tatar SEO stuff

:hiccup [:hr]

[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} [[form health]] facebook ads: re-set for geo targeting

{{[[DONE]]}} [[Sleeping Dog Properties]] blog reviews

{{[[DONE]]}} Management work

{{[[DONE]]}} hey! just wanted to follow up on [[MIT PEL]] #analytics -- did you/team have a chance to review the custom analytic tags that we set up? 

{{[[DONE]]}} Set up GA filters for #APCIA ([ticket](https://adkgroup.atlassian.net/browse/AP-2479))

{{[[DONE]]}} Review [[Tim Lupo]]s [[feedback]] on case studies for #[[ADK content]] & share with [[Sanjay Salomon]] #/

#[[Quick Capture]]

frisbee [[Moose Brook State Park]]

