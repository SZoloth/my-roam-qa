Hi all,

This morning we launched the Drupal 8 prospecting campaign on LinkedIn. Some quick bites of info:

Targets marketers/IT folks at MA and KY companies that are using Drupal 7

We have a variety (~30) of different ad images and copy combinations that cover different messages, tones, and positioning

As a reminder, we're [driving to this page](https://drupal8.adkgroup.com/) and asking for an email in exchange for either a PDF, a code audit, or a strategy session

We also have a chatbot set up

Next steps:

**Monitor**: We're scheduled to review at the end of day today, tomorrow, and Monday (Memorial Day).

**Optimize:** At each of those review days we'll be looking for areas to optimize. Following Monday we'll operate on a weekly schedule (so the next optimization date will be next Thursday)

**Report:** With each check in, I'll provide updates on what we're learning from the campaign.

**Retarget:** We'll create retargeting campaigns to both hit people who landed on the page and __didn't__ convert and to hit people who converted but went cold.

**Direct reach out:** We'll use the same list we used for the campaign to create an automated email outreach list to these leads that are now warm (at least have seen our brand before)

This was a __huge__ team effort requiring support from designers, sales people, technical leads, marketers, and team leads. Additionally, many of you reviewed and provided [[feedback]] along the way, which was __instrumental __to getting this live, so thank you!

____

If you're curious about __anything__ above (eg - why that monitoring schedule? what do we do when we optimize?) please don't hesitate to give me a shout.

Thanks again,

Sam

