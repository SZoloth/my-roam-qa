[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Re-write the [[Museum of Science]] landing page: https://docs.google.com/document/d/1aezd-tg_bsKE6g2gG2_XChp0yRc9XxgxFk3WLQQhQBA/edit?usp=sharing

Notes

For numbers, add a visual to show the scale of numbers

Heros

Tomorrow’s {{or: problem solvers|scientists|engineers|entrepreneurs|role [[model]]s|big thinkers|critical thinkers|mathematicians|biochemical engineers|computer scientists}} are being made in EiE classrooms today.

Today, I’m designing maglev systems and building automated computer systems in your classroom. Tomorrow, I’m doing it in real life.

Subheaders

With Engineering and Computer Science Essentials: An Integrated Program, your students will be immersed in hands-on engineering activities. Your teachers will be supported with powerful resources. And your district's STEM scores will be higher than ever.

Engineering and Computer Science Essentials: An Integrated Program gives your teachers everything they need to get students excited about engineering early - while hitting multiple NGSS requirements. 

Engineering and Computer Science Essentials: An Integrated Program gives your students opportunities to solve real-world engineering and computer science problems 

The real-world challenges in Engineering and Computer Science Essentials: An Integrated Program help all your students develop core problem-solving skills - while hitting multiple NGSS requirements. 

Help all of your students unlock their inner engineers from an early age with Engineering and Computer Science Essentials: An Integrated Program. 

The curricula built on proven principles

Every EiE curriculum undergoes rigorous testing to ensure that meets standards defined by the NSF, NGSS, and the Museum of Science in Boston, MA.

**Prepares the next generation workforce** by expanding critical thinking and problem-solving skills in elementary grades.

**Reinforces Habits of Mind**—serve as a framework for how your learners feel, think, and do using our uniquely integrated engineering and computer science curricula.

help students solve problems, persevere through failure, and improve on solutions, both as individuals and as functional work teams.

**Creates classroom equity**: Through our hands-on design challenges; stories set in different countries; impactful Resources for Diverse Learners; and a “teacher as facilitator” [[model]], you can level the playing field for all learners.

**Cultivates Critical Thinking**: Children will discover that there is more than one way to approach every problem, and that multiple solutions are valid and even celebrated.

**Supports Social Emotional Learning**: Our units help students develop agency and confidence and encourage them to practice ethical, compassionate decision-making.



{{{[[DONE]]}}}} Hand off [[Wasabi]] reporting to [[jordan daly]]

Notes on Wasabi reporting:

The metrics are automated at this point and [show up on this dashboard](https://datastudio.google.com/u/2/reporting/1G9PddItHb48rmrZTgBPatskzd3BU1vcf/page/X8Oy)

The theme or focus this week has been on an a/b test of the pricing page that launched on the morning of 8/19. 

Background on the test is [here](https://docs.google.com/document/d/1g3cs1x-scTnHv5YbvDrYJk25-YB6KddQ-AH_k9YoAjc/edit?usp=sharing).

To [calculate the primary metric](https://www.loom.com/share/3653159f5164442cb6bb4993aab6b6ae) (CTR from pricing page to RCS page):

Make sure you've split traffic by Control and Variant - these are both GA segments that have names that start with "A/B Test:"

Divide the number of pageviews of RCS that came from Pricing by the number of pageviews of the Pricing page.

Other things to pay attention to:

Work we've been doing towards SEO (the comparison work, the glossary work)

SEO progress or issues

Keywords and ranking

Organic conversion rates

{{{[[DONE]]}}}} Wasabi a/b test results?

{{{[[DONE]]}}} Questions for [[Privafy]] SEO kick off to give to [[darci nevitt]]

What has changed about your product and the specific problem it solves?

What's changed about your competitors?

What's changed about your target audience?

Their questions that they have before they know they need your service

What they'll research when they have a need for your prodct

What sites they use to educate themselves about your industry

Where they go for advice about your services: Google? A friend? An influencer? A magazine? A book? Television?

What have you learned since launching about your product and audience?

What are the common objections to your service?

{{{[[DONE]]}}}} Answer the [[ICP]] question from [[refine labs]]

{{{[[DONE]]}}}} Map out a blog charter: topic, bullet points about our unique POV, quotes to use #[[[[hiring]] a copywriter]]

{{{[[DONE]]}}}} [[form health]] email question from [[jess lopez mora]]

**Problem**: This weeks performance dipped hard. 

Up until this week we actually were seeing a ton of progress with multiple sign-ups a day and our CAC decreasing.

This week there hasn't been a single sign up

From the 23rd to the 29th, 

3 views of the thank you page

2 in Bio, 1 in Testimonial 2

Spend of $2,503.20

From 16 - 21, 

5 views of thank you page

1 in Medication, 4 in Bio

Spend of $3,388.46

Possible solutions

May be running into issues with audience overlap

Roughly, how to set up #CBO campaign in [[facebook]]

In which case, run a/b tests through their tool OR just ^^trust [[CBO]]^^:

Conversion, #CBO, Cost Cap around CPA of ---???

Minimum budget = cost cap (CPA) * 7.14 * # of ad sets

Goal: <30% of money spent in the learning phase

Campaigns should have a theme (angles/value props, offers, SKUs)

Ad set level for #CBO

Broad audience = unconstrained (functionally LAL)

exclude: existing customers, web traffic 30 days

Interests

Same exclusions

Web traffic remarketing

Cost cap should be lower than prospecting

Adsets in #CBO should have 3-5 ads

Each ad should have optimized placement creative

**What changed:** 

Some ad sets have been turned off and turned back on

CA MA TX IL NY WL and Peer Ad sets: Medication & Testimonial 2



{{{[[DONE]]}}}} Look into tributary site analytics for [[MIT PEL]] from [[Bridget O'Brien]]

boom. as suspected, they had `mit.edu` set to be excluded 

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FXzXgHf3OYn.png?alt=media&token=f97941d6-a288-4b15-888a-302c4753fe13)

{{{[[DONE]]}}}} Put in hours 

{{{[[DONE]]}}}} Questions for GTI PM for blog post on creating an FDA compliant app

{{{[[DONE]]}}}} coverage email

{{{[[DONE]]}}}} vacation responder

[[Meetings]]: [[Museum of Science]] check in

Attendees::

Time::

Notes::

Original strategy doc

in ad copy

increase specificity

around age

always say curricula

Include more copy in the top line

Today / tomorrow

maglev is too specific

drones, self-driving vehicles, cellphones

On image:

Bullet of features

Online

NGSS compliant

CTA

