[[Daily Journal]] for [[September 28th, 2020]]

[[Morning Routine]]

[[Morning Pages]] 

__Don't forget Gratitude!__

{{word-count}}

I already kind of did this in my [[Stoicism]] app, not sure if I need both. The benefit here is that I can start linking ideas and emotions together. The benefit of the app is that it's custom built for it? And mobile-friendly, which I think is the more important aspect actually.

[[What are you grateful for?]]

Overnight oats, baby. 

Air conditioning.

Sunny mornings.

[[What do you want the day's highlight to be?]]

Solving the [[Museum of Science]] tracking issue and sending over a keyword report to [[Wasabi]] that I am proud of.

[[Daily affirmations]]

I am smart, hard working, confident, and charismatic. My ideas are creative and good and people value my opinions.

[[What's on your mind?]]

[[What help could you ask for to solve your biggest challenge?]]

[[Daily Habits]]

{{[[TODO]]}} Meditate 10 minutes

{{[[TODO]]}} Cold shower

{{[[TODO]]}} Lift or run

{{[[TODO]]}} Read

[[Evening Routine]]

[[What did you do today? How did it make you feel?]]

[[What did you learn today?]]

[[How would you rate today? ]]

{{[[slider]]}}

[[How could you have made today even better?]]

[[What are your priorities for tomorrow?]]

Resolved **some** analytics issues for [[APCIA]] with [[aaron crootof]], but there are likely more #[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} Update `test` events

{{[[DONE]]}} Ensure cross-subdomain tracking is working #///

[[Meetings]]: [[Meetings with [[chris baker]]]]

Attendees:: [[chris baker]]

Time:: 14:59

Notes::

 Design leadership

To get [[sean riley]] engaged: here's your part of the problem to solve

SaaS + healthcare

Is there anything you would adjust?

Not starting from scratch

To free up time

{{[[DONE]]}} Reach out to Jen about blogging for [[Sleeping Dog Properties]] #[[🏔ADK [[Task Management]]]] #///

{{[[DONE]]}} Check in with [[darci nevitt]] on research plan [[🏔ADK [[Task Management]]]] #//

[[Meetings]]: overview of [[Glenmede]]

Attendees:: [[Michelle Smith]] [[darci nevitt]]

Time:: 11:31

Notes::

 x-domain with impactivate

Background

Glenmede Investment Management (glenmedeim.com) is **__very__** different business line

Might be a new domain

Impactivate 

Represents "impact investing" product

New designs

Don't want people returning to homepage

staging: glen-gtc.adkalpha.com

Content grouping for top-level GTC navs

All forms = [[pardot]]

Next steps #Glenmede #[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} Prep and send example tracking doc

{{[[DONE]]}} Prep tracking doc GA 

[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} [[Museum of Science]] [[Google Ads]] tracking issue

{{[[DONE]]}} Kick off [[sean riley]] on [[[[mHealth]] app kit]] landing page

{{[[DONE]]}} Finalize the **Wasabi keywords** and send to client [[Wasabi]] #//

{{[[DONE]]}} Edit [[Sleeping Dog Properties]] blogs from [[nick watkins]]

#[[Quick Capture]]

for process: make it right, then make it used

