At any given time, when you’re walking down the streets, a very small percentage of your brain is focused on the present. The rest is planning the future or regretting the past. This keeps you from having an incredible experience. It’s keeping you from seeing the beauty in everything and for being grateful for where you are. You can literally destroy your happiness if you spend all of your time living in delusions of the future. [4]

[4] Ravikant, [[Naval Ravikant]] and Shane Parrish. “Naval Ravikant: The Angel Philosopher.” Farnam Street, 2019. https://fs.blog/naval-ravikant/.

__We crave experiences that will make us be present, but the cravings themselves take us from the present moment.__

I just don’t believe in anything from my past. Anything. No memories. No regrets. No people. No trips. Nothing. A lot of our unhappiness comes from comparing things from the past to the present. [4]

[4] Ravikant, [[Naval Ravikant]] and Shane Parrish. “Naval Ravikant: The Angel Philosopher.” Farnam Street, 2019. https://fs.blog/naval-ravikant/.

__Anticipation for our vices pulls us into the future. Eliminating vices makes it easier to be present. __

There’s a great definition I read: “Enlightenment is the space between your thoughts.” It means enlightenment isn’t something you achieve after thirty years sitting on a mountaintop. It’s something you can achieve moment to moment, and you can be enlightened to a certain percent every single day. [5]

[5] [[Tim Ferriss]]. __Tools of Titans: The Tactics, Routines, and Habits of Billionaires, Icons, and World-Class Performers__. New York: Houghton Mifflin Harcourt, 2016.

__What if this life is the paradise we were promised, and we’re just squandering it?__

