Top mantras

* Double down on what's working and don't stop until it stops working

* Avoid shiny new distractions. AKA Focus. AKA see above.

* [[prioritize]] the biggest rocks each day. Feel no guilt if you never get to the small rocks.

* Momentum is all the things. Keep the streak going. Search for the perfect wave and ride it as long as you can.

For developing [[[[High Agency]][[*]]]]

High Agency is being resourceful and having an internal locus of control. Understanding external limitations, but constantly looking for creative ways around them.

"High Agency is about finding a way to get what you want, without waiting for conditions to be perfect or otherwise blaming the circumstances. High Agency People either push through in the face of adverse conditions or manage to reverse the adverse conditions to achieve [[Goals]]"

[[Shreyas Doshi]]

"When you’re told that something is impossible, is that the end of the conversation, or does that start a second dialogue in your mind, how to get around whoever it is that’s just told you that you can’t do something?"

[[Eric Weinstein]]

Work to understand that what people say you can/cannot do is just a story that they've made up or accepted from another person who made it up.

"High Agency is a sense that the story given to you by other people about what you can/cannot do is just that - a story. And that you have control over the story."

“Life can be much broader once you discover one simple fact: ^^Everything around you that you call life was made up by people that were no smarter than you^^ **and you can change it, you can influence it,** you can build your own things that other people can use.” - [[Steve Jobs]]

High Agency people constantly seek to expand their [[Circle of Influence]]

Review the [[Circle of Influence]] frame work from the [[7 Habits of Highly Effective People]]

Be mindful of the way you talk to yourself. When you notice low-agency self-talk seek to correct it.

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2Fcm0Kq3ThdI.png?alt=media&token=c990e5db-b26a-41b7-8aa3-09a7e21f31e3)

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FNAMnvXtJ6s.png?alt=media&token=ffb371ae-3f14-4501-aaad-eb92d634f626)

Be keyed into times you get frustrated or unhappy at work. This is often the result of slipping into low agency thinking

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2Fa3oQicNe-R.png?alt=media&token=3332d0cc-6e84-44c4-ae85-c33bf66aad2d)

[[Shreyas Doshi]]

Never outsource important decisions

Test from [[Jeff Bezos]]: "If you were stuck in a third world prison and had to call one person to try and bust you out of there - who would you call?"

"How can you achieve your 10 year goal in 6 months?" - [[Peter Thiel]]

Relates to [[Orthagonal Thinking]]: asking questions to seek out completely novel angles to frame problems through. As a result you see ideas that the crowd missed

[[Naval Ravikant]] and [[Robin Hanson]]

