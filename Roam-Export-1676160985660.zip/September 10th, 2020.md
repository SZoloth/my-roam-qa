[Example of SME [[webinar]] from thoughtbot](https://thoughtbot.com/events/digital-health-startup-event) [[Inspiration for ADK]]

[[Meetings]]: [[[[hiring]] a copywriter]] interview with [[deborah huso]]

Attendees:: [[chris baker]] [[heather mccormmack]] [[deborah huso]]

Time:: 10:00

Notes::

 Niche market focused communication firm

Help out by:

stepping in as subcontractor role

working directly 

Primary market: IT, construction, design, real estate, ag, travel and hospitality

We want

to heroize the client

Questions

Bulk of work = case studies + blog posts....what industries?

primary focus = digital health / health tech

people looking to submit an NIH grant

custom technology decision makers

multiple [[model]]s we compete against: build in-house, find a freelance team, get an experienced team (us), major multinational offshore shops (accenture, [[Deloitte]], cognizant)

Are there key competitors?

In digital health - not really? 

Not really in general - trying to keep 

How to approach case studies:

Start with creative brief from client

They develop brand and style guides

[[Meetings]]: [[[[hiring]] a copywriter]] topic discussion with [[sam ellison]]

Attendees:: [[sam ellison]] and [[chris baker]]

Time:: 11:01

Notes::

 Topic: Form Health

Was about 7 minutes late, citing tech issues

new email address: samwriteswords@gmail.com 

{{{[[DONE]]}}}} Follow up with Heather for W-9 or whatever for Sam Ellison

[[Meetings]]: [[Drawbridge]]

Attendees::

Time:: 14:06

Notes::

 competitors:

Honey, Hey screener, Thing testing, subscription boxes, ad blocker, gmail promotions tab, swaypay

Collect interests

Tinder style swiping

Share some info, get recommendations

Twitter or quora style category picking

Import from social profiles

Drawbridge animation:

Out of the 345345 offers and brands out there, we found 13 of the best ones for you:

Build a team to unlock this promotion

Invite three friends to double this promo

Answer a question to unlock your promotions

Get {{7}} promos. Have 3 slots to fill that worth different discounts.

[[Meetings]]: ADK marketing #[[Meetings with [[chris baker]]]] [[ADK Marketing Strategy]] [[ADK Marketing Project Management]] #team-development [[ADK marketing summit]]

Attendees:: [[chris baker]]

Time:: 12:30

Notes::

 ADK Marketing

Next steps:

ADK marketing summit: state of the state 

30m to convene next week with chris

1.5 hrs in 2 weeks for the meeting

By end of the year: we've got a defensible POV of the marketing sales 

Questions

What do we want to be best at?

CB thinks: either service to product team via analytics, content architecture OR go-to-market / product-launch package

How do we support product?

Challenge individual members of the team:

With marketing role evolving to be end-to-end product lifecycle how can we expand support for apps?

Go To Market campaign - out of the box, esp. for startups

Eg - for EiE or Form Health

Set up martech stack, and launch strategy, where to spend $50k

Here's what we do:

We set up scalable systems for growth, launch your product, then set up your marketing team for continued growth

Dan's critique of marketing:

When sales need projects - we don't

Need to evolve from cowboys to something to philosophy

Specialized process

For ADK

ADK's internal strategy and how to get Chris involved

Thinking about how do we maximize Refine Labs 

Retargeting campaigns + LinkedIn prospecting

Individuals should have learning and development [[Goals]]

Webflow, MailChimp, Ad Campaign creative

For clients

Projects

Mercer + Wasabi

Services that we're adept at

Technical SEO

Part of product

Analytics

Part of product

Information architecture

Part of product

Content

A little iffy on the production side but working to ameliorate that

A/B Testing / CRO

Weaknesses

Process

Creativity

