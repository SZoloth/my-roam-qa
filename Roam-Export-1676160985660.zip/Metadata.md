[[template/book]]

Author::

Reading Status::

Recommended By:: 

Tags:: #Books

[[template/article]]

Author::

Source::

Recommended By:: 

Tags:: #Articles

Blog Posts

Target Date::

Tags:: #[[blogging]] #[[✍️ blog-post]]

Progress Status::

Google Doc::

Projects

Due Date::

Completed Date::

Progress Status::

Priority::

Related [[Goals]]::

Success Criteria:: 

Tags:: #Projects

Resources

Relevant people:

The Plan

Journal

[[Goals]]

Projects:: 

Goal Status:: 

Success Criteria:: 

Completed Date::

Tags:: #Goals

People

Phone Number::

Email::

Company:: 

Role:: 

Location::

How We Met::

Birthday::

Tags:: #People

[[template/recipe]]

Tags:: #Recipes

Ingredients::

Tools::

Source:: 

:hiccup [:hr]

Writing I'm doing

**Tags:** #Articles #[[✍️ blog-post]]

**Status:** #draft

Weekend to do's

{{[[TODO]]}} Meditate

{{[[TODO]]}} Run

{{[[TODO]]}} Exercise/Lift

{{[[TODO]]}} Read

{{[[TODO]]}} Notes

{{[[TODO]]}} Write

{{[[TODO]]}} Work on ADK marketing strategy

#[[webinar]]

Source::

Host::

Guests::

Topic::

Tags::

Notes::

