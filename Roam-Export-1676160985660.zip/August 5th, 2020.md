[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} Build the marketing team and process #///

{{[[DONE]]}} Define the team #///

Content

Google Ads

Retargeting

{{{[[DONE]]}}}} Set up the PM process #[[ADK Marketing Project Management]] #//

{{{[[DONE]]}}}} Create cadence for ideating-testing-learning in Google Ads [[Google Ads Optimization]]

Other things to do

{{[[TODO]]}} Write the [[Article: Creating a Glossary for SEO]]



