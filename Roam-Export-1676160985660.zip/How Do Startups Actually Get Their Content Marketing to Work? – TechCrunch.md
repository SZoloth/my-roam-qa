Author:: [[social.techcrunch.com]]

URL:: https://social.techcrunch.com/2019/04/13/how-do-startups-actually-get-their-content-marketing-to-work/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

The lesson? Your objective is to write high quality articles that keep readers engaged. Almost everything else is noise. 

1. Write articles for queries that actually [[prioritize]] articles. 

**Note**: You can confirm this using clear[[scope]]

2. Write titles that accurately depict what readers get from the content. 

3. Write articles that conclude the searcher’s experience. 

Your objective is to be the last site a visitor visits in their search journey. 

Go sufficiently in-depth to cover all the subtopics they could be looking for. 

They skip filler introductions, keep their paragraphs short, and get to the point. 

And, to make navigation seamless, they employ a “table of contents” experience: 

Our data shows they still provide value, just much less. Notably, they get your pages “considered” by Google sooner: If you have backlinks from authoritative and relevant sites, Google will have the confidence to send test traffic to your pages in perhaps a few weeks instead of in a few months. 

Here’s what I mean by “test traffic:” In the weeks after publishing your post, Google notices them then experimentally surfaces them at the top of related search terms. They then monitor whether searchers engage with the content (i.e. don’t quickly hit their Back button). If the engagement is engaging, they’ll increasingly surface your articles. And increase your rankings over time. 

Having good backlinks can cut this process down from months to a few weeks. 

Our data shows you should not pitch your product until the back half of your post. 

Instead, plug your product using a normal text link — styled no differently than any other link in your post. Woodpath, a health blog with Amazon products to pitch, does this well. 

They encourage readers to provide their email so they can follow up with a series of “drip” emails. Ideally, these build trust in the brand and get visitors to eventually convert. 

They “retarget” readers with ads. This entails pitching them with ads for the products that are most relevant to the topics they read on the blog. 

Here’s why retargeting is high-leverage: In running Facebook and Instagram ads for over a hundred startups, we’ve found that the cost of a retargeting purchase is one third the cost of a purchase from ads shown to people who haven’t yet been to our site. 

Our data shows that clients who earn nothing from their blog traffic can sometimes earn thousands by simply retargeting ads to their readers. 

