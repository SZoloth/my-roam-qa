[[Mobile App Analytics]] 

# Stack

General notes:

Demand Curve recommends Appsflyer + Mixpanel/[[Amplitude]] because: Appsflyer = attribution from campaigns and app stores, while Mixpanel and [[Amplitude]] are primarily about logging events in-app and gathering analytics.

[[Amplitude]]

user-level tracking platforms

Best for:

These platforms are best for medium-sized to large companies because they’re pretty expensive. They’re also good for complex web and/or mobile apps (especially if you have both a web and mobile version), or a long sales cycle.

How it works:

GA tracks users on your site using “cookies,” which is how your browser knows they’re the same person every time they come back to your site.

If the user changes the device they use, changes their browser, uses incognito mode, doesn’t allow cookies, or clears cookies (which happens after a certain amount of time), then GA will consider them a new person. This makes down-[[funnel]] attribution difficult in GA, since people often change devices at least once (mobile → desktop, or home computer → work computer).

Instead of using cookies, user-level tracking platforms tie every action to the user using a unique identifier (often an email address, username, or database ID). If the user is signed into your site, all the actions they take will be associated to them—no matter what device or browser they’re using.

Blind to anything that happens before user creation?

[[AppsFlyer]]

Similar to Branch, Kochava, Tune, Adjust

It's a #MAAP

MAAP = mobile app/ad attribution platform

Tracks people from ad-->site-->app/play stores-->behavior within mobile app (last part is accomplished by integrating with in-app analytics like [[Amplitude]])

You can tell that the same person clicked an ad, installed your app, and took an action on your ad

Why AppsFlyer instead of #Branch?

But, a note from the CTO of BellCurve, a digital ads agency, on Branch:

Branch was wildly inaccurate for a past client

Branch didn’t have integrations direct to ad channel for install ads (maybe it does now?)

Branch didn’t let you pass in data like adset/ad/campaign to get more granular with the data like appsflyer (maybe it does now?)

Certified by Google Ads: https://ads.google.com/lp/appcampaigns/attribution/#?modal_active=none

Integrates with Apple Search Ads

AppsFlyer lets you track down-[[funnel]] performance on Apple Search Ads (ASA)—something the ad channel itself doesn’t let you do.

Facebook app install ads --> integration

[[MAAP]]



