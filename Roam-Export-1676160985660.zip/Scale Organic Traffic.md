**Meta**

Tags: #SEO, #scale, #organic, #[[organic growth]]

Source: https://cxl.com/blog/scale-organic-traffic/

Author: [[kevin indig]]

Aggregator sites or sites with a lot of #UGC (Think: Quora, Twitter)  are starting to make spaces/genres/categories pages that end up being like Reddit/forums (structurally optimized for SEO but filled with UGC). Quora = Spaces, Twitter = Moments

Other examples: Q&A feature on Amazon, Trello templates, Pinterest topics

What is an [[aggregator site]]? A site that scales with inventory (of movies, products, profiles, information, etc.) vs. content (blog posts)

## Using jobs to be done (#[[jobs to be done]]) and user intent to create new products

### Identify and categorize [[jtbd]]

Example process for #spotify

We can flip “focus market” to “target topic”—the topical space in which your product provides value. For Spotify, the target topic would be “music” because it’s core to Spotify’s product.

Define jobs: “listen to music,” “share music with friends,” “explore new genres,” etc. (There are probably hundreds or thousands of jobs.) Simply describe interactions your target audience has with your product.

Cluster your jobs into groups like “listen,” “share,” or “explore.” Think about the __action__ that users take.

Write job statements consisting of an object, a verb, and context. For example, “listen to music on a plane”; “share music with friends while texting on WhatsApp”; or “explore new genres when I’m bored at work” (which never happens, of course).

[[prioritize]] the jobs according to your core product value—the __main thing__ users get out of your solution. This is when you look at the importance of each job for your business and categorize them as “main jobs” or “side jobs,” depending on how important they are __for the customer__.

Results in a [[prioritize]]d list of important problems your audience is trying to solve

#Google [has identified six needs](https://www.thinkwithgoogle.com/consumer-[[insight]]s/consumer-needs-and-behavior/), that are really the emotional context for users searching

Surprise me;

Thrill me;

Impress me;

Educate me;

Reassure me;

Help me.

To merge this emotional context with the [[jtbd]] framework, use needs as filters. Each job should satisfy at least one need.

### Next, pair the [[jtbd]] with #SEO research

Goal is to find a [[query pattern]] or template that scales across thousands of searches

Imagine YouTube users were searching for “[title of video] English subtitles” on Google. This would indicate that users want to see English subtitles for videos. YouTube could build a feature to show English subtitles automatically. To make it search-friendly, the transcription could be added on the page and provide additional content for Google.

Say you find that queries with the pattern “investors of [company]” have a lot of search volume. That would indicate to a site like Crunchbase that they might want to build a feature to let users see the investors of any company (if the information is available) on the company page.

A query syntax like “[business type] reporting template” would indicate to a company like Google that they should build standardized, industry-specific templates for Google Data Studio.

Examples for ADK clients:

SDP could be something like "[design style] inspiration"

CAPA could be "[destination] packing list"

**Ways** to discover queries that follow a pattern ([[keyword research]])

#[[ahrefs]] content gap tool to see what keywords your competitors rank for but you don't

Set "word count" to a minimum of 3 words (to find only longtail keywords)

In #[[ahrefs]], filter your domains keywords for a higher word count (eg, 5+) and lower positions (20-40) to see what patterns you already rank for, just poorly

Optimize for this pattern

Look at your websites internal search

#ahrefs content explorer can also show topics gaining traction on the web more broadly

This needs to be seeded with your [[jtbd]]

### Finally, make new product features #SEO friendly

Build a new page or add a feature to existing pages?

If your existing pages already target a clear intent, and the new feature would dilute it, create a new page for it.

If the new feature is additive or complementary, integrate it on existing pages.

You can also test at a smaller scale to see if it one solution ranks for one query

### Keys to adding SEO friendly features

Accessibility: Speed, mobile friendliness, visibility, etc. 

This is technical

Discoverability: Internal links and XML sitemaps., no orphaned pages

Technical

To mitigate issues: add a homepage module that links to hub pages (category pages) and ensure you link between new feature pages

Relevance: Features/content need to address a new user intent or job-to-be-done (or address it better)

This is keyword research: Does the content you're providing match the intent of the searcher? Does it provide value?

## Pitching new features

Define the value by estimating traffic numbers from the query research you did earlier. Ideally, connect traffic to conversion numbers

Start small

Roll it out on a subset of pages or limited functionality (be sure to set different expectations for an MVP launch vs. the actual launch - in other words: define the threshold you need to hit to decide to invest further

