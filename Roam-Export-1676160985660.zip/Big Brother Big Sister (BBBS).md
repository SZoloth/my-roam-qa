[[activities]] for #[[nayvon]] and [[things to do with ally]] in [[boston]]

ice skating

bowling

museums

aquarium

zoo

arts & crafts

cooking

kayaking

duck tours

[[BK/Brooklyn]] boulders

needs advance planning

diablo glass blowing

