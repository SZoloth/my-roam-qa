Author:: [[humanparts.medium.com]]

URL:: https://humanparts.medium.com/reflections-from-a-token-black-friend-2f1ea522d42d

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

For those wondering about the structural side of systemic racism, I’d ask you to consider a few questions. First: Why does METCO still exist? Segregation ended more than 60 years ago, yet there is a still a fully functioning integration program in our state. We haven’t come very far at all. Many of our schools remain nearly as segregated as they were in the 1960s. 

As for the Boston students, most of whom are black, they receive a much higher-quality education. Property taxes, a structural form of racism meant to allow segregation to endure, have ensured that while schools have grown increasingly better in our suburbs, the inner-city schools continue to struggle with resources, attendance, and graduation rates. 

I think of how quickly others in school assumed I had a single mother, simply because my father, much like many of theirs, didn’t visit school often. Or the number of times I’ve heard “you are so articulate” in a conversation where all I’ve shared is my name and other small personal details. Standing alone, each instance may seem insignificant or merely a compliment to my upbringing and education. However, the frequency with which I’ve received that comment tells otherwise. It reveals how a black kid speaking properly is surprising, and further, how it makes me appear worthy of sharing the person’s company. 

It was especially hard for me because, outside of that statement, there was nothing to suggest he was racist. 

It was simply ignorance, which had probably been reinforced countless times. That was difficult to wrestle with. 

Every token black friend can recall the times when a white friend chooses to dub you “the whitest black kid I know.” 

Another example: when I am criticized by my white friends for code-switching when I am with my black friends, just because they don’t understand the slang and how it connects black people to a common culture. 

I’d emphasize that most white people do not understand their level of ignorance — especially the good ones, who mean well, and that negligence is part of the problem. 

The problematic result of these overtly racist situations is that good white people feel liberated from any responsibility concerning the privilege, structural racism, and implicit biases that do not make them racist themselves, but that they do benefit from. This moment is one of the first times I have felt it was not only okay but encouraged to share these things. 

If there is one thing every token black friend knows, it is that we are not to provoke serious discussions of racial issues among our white crowd. We should only offer an opinion on such matters when invited to do so by our white peers. 

You can celebrate black lives by making a choice to inquire about them, to educate yourself, and to question many of the norms around us. You no longer have the excuse of being unaware of your own ignorance. I’d reword my uncle’s post to a question that we should all ask ourselves: “When the dust settles, I wonder if I will actually change?” 

