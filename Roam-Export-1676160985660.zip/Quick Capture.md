[[STEAM-2526]]: Booking Bar UI | Research Add Passengers Button #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-2504]]: Content | Error message - error loading availability #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-2381]]: Write copy for esignature terms & request process #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-2261]]: Content | Student Commuter [[ticket book]] #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-1323]]: Content/Design/Strat/Dev | Follow up with Sean around News needs 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1324]]: Content/Design/Strat/Dev | Come up with a blog launch and then release plan 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-952]]: Family accounts 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1323]]: Content/Design/Strat/Dev | Follow up with Sean around News needs 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1324]]: Content/Design/Strat/Dev | Come up with a blog launch and then release plan 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1031]]: Accessibility-related needs 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1406]]: Trip watcher 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1406]]: Trip watcher #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-1405]]: [[waitlist]] estimator #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-1031]]: Accessibility-related needs 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1324]]: Content/Design/Strat/Dev | Come up with a blog launch and then release plan 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1323]]: Content/Design/Strat/Dev | Follow up with Sean around News needs 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1323]]: Content/Design/Strat/Dev | Follow up with Sean around News needs 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1324]]: Content/Design/Strat/Dev | Come up with a blog launch and then release plan 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1324]]: Content/Design/Strat/Dev | Come up with a blog launch and then release plan 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1324]]: Content/Design/Strat/Dev | Come up with a blog launch and then release plan 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1323]]: Content/Design/Strat/Dev | Follow up with Sean around News needs 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1324]]: Content/Design/Strat/Dev | Come up with a blog launch and then release plan 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1323]]: Content/Design/Strat/Dev | Follow up with Sean around News needs 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1323]]: Content/Design/Strat/Dev | Follow up with Sean around News needs 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1031]]: Accessibility-related needs 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1031]]: Accessibility-related needs 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-969]]: repurpose 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1324]]: Content/Design/Strat/Dev | Come up with a blog launch and then release plan #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-1323]]: Content/Design/Strat/Dev | Follow up with Sean around News needs #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-1323]]: Content/Design/Strat/Dev | Follow up with Sean around News needs 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1322]]: Content/Design/Strat/Dev | Follow up with Sean and Kimberlee on event content needs 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1324]]: Content/Design/Strat/Dev | Come up with a blog launch and then release plan 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1044]]: Track reservation edit/change history 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-962]]: Create a roadmap 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-384]]: Mktg | Build Measurement Plan 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-969]]: Advertising guidelines 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1069]]: Analytics map 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-961]]: Summarize [[insight]]s from user interviews 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-963]]: Summarize opportunities from on-site 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1069]]: Analytics map #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-964]]: Upload remaining recordings to notably 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-963]]: Summarize opportunities from on-site 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-961]]: Summarize [[insight]]s from user interviews 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1031]]: Accessibility-related needs 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1021]]: Strategy | Spike | What are the differences between a business account and a personal one? 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1021]]: Strategy | Spike | What are the differences between a business account and a personal one? 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1034]]: Filter upcoming reservations 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1033]]: Calendar view of future trips #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-1034]]: Filter upcoming reservations #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-955]]: Scan documents with OCR for [[program]] applications 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-946]]: [[waitlist]] position updates 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1033]]: Calendar view of future trips 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-970]]: Homepage strat 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-759]]: Analytics | Define analytics requirements for dev team. 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-533]]: Document & activate requirements 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-533]]: Document & activate requirements 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-977]]: Pressure test imarc's GA code updates 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-897]]: Marketing Content | First pass at About pages 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-913]]: Design/Strat | Start documenting [[alerts]] 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-973]]: Mobile app workshop 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-964]]: Upload remaining recordings to notably 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-963]]: Summarize opportunities from on-site 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-961]]: Summarize [[insight]]s from user interviews 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-961]]: Summarize [[insight]]s from user interviews 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-973]]: Mobile app workshop 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-964]]: Upload remaining recordings to notably 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-973]]: Mobile app workshop 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-897]]: Marketing Content | First pass at About pages 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-966]]: Content review 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-964]]: Upload remaining recordings to notably 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-973]]: Mobile app workshop 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-897]]: Marketing Content | First pass at About pages 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-977]]: Pressure test imarc's GA code updates #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-977]]: Pressure test imarc's GA code updates 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-972]]: Marketing Content | About page content revisions 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-973]]: Mobile app workshop #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-973]]: Mobile app workshop 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-966]]: Content review 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-970]]: Homepage strat #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-969]]: Advertising guidelines #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-961]]: Summarize [[insight]]s from user interviews 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-966]]: Content review 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-961]]: Summarize [[insight]]s from user interviews 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-962]]: Create a roadmap 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-963]]: Summarize opportunities from on-site 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-967]]: Win more ACK passenger traffic #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-966]]: Content review 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-966]]: Content review 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-533]]: Document & activate requirements 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-966]]: Content review #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-964]]: Upload remaining recordings to notably 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-963]]: Summarize opportunities from on-site 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-963]]: Summarize opportunities from on-site #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-962]]: Create a roadmap #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-964]]: Upload remaining recordings to notably #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-913]]: Design/Strat | Start documenting [[alerts]] 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-944]]: Accurate and timely [[standby]] data 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-944]]: Accurate and timely [[standby]] data 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-944]]: Accurate and timely [[standby]] data #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-944]]: Accurate and timely [[standby]] data 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-759]]: Analytics | Define analytics requirements for dev team. 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-913]]: Design/Strat | Start documenting [[alerts]] 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-913]]: Design/Strat | Start documenting [[alerts]] #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-913]]: Design/Strat | Start documenting [[alerts]] 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-759]]: Analytics | Define analytics requirements for dev team. 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-759]]: Analytics | Define analytics requirements for dev team. 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-706]]: Outline recommended updates to current GA setup in order to start collecting benchmark data -> send to SSA for thumbs up/down 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-706]]: Outline recommended updates to current GA setup in order to start collecting benchmark data -> send to SSA for thumbs up/down 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-707]]: Provide best practices for privacy policies re: GDPR and CCPA (keeping these distinct as it makes sense) 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-707]]: Provide best practices for privacy policies re: GDPR and CCPA (keeping these distinct as it makes sense) 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-707]]: Provide best practices for privacy policies re: GDPR and CCPA (keeping these distinct as it makes sense) 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-643]]: Dev & Strategy | Align on URL strategy 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-707]]: Provide best practices for privacy policies re: GDPR and CCPA (keeping these distinct as it makes sense) 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-643]]: Dev & Strategy | Align on URL strategy 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-707]]: Provide best practices for privacy policies re: GDPR and CCPA (keeping these distinct as it makes sense) 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-643]]: Dev & Strategy | Align on URL strategy 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-643]]: Dev & Strategy | Align on URL strategy 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-711]]: Design | Run User Testing to get [[feedback]] on Dashboard  
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-706]]: Outline recommended updates to current GA setup in order to start collecting benchmark data -> send to SSA for thumbs up/down 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-706]]: Outline recommended updates to current GA setup in order to start collecting benchmark data -> send to SSA for thumbs up/down 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-706]]: Outline recommended updates to current GA setup in order to start collecting benchmark data -> send to SSA for thumbs up/down 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-706]]: Outline recommended updates to current GA setup in order to start collecting benchmark data -> send to SSA for thumbs up/down 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-706]]: Outline recommended updates to current GA setup in order to start collecting benchmark data -> send to SSA for thumbs up/down 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-706]]: Outline recommended updates to current GA setup in order to start collecting benchmark data -> send to SSA for thumbs up/down 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-706]]: Outline recommended updates to current GA setup in order to start collecting benchmark data -> send to SSA for thumbs up/down 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-706]]: Outline recommended updates to current GA setup in order to start collecting benchmark data -> send to SSA for thumbs up/down 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-649]]: Edit the discovery deck for the public board meeting 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-706]]: Outline recommended updates to current GA setup in order to start collecting benchmark data -> send to SSA for thumbs up/down 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-649]]: Edit the discovery deck for the public board meeting 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-742]]: Test vert vs. horizontal with Optimal Workshop 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-711]]: Design | Run User Testing to get [[feedback]] on Dashboard  
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-627]]: What data do we need from the database? 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-742]]: Test vert vs. horizontal with Optimal Workshop #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-742]]: Test vert vs. horizontal with Optimal Workshop 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-627]]: What data do we need from the database? 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-167]]: UX audit of mobile and desktop experience of website 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-627]]: What data do we need from the database? 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-649]]: Edit the discovery deck for the public board meeting 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-627]]: What data do we need from the database? 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-529]]: Align on testing plan: Hypotheses, Experiment Design, Prioritization, Communication & Application 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-226]]: PA | Assumptions to test 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-649]]: Edit the discovery deck for the public board meeting 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-627]]: What data do we need from the database? 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-647]]: Document how discounts work 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-626]]: Message for client re: lack of data/privacy compliance 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-532]]: User Interview plan: Recruitment, Cadence, Process, Application 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-649]]: Edit the discovery deck for the public board meeting 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-627]]: What data do we need from the database? 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-649]]: Edit the discovery deck for the public board meeting #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-529]]: Align on testing plan: Hypotheses, Experiment Design, Prioritization, Communication & Application 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-534]]: Document assumptions 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-243]]: Validate breakdown of operational vs. main site content with the client 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-647]]: Document how discounts work 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-649]]: Edit the discovery deck for the public board meeting 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-647]]: Automate finding, applying for, and using discounts 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-647]]: Automate finding, applying for, and using discounts 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-626]]: Message for client re: lack of data/privacy compliance 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-647]]: Automate finding, applying for, and using discounts 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-647]]: Automate finding, applying for, and using discounts #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-626]]: Message for client re: lack of data/privacy compliance 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-626]]: Message for client re: lack of data/privacy compliance 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-167]]: UX audit of mobile and desktop experience of website 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-627]]: What data do we need from the database? 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-532]]: User Interview plan: Recruitment, Cadence, Process, Application 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-529]]: Align on testing plan: Hypotheses, Experiment Design, Prioritization, Communication & Application 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-534]]: Document assumptions 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-226]]: PA | Assumptions to test 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-627]]: What data do we need from the database? 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-375]]: UX | Create Design Stories/Tasks for Design Phase  
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-627]]: What data do we need from the database? 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-367]]: PA | Summary and follow up for the Story Mapping exercise 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-534]]: Document assumptions 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-534]]: Document assumptions 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-627]]: What data do we need from the database? 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-627]]: What data do we need from the database? #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-627]]: What data do we need from the database? 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-532]]: User Interview plan: Recruitment, Cadence, Process, Application 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-532]]: User Interview plan: Recruitment, Cadence, Process, Application 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-182]]: PA | Story mapping exercise  
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-534]]: Document assumptions 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-367]]: PA | Summary and follow up for the Story Mapping exercise 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-529]]: Align on testing plan: Hypotheses, Experiment Design, Prioritization, Communication & Application 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-347]]: PA | Review the User Map Review recording & update notes 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-532]]: User Interview plan: Recruitment, Cadence, Process, Application 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-347]]: PA | Review the User Map Review recording & update notes 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-534]]: Document [[assumption]]s 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-367]]: PA | Summary and follow up for the Story Mapping exercise 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-449]]: Find and collect any question/help/error/complaint searches on Google, the website, and maybe social 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-532]]: User Interview plan: Recruitment, Cadence, Process, Application 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-449]]: Find and collect any question/help/error/complaint searches on Google, the website, and maybe social 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-531]]: Revisit Parking Lot Opportunities with Ben Kaplan 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-530]]: Follow up on North Star Metric w/ Dave + Sean 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-237]]: Understand existing: [[outcome]]s, Metrics, and Goals (OMG) 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-530]]: Follow up on North Star Metric w/ Dave + Sean 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-531]]: Revisit Parking Lot Opportunities with Ben Kaplan 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-326]]: PA | Clarify deliverables for Focused Innovation 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-350]]: Update Post-Project tracker 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-529]]: Align on testing plan: Hypotheses, Experiment Design, Prioritization, Communication & Application 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-530]]: Follow up on North Star Metric w/ Dave + Sean 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-227]]: Assess need/opportunity for user research in FI 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-532]]: User Interview plan: Recruitment, Cadence, Process, Application 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-531]]: Revisit Parking Lot Opportunities with Ben Kaplan 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-534]]: Document [[assumption]]s 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-530]]: Follow up on North Star Metric w/ Dave + Sean #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-529]]: Align on testing plan: Hypotheses, Experiment Design, Prioritization, Communication & Application #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-531]]: Revisit Parking Lot Opportunities with Ben Kaplan #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-532]]: User Interview plan: Recruitment, Cadence, Process, Application #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-534]]: Document [[assumption]]s #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-370]]: Mktg | Define & Compare Scalable Analytics Contenders 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-238]]: Align on advertising needs with client 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-354]]: PA | Finalize [[[[product]] [[strategy]]]] document 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-353]]: PA | Review [[[[product]] [[strategy]]]] document 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-227]]: Assess need/opportunity for user research in FI 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-352]]: PA | Draft [[[[product]] [[strategy]]]] document 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-242]]: PA | Explain why blockchain/crypto/NFTs are not a high priority for this project 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-296]]: Mktg | Explore alternatives to GA 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-370]]: Mktg | Define & Compare Scalable Analytics Contenders 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-240]]: Validate content audit criteria with the client 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-448]]: Put together a pivot table of keyword volume by the different "activity" tags in that "New SSA Competitor Audit" .xls 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-243]]: Validate breakdown of operational vs. main site content with the client 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-237]]: Understand existing: [[outcome]]s, Metrics, and Goals (OMG) 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-238]]: Align on advertising needs with client 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-182]]: PA | Story mapping exercise  
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-352]]: PA | Draft [[[[product]] [[strategy]]]] document 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-368]]: Mktg | Define Compliance for: Mass Pub Records Act, GDPR, CCPA 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-351]]: Prep North Star Metric workshop 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-386]]: Review the future state outline 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-366]]: PA | Review future state with MC in preparation for reviewing with client 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-386]]: Review the future state outline 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-349]]: Summarize learnings + follow ups for HR/Hiring Needs discussion 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-281]]: Prepare content/marketing performance audit doc/presentation for client 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-281]]: Prepare content/marketing performance audit doc/presentation for client 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-266]]: Conduct competitive SEO audit 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-386]]: Review the future state outline 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-386]]: Review the future state outline #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-298]]: Story mapping exercise prep 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-329]]: Mktg | reporting follow-up with Kimberlee 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-238]]: Align on advertising needs with client 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-375]]: UX | Create Design Stories/Tasks for Design Phase  
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-238]]: Align on advertising needs with client 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-266]]: Conduct competitive SEO audit 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-281]]: Prepare content/marketing performance audit doc/presentation for client 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-329]]: Mktg | reporting follow-up with Kimberlee 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-237]]: Understand existing: [[outcome]]s, Metrics, and Goals (OMG) 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-350]]: Update Post-Project tracker 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-349]]: Summarize learnings + follow ups for HR/Hiring Needs discussion 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-298]]: Story mapping exercise prep 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-347]]: PA | Review the User Map Review recording & update notes 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-351]]: Prep North Star Metric workshop 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-326]]: PA | Clarify deliverables for Focused Innovation 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-266]]: Conduct competitive SEO audit 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-375]]: UX | Create Design Stories/Tasks for Design Phase  
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-349]]: Summarize learnings + follow ups for HR/Hiring Needs discussion 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-298]]: Story mapping exercise prep 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-347]]: PA | Review the User Map Review recording & update notes 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-349]]: Summarize learnings + follow ups for HR/Hiring Needs discussion 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-237]]: Understand existing: [[outcome]]s, Metrics, and Goals (OMG) 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-281]]: Prepare content/marketing performance audit doc/presentation for client 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-349]]: Summarize learnings + follow ups for HR/Hiring Needs discussion 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-351]]: Prep North Star Metric workshop 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-347]]: PA | Review the User Map Review recording & update notes 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-350]]: Update Post-Project tracker 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-356]]: Outline Discovery Summary Slides 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-354]]: PA | Finalize [[[[product]] [[strategy]]]] document 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-352]]: PA | Draft [[[[product]] [[strategy]]]] document 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-353]]: PA | Review [[[[product]] [[strategy]]]] document 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-375]]: UX | Create Design Stories/Tasks for Design Phase  #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-375]]: UX | Create Design Stories/Tasks for Design Phase  
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-367]]: PA | Summary and follow up for the Story Mapping exercise 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-366]]: PA | Review future state with MC in preparation for reviewing with client 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-98]]: Content - Marketing Performance Audit 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-352]]: Draft [[[[product]] [[strategy]]]] document 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-354]]: Finalize [[[[product]] [[strategy]]]] document 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-353]]: Review [[[[product]] [[strategy]]]] document 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-124]]: PA | Create roadmap and/or phase (release) definition 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-123]]: PA | Create Summary of Findings deck and presentation 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-236]]: PA | Business [[model]] Canvas 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-349]]: Summarize learnings + follow ups for HR/Hiring Needs discussion 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-351]]: Prep North Star Metric workshop 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-355]]: Review [[[[discovery]] [[summary]]]] questions 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-356]]: Outline [[[[discovery]] [[summary]]]] Slides 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-298]]: Story mapping exercise prep 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-123]]: PA | Create Summary of Findings deck and presentation 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-238]]: Align on advertising needs with client 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-227]]: Assess need/opportunity for user research in RR and FI 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-266]]: Conduct competitive SEO audit 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-366]]: Review future state with MC in preparation for reviewing with client 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-354]]: Finalize [[[[product]] [[strategy]]]] document 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-366]]: Review future state with MC in preparation for reviewing with client 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-367]]: Summary and follow up for the Story Mapping exercise 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-354]]: Finalize [[[[product]] [[strategy]]]] document 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-242]]: PA | Explain why blockchain/crypto/NFTs are not a high priority for this project 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-123]]: PA | Create Summary of Findings deck and presentation 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-124]]: PA | Create roadmap and/or phase (release) definition 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-226]]: PA | [[assumption]]s to test 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-236]]: PA | Business [[model]] Canvas 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-353]]: Review [[[[product]] [[strategy]]]] document 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-352]]: Draft [[[[product]] [[strategy]]]] document 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-367]]: Summary and follow up for the Story Mapping exercise #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-182]]: PA | Story mapping exercise  
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-367]]: Summary and follow up for the Story Mapping exercise 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-366]]: Review future state with MC in preparation for reviewing with client 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-366]]: Review future state with MC in preparation for reviewing with client #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-329]]: Mktg | reporting follow-up with Kimberlee 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-355]]: Review [[[[discovery]] [[summary]]]] questions 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-347]]: PA | Review the User Map Review recording & update notes 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-355]]: Review [[[[discovery]] [[summary]]]] questions 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-356]]: Outline [[[[discovery]] [[summary]]]] Slides #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-355]]: Review [[[[discovery]] [[summary]]]] questions #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-355]]: Review [[[[discovery]] [[summary]]]] questions 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-348]]: Prep for HR/Hiring Needs discussion 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-347]]: PA | Review the User Map Review recording & update notes 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-356]]: Outline [[[[discovery]] [[summary]]]] Slides 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-350]]: Update Post-Project tracker 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-354]]: Finalize [[[[product]] [[strategy]]]] document 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-237]]: Understand existing: [[outcome]]s, Metrics, and Goals (OMG) 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-351]]: Prep North Star Metric workshop 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-349]]: Summarize learnings + follow ups for HR/Hiring Needs discussion 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-352]]: Draft [[[[product]] [[strategy]]]] document 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-238]]: Align on advertising needs with client 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-348]]: Prep for HR/Hiring Needs discussion 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-353]]: Review [[[[product]] [[strategy]]]] document 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-352]]: Draft [[[[product]] [[strategy]]]] document #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-353]]: Review [[[[product]] [[strategy]]]] document #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-351]]: Prep North Star Metric workshop #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-354]]: Finalize [[[[product]] [[strategy]]]] document #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-347]]: PA | Review the User Map Review recording & update notes 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-348]]: Prep for HR/Hiring Needs discussion 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-349]]: Summarize learnings + follow ups for HR/Hiring Needs discussion 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-350]]: Update Post-Project tracker 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-347]]: PA | Review the User Map Review recording & update notes #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-237]]: Understand existing: [[outcome]]s, Metrics, and Goals (OMG) 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-237]]: Understand existing: [[outcome]]s, Metrics, and Goals (OMG) 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-279]]: Finalize architecture characteristics 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-326]]: PA | Clarify deliverables for Focused Innovation 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-124]]: PA | Create roadmap and/or phase (release) definition 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-123]]: PA | Create Summary of Findings deck and presentation 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-182]]: PA | Story mapping exercise  
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-236]]: PA | Business [[model]] Canvas 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-242]]: PA | Explain why blockchain/crypto/NFTs are not a high priority for this project 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-226]]: PA | [[assumption]]s to test 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-237]]: Understand existing: [[outcome]]s, Metrics, and Goals (OMG) 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-237]]: Understand existing: [[outcome]]s, Metrics, and Goals (OMG) 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-279]]: Finalize architecture characteristics 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-298]]: Story mapping exercise prep 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-328]]: track ad clicks 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-229]]: Assess priority and needs around Partnerships & Advertising 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-238]]: Align on advertising needs with client 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-327]]: What are the final deliverables for Focused Innovation? 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-328]]: track ad clicks 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-328]]: track ad clicks 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-98]]: Content - Marketing Performance Audit 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-327]]: What are the final deliverables for Focused Innovation? 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-326]]: Clarify deliverables for Focused Innovation #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-327]]: What are the specific questions around deliverables for FI? #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-228]]: Plan to capture HR and Hiring needs 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-227]]: Assess need/opportunity for user research in RR and FI 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-279]]: Finalize architecture characteristics 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-243]]: Validate breakdown of operational vs. main site content with the client 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-240]]: Validate content audit criteria with the client 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-98]]: Content - Marketing Performance Audit 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-227]]: Assess need/opportunity for user research in RR and FI 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-228]]: Plan to capture HR and Hiring needs 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-227]]: Assess need/opportunity for user research in RR and FI 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-226]]: [[assumption]]s to test 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-229]]: Assess priority and needs around Partnerships & Advertising 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-297]]: [[schedule]] intro to UTMs call w/ Kimberlee McHugh 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-98]]: Content - Marketing Performance Audit 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-229]]: Assess priority and needs around Partnerships & Advertising 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-263]]: Build trust + excitement w/ Kimberlee by solving ad tracking ASAP 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-120]]: Understand requirements for CMS UI/strategy 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-238]]: Align on advertising needs with client 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-229]]: Assess priority and needs around Partnerships & Advertising 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-228]]: Plan to capture HR and Hiring needs 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-229]]: Assess priority and needs around Partnerships & Advertising 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-228]]: Plan to capture HR and Hiring needs 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-228]]: Plan to capture HR and Hiring needs 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-279]]: Finalize architecture characteristics 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-237]]: Understand existing: [[outcome]]s, Metrics, and Goals (OMG) 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-228]]: Plan to capture HR and Hiring needs 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-238]]: Plan to capture advertising/partnership needs 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-240]]: Validate content audit criteria with the client 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-229]]: Assess priority and needs around Partnerships & Advertising 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-299]]: Collect CMS pain points, [[assumption]]s, requirements, and questions #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-299]]: Collect CMS pain points, [[assumption]]s, requirements, and questions 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-223]]: Collect and organize learnings, opportunities, questions 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-298]]: Story mapping exercise prep 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-298]]: Story mapping exercise prep #jira #ticket #[[🚢 Steamship Authority]]

[[STEAM-279]]: Finalize architecture characteristics 
[[status]]: In Progress
[[description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-294]]: Draft discovery deck skeleton/outline #[[[[jira]] ticket]] #[[🚢 Steamship Authority]]

[[STEAM-2108]]: Content | Vehicle Dimensions blog post 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2182]]: Content | Draft introduction to [[waitlist]] for the date selection step 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2108]]: Content | Vehicle Dimensions blog post 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-864]]: Micro copy  | Account  
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2108]]: Content | Vehicle Dimensions blog post 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1778]]: Content | Internal CTA content 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1780]]: Content | Profile and Preferences Dashboard content 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2196]]: Add email communications opt-in language to account creation flow 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2261]]: Content | Student Commuter [[ticket book]] 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2108]]: Content | Vehicle Dimensions blog post 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1743]]: Content | Create What To Do posts for each island 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1741]]: Resident Programs Landing Pages - Both Islands 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1887]]: Content | Create content for blog posts that used to be tertiary pages 2 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1779]]: Content | Reservation summary sidebar CTA content 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1846]]: Web New User Onboarding experience 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1069]]: Revisit benchmarking 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1739]]: Design | QA Coded Designs 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1777]]: Content | Tool tip content 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1779]]: Content | Reservation summary sidebar CTA content 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1777]]: Content | Tool tip content 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1779]]: Content | Reservation summary sidebar CTA content 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1777]]: Content | Tool tip content 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2202]]: As an analyst, I want to be able to report how long it takes users to complete a reservation 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2202]]: As an analyst, I want to be able to report how long it takes users to complete a reservation 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-947]]: Trip search 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-949]]: Freight booking experience 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1741]]: Resident Programs Landing Pages - Both Islands 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1779]]: Content | Reservation summary sidebar CTA content 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1887]]: Content | Create content for blog posts that used to be tertiary pages 2 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1741]]: Resident Programs Landing Pages - Both Islands 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1846]]: Web New User Onboarding experience 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1779]]: Content | Reservation summary sidebar CTA content 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1846]]: Web New User Onboarding experience 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1777]]: Content | Tool tip content 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1069]]: Revisit benchmarking 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1069]]: Revisit benchmarking 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1846]]: Web New User Onboarding experience 
[[status]]: [[READY FOR REVIEW]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2202]]: As an analyst, I want to be able to report how long it takes users to complete a reservation 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1846]]: Web New User Onboarding experience 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1069]]: Revisit benchmarking 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1069]]: Revisit benchmarking 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1069]]: Revisit benchmarking 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1919]]: Implement copy from mobile app testing 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1744]]: Content | Create blog post for Change / Cancel reservations 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1741]]: Resident Programs Landing Pages - Both Islands 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1739]]: Design | QA Coded Designs 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1739]]: Design | QA Coded Designs 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1634]]: Content | Create content for Commercial Freight 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1741]]: Resident Programs Landing Pages - Both Islands 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2381]]: Write copy for esignature terms & request process 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2328]]: Dev | Edit or Save Travel Settings (default trip): Trip Summary screen 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1779]]: Content | Reservation summary sidebar CTA content 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1779]]: Content | Reservation summary sidebar CTA content 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1779]]: Content | Reservation summary sidebar CTA content 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1744]]: Content | Create blog post for Change / Cancel reservations 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1634]]: Content | Create content for Commercial Freight 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2108]]: Content | Vehicle Dimensions blog post 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1846]]: Web New User Onboarding experience 
[[status]]: [[Done]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1742]]: Alert / [[notifications]] templates  
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1744]]: Content | Create blog post for Change / Cancel reservations 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1634]]: Content | Create content for Commercial Freight 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1887]]: Content | Create content for blog posts that used to be tertiary pages 2 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1779]]: Content | Reservation summary sidebar CTA content 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1779]]: Content | Reservation summary sidebar CTA content 
[[status]]: [[In Progress]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2504]]: Content | Error message - error loading availability 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1634]]: Content | Create content for Commercial Freight 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-1744]]: Content | Create blog post for Change / Cancel reservations 
[[status]]: [[Blocked by Client]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2526]]: Booking Bar UI | Research Add Passengers Button 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2526]]: Booking Bar UI | Research Add Passengers Button 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

[[STEAM-2526]]: Booking Bar UI | Research Add Passengers Button 
[[status]]: [[To Do]]
[[Description]]: 

#jira #ticket #updated #[[🚢 Steamship Authority]]

