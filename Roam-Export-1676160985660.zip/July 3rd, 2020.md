#[[Quick Capture]]

pair chefs with local suppliers to craft dinners. create kits from the supplier to send to people. work with chef to create video tutorials (recipes)

subscribe to save weekly or buy one off at a premium 

