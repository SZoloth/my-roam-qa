[[People at ADK]]

My team

[[nick watkins]]

I would be totally fine doing any part - outlines, or doing the actual writing (which I think keyword research would be part of either/or). Writing blogs for our own company was one of my favorite things back in the olden days.

## Is responsible for:

1 adk blog post every 2 weeks

1 adk outline every 1 week

Posting all blogs?

[[jordan daly]]

What I would like to do is actually write and edit writing, as well as oversee much of it. What I like is the writing & editing part. Topics are sort of fun and easy too.

The keywords part is where I would prefer to stay out of it, other than maybe review data pulled relative to topics

I think I just feel a bit stretched thin between PM, Excution, and general overseeing our team's execution here on all accounts.

## Is responsible for:



