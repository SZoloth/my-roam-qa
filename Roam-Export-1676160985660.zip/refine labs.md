## {{[[DONE]]}} How will we promote/support [[refine labs]] project? #/ 

Assets:

Longform podcast

Short audio clips

Short video

Long video?

SMEs

Distribution:

Transcribe Longform podcast

Edit and publish on blog

Embed: YT clips, full audio

Share blog post on email, social media

Promote signups for podcast by

Pitch Dan Tatar as guest on other podcasts

SparkToro

Short video clips

Publish on social media, YouTube

Share on email

Turn into email lessons?

Process:

Refine Labs assets created:

Longform audio

Do: 

Transcribe & edit

Moz whiteboard fridays use [speechpad](https://www.speechpad.com/pricing), which starts at $1/minute

Create an image template with speaker + impactful quote

Create a new blog category

Publish: blog

Distribute: email, social, reach out to any clients/companies/people mentioned

Short video clips

Publish: Natively to every social channel (including YT)

Distribute: social, paid promo handled on case-by-case basis, alert internal team

Longform video?

Publish: YouTube

Distribute: email, social, embed in longform blog

Podcast

Distribute:

Podcast channels: itunes, spotify, stitcher, soundcloud, deezer, iheart radio, overcast, breaker, pocket casts (using [simplecast](https://simplecast.com/)?)

Promo on site

low-fi/DIY: Launch blog + announcement banner

hi-fi: minisite for podcast (simplecast?) + announcement banner

Phase 2: Use SparkToro to find other podcasts for hosts to be featured on / advertise on

