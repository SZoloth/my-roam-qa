[[Personal Task Management]]

{{[[DONE]]}} prep for [[Vinalhaven]] #/

{{[[DONE]]}} Groceries

Laundry

Bills

{{{[[DONE]]}}}} Contact solution

{{[[DONE]]}} Retainer drops

[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}} Where did [[Cambridge Associates]] come from?

{{{[[DONE]]}}}} [[Museum of Science]] referral strat

send an email to current clients asking for emails

{{{[[DONE]]}}}} MIT PEL analytics #Delegated[[darci nevitt]]

{{{[[DONE]]}}}} Ads for Facebook / Google #Delegated[[darci nevitt]]

{{{[[DONE]]}}}} SDP link building #/

{{{[[DONE]]}}}} Review an [ADK instagram post](https://docs.google.com/document/d/10-cg9lQDl7XrvMEeuAFtbz0Mv8k1_F13TvOQi_X6iJg/edit#) from [[nick watkins]]

{{[[DONE]]}} Make the [[DCF]] case study anonymous and incorporate [[feedback]] from [[Dan Allard]] #//

[[Meetings]]: About the [[Museum of Science]]

Attendees:: [[darci nevitt]]

Time:: 09:34

Notes::

From [[Lauren McDonough]]

Confused because we went into tactics without big idea

2 ideas that aren't completely fleshed out

tagline, overarching message

Felt that the messaging wasn't specific enough to the new product line

 Referral program?

[[Meetings]]: internal regroup on [[Drawbridge]]

Attendees:: [[jayne hetherington]] [[sean riley]] [[alex fedorov]]

Time:: 10:03

Notes::

????

