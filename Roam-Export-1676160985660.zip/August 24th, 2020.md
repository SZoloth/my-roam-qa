[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} For [[Museum of Science]]: #/

Review

Facebook

Landing page

Example emails & [[feedback]]

https://docs.google.com/document/d/1fK4jEk0cSQwAq8cIpDACcpMI7l4x6r6TFELyHuPIEjM/edit?usp=sharing

https://docs.google.com/document/d/13HElrzjfida0rgLBTgQQhHtzMuQ8cWYrlk_kBYw_LkE/edit?usp=sharing

https://docs.google.com/document/d/1sQVxgWlnbft39EOm5PSF2N7_YbX9HAJ3UBjH3PRjLZ0/edit?usp=sharing

Write

emails for [[Museum of Science]]

Review Example emails & [[feedback]]

Based on "My Dream is to Explore. Math is my ticket." ^^creative strategy positioning^^

Example from [[Lauren McDonough]]

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FA3gbS24Ccd.png?alt=media&token=1e9538b6-28cc-452c-a6d1-80ab814870a3)

I could be the next Elon Musk. I just need the right introduction to STEM. 

You're teaching the next generation of {{or: problem solvers|scientists|engineers|entrepreneurs|role [[model]]s|big thinkers|critical thinkers|mathematicians|biochemical engineers|computer scientists}}. 

Create the next generation of {{or: problem solvers|scientists|engineers|entrepreneurs|role [[model]]s|big thinkers|critical thinkers}}.

^^**Tomorrow's**^^ {{or: problem solvers|scientists|engineers|entrepreneurs|role [[model]]s|big thinkers|critical thinkers|mathematicians|biochemical engineers|computer scientists}} ^^**are being made in EiE classrooms today.**^^

**Today, your students are designing maglev systems and building automated computer systems. Tomorrow, they're doing it in real life. **

Today, your students are designing computer games in your classroom. Tomorrow, they're doing it in real life. 

^^**Today, I'm designing maglev systems and building automated computer systems in your classroom. Tomorrow, I'm doing it in real life. **^^

These are the challenges that fuel tomorrow's {{or: problem solvers|scientists|engineers|entrepreneurs|role [[model]]s|big thinkers|critical thinkers|mathematicians|biochemical engineers|computer scientists}}.

Technology is all around me. I just need the right introduction to it. 

I'm one of the 5 million students enjoying EiE's introduction to STEM

I'm one of the 44,000 educators inspiring a lifelong passion for engineering in my elementary school classes. How do I do it? 

**For me, engineering + computer science = **{{or: a future in STEM|a passion for problem solving|a fulfilling [[career]] path}}

Target audience: cold

Dear {{title}} {{name}},

If {{or: district is like | you're like}} the other {{or: districts|educators}} I've been talking to, the recent NGSS updates have pushed the development of science skills, critical thinking, and discovery to the top of your priorities for this year. 

You also might be struggling to balance that with budgets and limited teacher time. 

So I thought you'd be interested in early access to the new integrated STEM curriculum from Engineering is Elementary.

Engineering is Elementary (EiE) is the award-winning curricula division of the Museum of Science, Boston. We're here to provide educators like you with the tools that cultivate problem solving and innovation in your students through joyful and inspiring hands-on engineering activities. 

Our latest curriculum, __Engineering & Computer Science Essentials: An Integrated Program__, is based on the same principles (and research) that make EiE curricula proven to increase STEM scores, adopted by school districts across the country, and endorsed by the NSF.

You can learn more here, or I could give you a personalized walk through - what do you say?

Target audience: lead

Draft: Lite edits with Lauren [[feedback]]

Dear {{title}} {{name}},

If {{or: district is like | you're like}} the other {{or: districts|educators}} I've been talking to, the recent NGSS updates have pushed the development of critical thinking, discovery, and a passion for science to the top of your priorities for this year. 

You also might be struggling to balance that with budgets and limited teacher time. 

So I thought you'd be interested in early access to the new integrated STEM curriculum from Engineering is Elementary (see below for how to get it).

__Engineering & Computer Science Essentials: An Integrated Program__ is based on the same principles (and research) that make EiE curricula proven to increase STEM scores, adopted by school districts across the country, and endorsed by the NSF.

This game-changing integrated STEM curriculum:

combines science, mathematics, and technology into one engaging and inspiring program

reinforces the Habits of Mind that help your students persevere through failure

creates classroom equity to help engage and support all learners

It's also designed specifically to meet NGSS and K-12 CS standards, whether you're teaching in a physical classroom or virtually. 

Thousands of teachers and millions of students are already using EiE curricula to improve STEM engagement, performance, and excitement. With exciting new hands-on activities like designing maglev system and coding automated systems you too can inspire the next generation of problem solvers and big thinkers. 

I've put together a guided tour of the entire curriculum with some FAQs about implementing it at {{district}} -- would you mind if I shared it with you? 

Target audience: up sell

Draft: from Jay Santos

Hello {{title}} {{name}}

My name is {{sales rep}}. I am with the Museum of Science in Boston and have been working to implement Engineering is Elementary into the elementary schools in {{district}}.

With the recent updates to the NGSS, other {{titles}} in {{district}} have expressed concern about being able to effectively [[prioritize]] the development of critical thinking, discovery, and a passion for science among their students.

I'm excited to share that over the last few years we've been able to develop a curriculum built specifically for this NGSS update - that might be able to help you, too. 

__Engineering & Computer Science Essentials: An Integrated Program__ is based on the same principles (and research) that make EiE curricula proven to increase STEM scores, adopted by school districts across the country, and endorsed by the NSF.

It's a game-changing STEM curriculum built around three pillars:

Equity and access to engaging STEM lessons for all students

Teacher support, no matter their background or experience in STEM

Building coherence to and supporting ELA and mathematics

You probably have a lot of questions! To help, I put together this video that dives deeper into it - and gives you an exclusive first look at the curriculum. 

But if you have any other questions (or would to prefer to just talk about it) please let me know! 

Check in on

referral program

gmail ads

google display ads

{{{[[DONE]]}}}} Prep for the Interview (content strategy) #/

{{{[[DONE]]}}}} Prep the [[[[Google Ads]] for #ADK]] ad concepts for [[maggie o'connor]] #/

{{{[[DONE]]}}}} Google Ads report for [[Dan Tatar]] [[[[Google Ads]] for #ADK]] 

Timeline

July 20th - August 23rd

Spend: $16,200

Clicks: 938

Impressions: 48,534

Conversions: 17

Averages

CTR: 1.93%

Conversion rate: 1.81%

Cost per click: $17.25

Cost per conversion: $951.86

Companies that converted:

Equals Human

Friends of Father Zenon Decary

Project Starquest (no response)

OAI Consulting (http://www.bycatch.org/, drupal upgrade)

Rand-Whitney

Tinted Health

AlwaysOn Digital (for a web app, not positive this was google ads - might be organic)

Menu2Order (might be confused and think we own Mistral)

US Coast Guard

ChoicesMedical

{{{[[DONE]]}}}} [[Wasabi]] GDPR/CCPA research. #//

Some say cookies/clientID from GA fall under GDPR, some don't. This is a distinction that **lawyers** must make.

If they don't, then you're fine running GA without consent as long as you:

__[Policy requirements for Google Analytics Advertising Features](https://support.google.com/analytics/answer/2700409?hl=en): “If you’ve enabled any Google Analytics Advertising features, you are required to notify your visitors by disclosing the following information in your privacy policy”__

Can you make GA GDPR compliant? Maybe. 

Audit to make sure PII is not being sent to GA

Turn on IP anonymization

Disable Data Sharing with google. By default Google uses the data for 5 different purposes. Each of them would require consent from the visitor of your website. So you need to switch that off.

Open the settings menu from Google Analytics

Go to Admin

Choose Account Settings

Scroll down to the data sharing settings

Uncheck all checkboxes (Google producs & services, Benchmarking, Technical support, Account specialists and access for sales experts)

Click Save

{{[[DONE]]}} Disable Data Collection for Advertising. This has to be disabled at a different location, for the same reason as the previous step.

If you've enabled any Google Analytics Advertising features, you are required to notify your visitors by disclosing the following information in your privacy policy:

The Google Analytics Advertising Features you've implemented.

How you and third-party vendors use first-party cookies (such as the Google Analytics cookie) or other first-party identifiers, and third-party cookies (such as Google advertising cookies) or other third-party identifiers together.

How visitors can opt-out of the Google Analytics Advertising Features you use, including through Ads Settings, Ad Settings for mobile apps, or any other available means (for example, the NAI's consumer opt-out).

You must also [follow these guidelines](https://www.google.com/about/company/user-consent-policy/)

Open the settings menu from Google Analytics

Choose Property settings

Choose Tracking info

Choose Data collection

Turn off these two options (remarketing and advertising reporting)

Click Save

Disable the User-ID feature. This is probably turned off by default. But it is important to keep it turned off. So you need to verify this.

Open the settings menu from Google Analytics

Choose Property settings

Choose Trackinginfo

Choose User-ID

Disable it

Click Save

We also encourage you to point users to Google Analytics' [currently available opt-outs](https://tools.google.com/dlpage/gaoptout/) for the web.

If they GA does fall under GDPR according to your lawyers, then you can:

Fire GA only after obtaining consent

Replace GA. But with...what

Potential alternatives

Piwik Pro

You can enable [anonymous data tracking](https://help.piwik.pro/support/questions/how-can-i-get-accurate-statistics-when-visitors-refuse-to-be-tracked/)

"Piwik PRO will register an anonymous visitor and session, but won’t store a visitor ID or IP address. Also, when a visitor starts a session, Piwik PRO will set a temporary cookie in the visitor’s browser and will delete it 30 minutes later."

Drawbacks

Since we’re not using permanent cookies or other identifiable data, we treat each anonymous visitor as a new visitor. Therefore, in reports, you may see an overstated number of new visitors and an understated number of returning visitors.

You will still get accurate number of sessions, page views, and session time.

"You will get accurate data about Country and City. Piwik PRO will capture this information from the full visitor’s IP address and then will mask it. IP addresses will appear with zeros in reports: 0.0.0.0."

This sounds like it breaks GDPR?

Matomo

You host analytics on your own servers.

[According to the Berlin Data Protection Office](https://matomo.org/blog/2019/11/berlin-website-owners-need-consent-for-using-google-analytics/), if you’re collecting and sending data to third-party services (like Google Analytics) who use data “for own purpose uses” in Berlin, you now need to ask for specific consent from visitors in order to collect that information. This is not the case for Matomo. With Matomo On-Premise, Cloud and Matomo for WordPress, the data you collect is yours to own and work with. Matomo will never use your data for “own purposes” or any other purpose, as your data is completely yours.

The [CJEU ruled US cloud servers don’t comply with GDPR](https://matomo.org/blog/2020/07/storing-data-on-us-cloud-servers-dont-comply-with-gdpr/). Matomo’s cloud-hosted data is stored in Europe and your On-Premise data can be stored in any country of your choosing.

Claimed to be used by UN, Amnesty International, NASA, European Commission

though looking at UN, Amnesty International its clear they're using GA

UN = no banner

Amnesty = opt-out and assumed opt-in, plus other platforms

NASA = GA, no banner

EU = ??

SalesForce = no cookie banner + GA

Apple = adobe analytics, no banner, [additional statement about use of cookies](https://www.apple.com/legal/privacy/en-ww/cookies/) on european [[language]] versions of their site

[[Snowflake]] = GA plus banner ("By clicking "Accept Cookies" or closing this banner, you provide your consent to our use of cookies." and then option to customize cookie settings)

Using OneTrust

I opted out, but it still looks like GA is at least not being blocked/removed

Goodyear defines GA as required

Oribi

Looks like it stores its own version of a clientID

Adobe

How are the others doing it?

AWS = https://sitecatalyst.omniture.com/login/

Google = Google Analytics

Microsoft = Google Analytics & Facebook

[[Meetings]]: check in about [[Museum of Science]]

Attendees:: [[darci nevitt]]

Time:: 10:01 - 10:24

Notes::

what do we have (sam to review)

Facebook ads

Google search ads

what's in progress

landing page

what do we need

emails

Sam to write

gmail ads

google display ads

referral program?

what's required to get what we need

blocker: on the referral program, jill is busy

how long will it take

Thought re: [[ADK Marketing Project Management]] and [[ADK Marketing Strategy]] -- should we organize as individual specialists? or problem-based teams?

eg - when we have a certain type of problem, always use this combination of people

[[Meetings]]: [[Wasabi]] for [[CCPA/GDPR]]

Attendees:: [[andrew creek]] and [[Michelle Smith]]

Time:: 11:32

Notes::

[[Meetings]]: [[Drawbridge]] presentation

Attendees:: [[jayne hetherington]] [[andrew creek]] [[alex fedorov]] [[Dan Tatar]] [[mike ohara]] [[sean riley]] [[ted schleuter]] [[colby greco]] [[Dan Tatar]] [[quin o'hara]] [[dan madsen]] [[The Grist]]

Time:: 16:00

Notes::

Tagline: Rule the marketplace.

Where products can put their products for sale and allows their user to reach out and decide and choose which brands they want to interact with

Like following or joining an email list

Elevator pitch: an elevated private marketplace where consumers can selectively engage with the most exciting brands.

Pitch deck

Testflight for brands?

What's the killer content? 

Brands might be pushing videos

Drops as a Service❓

Honey, My Mind, 

 [[Personal Task Management]] #/

{{[[DONE]]}} Research deodorant

{{{[[DONE]]}}}} Fix phone and send back!!

Apps: MyMind, Roam, Command, Riff

