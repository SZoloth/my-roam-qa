[[🏔ADK [[Task Management]]]]

#[[email inbox]]

{{{[[DONE]]}}} [[[[Sleeping Dog Properties]] Marketing Strategy]] slack from [[heather mccormmack]]

{{{[[DONE]]}}}} [[hiring]] the copywriter slack from [[heather mccormmack]]

{{{[[DONE]]}}}} Question about report + conversion window from [[jess lopez mora]] for [[form health]] #/

pull together a report comparing platforms, formats, and DMA locations [[August 19th, 2020]]



"digital health application development" #[[Inspiration for ADK]] #//

{{{[[DONE]]}}}} check in on CMS

On [[[[hiring]] a copywriter]]

Different from [[[[hiring]] a content marketer]]

[source](https://growandconvert.com/hiring/hiring-content-marketer/)

About a content strategy:

a plan that states what differentiates your content from the competition, how they plan to attract your target audience to the blog, and some ideas around what type of content will do best for the company

plan to distribute your content so that it gets seen by your target audience

Coupled with a blog editor who:

edits blog posts

manages content calendar

SEO

promotes on email

Good [source](https://growandconvert.com/hire-writers/) for background info

One alternative is to use internal resources, but that requires:

CEO buy-in

Incentivized or excited employees

A content calendar/deadline manager

At least 5% of employee time to writing

Good frequency is 3-4 articles per week

Typically look for 3-5 solid writers

Finding freelance writers:

Sites: Problogger, LinkedIn, AngelList

Job posting example:

Have a passion for the topic

You are a storyteller. You can research.

You can come up with story ideas with minimal guidance

Creative non-fiction and interview skills

Please share samples + what type of writing you enjoy most!

To evaluate writers produce a [document](https://www.growandconvert.com/wp-content/uploads/2016/02/Grow-and-Convert-Writer-Onboarding-Guide.pdf) that includes info:

About your company

About your content strategy

Writing samples that you like

Style that you're going for

A writing test

Pitch 3 story headlines and a one sentence description of your thought process for each that you'd like to write based on everything you've read in this doc

I'll pick a piece for them to write

If it needs minimal editing, then we pay and onboard

If it needs heavy editing or is way off base then thank them for their time and let them use the post however they want

Payment

Pay writers per post

$150 per post for writers with SME in your area

$200 for more experienced writers that go above and beyond for the blog. If they reach out to other SMEs for quotes or do additional research, for example.

$350 if the writer is doing an interview style.

$500 for heavy research and huge projects. THese typically require someone to outline, project manage, write, and coordinate details.

Process for writing

Ask writers how many posts they would want to contribute per month

Writer pitches each idea: a headline and a 2-3 sentence description of the what the article is about

On top of these pitches, I'll assign 3-4 articles per month to writers

Eg - interviews with influencers, or topics based on SEO research

Keeping them engaged:

Share metrics on a monthly basis

Get all the writers on a video call

Evaluation doc for [[[[hiring]] a copywriter]]

About [[ADK]] Group

We are a full service digital product agency that partners with a wide variety of clients to design, build, and launch websites, apps, and digital experiences.

ADK was created about 10 years ago by a non-technical founder to make deep technical expertise more friendly and accessible to more companies. We began by partnering with creative agencies to build out websites, but have continued to rapidly grow out of that [[model]] - integrating design, marketing, and [[[[product]] [[strategy]]]] expertise in service of both scaling startups and Fortune 500 enterprise brands.

Our vision and content strategy for ADK Group

We aim for our blog to be a destination that product leaders go to when they want advice, guidance, and inspiration for [[[[product]] [[strategy]]]]. Whether that's choosing the right CMS for a higher education website or building virality into the product, we help businesses come up with and execute the product strategies that set them apart from their competition.

Our target audience has titles like CMO, CPO, and Founder. They often work in healthcare or education, but we've partnered with financial, cloud storage, alcohol, insurance, and manufacturing companies (among others).

In the past, we've skirted too close to writing introductory or tactical blog posts that are most interesting to entry level operators, rather than high level strategic thinkers. We need to steer clear of this.

To get a better idea of the writing we're looking for:

From us

The following blogs do an effective job of taking information from a subject matter expert and presenting it in an interesting narrative.

https://www.adkgroup.com/case-studies/cambridge-savings-bank-website/

https://www.adkgroup.com/blog/react-native-development-company/

https://www.adkgroup.com/blog/technology-adoption-strategy-ALKU/

https://www.adkgroup.com/blog/expert-opinion-promise-and-reality-manufacturing-iot/

From external sources

These break down a relatively complex mental [[model]] into something easily digestible and provides examples and questions for the reader to take home with them.

https://brianbalfour.com/quick-takes/universal-growth-loop

https://futureblind.com/2019/08/03/advantage-flywheels/

https://www.screenshotessays.com/

This (and all of Firstround's content) take interviews with influential SMEs and turn them into actionable guides.

https://firstround.com/review/the-ultimate-guide-to-the-founding-designer-role/

These make traditionally dry topics engaging and filled with personality.

https://www.bloomberg.com/opinion/articles/2020-08-11/goldman-loves-a-good-crisis

https://notboring.substack.com/p/shopify-and-the-hard-thing-about-a05?token=eyJ1c2VyX2lkIjo5NTk5MzcsInBvc3RfaWQiOjgzMDgwNSwiXyI6Im1KTVdkIiwiaWF0IjoxNTk3NzgwMDA5LCJleHAiOjE1OTc3ODM2MDksImlzcyI6InB1Yi0xMDAyNSIsInN1YiI6InBvc3QtcmVhY3Rpb24ifQ.3hgVVfOJ2qLoM4nZU8t9XuzirW65a4Xm72pujhr3dCA

Targeted firmly at company leadership.

https://www.nfx.com/post/how-ceos-think-mental-models-shift-founder-to-ceo

Data or research-backed and coining a new concept.

https://andrewchen.co/the-law-of-shitty-clickthroughs/

Tone/style details for our blog:

Conversational tone in the second person.

Post must help readers accomplish something and/or learn from examples.

Paragraphs focus on being concise and easy to ready.

Broken up with headers to make articles easy to skim through.

These are not 101 or introductory level blog posts.

Length is generally 1000-1400 words, though there is not hard and fast rule.

Our evaluation process:

After reading through all of the above, here's the exercise you'll need to complete to become one of our regular contributors.

1) Send an e-mail to szoloth@adkgroup.com and pitch me three story headlines (and a one sentence description of their thought process for each) that you would like to write about based on everything you have read in the writer onboarding document.

2) If the headlines fit within our content strategy, then I'll have you write one of the stories.

3) After we review your piece, if we like it, then we'll pay your for the post, publish it, and you'll become a regular contributor. If it doesn't meet our standards, we will not use it, and you'll have full rights to the post.

For marketing strategies

We need breakdown of channels (and data behind why we chose specific channels)

We need timelines for everything - build in creative presentation and review

Avoid saying things like "we didn't choose twitter because we don't know how to use it"

