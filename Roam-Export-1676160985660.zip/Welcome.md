### Hello! I'm Jacob Jolibois.

I've been following [[Naval Ravikant]] for years and have dreamed about the concept of a collection of his thoughts before so I was thrilled when [[Eric Jorgenson]] announced he was releasing [[The Almanack of Naval Ravikant]]!

Of course, as part of the #RoamCult, I also knew that adding it to Roam was a priority so I (and others) can continue to surface Naval's wisdom across a wide range of topics.

Enjoy!

—Jacob Jolibois, [@jacobjolibois](https://twitter.com/jacobjolibois)

