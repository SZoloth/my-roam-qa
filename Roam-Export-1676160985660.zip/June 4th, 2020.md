[[🏔ADK [[Task Management]]]]

[[[[Sleeping Dog Properties]] Marketing Strategy]]

Facebook

Total

Spend: $1,193

Reach: 59,069 people

Cost per click: $0.52

Total clicks: 2,030

CTR: 3.41%

Prospecting

1,867 visits to the blog post at a CPC of $0.55

Average time on page: 2m 13s

9 visits to contact page out of 34 visits to the home office speciality

2.42% ad to LP

26.46% LP to contact page

19 views of portfolio gallery

13 shares on pinterest

Meeting notes

Finished 591 Albany St - new marijuana dispensary

Team wants **any** work 

Seeing some shifts in real estate out of city

Focus

1-3 family dwellings

A client just bought a $10m place in Swampscott because of COVID

When people move from city to outside they want the luxuries and amenities

Newton, Weston, Wellesley - competition might be too much?

Brookline - too Jewish...

Remove / exclude Boston

Target affluent suburbs

Do we try to get a development project in the suburbs?

Hacin and associates

Next steps

Brand guidelines from Toy

Google Ads for Home Offices

[[ADK Drupal Retargeting]]

Examples

Mercer Audit

Harvard China Found Technical Audit Summary of Findings (4 hours top)

FE code = 5m

Security risk

Plugins rating

Had administrative backend access

JDA Drupal 7 to 8 transition

What is a code audit? Why is is important? Get an example. Would you want done for you? Where should you focus

Questions

Can we pretty it up?

What can be automated?

Could we do a self-audit

how do you use your site? how does your audit

What can you get without backend code? Aaron can send over links for these

Builtwith

Speedtest

HTML validator

Any one of 6 people can do this code audit

anybody on drupal org

Drupal options

Drupal 7 to 8

Stay on Drupal 7

Reasons to pick Drupal: Users, data throughput, ecomm

Bring in Stowell for Drupal next steps

What are the key major features of your site?

Needs

Landing page

Sample audit

Template for audit offer

[[ADK Marketing Needs]]

Google Ads for Drupal and WP? 

Process for announcing new launches {{{[[DONE]]}}}} What to do with new [[ADK Marketing Assets]] from [[Dan Tatar]] #//

Span Tech new app launch

Feature releases - 

Trade Hounds job board

UX and Dev

[[ADK Website Rebuild]]

{{[[DONE]]}} List of clients needing case studies for #[[ADK Website Rebuild]]

Mercer

Trade Hounds

Sika

Firefly

Alku

SpanTech

HNRG

Toyota

mHealth

Sonoma

JDA

Wasabi

MCOP

SDP

Form Health

[[APCIA]]

Woodford

MIT PEL

[[Santander]]

Vyaire

HUAC

BSF / CEC

CSB

Privafy

Beyond insurance

GTI

Escher

Avast

DCF

FTS

TripAdvisor

FedEx

Harvard

GE HEalthcare

Titleist

New England Journal of Medicine

Wordstream

JSTOR

{{[[DONE]]}} name for services / approach for #[[ADK Website Rebuild]]

[[Vote Save America]]

Who to target?

People who 

don't know how to volunteer

care about the issues

in priority districts and states

Hard Asks 

Are

Specific

Unapologetic

Defined

Mechanics

Introduction

Use elements of your personal story

Connection

Identity with their values

Define the problem/work

What is the campaign doing and what problem are you trying to solve?

Urgency

Why is it important now?

Action

What action can they take to solve the problem?

Commityment

Ask for a specific commitment

Follow up

What are the next steps

Common reasons people say no

Not __this__

Not __now__

Not __ever__

Solution is to be prepared with backup asks for "not __this__" and "not __now__"

