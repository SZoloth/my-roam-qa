Tags:: #[[form health]] #facebook #ads #PPC #[[paid social media]] #[[a/b test]] 

Client: Form Health

Goal:

Create a new campaign titled "HHI Prospecting"

Please do **not** launch the campaign until it's been reviewed by Sam

Each adset should target:

Just MA & TX

A unique HHI level

That should result in 4 ad sets

Conversion: Schedule appointment

Creative: Highest performing from "Geo Prospecting campaign"

Clinician Plaintext

Medication Plaintext

Budget: $200 at campaign level

