Author:: [[blindfiveyearold.com]]

URL:: http://www.blindfiveyearold.com/query-classes

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

Knowing this, you can provide the relevant content to satisfy the user’s active intent. But the sites and pages that wind up winning are those that satisfy both active and passive intent. 

The person looking for vacation homes in tahoe might also want to learn about nearby attractions and restaurants. They may want to book airfare. Maybe they’re looking for lift tickets. 

On larger sites the beauty of query classes is that you can map them to a page type and then use smart templates to create appropriate titles, descriptions and more. 

**Note**: Use for national speed

It goes well beyond just the Title and meta description. You can establish consistent headers, develop appropriate content units that satisfy passive intent and ensure you have the right crosslink units in place for further discovery. 

