Long term vision, this **should** be pretty close to Atlas from Stripe

**__The__** platform for launching a clinical research app



