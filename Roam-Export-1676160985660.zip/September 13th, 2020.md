[[getting a car]]

Costs of Ally's car

New battery

$50-$200

AC system

$800

Cannot do the snow 

Insurance

$150-$200 / month

Possibly

New plates

Re-register in MA

Parking

Fix the doorhandle that was torn off

AAA?

$150 / year

Car tax

$300 / year

Questions

Windshield wipers

