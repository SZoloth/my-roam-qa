 Had some ideas about 

Based on G2 data that shows that most decision makers make purchase decisions based on recommendations from their networks

source: 

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2F6pq13LekF-?alt=media&token=c25d0ed0-e951-43a7-893e-d20184269070)

Need to get our clients to reach out to their networks and recommend us

Classic ways: affiliate program / referral

Monetary incentives won't help, but maybe discounts on their work? Or their partner's work?

Other ways #[[Inspiration for ADK]]

1-1 human connections: our PMs / relationship managers should posts congrats and tag their relation on LinkedIn to bait engagement and, ideally, a share

Create social/blog content that our social can post that our clients want to post

Would likely need to be relevant to their direct audience, not peers

Example: site speed for BrainSell

Create social/blog content that their social can post

[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} Edit [[nick watkins]] blog posts for ADK #ADK/blogging

{{[[DONE]]}} Edit [[darci nevitt]]s copy for the Drupal campaign #ADK-advertising 

Put self in role of Demand Curve

{{[[DONE]]}} Update the dashboard for [[Wasabi]] #analytics

{{[[DONE]]}} Need list of all projects launched 

{{[[DONE]]}} Edit [[darci nevitt]]s copy for the [[Major Decision]] ads

{{[[DONE]]}} Edit [[brian mullen]]s blog ideas

{{[[DONE]]}} Reached out to [[Metalab]] about their podcast ads on [[Pivot]] from [[Vox Media]]

Hi there! I want to be up front since I'm the one who reads things like this on our own site - this is neither a sales pitch nor a project request. Just a question for the marketing team at Metalab.

I'm beginning to gear up marketing for ADK Group and am curious if I could ask a few questions / get some advice from you. 

My specific tactical question was about podcast advertising - I had heard one of your ads (I think on Pivot from Vox) and am wondering how you felt about the ROI. 

I'm also broadly curious about what you've felt the best marketing channels have been, what you wish you had started earlier, etc. 

If I can be of any help in return I'd more than happy to - I'm most skilled with SEO and performance marketing.

All the best,

Sam

{{[[DONE]]}} Worked on [[ADK React Blog Notes]]

{{[[DONE]]}} Facilitate grassroots sales?

Blog

Social media posts

{{[[DONE]]}} ADK MGH COVID app?

