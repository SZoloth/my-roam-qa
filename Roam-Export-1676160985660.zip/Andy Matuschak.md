Resources::

https://andymatuschak.org/ [[to explore]]

