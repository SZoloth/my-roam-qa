Author:: [[Brittany Bingham]] and [[Mark Fiske]]

URL:: http://www.reforge.com/blog/crossing-the-canyon-leading-your-first-marketing-team

Recommended By::

Tags:: #Articles #Inbox #Readwise #[[From Senior Marketer to Team Leader]] #[[How to Become a Strategic Leader]] #[[management]] #self-development

# Notes

Start narrow and deep ([[Focus[[*]]]] first):

For marketers in technology companies, one profile increasingly fills the ranks of rising VPs and CMOs: the marketer who starts with a single acquisition or retention channel before broadening [[scope]] and responsibility beyond that channel. 

The shift from highly-skilled IC to a manager generally includes these transitions:

Being an expert in one channel → Building strategy across all channels 

Being good at your job → Guiding others to be good at theirs 

Focusing on your area → Collaborating across departments 

Playing an instrument → Conducting the orchestra 

For example, if you're managing a paid channel as an IC:

1. Know your channel inside and out technically.

2. Understand how increasing the channel's budget or resourcing will impact your results, whether it be volume, Cost per Acquisition (CPA), or other metrics.

3. Rotate your creative assets effectively and manage your creative asset production.

4. Discuss channel [[Goals]] with your team leader and advocate effectively for budget when you recognize opportunity. 

Quickly transition from an "I" to a "T" shape. In other words, you have to find a way to gain enough knowledge across your gaps to be able to build and run your team's strategy. 

Here are a few factors to consider: #[[Focus[[*]]]] #[[[[strategy]] [[*]]]] #team-development

What is the right [[North Star]] metric ([objective]([[OKR]])) for the team and how does that metric ladder up to the company's [[North Star]] metric?

How does your team's outputs fit into the company's financials?

What is your growth [[model]] and where is it constrained?

How does each channel fit into the lifecycle of your customers?

What are the right operational KPIs for each channel?

What are the important [[qualitative]] factors surrounding your customer? 

These are the foundations for building a strong strategy: budget resources across existing channels, select new channels, determine your creative and testing approach, and inform [[assumption]]s in your attribution [[model]]. 

If you don't understand what your company is trying to do and why, your acquisition strategy won't align with the rest of the organization, potentially creating conflict. 

Start by answering how your specific [[OKR]]s or metrics contribute to business [[outcome]]s, and what needs to be true for you to deliver on them? What are the drivers, both [[qualitative]]ly and quantitatively, what [[assumption]]s were made when forecasting targets, and more - you run the risk of optimizing metrics that don't matter. Should you be driving account registrations, or working towards a 7-day retained user that can be monetized? Scrutinize the metrics and build your strategy around meaningful metrics 

When training someone new, 1+1 will initially only equal 1.5. But when you're used to moving quickly on your own, it can feel like 1+1 = .75, and that can be incredibly frustrating. #[[management]] #[[how to delegate]]

The up-front investment in training your team will pay dividends in the long run, but you have to be willing to make the effort first. 

Stepping in yourself to keep things on track often works for a short period. Eventually, though, your team's development stalls, their motivation declines, you're late to ask for additional resources, and your personal progression fizzles out. 

You have to ask good questions and develop a sense of when things don't add up. 

“**One skillset that becomes really valuable is knowing the right questions to ask to be able to discover and flag potential problems even if you are not familiar with running a particular channel.** Knowing how to ask your IC good questions, scrutinize the specific channel strategy, and reverse engineer its potential are all things you need to lean into.” 

Quickly learn how to **vary your personal approach and management style for each member of your team** 

“I use this saying that ‘when it comes to [[feedback]] some people are a Ferrari and others are a Honda Civic.’ I’ve had team members where I give them a little bit of [[feedback]] and the next day I see a night and day difference. Other times, they overcorrect and spin out of the race entirely if you aren’t careful about how you deliver [[feedback]] and take their individual personality into consideration. And some people really require continuous reinforcement of the same [[feedback]] because their handling might be much softer and it takes them a long time to adjust.” 

**Finance will evaluate ROI based not just on CAC and LTV, but also on payback period, contribution margin, and net-present value, among others.** While you might not be familiar with those terms, the finance team definitely won't have a deep understanding of your channels. To have productive conversations about budgets and [[OKR]]s, you'll need to learn their [[language]] and be able to communicate important aspects of how different marketing channels work. 

Marketers often make several mistakes when making requests for the [[[[product]] [[road[[map]]]]]]:

Not framing requests in terms of ROI for the business. Product and engineering time is often the most sought after resource at a company with countless competing priorities. 

**To get your request [[prioritize]]d, you'll have to demonstrate how it impacts the overall business, not just the marketing team. Going in without a business case looks amateur. **

Focusing on short-term band-aids. Since Product is focused on the business over the long-term, they hate doing any work that will be thrown away (not that any of us like this!), even if that work will provide a short-term boost to KPIs 

Not thinking in terms of systems. **Companies** [[scale]] **by creating systems and automated processes that improve efficiency and create compounding effects. **

Walking in with an overbuilt solution. There are often multiple ways to accomplish an objective. So it's critical to frame the problem you're trying to solve and work through the solution collaboratively with the product team. 

When Marketing teams ask for incremental, one off, tactical fixes quarter after quarter it makes it really difficult for Product Management to understand the whole picture and batch projects for efficient implementation. Instead, **develop a shared roadmap for the next 12 months and create a partnership with Product so you can go on the journey together.** 

How you navigate this conversation and set shared expectations will determine if this relationship is a battle or a ballet. 

“A lot of the disconnect stems from not selecting a metric that creates shared accountability. Focusing only on MQLs (Marketing Qualified Leads) won't incentivize the marketing team to collaboratively solve problems deeper in the [[funnel]]. **Try to goal marketing on metrics after the hand-off to sales, perhaps SQLs, SQOs, or down-[[funnel]] sales pipeline.** This will incentivize both teams to coordinate across more of the process and focus everyone on shared success. It will expose disconnects and foster more alignment.” 

"Don't lead with an ask - no matter how good you think it is. Build a path to it. Share accountability for and understanding of [[Goals]], know what they're trying to achieve and how you can support, and provide context early." #[[Getting buy in from leadership]]

The way to do this is by managing through habits, rituals, and processes. **Your job is no longer to optimize the channels; it's to run the budgeting process, the weekly meetings, the team-building exercises, the strategy offsite, and more. ** #[[management]]

The rituals and processes you establish create the operating tempo for the team. They determine when reporting is expected, what updates should look like, how creative is approved, etc. 

