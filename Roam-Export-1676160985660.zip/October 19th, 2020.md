{{[[DONE]]}} For [[Museum of Science]] experiments and optimizations #/ [[🏔ADK [[Task Management]]]]

Focus on Google Ads, but can also include: landing page, email

**Obviously, keywords**

elementary STEM curriculum

early childhood STEM curriculum

stem curriculum lesson plan

engineering lesson plans

computer science lessons plans

elementary engineering curriculum

elementary computer science curriculum

**Review previous campaigns closer**

Keywords

stem activities for elementary

stem projects

^^engineering design process^^

should be separated out from STEM curriculum ad group

design process steps

engineering for kids

stem curriculum kits

**Notes**

NGSS ad group should be heavily restricted, probably (low intent)

NGSS lesson plans

NGSS currciulum

STEM curriculum

stem, stem curriculum likely too broad -- need to restrict by age

Most keywords here are too broad

And yet - previous ad campaigns had success with these..

Keywords

Engineering

elementary engineering curriculum

engineering curriculum for 1st grade

engineering curriculum for 2nd grade

engineering curriculum for 3rd grade

engineering curriculum for 4th grade

engineering curriculum for 5th grade

engineering lesson plan for 1st grade

engineering lesson plan for 2nd grade

engineering lesson plan for 3rd grade

engineering lesson plan for 4th grade

engineering lesson plan for 5th grade

elementary engineering lesson plan

elementary engineering projects

elementary engineering activities

kids engineering curriculum

kids engineering lesson plan

Computer Science

computer science curriculum

elementary computer science curriculum

for 1st grade

for 2nd grade

for 3rd grade

for 4th grade

for 5th grade

computer curriculum

computer science lesson plan

elementary computer science projects

elementary computer science activities

STEM

stem curriculum

stem curriculum elementary

for 1st grade

for 2nd grade

for 3rd grade

for 4th grade

for 5th grade

stem lesson plan

elementary STEM projects

elementary STEM activities

Ads

Hands-on + Project based

{{offer}} for grades 1-5

See existing ads

**Tests / experiments**

Display Network!!

Discussed shopping ads because they were seen in the SERP, but ultimately decided against because:

The main objective is that a user can click to purchase online, but as it stands we're sending users to sales reps.

there's a lot of lift that would require their attention before we can kick shopping ads off. He mentioned that setting up Google Merchant Center gets pretty in the weeds with things like Tax IDs and other business info

{{[[DONE]]}} Updated dash for [[Museum of Science]] #/

Updates

Restructured ads - what & why

At the top of our week we had run our normal round of optimizations - pausing keywords that weren't performing, adding negative keywords, etc. 

Not doing enough, esp. w/o facebook

So - spent the time restructuring ad groups around tighter themes 

STEM curricula

Comp sci curricula

Engineering curricula

Still early innings

Also explored:

Briefly vetted shopping ads

Display network

Worth testing

Trends

Look up 

Proposals

Display network

[[Meetings]]: [[agile marketing]]

Attendees:: [[kirsten weinsheimer]] & [[jordan daly]]

Time:: 14:00

Notes::

 JIRA

Child tasks might be hidden on board during a sprint

Change them into regular tasks and relate them to the Objective

What's currently set up as a key result should be a user story

Break tickets down from there

Objectives --> User story

Include acceptance criteria

PM creates user story with acceptance criteria

