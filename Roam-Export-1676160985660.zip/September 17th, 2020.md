[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} First draft of [ADK SEO site launch check list](https://docs.google.com/spreadsheets/d/1WTx5a7RYjXOAga5xTA6DFGFLng_vQwQJtsBe4h92Lf0/edit#gid=0) #ADK #SEO

{{{[[DONE]]}}}} For [[Drawbridge]], begin to jot down notes on user personas #/

Rough examples

The fact that brands seem to follow me around online and know what websites I visit gives me the creeps. I installed an ad blocker to make this better but do feel a little guilty about what it does to news/media sites. I do my best to protect my data, but it feels inevitable that it'll get loose. Giving up my social profiles or learning about the deep web are too extreme or technical for me. Plus, I do prefer ads that are relevant to me than totally useless ones. My inbox is a total mess. 

I'm probably a Millennial or Gen X.

I don't really care about my online privacy. I grew up as a "digital native" and know the deal: you get my data, I get a personalized experience. This is worth it to me since I spend so much time online and get so much utility out of it (plus - what's the worst that could happen?). 

I have a philosophy about my consumption: I'll pay extra for a "green" version of a product. Non-toxic frying pans, CBD soda, subscription toothbrushes -- it's all worth it to make my life healthier, greener, and frictionless. I dislike giving my money to big corporations with classic branding. I like having relationships with the brands I buy from (I own a sweatshirt from a CBD-infused sparkling water company because I like how it captured )

I live in SF where conspicuous consumption and the brands you purchase is a status symbol. I own more than 50% of [the "blands" that Ben Schott skewered in Bloomberg](https://www.bloomberg.com/opinion/articles/2020-09-07/welcome-to-your-bland-new-world-of-consumer-capitalism).

I am a HENRY - High Earner, Not Rich Yet. Likely work in tech or consulting. I'm a Millennial or Gen Z.

I'm a savvy shopper obsessed with finding "grails" - I love brands like Supreme or Off-White, but pride myself on never paying full price for them. I haunt apps like Grailed, Goat, and Stockx for the best deals. I have [[notifications]] set up for price drops, maybe using Honey.

Most important to me is being on the bleeding edge of fashion and trends. I'm absorbed with TikTok and follow a host of industry publications (think: Four Pins, Hypebeast, Lean Luxe, Thing Testing).

I live in NYC and get dressed up to go to the pharmacy.

Proud Gen Z, baby. 

Primary concerns

Privacy

Don't want to give up data, don't like the idea of it but are not savvy enough to know how not to / feel resigned to the fact that it's given up.

Millennial or previous gen

The latest hype

Privacy isn't a major concern.

Gen Z

Deals

Totally happy to give up data in exchange for deals. 

Personas

Tinfoil hat Terry

Hypebeast Hailey

[[Meetings]]: [[Wasabi]] keywords and SEO

Attendees:: [[jordan daly]]

Time:: 11:39

Notes::

 Keep it in [[ahrefs]]

Start with paid keywords to target

How to [[prioritize]]?

Take paid keywords

Run thru [[ahrefs]]

[[prioritize]] & group list

Groups/tags: pricing, industry

Should we do an optimization campaign

What keywords are 5-10?

Lists

[ [[ahrefs]] export](https://docs.google.com/spreadsheets/d/1RUBSKz5rOw0NquiHwEg0u5SrsMC2nOQczzfXmsd2tXA/edit#gid=257103221)

[Google Ads export](https://docs.google.com/spreadsheets/d/156RmJNhZCgOIL-ojM1rwHq4roYBkf0AnCii8xLqWBRI/edit#gid=1432185644)

[GSC dash](https://datastudio.google.com/u/2/reporting/f724a02a-5892-42ac-a7e7-af654d009936/page/6zXD)

{{[[DONE]]}} Refine and finalize the ADK [SEO project deliverables template](https://mail.google.com/mail/u/1/#inbox/KtbxLvhRbDTfMBvBhTZdFChPzPdtLXbdNV) #// #[[ADK Marketing Project Management]] [[ADK Marketing Strategy]] [[ADK Marketing Process]]

{{{[[DONE]]}}}} Time for [[darci nevitt]] next week

{{{[[DONE]]}}}} Review [[Privafy]] [SEO strat doc](https://docs.google.com/document/d/1qPknj6bLmet37ewk8poTQ54CL8jhhF_U_63KHuzHeA0/edit) from [[darci nevitt]] #/

{{[[DONE]]}} [[refine labs]] profile optimization homework #/

[[Meetings]]: [[refine labs]]

Attendees::

Time:: 16:07

Notes::

 Goal with content: Educate, inform, and entertain

Goal with profile: selling

About

What do you do

Who do you do it for

What's the secret sauce

What are the results you can expect

30-50 requests per day

