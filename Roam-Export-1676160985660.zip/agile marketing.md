Tags::

Resources::

From #ADK - [Confluence page](https://adkgroup.atlassian.net/wiki/spaces/ADK/pages/472055820/Starting+a+Project+Wrike+JIRA)

question::

~~Should we set up Wrike?~~ No

Should we set up Confluence?

~~Likely yes, for meetings~~ Yes

~~How do I copy the Overview page?~~

Should we include all of our work in JIRA? Including client, etc?

WIP limits?

How should we set up JIRA?

Setting up in [[jira]]

Define: workflow

Backlog

To Do

In progress

Review/QA

Publish

Done

Sprints: 2 weeks

Issue types / labels / typing it in

Content

Email

Paid

Analytics

Technical SEO

Social

Strategy

Administrative

Epic

Website

Questions

Task

Campaign

Sub-tickets/issues:

Tactics, initiative

Tickets:

Key Results

Epics: 

Objectives

Versions: 

Ignore

Kick off meeting

Finalize individual [[OKR]]s

Break into tickets for the backlog

Future meetings

Half-day quarterly strategy meeting to define the [[OKR]]s

Sprint [[[[retro]]spective]]s

Every two weeks the team should get together
and discuss their process. What’s working,
what’s not, and what concrete steps will they
take to improve it? And yes, I mean every two
weeks without exception. Just put it on the
calendar and make it happen.

Sprint kick-offs

Daily standup meetings first thing in the morning to check in on Sprint progress

Many teams answer three questions -- what
did you do yesterday, what will you do today,
and what impediments do you have

