Author:: [[firstround.com]]

URL:: https://firstround.com/review/drive-growth-by-picking-the-right-lane-a-customer-acquisition-playbook-for-consumer-startups/

Recommended By:: [[Lenny Rachitsky]]

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[October 7th, 2020]]

Unfortunately, this often leads to founders running head-first into one of the most common startup failure modes: investing in too many channels at once, and as a result not investing in any one channel enough. 

**Note**: Trying to find more ways to grow can spread your company too thin.

For consumer companies, there are only three growth “lanes” that comprise the majority of new customer acquisition:

1. [Performance marketing]([[paid acquisition]]) (e.g. Facebook and [[Google Ads]])

2. [[virality]] (e.g. word-of-mouth, [[referral]], invites)

3. [[content]] (e.g. [[SEO]], [[YouTube]]) 

There are two additional lanes ([[sales]] and partnerships) which we won't cover in this post because they are rarely effective in consumer businesses. And there are other tactics to boost customer acquisition (e.g PR, brand marketing), but the lanes outlined above are the only reliable paths for long-term and sustainable business growth. 

In the case of [[virality]], you are competing for something even more precious: a customer’s social standing. Consumers only want to recommend things that improve their relationships by genuinely helping other people with great recommendations, or perhaps just making them look cool. 

**how do you find out about new products?** You either hear about it from a friend (i.e. virality), you come across it while doing something unrelated (i.e. content or performance marketing), or you get contacted directly by the company (i.e. sales, partnerships). That’s it. These are effectively the only channels companies have to find new customers. 

[Performance marketing]([[paid acquisition]]) is a natural fit if:

You generate revenue directly from new users (e.g. purchasing a product, subscribing to a service), which you can then use to fund more marketing

Customers are not naturally going to be looking for your product, and thus you have to come to them (e.g. a new DTC brand) 

[[virality]] is a natural fit if:

Your product is better when your friends or colleagues are using it (e.g. Snapchat)

The product is innately fun to share (e.g. travel photos, homes for sale) 

[[content]] is a natural fit if:

Your users naturally generate public content (e.g. reviews or answers to questions) when using your product, which you can use to attract new users

You have a lot of unique data (e.g. restaurants in Seattle, plumbers in Phoenix), which you can turn into rich auto-generated pages 

[Performance marketing]([[paid acquisition]]) could take as little as 2-4 weeks to test. [[virality]] (such as launching a referral program) can often be tested in 1-2 months. [[SEO]] typically requires the most investment, and many companies see zero results for 3 or more months. 

[Performance marketing]([[paid acquisition]]): Your tests generate paying customers with a healthy payback period 

The most important metric to measure is payback period: the amount of time it takes you to earn back what you spent to acquire a customer. This is critical because it determines how quickly you can re-invest in more paid marketing. 

For low frequency transactional businesses (e.g. buying car insurance), a common benchmark to target is payback on the first purchase. For high frequency transactional businesses or subscription businesses (ecommerce, media subscriptions), payback within 6-12 months would generally be considered healthy. 

[[Virality]]: Over 50% of your new customer acquisition today is through word-of-mouth, customers are naturally telling their friends and family about your product, and you’ve run a handful of successful experiments that increase this behavior. 

Resources were limited, so we took the approach that we needed to choose bets carefully, and when we did choose, to go all in with basically 100% of our resources. We viewed everything else as a distraction. 

Keyword research. “We looked at the Google Keyword tool and saw that there were people out there searching in volume for keywords that matched what our product offered. People are out there searching for “movers in Austin” and “electricians in Tallahassee”. And for example, they’re not searching for “app to communicate with my friends where my messages disappear after they’re viewed”. So for Snapchat, [[SEO]] makes no sense.”

Competitive research. “We looked at the competition and saw that it wasn’t a supersaturated space. The players in [[SEO]] were a lot of local players, not national players, so we thought we could make an impact.”

Analogous companies. “We had seen other companies in adjacent spaces like Yelp and TripAdvisor find success in [[SEO]].” 

How did the team make this decision? First, they looked at the natural behavior of what was already happening — strong word of mouth. They had a hypothesis that amplifying an existing behavior would be a lot more effective than trying to create a new one, and noticed that a lot of users took screenshots of Airbnb listings to send to friends — a behavior that could be facilitated with product. 

**Committing to a lane** generally includes doing two things, both of which can be scary, particularly early in a company’s life:

Dedicating a significant amount of cross-functional resources to the effort, including product, design, marketing, and engineering

Influencing the core [[[[product]] [[road[[map]]]]]] and customer experience to optimize for the lane being pursued 

The first wave of this investment was in the “mechanics” of [[SEO]] to lay the foundation. This meant investment in three primary areas:

1. Site architecture

The team built out thousands of pages targeted at high value keywords, and optimized their entire website and URL structure for SEO. This meant making it as understandable and crawlable by googlebot as possible. Importantly, in some areas this came at the expense of the user experience. These were hard tradeoffs to make, especially before SEO was yielding any benefits. 

To support the new pages, the team needed a massive volume of high quality, unique [[content]]. They built a team dedicated to content, which curated user-generated content like reviews and the profile pages of service professionals, and adapted it for the needs of different kinds of pages. At first this was a highly manual effort. At its peak, there were hundreds of people across multiple offices entirely devoted to content curation and generation. However once the company had meaningful engineering resources, they began investing in automation of this process, an initiative that continues today. 

To provide a sense for the scale of this effort, one of the most successful initiatives became known as the “Small Business Friendliness Survey.” It involved surveying about 15,000 service professionals each year on how well their local state and city governments supported small businesses. They used this data to create many locally-targeted press releases. In fact in the early days, for each wave, Sander personally wrote 130 individual press releases. These press releases were pitched to a database of every local newspaper, radio station, TV station, chamber of commerce, state and national senator, governor, and mayor — some 30,000 contacts in all. 

So, what did all of these efforts yield? For the first 3 months, almost nothing. And then a trickle of traffic. At 6 months, there still wasn’t much traffic, but there was at least enough to start analyzing. At 18 months, it became a meaningful share of consumer traffic to the site. At 36 months, it was the primary form of customer acquisition. These lead times are not uncommon, and can cause companies to give up hope on [[SEO]]. 

**Virtually every customer acquisition channel becomes harder over time** because you are acquiring lower and lower intent customers. This is often referred to as the S-curve of growth. 

