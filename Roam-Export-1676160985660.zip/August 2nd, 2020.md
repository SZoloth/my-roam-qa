[[Personal Task Management]]

For Today

{{[[DONE]]}} meditate

{{[[DONE]]}} run

{{[[DONE]]}} bills

{{{[[DONE]]}}}} chair / desk

{{{[[DONE]]}}}} work

Info for [[bills]]

[[Xfinity]]

ALEXANDER TSANKOV

**Xfinity username:** alexander_tsankov

**Xfinity email:** alexander_tsankov@comcast.net

**Personal email:** atsankov@alum.mit.edu

**Mobile phone number:** (617) 953-3290

**Xfinity account**: 8773102262647458

Address

sam zoloth

43 market st fl 1

cambridge Ma 02139-1509

