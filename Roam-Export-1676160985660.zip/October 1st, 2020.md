{{[[DONE]]}} Review [[darci nevitt]] [tickets](https://adkgroup.atlassian.net/secure/RapidBoard.jspa?rapidView=497&projectKey=GLEN&view=planning&selectedIssue=GLEN-363&epics=visible&issueLimit=100) for [[Glenmede]] Analytics #/

Pomos

{{[[POMO]]: 25}}

{{[[POMO]]: 25}}

Events

Sharing [[insight]]s

Video tracking

Open, play/pause etc.

Subscribe

Download [[insight]]

Contact

Email

Submit form

Request information

Initiate an RFP

Other downloads

Download all

Quarterly Commentary

Fact Sheet

Capital Gains

[Summary Prospectus](https://adkgroup.invisionapp.com/d/main/#/console/20122425/423007303/preview)

Download

Analytics account set up

How do you track across [all subdomains](((Qn18Dy-jU)))

All subdomains = glenmede.com, glenmedeim.com, impactivate.com, glenmedeconnect.com

Show full URLs

Search parameters

Site

[[insight]]s

People

Other considerations

[[pardot]] integration

Content grouping

Business line

Domain?

Custom dimensions/metrics

Tracking logged in users?

Questions

^^[[insight]]s URL structure for^^ [[Michelle Smith]]

Strategy finder?

Fund finder?

Tabs on this [equities page design](https://adkgroup.invisionapp.com/d/main/#/console/20122425/425271651/preview) (performance overview, people, literature, etc.)

{{[[DONE]]}} Wasabi SEO strategy from [[Wasabi analytics: 9/4/20 - 9/17/20]] #//

{{[[DONE]]}} Finalize the **Wasabi keywords** and send to client [[Wasabi]] #//

Problems/opportunities

International SEO

Transcribe videos

More calculators

On prem vs. cloud

Stats round up

Technical SEO

Blogs

Heroize the customer campaign - interviews

Optimize

Use case pages

Industry pages

[[Meetings]]: [[Wasabi]]

Attendees:: [[nick watkins]] [[darci nevitt]] [[jordan daly]]

Time:: 10:10

Notes::

 Straightforward

Videos

Blogs

Technical SEO

Bigger projects

International SEO

Calculators

Heroize the customer campaign

{{[[DONE]]}} mHealth landing page

https://docs.google.com/document/d/1ZIDduMF1gBWL0vf3DhudeT8JpHQdTA8od-WVLiPXfYA/edit

{{[[DONE]]}} [[refine labs]] profile optimization homework #/

{{[[DONE]]}} mhealth landing page [[🏔ADK [[Task Management]]]]

