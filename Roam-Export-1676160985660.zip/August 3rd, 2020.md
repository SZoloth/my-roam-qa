[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Growth Machine response

{{{[[DONE]]}}}} Slack writers follow up

[[Meetings]]: [[Meetings with [[chris baker]]]]

Attendees:: [[chris baker]]

Time:: 4:30pm

Notes::

ADK marketing

Products, branded services

PR

[[webinar]]s, videos, interviews, podcasts

events, conferences?

We're marketing like Vyaire - Dan holding up COVID email, which doesn't even have to be a COVID email

Writers: Growth machine, others

General

Feeling kind of in a rut? 

Generate and test ideas

Jill Starett talking about design research process and why it results in better applications #[[ADK content]]

Ideation session with Chris: {{{[[DONE]]}}}} Find some time with [[chris baker]] in [[August 3rd, 2020]] to brainstorm on broader [[ADK Marketing Strategy]] #///

{{{[[DONE]]}}}} Set up the PM process #[[ADK Marketing Project Management]] #//

{{[[DONE]]}} Define the team #///

Content

Google Ads

Retargeting

Dive in to Google Ads

Metric for success:

new creative in Google Ads

{{{[[DONE]]}}}} Every two weeks present on ADK Google Ads: [[[[Google Ads Optimization]] Log]] [[[[Google Ads Optimization]] Log]]

Data

Interpretation

Hypotheses

State of the state of Google Ads

Whats working, what isn't 

Digital product agencies

Crema.us

https://work.co/

https://clay.global/

metalab

