Tags:: #[[ADK Marketing Needs]] #[[ADK Marketing Process]] #[[Selling ADK Group]] #[[Inspiration for ADK]] #[[ADK enterprise campaign]]

Concepts and high-level plans

Strategy and research

Who are we targeting? What is the ideal customer profile?

Campaign process

Offer / goal (UVP)

Landing page

Ad creative

Targeting and campaign set up

Content - writing

[Planning](https://docs.google.com/spreadsheets/d/1us8QmUHzCGOvRFbeCQmkIMFdpNx5vwjvlVm0ZremCM0/edit#gid=1004632142)

Blog posts

Unsolicited Redesigns

Conversational teardowns Similar to [[profitwell]] and [[Patrick Campbell]]

The Future of

AR/VR

IoT

Healthcare

Case studies

Lead magnets (books/guides/playbooks)

Guide to Custom Enterprise Software Success

Managing Legacy Products

UX Audit

Enterprise Design System Playbook

Code Audit

Examples: Mercer, Harvard China Found(sp?), JDA Drupal 7 to 8

What is a code audit? Why is is important? Get an example. Would you want done for you? Where should you focus

Product Audit

https://www.accenture.com/us-en/[[insight]]s/future-systems/enterprise-innovation-[[model]]?src=SOMS

Glossary of term

Managing writers

Editing

Adding imagery

Promoting

Updating with Clear[[scope]]

Social media

Tone and voice

Plan for thought leaders

Should we write for Dan, Jon, Aaron, Alex linkedin profiles? #[[ADK Marketing Process]]

SEO

Technical audits

Meta audits

Metadata

URLs

Backlinks

Content - other

Interviews with

Team mates

Clients

https://www.mckinsey.com/business-functions/mckinsey-analytics/our-[[insight]]s/how-companies-are-using-big-data-and-analytics

External experts

[[webinar]]s

Quizzes

Send physical book copies

Video content

Audio content

Promoting leaders as guests for podcasts

Stripe Atlas / Growth.segment.com for target audiences

Email strategy

Build list

Regular cadence to list

Create short email courses

Client surveys

Awareness plays

Podcast ads

Direct sponsorships

Internal process definition #[[ADK Marketing Process]]

Ticket templates for dev work as it relates to SEO and Analytics

Defined, repeatable template for SEO and EAT

React SEO

React Analytics

A/B Testing

Tracker for marketing work

Tactic

Client

Audience

Goal

Results

Internal playbooks for 

Client project launches

Social post

Blog post

Case study

PM social post congratulating the client

"newsjacking"

eg - Drupal 8, CCPA

How should we be positioning 

our HelpDesk?

Onboarding in a lower-commitment manner as a means to getting next projects

Reliable, well-architected support - maintenance/helpdesk/new features

Big agencies don't do it, small shops don't have systems/process scale, offshore is risky

ADK Ventures?

ADK mHealth App ~~Kit~~ Platform

Enterprise Awareness campaign

Client surveys

Campaign playbooks

Inbound + owned media

Blog post

Email

Social post

Outbound

Offer

Tool

Audit

PDF

Consultation

Landing page

Ad copy + creative

Campaign set up

Optimization

Measure and track KPIs

SEO / content optimizatoin

PPC optimization process

Landing page optimization process

