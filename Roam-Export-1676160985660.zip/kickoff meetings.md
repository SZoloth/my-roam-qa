![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2F5xsO7ECU0V.png?alt=media&token=844c8101-09bd-482c-8256-3852f429e7b5)

Internal [[kickoff meetings]] agenda

Contextualize and summarize background information (sales docs, eg)

Who is the client?

Who are the customers?

What are their pain points?

What is the initial [[product [[vision]]]]?

Review timeline

Review deliverables and [[outcome]]s & how they got there

Teammates & roles

Align on recommended approach

Our current [[product [[vision]]]] is X

Our experience is the fastest and easiest way to plan, book, and monitor trips between the mainland and the Islands (ACK and MV).

What we need to uncover is Y

Align on goals + quantify current state

Validate priority problems + opportunities

How might we do that?

Knowledge gap analysis?

Tech 

audit 

architecture needs assessment

constraints

Discovery interviews

[[assumption]] testing

Concept validation?

Unmoderated usability testing?

Guiding principles?

What do we need from client in external kickoff?

High level [[RR/Revealing Reality]] strategy

Align on goals

Align on current state

Discover opportunities

Ideate, [[prioritize]], and test solutions

Capture learnings

[[jtbd]]

[[[[product]] [[strategy]]]] (vision, strategic intents, initiatives + options)

Journey map/blueprinting

