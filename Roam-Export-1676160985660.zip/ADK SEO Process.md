Tags:: [[ADK Marketing Process]], [[SEO]]

Resources::

https://trello.com/b/FiHXRDxe/e-a-t-factor-checklist-template

https://nickeubanks.com/keyword-strategy/

[[clearscope]] & #[[Using Clear[[scope]] for keyword research]]

https://adkgroup.atlassian.net/wiki/spaces/ADK/pages/1420623951/Clear[[scope]]

[[Demand Curve]]

https://drive.google.com/drive/u/1/folders/1rZxZSdNGam2An5bzFoJU3QA_9_kjqZRU (number 207)

Starting from scratch

Understand the client, their [[Goals]], their product/service, their competition

Keyword research

Content optimization

What content should I optimize?

How do I optimize it?



