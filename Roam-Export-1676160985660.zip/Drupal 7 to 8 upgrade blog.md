Introduction

Drupal 7 isn't getting retired until November of 2021 - why are developers talking about upgrading to Drupal 8 (and 9) now? And should you?

This is for site managers, CMS admins, marketers, etc. wondering about upgrading to Drupal 8. 

For a more technical perspective these blogs about preparing to upgrade your Drupal 7 site and steps to take to upgrade your Drupal 7 site will help steer you in the right direction.

The 3 most important things to know are:

**You will need to upgrade your website if you want to continue using it.** When Drupal 7 gets "end of lifed" that means it will stop receiving security updates and patches, making it exponentially easier for bad actors (hackers) to exploit your website. 

**This is an overhaul not an update.** The transition from Drupal 7 to Drupal 8 is nearly a complete overhaul of the underlying technology that powers your website. That means your sites speed, security, and UX will likely improve, but it will take more effort.

**It may also be the perfect time to upgrade your website.** The transition to Drupal 8 essentially requires rebuilding your website. If you have a [[backlog of features]] or some structural changes in the pipeline you may want to do this in conjunction with the update. Batching big lifts like this is often the most efficient way to accomplish them, and doing them ahead of the upgrade may mean you need to do it twice. 

Proper planning can help your team turn this upgrade into an opportunity to unlock growth. 

We've been fielding these questions from our Drupal clients (link to portfolio?) to help them properly plan to take advantage of this update. They were helpful enough that we're making them public for you. 

Proper planning can help your team turn this upgrade into an opportunity to unlock growth. The answers below will help you decide if you should, and how to begin.

CTA: Want to talk to someone directly? Have a specific question? Talk to a Drupal architect.

Why can't we just keep using Drupal 7?

In November 2021, Drupal 7 will no longer receive active support from the Drupal community, resulting in no further security updates. To ensure your website remains secure, online, and healthy, it will need to be upgraded to a more modern application.

What should we use instead of Drupal 7?

[Drupal remains a powerhouse](https://www.adkgroup.com/blog/drupal-vs-wordpress-comparing-enterprise-cms-platforms/) in the Open Source CMS world. The structural limits of Drupal 7 were identified early, and powerful additions were made with the introduction of the more modern, scalable, and secure Drupal 8. 

Key benefits of Drupal 8 include:

**Modern technology stack**, which results in more efficient development and lower day-to-day operating costs.

**Improved security** from a new templating [[language]] that streamlines frontend development and increases application security. On a technical level, all templates would be built using the new Twig template engine. This technology abstracts PHP to improve security and performance.

**Lower cost of management** as a result of the improved templating. 

**Friendlier content management** that makes adding, removing, and editing content much easier.

**Mobile-responsive admin interface** so site admins can modify content from their phones or tablets.

**Speed and performance improvements** that result in improved user experience (UX), site engagement, and SEO performance. Drupal 8 uses improved caching mechanisms to substantially improve loading times for end users.

**Future-proofing** your website with a direct upgrade path to Drupal 9 in 2021.

Why shouldn't we wait and upgrade from Drupal 7 to Drupal 9?

The difference between previous versions and Drupal 8 is substantial, and that's where the benefits lie. Drupal 9 is essentially cleaning up vestigial parts of Drupal 8: it removes some legacy and deprecated code, without adding any new features. 

Drupal’s founder and project lead, who is the co-founder of Acquia, Dries Buytaert, has provided [his [[insight]]](https://www.drupal.org/blog/plan-for-drupal-9) and expertise around this exact topic. According to Buytaert, “the big deal about Drupal 9 is…that it should not be a big deal. The best way to be ready for Drupal 9 is to keep up with Drupal 8 updates.” He says “the upgrade to Drupal 9 will be easy. Because we are building Drupal 9 in Drupal 8, the technology in Drupal 9 will have been battle-tested in Drupal 8.”

Upgrading to Drupal 8, now, lets you get all the benefits without waiting. And once you're at Drupal 8, getting to Drupal 9 will be negligible. That upgrade will likely take days - or even hours - depending on the complexity of your site. Upgrading from Drupal 7 is much more involved.

How much work is it to upgrade from Drupal 7?

There are substantial technical differences between Drupal 7 and Drupal 8+. These differences are significant enough to equate D8+ as an entirely different type of technology. As such, Drupal 7 cannot be "upgraded" to Drupal 8. A Drupal 8 application needs to be built from the ground up.

What sort of projects should I consider during the upgrade to Drupal 8?

Drupal 8 unlocks a bevy of advanced functionality, meaning your website will be able to perform better than before. How can you best take advantage of this? 

Here are some areas to think about:

**User Experience and Design Improvements.** If you've been auditing your user experiences or working on improving conversion rates you likely have a backlog of improvements to make. This update could be a great time for the implementation of design refinements and new features based on the results of Conversion Rate Optimization and a User Experience Audit.

**[[multilingual]] Support Improvements.** Drupal 8 has extensive support for [[multilingual]] capabilities. Capabilities allow for native support for the administrative interface in addition to the public site, and how this information is presented and managed to users. This - along with thoughtful SEO - can help with internationalization efforts. 

**Administrative Streamlining.** Many people complain about the administrative side of Drupal 7. And oftentimes resources aren't devoted to that. But upgrading to Drupal 8 is a great time to take advantage of the improved UX and flexibility by making customizations. These could allow for faster data searches, improved permission controls, and easier content management.

**Better Data Imports.** Drupal is at its best when it's handling large sets of complex data. The newer Drupal 8 Migrate API allows for finer-grained controls of the frequency, resiliency, and [[notifications]] for data imports.

**Accessibility.** Being [ADA compliant in 2020](https://www.adkgroup.com/blog/importance-website-ada-compliance-2020/) is table stakes. From the administrative interface to the semantic HTML5 output by the Twig template engine, Drupal 8 applications support a larger audience than ever.

These are just generic examples. If you want to get all the benefits of Drupal 8 - with minimal disruption - __and__ create a strategy to maximize opportunities relating to your unique website, you need to have a chat with a Drupal expert.

