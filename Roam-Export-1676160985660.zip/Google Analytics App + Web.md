Questions?

Do we use Firebase for apps?

