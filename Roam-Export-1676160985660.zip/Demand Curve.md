**Sources:**

https://app.gitbook.com/@bell-curve/spaces

https://www.demandcurve.com/[[webinar]]s

[[paid social media]]

Quick wins for brand-new [[paid social media]]accounts

First - #retargeting people who have already been to the website

Second - bomb removal approach to targeting: don't narrow too specifically unless you know they're the best

Start with broad targeting

Then do a breakdown analysis by demo's (age, gender, geo, device type) and other variables

Then remove the variables that are performing much worse than anything else

Keep narrowing until you reach an average #CAC

## [[Prospecting]]

prospecting is: #targeting people who have not heard of your [[brand]] or company

Wrong way to think about [[targeting]]: narrow into demos, interests, or look-a-likes

Best #targeting tactics for #prospecting :

Big [[insight]] = "[[transitional audience]]"

Transitional audiences means: target people who are in the moment part of a shifting group

eg - newly eds, new relationships, new parents, just joined a new job, just made a major purchase

These are all behavioral targeting audiences

Benefit is that the audiences are always fresh

Time of day and day of week #targeting are most significant way to reduce costs

Need to use a third-party tool to only run during those hours (#AdEspresso)

Look-a-like audiences

Pixel-sharing

Perfect for very-niche audiences

Geo roll-outs

Expand targeting one region at a time (one city a time) to give off impression of size

Cross-channel retargeting

Combine w/ geo roll-outs - this is good to approximate social cue of size

How to use #linkedin for #prospecting

LinkedIn ads are generally terrible b/c CPC is super high ($45!) & performance is terrible on-site, but two tricks to make it work

First - LinkedIn-first retargeting. Goal is get cheapest clicks possible from right people. Use right-hand side text ads with a max CPC very low - blast that with clickbaity stuff.

Use LI to target firmographics and individuals

Then retarget w/ FB or IG

Clickbaity ad: big face of a good-looking man/woman

## #retargeting

pretty much always good - pretty much always use #facebook or #instagram

But also pair that with something off FB and IG

First 4 days after visiting the website = highest conversion period

Blast ad spend in those 4 days, then from 5 - forever: taper way off

For 4 day window, retarget relatively broadly — optimize for people going back to the web page

introduce a drastically different landing page (eg - a short-text pitch + a video) — shouldn't be an intro, should be more about benefits

ads

Days 5-30: introduce time-limited pressure

Goal is to be everywhere in those 4 days, even if that person doesn't check FB or IG

Complement it with [Criteo.com](http://criteo.com) retargeting — banner ads

Includes Google Display Network - according to BellCurve it out performs GDN, AdRoll, etc. Optimizes for time of day, etc.

Criteo breaks down conversion data (but not cross-channel attribution)

Also with LinkedIn

Demand Curve's best performing ad of all time: IG for a company selling $50k ML to companies

Best performing = made the most $

Before cold outreach

Whitelist ABM

Upload that list to LI - run ads against them

## How to make good [[ad creative]]

How does BellCurve do videos?

Test an MVP, using Animoto with shutterstock footage

Create a cheap video to test different styles of positionin

Positioning: testimonial-style (person talking while at a kitchen), how it works (product in action or narrated/animated explainer), screen recording video (open up the SaaS tool, go through features, add subtitles), teaser videos (5-10 seconds with 5-6 image frames explaining what the product is like stop-motion)

Most common tests: Product vs. Lifestyle positioning

Product photo = product itself

Lifestyle = how does someone use the product

Type of ads: comparison or competitor ads (esp. when tied with a landing page)

Start with 4 distinct ads, find a winning angle, THEN do dynamic creative

Ad copy

Long ad copy and longform landing pages

Specific framework for ads:

Quick opener for attention

medium paragraph: narrative of the story

checklist of all the cool stuff the product / service provides

Longform ad copy works b/c it helps the audience understand why they're seeing the ad + why the should buy you

Quicktip: CTAs

Add cta's to images

Use square images (vs. portrait) for FB + IG b/c they outperform others and can be used across both channels

Social proof:

Test ads to find best-performing ads

Send those to your friends for them to add a bunch of comments

[[analytics]]

Cross-channel [[attribution]]:

Use tools like Heap, Segment + [[Amplitude]], GA, FB — but generally use surveys to ask where they heard

If the purchase is hugely valuable, call them.

Misc

Positioning SaaS ads:

screen-recording video ads - show the product in action, show the dashboards

target competitors

skip the big pitch and just do the benefits

How to evaluate effectiveness of ad for long B2B sales cycles

Limit audience

[[Critiques - social ads]]:

[Common Energy](https://www.facebook.com/ads/experience/confirmation/?experience_id=2341875285933728&hmac=AVIGSs7ZW0PK1p1drV_mNdooJ9lPfwdNLchQGLvPfomoRQ)

Access clean energy in MA

Don't know what this means

Good benefits list

Unclear what you're being sold

Image = good copy

The image itself is too generic + small

Recommendation: Go __very__ copy heavy unless you're a physical product

Switch it to a video ad to show the dashboard in action

[Eva gift assistant](https://www.facebook.com/ads/experience/confirmation/?experience_id=479639339265968&hmac=AVLzi2jR12bUgM2O875PPsjdCu4vDnBVXr2hnqE6BxcOYw)

Initial copy is too vague - copy in the video is better

[Modern Cotton](https://www.facebook.com/ads/experience/confirmation/?experience_id=348157492750042&hmac=AVKE0A0uvkKtmr5QQu0uGaJ9297hHWihL-9lwd-7K0rpzw)

Doesn't say "t-shirt" earlier

Targeting men, start with product close up, end with lifestyle

[eComm Open format](https://www.facebook.com/ads/experience/confirmation/?experience_id=341685336773469&hmac=AVLRcauxAfEvEmT9FtKaaZ_LJTGnvC95s7fLXzw78hLTfw)

Good opening line: self-evident description of what you're selling + for who

"perfect" isn't great, do something more specific

Value props are good (survey users to make sure the value props are valuable and in that order)

emoji pointing to in-line link is great

Copy below the image should be used for more value-props or a simple description

Video: visualizes the value props of the ad

Great ad

Quick paced

It's visually enticing (disgusting stuff)

[[B2B Outreach]]

Ads, lead gen, and cold emailing for B2B

## #prospecting in #Email

Best way to know who needs you is to see who is using your competitors

tools: nerdydata, clearbit, builtwith, datanize etc.

Get emails with: skrap, [hunter.io](http://hunter.io), **[gem.com](http://gem.com)**, **[clearbit.com](http://clearbit.com)**

Other ways to find people who use your competitor

Search twitter for your competitor

Scrape the client logos from competitor web pages (testimonials and case studies → risky?)

Look for reviews of your competitors (g2crowd, getapp, etc.)

Steps:

Find people using competitors

Grab their emails

Use LI ads to "pre-target"

Run ads against everyone with the right job functions at those target companies

Sponsored content or newsfeed ad ("something in your face")

Budget = $150-500 (very rough)

Send a strong email

Make it feel personal to the recipient

Batches of sentences tailored to that persons company type, needs, the competitor, etc.

Copy: short and punchy

fewer sentences, skip the pre-amble (don't include an introduction)

hey, i saw you're using X. We're better than X because Y — there is a lot more information at this landing page but if you have questions I'm happy to hop on the phone with you.

Let your landing page do the pitching

Drive to a comparison landing page

Tools to automate outreach and follow up - [](https://www.persistiq.com/)https://www.persistiq.com/

[[persist iq]]

## Tricks for [[cold-emailing]]

programmatically pumping out in line images in your email

Do this programmatically

Clearbit company logo API

Grab company logo

Cloudinary image triation API

Dump it into an image

Pipe those into PersistIQ

Email from Brex:

It was a forwarded email

The original email was the CEO of Brex saying "Go talk to Julian Shapiro, I like what he's doing and I want you to give him a year free of Brex"

The sales person forwarded that email and added a note: "Hey julian my boss thinks you're awesome and sees what you're up to and wants you to be one of our first customers

### Q&A

If no one follows up is the lead dead?

He don't know - test following up 3x vs. not-following up

Uses #Copper for a [[sales CRM]]

Contact additional decision makers at a company

ID the decision maker

Upload your list to Clearbit so it can highlight roles

## How to make #ads work with #B2B

About #linkedin

What businesses work on #linkedin ?

Clusters around: employment recruiting service, higher ed (MBA school) recruiting applicants, B2B products/services with LTV > ~$15,000

LinkedIn performance has high #CPC and terrible on-page conversion

Remedy: re-think what LI is doing for you

It's not an immediate sign up or purchase

It's a way to retarget or capture an email

Two #linkedin ads that tend to work ok

Right-hand column text ad

Use a zoomed in face of an attractive man/woman

Feed ad

Use a giant piece of text in the image - huge type, bold letters, big value prop

[[Goals]] for #linkedin advertising

Capture their email

Need to have good content to get their email

And run automated drip campaigns

Pixel & blast on FB

^^**FB ads convert WAY better than LI**^^

#facebook look-a-like audiences

Requires you to create an audience of at least 1m people

More money you spend per day on that look-a-like, the more you venture out into the extremes of the audience

$10/day will keep your target very tight, to only people who look a lot like your audience

Revisit this in context of #[[form health]]

#Quora ads

Target niche interests

Trick for building B2B #brand [[awareness]]

Build a community on slack, run ads to your community

Find a niche that people want to talk about

Gating #content

Content examples: guides, podcasts, [[webinar]]s, etc.

**^^People think highest leverage use of #content is to prospect^^**

But it's better for #retargeting

LI to landing page, pixel to retarget on Fb

Use pieces of #content that are conversion boosting, __not__ lead driving

Content that when you consume it, you think "wow these guys are experts"

Once they've consumed that content, retarget to keep brand top of mind

Content that's hero content: Julian's indie hackers podcast

He ran ads to that podcast, which just sounded smart and

#content & #SEO

joined late

## #keyword prioritization

[[prioritize]]d Google sheet:

Columns: Keyword difficulty, volume, target score (volume divided by difficulty squared)

Tactics for [[link building]]:

Try #Backlinko

[[link building]]: 1-2% hit rate per outreach is good

Send 200-500 emails per week per client

Pick two pieces of #content per month to use as link targets, make them AMAZING, send them to other blogs in the niche

Recommended cadence of #blogging: 2 per week

Good results: 4-6 per week

Start with a narrower keyword then work up to a broader one:

Start with "green tea benefits", rank for that first, then optimize and expand to go broader

Stack: [[ahrefs]], google analytics, clear[[scope]], accuranker

Clear[[scope]] used in first draft

## Writing #content that can rank

#content is the most competitive, zero sum marketing channel b/c for any keyword there can only be 1-3 winners that will get the traffic

IG - you can have thousands of keto lifestyle accounts with tons of followers

So you really need to have the best content

Content quality — have you published hundreds of thousands of posts online & gotten a site to 100,000+ organic monthly visits?

Growth Machine has a database of writers organized by skill, area of expertise, and price

eg - [draxe.com](http://draxe.com)

Paying $150-400 per article (1500 words)

Good B2B writers cost more per article

[Growandconvert.com](http://Growandconvert.com)

[](https://www.thewriterfinder.com/)https://www.thewriterfinder.com/

Only hire writers who have previously published on the topic or is a domain authority

Generate infographics of your #content for #Pinterest success

Resources to learn about #content :

Growth Machine blog

Grow & convert blog

how long should #content #blogging be? 1500-2000 is rule of thumb length

Best cadence for #blogging 

Go for 1-2 higher quality articles per month > 4 shallow posts

Target smart keywords though

For more info on directly above: [](https://www.growthmachine.com/free-course/lesson-4-write-content-that-ranks?ck_subscriber_id=535808417)https://www.growthmachine.com/free-course/lesson-4-write-content-that-ranks

Look at the pages that rank for your target keyword

What other keywords do they rank for?

Reverse engineer the best (highest ranking) content

## #Conversion optimization for #content

Two steps to purchase:

Read first, then buy

How to get them to read first:

Intro (how to write good #content)

Have a hook, be concise, skip fluff

Tease the content

Use simple sentences (see [healthline.com](https://www.healthline.com/health-news/the-right-plant-based-diet-can-lower-your-risk-for-type-2-diabetes#Blurry-lines-of-a-%E2%80%98healthy%E2%80%99-diet))

[[a/b test]] intros(!) and track read to completion rate & purchases

Use Google Optimize to run tests on:

Alternate intro w/ different hook and different degree of brevity

CTAs

How to know if people are reading your posts: Hotjar (scroll depth maps)

[[GA/Google Analytics]]

look at exit rates

Average time on page data is messy, only measures difference between two page views

Search [Riveted.js](https://riveted.parsnip.io) and install to properly measure time on page

Use Facebook analytics to track every journey

How to get people to buy

Segue naturally and smoothly and subtly

## Misc + #content Promotion

One of the most effective #content strategies for well optimized site is going in and re-optimizing pages that were on the second page

Republish, repromote

Be stingy with out #links in your #content — only use high authority pages

Be selective with guest writers and only use high quality writers

Promotion:

Reddit - create a few accounts and pump it up

Facebook groups

LinkedIn groups

Pinterest page

[Also see](https://www.growthmachine.com/blog/seo-case-study) that case study by growth machine of tea & leaf

Know exactly where your ideal customer #persona (SEO in a small online business) is hanging out online (authority blogs) and what #content really excites them (actionable case studies). — saashacker

[[landing page]] #design & #CRO

### Myth 1: [[CTA]]s should be aggressively focused in the ATF (hero section) to get visitors to click as quickly as possible

Reality: visitors should actually hit a threshold of understanding

B/c visitor gets taken to a squeeze page too soon

Instead, write the landing page so well that you want them read it before converting

3 Steps for optimizing [[CTA]]s on your [[landing page]]:

Put hero CTA into nav bar (remove from hero)

Don't intersperse the CTA throughout the sections until you've reached 1-2 sections down

Conclude whole landing page with big CTA

### Myth 2: Long [[landing page]]s are bad

__fluff__ is bad, length can be good

Sections - not in order (esp. for #B2B #SaaS):

Detailed breakdown of specific uses for the product

Comparison grid of how the product compares to competitors

Hero

How it works

Social proof

Visualization of product in action

## Overlooked pages:

### Comparison [[landing page]]

Could be useful for [[form health]]

Pair with comparison #ads on #facebook (ads that call out competitors by name — [competitor] vs. [your product]? Here's why [your product] is better!)

You know your audience understands the product category so you can focus on why you're better

Split page into two halves:

1 = your product to accomplish something

Explains how it's greater

2 = your competitor

### Press article [[landing page]]

Whenever a press outlet covers you, dont run the ad traffic to that outlet

Solution: copy & paste that article into your own page

Embed the article

Add your intro on top of the article and cite the source (link back to the original source)

Tweak the post slightly so that every mention of your name is a text link back to your product pages

Surround the top & bottom of post with CTAs

### #retargeting [[landing page]]

Pages you send retargeted audiences to should be other pages than what they left from

What can you do differently with this second shot at bat?

You can assume the visitor already knows reasonably well what you do (...sort of)

Page components:

The same value props, but laid and pitched out very differently

Example structure:

A few paragraphs of a blog-style story of why our product is awesome

Giant bullet list of benefits

Video of product in action

Offer a retargeting specific deal

For users who invite other users — identify which VP would be most attractive to person being invited

How do you know what the want to hear about? Ask the person doing the inviting for details about the person they're inviting

Fill out a little survey with: role at company, type of company, interests, height, etc.

Example: show off the value that the person doing the invitation that they're getting from your product

eg - Your friend John has been using Clockwise to increase their flow time 50% per week

### Misc:

Example home page: [Tovala](https://www.tovala.com/)

Add maybe 30% more content (3 more paragraph/sections)

Homepage performance metrics to monitor: $$$$$$

Examples:

Tovala

Tools for landing pages: Webflow

### Questions:

How do you manage all these [[landing page]]s?

What's the highest leverage thing to build? Julian picks two that he thinks will be the strongest, test them, and either iterate if they performed or bombed?

80/20 of landing pages beyond homepage:

Retargeting landing page

Competitor comparison page

how to #optimize for #mobile first (#CRO)

Reduce scroll, delete fluff, become more succinct and tighter

Keep CTA hovering in nav bar or footer to keep it out of the body

What do you think about closed or squeeze pages? These work (if you a/b test with or without the nav bar)

Requesting backlinks from press: yes

For copy surveys: what do you like most about my product?

Tools:

Google Analytics, Google Optimize, HotJar

Nav bar:

Use to let people self-identify — list out persona-segmented landing pages

## Critiques of [[landing page]]s

[Usesession.com](http://Usesession.com)

Hero:

Hero sentence is vague. should be: Hey Photographers. We make booking your sessions 10x easier.

2nd section:

Text is a mouthful, icon grid is too busy — remove the obvious

Focus on the items that make people say, "wow they have __that__?"

3rd section:

Great using social proof of her ig followers

4th section:

Visualizing the product - great for SaaS

Remove aspirational copy & stuff about beautty

Instead use specifics, point out pain points, twist the knife

CTA should be dynamic with the image and surrounding content

5th section:

Real-time interactive simulator is GREAT

6th section:

Kind words for customers

Oasense

Hero

Video is not showing what the product is well

Hero message is redundant

Home page just links to learn more

Learn more page

First text on a page should be a very quick sentence, that builds momentum to longer paragraphs

When you start with a paragraph you get them to get into the skim reflex

Askquesty

Hero

Great copy — super clear, visualizes an example of the problem it can fix

Also tells price point immediately

2nd

Include more logos in the hero

Doesn't describe type of questions, instead has generic value props

Should have example use cases here to demonstrate pain points

image looks generic

this hsould be 4th

3rd section help from all directions

this is what should be 3rd

4th whats supported

Should be 2nd

5th get help 3 ways

Compare them, no one is going to click on these links

6th incredible talent

good placement near the bottom b/c its a lesser concern

though the people look young

7th reviews

[openphone.co/openphone-vs-google-voice](http://openphone.co/openphone-vs-google-voice)

Beautiful comparison page

Hero

Great copy, great CTA, great hi-def visualization of app experience

Problem is that it doesn't say what specifically openphone does

Have a sentence

Social proof - not clickable

should be clickable or provide more context

More social proof and reviews

great

comparison grid

replace the sub-header copy to be more specific

Great - but make sure this is stuff prospectcs actually care about

customer support section

Title is unclear

Business hours

Ditto with the header

good bullet points, good CTA

End by repeating the #1 rated app in the app store

Maybe switch up the CTA copy

[uprisingfood.com](http://uprisingfood.com)

Hero

Copy is too cute

Section 2 - saying your food is the best is kinda dumb

a/b test the brand vs. product focus instead of standing in the middle

[bannerman.com](http://bannerman.com)

Hero:

software if youre targeting people who already have security guards

images if youre targeting people wh oshould have guards

2nd section;

each paragraph is way too long — turn it into 3 sentences

Hero message + sub header is a good pairing

copy needs to be much more specific — point out pain problems and twist the knife: eg, low quality guards don't screen people well and randos sneak in and steal your shit

your mission control

this one is perfectly written

Good client logos + social proof

Believable because they have quotes

3 value props: custom solutions, centralized support, 100% transparency

Footer: the CTA is super generic

Be more specific

[rentsweet.com](http://rentsweet.com)

hero

Great explanation and hook offer

Clipart is bad - use dashboard or product

2nd section

Remove redundancy — first sentence is the same

turn paragraph into bullet points

paragraphs are only good to explain problems or solutions that are not self evident

make screenshot larger higher res

ending CTA

The text is too long and the CTA is too unclear for what youre putting your info in for

[Podyssey.fm](http://Podyssey.fm)

Hero is __ok__ — too many CTAs though

make sure the first section/value prop is the most interesting or valuable

the featured community-created playlists should be up top

if youre curating content THATS your hook - let people play around with it before converting

[weardulo.com](http://weardulo.com)

hero

photography looks professional and nice

kind of bland copy and photography

social proof and testimonials — way too soon for a shirt or food

instead show a video and/or up close high res photography of the product

products are just segmented by color

value prop of saves time is way too late, should be up front

the social wall should be way up higher w

Bizybee.app

Hero

Confusing what a message, confusing who this is for, confusing what the root cause of the problem is?

Second section

Not clear what type of messages...instead show a "real" conversation between the user and a business

3rd: multi-send support

Flip the header and the paragraph - put "quickly compare quotes" as the header

Because people are scrolling through looking for whats interesting

4th: works with your favorite messenger

5th: fast & minimal

helps you get stuff done is super generic & useless

Validating New #product Ideas

With [[Hiten Shah]]

[[idea [[validation]]]] helps you waste less time and money

Do this by finding the fastest path to learnings

So need to first: define the question

__Design Sprint__

Code is an expensive way to validate ideas

Research = fast and cheap (surveys, interviews, competitive analysis)

Only write code when it becomes the fastest way to learn

**#surveys**

[[qualitative]] and open-ended —> enable you to learn as much as possible

Example:

Question: What's your single biggest challenge when it comes to [X]?

Please provide as much detail as possible about the challenge you face. The more information you provide the more it will help us create software that will be super valuable to you.

Tools: Ask Your Target Market, Survey Monkey

5-10 questions, get early access to the results

Then share a blog post

Format depends on where your audience is

#[[[[interview]]s]]

Key question: Do you have any stories about when something when wrong when trying to [X]?

Go through a marketing site and tell use about what you love and hate for each section

[[competitive analysis]]

#NPS

Customer #reviews

Helps you understand how customers think about the problem, brands, etc.

Website Analysis

Validate with the lightest weight MVP as possible

FYI tested whether the search box is good enough

Advanced #copywriting

Also related to: #content & #blogging

Good blogs

[MeltingAsphalt.com](http://MeltingAsphalt.com)

Kwokchain

Medic update (#SEO) and #EAT

#Google is trying to rank sites that have demonstrable domain expertise relative to the topic

"Subject matter authority"

Type of topics

Health (acne, ADHD, anything medical)

Financial advice

How to demonstrate authority

Healthline is a good example

Posts have a blurb:

"Medically reviewed by Timothy Legg PhD, PsyD on June 13, 2019. Written by Tracy"

Citations - trusted sources and high quality #links

PerfectKeto

Has medical professionals review their blogs

"Fact checked"

Start by demonstrating your authority.

Getting started with #blogging - few EXTREMELY high quality blog posts, or higher volume of good quality

More important to really hone in on a small range of long tail questions or searches

Less competitive

Closer to transactional query

Prune and #optimize #content

Go into GSC (or #[[GA/Google Analytics]] ) - and look at pages over 12-16 months

If pages aren't capturing any clicks or very few impressions, they're good candidates for axing

Remove with 410 or 404 or merge with something else or re-write?

Do NOT do a soft 404 (remove the page and 301 redirect to homepage)

Consider using the "site:www.example.com" search operator to see which post #Google is returning first for a particular intent

If a page created for a particular intent is lower ranked than another page on your site —> you have a problem with the content on that page

When seeing a wide range of overlap between two queries (eg - how to get rid of pimples and how to get rid of pimples fast) that means Google thinks that subintent is the best result

If you had posts on both topics, you'd merge into the winning subtopic

Writing for B2B or anything - post straight to #medium , #linkedin , website or all 3?

__Never__ use #medium or #linkedin as primary platform

Post everything on your own site, republish on platforms and include "originally posted on __website__" at top

Customer personas for blog - meh

#content refreshes

Only when topics change

High impressions, low clicks

Rank 5? This is actually just the photo gallery

Pumping out 12 posts / month - how to manage?

Live by the outline - work on [[insight]]s first

Break down into outline

[[linkedin]]: #organic + #paid

[BAMF.co/linkedin-influencer](http://BAMF.co/linkedin-influencer)

AJ Wilcox - paid [b2linked.com](http://b2linked.com)

## Paid #linkedin w/ AJ Wilcox

Note to self: this is a great resource to supplement with #[[Demand Curve]] course notes

Day parting is important, but its not offered via LinkedIn (all of LI is based off UTC-GMT)

If your budget is small, then your ads will start running at like 9pm EST

[adstage.io](http://adstage.io) can help automate this, otherwise you have to manually pause and turn on

Split [[audience]]s - micro[[segmentation]]

By job seniority: marketing director campaign, CMO #campaign, etc.

Helps us understand who our actual target #audience is

Also breakup by different types of target

job title, job function with seniority, skill with seniority, groups with seniority

eg - CIO job title, IT/engineering job title w/ c-level seniority, IT skills with c-level seniority, IT groups w/ c-level seniority

sponsored content #ads on #linkedin

People interacting as if they're organic, but these don't give admins [[notifications]]

Rep [[management]] is hard with this

Targeting smb you're doing it by company size

Most smaller companies dont declare their size or dont have a company page

So instead of targeting a specific small size, just exclude bigger companies

Targeting by skills or groups

people who are selling to your target audience often list these skills or groups

exclusion job function: marketing, sales, biz dev

Add LI pixel

You can go to anyones page and click on their ads tabs -

Bid cost per click - bid to the floor

If CTR are over 1% for two straight days, bid CPM

Interest narrowing:

Interests are very broad

#campaign nomenclature:

Name campaigns by audience:

Ad format | Objective | Audience

#B2B companies that dont work well on #linkedin

Ad/digital marketing/SEO agencies b/c its a perceived commodity until you have a strong value prop/offer

What's the best offer or value prop?

Provide an interstitial on a landing page that provides content that captures email address

Gated content: free checklist, cheatsheet, guide, [[webinar]]

Goal: email

For #linkedin #ads - start with simple: single image, text ads

very easy to troubleshoot

text ads only show up on desktop (this is the only way to just get desktop traffic)

LI native lead gen ad format

good if you can't make a landing page

most fields are auto filled

**downsides**: lower lead quality, can't be tracked, can't be retargeted

60% of AJ's clients use lead gen forms exclusively b/c of low CPL

Used for quantity > quality

Landing page = quality > quantity

If: good results but tapering off quickly, what do you do?

This is saturation

On FB frequency gets high quickly - can burn out within half a week to a week and a half

What to do: update creative for same offer

#benchmark #metric for #linkedin:

CTR

Spon con

above .5%

Text ads:

.025% CTR

Sponsored inmail

55% open rate

4% CTR

.40 to .60 cents

conversions:

hard (like sign up): 1.5% to 4%

Content offer: 15-20%

## Organic LI with Houston

founder and CEO of [BAMF.co](http://BAMF.co)

### Profile optimization

Profile photo

[snappr](http://snappr.co) linkedin photo analyzer

[clippingmagic](http://clippingmagic.com) to remove the background

tagline

Formula: {{achievement, tangible benefits, questions (looking for x?)}}

Emoji

header image

event photos - you speaking on stage in front of an audience

group photos of your team

custom graphics with a call to action

social proof

summary or about section

First line = clear CTA (include email in first line)

Links

make sure these links are optimized for LI (with open graph)

customize your URL

experiences

recommendations

publications

honors & awards

### Building an audience

### Creating content

### [[translate]] an audience into sales

### Q&As

#referral programs

Definition of [[referral]]s:

Amplify and encourage distribution of information through a system of incentives

Referred users are most excited b/c they found through trusted source

Referred users = strong #cohort of users

[[referral]]s = system

Similar to #engagement with a feature or driving a purchase

What signals is your audience giving? You have to know your audience

Look at users by type, engagement, product type they're using

Allows you to put them into a personalized engagement campaign that leverages conversion tactics

You can also understand exactly what type of audience would be a good fit for your company

Make sure your current users know who would be a good fit

Treat [[referral]]s as one of your #acquisition #channel

Look at points where the user has been delighted to trigger a [[referral]] request

First purchase, first open, product surprise

Track how links are being shared organically

The more personalized and private the [[referral]] conversation is, the better success

B2B products: use email

Personalize the programs:

have the #referral [[landing page]] include referrer's name in URL

simple and straight forward [[language]] + emotional touch works best.

Imperfect Foods uses a combo of reward + specific, emotional ask:

give $10, get $10

refer to someone who you think would help fighting food waste

How to personalize

survey during onboard (what's your role? etc.)

monitor behavior on site/platform

enrich email address with clearbit or something

Incentivize with non-cash rewards

Maximum payback period for [[referral]]s

Brex: make sure its not over the rest of acquisition

CAC:LTV ratio is a function of a risk you're willing to put on

How do you build out your programs

Brex: built in house

Run [[referral]]s as early as possible - they lower #CAC !

Ambassador programs vs. #referral programs

Ambassadors get special treatment: unique tools + larger pay outs

KPIs for [[referral]]s

number of referred / users

For when youre in a market where people are ashamed to use yout

[[webinar]]



