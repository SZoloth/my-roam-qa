Author:: [[moz.com]]

URL:: https://moz.com/blog/understanding-fulfilling-search-intent

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

informational, navigational, investigational, and transactional-related intent types, 

Is it navigational in nature, people just trying to go to one destination? 

Transactional, are there tons of ads? 

any given SERP doesn't necessarily have one intent type 

