Author:: [[worldpositive.com]]

URL:: https://worldpositive.com/a-modern-guide-to-lean-okrs-part-i-c4a30dba5fa1

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 22nd, 2020]]

Even if you check these boxes, there’s one more element that is critical to the success of modern companies today: a clear articulation of purpose and values. One’s purpose is the “animating force” of achieving profits today, according to BlackRock CEO Larry Fink. Yet purpose and values — a [[North Star]] and navigational system — have historically been absent from the OKR process. 

