Note Dump for [[Article: Creating a Glossary for SEO]]

Examples:

PathAI

https://www.datarobot.com/wiki/ai-engineer/

https://www.flexport.com/glossary/

some sites have their glossary as a continuously-updated blog post (https://www.outbrain.com/blog/digital-advertising-glossary/) and others have it as separate webpage (such as the examples you sent over). the main negatives i can think of for putting glossary on blog is having to work within the confines of a blog post (i.e. difficult to link to sub-pages dedicated to specific glossary terms, and not able to organize terms in any helpful way)

this is bad because you can't optimize URLs

the one advantage a single page glossary (like outbrain) has is if you’re targeting [industry name] glossary but you’re doing so at the expense of optimizing for all the other glossary terms (edited)

the outbrain page ranks very highly for digital advertising glossary and nothing else.the flexport example i sent contains multiple pages that rank #1 for 197 keywords, some with 5k+ search volume

architecture

i’d recommend:

[yoursite.com/industry-name-glossary](http://yoursite.com/industry-name-glossary) for the list page

[yoursite.com/industry-name-glossary/term](http://yoursite.com/industry-name-glossary/term) for each term

couldn't you get best of both worlds though if you have brief definitions on main glossary page and more in-depth definitions on the term-specific pages? 

DataRobot is getting away with this with https://www.datarobot.com/wiki/

Although you shouldn’t use wiki since that’s going to put you in competition with wikipedia.

unless, of course, ~3rd place for wiki is > ~1st place for glossary

another example of an optimized main/list page - https://pathmind.com/wiki/

yeah on your list/main page you’ll want to have links to all the terms

things that would only really help your biz, not the type of audience looking for definitions

subscribe

nice to haves that __could__ help:

featured article

search functionality

filter functionality

share buttons

the key things that page would __need__ are:

H1 withyour keyword

H2 with "what is {{your keyword}}

title with your keyword

URL with your keyword

list of internal (definition) pages

Some form of introduction text (the [pathmind.com/wiki](http://pathmind.com/wiki) does this better than datarobot, and they rank higher for ai wiki than datarobot as a result)

also note that ranking really well for keyword definitions will sometimes land you in the featured snippet, and may actually __reduce__ traffic to your site..

 https://files.slack.com/files-pri/TMBUV02NS-FS8RT0UKD/screen_shot_2020-01-13_at_1.02.27_pm.png

how to pick terms

industry terms, sorted by search volume



