Ways to improve [[backyard]]

[[gardening]]

vines

star jasmine vine

To avoid damage, grow aerial-rooted vines on trellises or lattices that are installed just in front of your wall so the vine doesn’t actually touch it.

Many vines are easy to grow from seeds, including cypress vine, moonflowers (__Ipomoea alba__), black-eyed Susans, and morning glories.

likely need a [[trellis]]

For flowering vines that sprawl, such as climbing roses, use garden ties or stretchy fabric, like old pantyhose, to help them get established.

How to plant vines

In general, plant most vines in loose, well-draining soil. Dig a hole twice as big as the plant’s root ball and about as deep. Work aged manure or compost into the soil at the bottom of the hole.

Gently slide the vine out of the pot and put it in the hole no deeper than it was already growing. Make a basin from more soil over the root zone, so water won’t run off before it has time to soak into the ground.

Water thoroughly and deeply, and apply a generous layer of mulch, keeping it away from the stems of the vine.

[[outdoor furniture]]

hammock

probably not feasible unless a stand up

[Wayfair spreader bar](https://www.wayfair.com/outdoor/pdp/longshore-tides-addie-double-spreader-bar-hammock-w001316232.html?piid=339945782): $78.99 (on sale)



