#[[Quick Capture]]

L’aviva for [[Ally Portocarrero]]

[[Meetings]]: [[Drawbridge]]

Attendees:: [[mike ohara]] [[Jill Starett]] [[sean riley]] [[Carolina Escobar]] [[alex fedorov]] [[jayne hetherington]] [[quin o'hara]]

Time:: 14:28

Notes::

 Personas

We looked at trends around sensitivity to privacy and how users are reacting to things like data breaches

We combined that with what we know so far about the direction of the product and the brand and developed these 4 personas 

