[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Update COVID blog

{{{[[DONE]]}}}} Edit the MVP design blog

{{{[[DONE]]}}}} Check in on case studies - sent an email to #[[chris baker]]

{{{[[DONE]]}}}} JIRA process for marketing

Research notes

Notes with sources below

Workflows

List and group the content you might make

Things like: banner ads, organic social post, email copy, [[webinar]] abstract, [[webinar]] deck, newsletter article, blog post, microsite article, customer story/case study, product announcement, thought leadership article, landing page, website update, video, press release

https://3kllhk1ibq34qk6sp3bhtox1-wpengine.netdna-ssl.com/wp-content/uploads/JIRACore-smartplan-blog-600x-retina2x-table.png

Sketch out all the steps involved and the people needed

Assign different stakeholders to each step in the workflow

Example of JIRA software agile marketing

Sprints span 2 weeks

Epics are defined as months of the year

Versions are defined as quarters of the year

Process for managing:

Half-day quarterly strategy meeting  to define the project's big-picture [[Goals]].

1 hour monthly strategy meetings to ensure that the team is on track to meet the quarterly [[Goals]].

30-minute weekly Sprint meetings first thing on Monday morning to describe high-priority tasks, roadblocks or capacity issues.

Daily standup meetings first thing in the morning to check in on Sprint progress.

Sort issue types by project type (eg: content, email, paid, SEO, etc.)

http://atlassianblog.wpengine.com/2016/01/3-steps-marketing-zen-visualize-your-workflow/

https://www.atlassian.com/software/jira/core/marketing

https://support.atlassian.com/jira-core-cloud/docs/use-jira-core-for-marketing-projects/

https://www.atlassian.com/teams/marketing

https://www.ricksoft-inc.com/post/jira-for-marketing-definitive-guide/

if i wanted to set up a jira project to handle marketing stuff (like drafting, editing, publishing, and promoting blogs or campaign set up, writing, designing, reviewing, and optimizing ad campaigns) would I:

do classic or next gen? set up different projects for each channel? or have each channel be it’s own swim lane? or epic?

For content (eg blogs, case studies, emails, pillars)

Steps & owner

Open

Owner: author

To complete blog:

Define target keyword or topic

Write outline in clear[[scope]]

To complete case study:

Interview PMs and stakeholders

Structure notes into outline

Draft

Owner: author

To complete:

Write draft

Add draft images

Define publish date

In review

Owner: stakeholder / manager

To complete case study:

Send to PM for review

PM send to client for review

PM to request Clutch review if relevant

To complete blog:

Send to SME / manager for review

Get final sign-off from editor

Add final graphics

Publish

Owner: author

To complete:

Publish on CMS

Share with social media team

Share with sales

For ad campaign

Steps & owner

Open (strategy)

To complete:

Define target audience & persona

Define primary value prop & positioning statement

Define channel

Define budget & goal

Draft campaign

To complete: 

Write ad variations

Design corresponding creative

Add to the campaign manager for the ad channel

Define launch date

Set up targeting

In review

To complete:

Get final sign-off from manager

Launch

{{{[[DONE]]}}}} Positioning / messaging strat for [[Museum of Science]] #/

[Personas](https://docs.google.com/spreadsheets/d/1cB3n-tVQJi_cdagdNY2DwzbHx_Fbbln5FZk-wRt9AQk/edit#gid=0)

{{{[[DONE]]}}}} Awareness ads & retargeting

#[[Inspiration for ADK]] What tech resources could we create for education partners for free that they could link to?? 

Interview with [[Dan Gardner]], CMO of [[Code and Theory]]

Dude is also the founder

Creativity & technology to solve business problems

Agency landscape teardown (types & roles)

Historically, they were boxes

Traditionally advertising (TV)

Copywriter, art director, planner (who you're reaching and what problem you're solving)

Then you throw in:

Tech companies (large scale engineering to build things)

Management consultants

Code & Theory = intersection of above

data at the center to inform operational, business, technology, marketing & comm, product and services

Celebrated agencies are boutique that do a few things very well - how do you scale while maintaining specificity, skill, and quality

Two components to any agency: people + culture

People = talent

Culture = how people work together

How to do creativity remote [[Inspiration for ADK]] [[alex fedorov]]

Recent opportunites since COVID

Education and remote learning

Mainly at lower ed levels

healthcare

a newly formed business unit called C&T Health with a partnership with Scout Health (an agency leading in rare disease and specialty health)

government

DMV

digital infrastructure behind the scenes

DMV UX tear down [[Inspiration for ADK]]

Biggest opportunities accelerated by the pandemic [[Inspiration for ADK]]

Launched **Decode**, a digital publication

Has a uniqe experience within media and publishing world

Daily Beast, LA Times, BBC, Guardian, Bustle

Know editorial, commercial, technology sides

Modern media marketers say brand is/as publisher

1-1 not 1-all

atomize your messaging

Want to experiment with contents and formats

The short form email [[Inspiration for ADK]]

Communicate a culture of change and innovation externally

Hire the person not the role

They specialize in UX but don't have a UX department

How do you measure success?

What are we making? What's our ability to solve problems?

Via acquisitions and experimental hires

Constant analysis to make sure they're a healthy company

The resources to invest in the future

The right people to deliver effectively today

Brand campaign

launched the daily beast

