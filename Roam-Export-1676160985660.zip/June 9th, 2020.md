[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} [[form health]] facebook ad check in from [[darci nevitt]] (HHI campaign)

{{[[DONE]]}} Follow up on above

[[Sleeping Dog Properties]] [[Home Office Campaign]]

[[Meetings]]: [[ADK Marketing Project Management]]

Attendees:: [[Jessica Hodgkin]], [[chris baker]]

Time:: 1:30 - 2:00pm

Notes::

Create artificial divide between campaigns and website

Focus on campaign playbooks

[[Meetings]]: #APCIA #analytics

Attendees:: [[aaron crootof]]

Time:: 2:00-2:10pm

Notes::

Just passing advice about analytics

[[Meetings]]: [[ADK marketing team meeting]]

Attendees:: [[nick watkins]], [[darci nevitt]]. [[jordan daly]]

Time:: 2:00-2:30pm

Notes::

[[Mercer SEO Presentation]] status update: 

{{[[DONE]]}} for [[sam zoloth]]: [Content ready for review](https://docs.google.com/document/d/1mSfLq1STrAFaDFaKDOcC2JX17Mpl6-vsZZwy4WFI3XQ/edit)

Draft for a worksheet ready for review

[[[[Wasabi]] analytics]] #Wasabi

Quora is working as an organic channel? for [[[[Wasabi]] analytics]]

[[Meetings]]: #[[Wasabi meeting]] 

Attendees:: [[Michelle Smith]] [[chris skoglund]], [[juan bermudez]], [[lindsey kinzer]], [[darci nevitt]], [[nick watkins]], [[jordan daly]]

Time:: 2:30pm-3:00pm

Notes::

Landing page specifically for partners

{{[[DONE]]}} Things to do for SEO  - can #[[Michelle Smith]] get these into project updates?

Optimize glossary

Partners

Comparison page

Split pricing page

Documentation - https://stripe.com/docs

[[Big Brother Big Sister (BBBS)]] [[activities]] for #[[nayvon]] and [[things to do with ally]] in [[boston]]

ice skating

bowling

museums

aquarium

zoo

arts & crafts

cooking

kayaking

duck tours

[[BK/Brooklyn]] boulders

needs advance planning

