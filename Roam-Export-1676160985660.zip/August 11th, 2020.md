[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Prep [[Wasabi]] marketing #/

From GA

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FeSCL8P1dan.png?alt=media&token=da1b0af4-a009-48dd-9309-28fbca66c01f)



Keywords for wasabi

cloud storage pricing

s3 calculator

s3 storage costs

cloud storage pricing comparison

object storage cloud

immutable

cloud migration tools

cloud storage comparison

google cloud storage pricing

data storage support

cloud storage for video production

offsite data storage pricing

healthcare data storage

msp backup software

pay as you go cloud

hybrid storage solutions

cloud storage for education

multicloud storage

cloud object storage providers

video content delivery

buy cloud storage

petabyte

cold storage cloud

how much does a petabyte cost?

what is a petabyte?

what is an exabyte?

what are api tools?

what is access key?

how much does cloud storage cost?

what is cloud lock?

what is direct connect?

what is backup as a service?

how much does s3 really cost?

backup as a service

Opportunities for wasabi

Analytics

Pillar pages

Audit existing content & use the real design

topics:

what is cloud object storage

cloud object storage comparison

http://gaul.org/object-store-comparison/

https://www.qualeed.com/en/qbackup/cloud-storage-comparison/

cloud object storage pricing

cloud storage backup

immutable storage

Glossary pages

Expand breadth: more topics

Strengthen depth: add more detail per topic

Linking & offsite

Review sites

G2, trustradius, capterra

Link building

guest posts

**A/B testing**

formalize process

stablize implementation

increase cadence

Technical improvements

internationalization

speed

Content audit

UX and linking updates

blog architecture

Content themes

replication

backup

petabyte and high-volume storage

competitor comparisons

enabling high tech (AI)

Edge & microvaults

vertical specific

Media & entertainment

Surveillance

Higher Ed

Moonshots

Training/resources/academy

https://www.digitalocean.com/hatch/

https://stripe.com/atlas

growth.segment.com

https://segment.com/academy/

Expanding partner landing pages

Zapier example

Help docs

Stripe example

{{{[[DONE]]}}}} ADK Brand campaign #/

From a conversation with #[[chris baker]]

Worth ideating on what we could do that could be somewhat viral or could really drive visibility with decision makers, even if not directly related to our areas of focus.

I think we could get away with it if we focused on the Comcasts/Verizons of the world. [BadUX.blog](http://badux.blog/)

"A not-so-carefully curated collection of broken products from companies bigger than yours. We hope it makes you feel better about your own broken products, like it does for us. Curated by the product engineers and designers at @adkgroup."

Steps:

1. Refine idea
Concept

Name

2. Purchase domain
3. Collect content
4. Loop in designer

[[Meetings]]: [[MIT PEL]] #MIT UTM questions

Attendees:: [[Michelle Smith]] [[Adin Zussman]]

Time:: 11:00am

Notes::

PEL is looking to add ?utm_source=__the URL from MIT PEL__&utm_medium=refferal to any external link programmatically.

PEL is pulling URLs from a centralized database

The URLs in that database have UTMs that apply to different URLs

made up eg: ?utm_source=PE&utm_medium=website

yeah if we’re pulling in the PE UTMs and **__not__** stripping them, then outbound traffic from PEL to {__example tributary site__} will look like it’s coming from PE (not PEL)

That means: when a user lands on PEL and clicks on one of those URLs, the traffic will get attributed to the PE site

The UTM questions brings up an opportunity they're not taking advantage of (b/c of lack of coordination across tributaries): if they could set up unified analytics for all websites, they would have much cleaner data on users and could track people as they bounced around from __any__ MIT property. With the current implementation, if a user goes __Google Search -> PEL -> Tributary 1 -> PEL -> Tributary 2 -> Convert__ we've lost the fact that the conversion was originally driven by Google Search. It'd just look like __PEL -> Tributary 2 -> Convert__.

Ideal set up

A unified GA property 

One view for each 

Landing page enroll button -> ecomm site

comes in as direct, not sure why

all tributaries are subdomains

{{?utm_source={the URL from MIT PEL}&utm_medium=refferal}} is better in that it would show the specific PEL page that drove traffic

the other one would just lump it all into “MIT PEL” that ones just easier because it’s less dynamic (doesn’t require populating the UTM with the current URL)

{{?utm_source=MIT%PEL&utm_medium=refferal}}

ADK Blog idea [[ADK content]] [[ADK content]] [[Inspiration for ADK]] #//

could be interesting to do vertical-specific tech stack recommendations

eg - recommended tech stack for mhealth app + real world (client) example

then recommended tech stack for higher ed site + real world (client) example

could also do role specific, like recommended martech stack

My thought would be related to how one of those groups (mhealth) for example improved their tech stack to create efficiencies while also looking at users needs and improved workflows for users

[[Meetings]]: [[Museum of Science]] 

Attendees::

Time::

Notes::

$2000 for 4200 leads

$0.47/lead

quick note about the phrasing of that - “what are we offering” vs “what do we have available to pick from”

Offers

posters

discount

free trial or guided access

BOGO

referral

landing page, emails, 

{{[[DONE]]}} Marketing strategy outlines for the following #///

Outline = deliverable + how to get there

Competitive research

Channels

Positioning

Pricing

[[a/b test]] [[ADK A/B Testing Process]]

[Tracker](https://docs.google.com/spreadsheets/d/1-IvTkbdazwSo4cpsZMUa5CdqTewdDBSrvGfk0SL6d1A/edit?_hsmi=92447712&_hsenc=p2ANqtz-_qf1Sx-h1qrZFxQLOMd7Gp2cMZ4du0VlCmCfJqLwSZPB1EHHnm_xHb6F0oiaCCUwrl58OzHlC3uwe-mbOD_EYS3bWb_A#gid=2039954270)

[Proposal template](https://docs.google.com/document/d/1U1p4Eb4wL4WWE9Nwfq6awktcjANZUxNJUN_MNj6DH7A/edit?_hsmi=92447712&_hsenc=p2ANqtz-_h0WQi42gPWJLpWm__o8rbPRHvCrwDUWOTD3wgLQKx5Gg2PHknqmIAQHlNNqtoNbDsoFws82bYNj-5AjvmvrOdQ_-nHQ)

[Alternate proposal](https://docs.google.com/document/d/1zh6I_LqBubhQHsKYZYL4GD-gEZXEo0CVttr-CdOsQ-U/edit#heading=h.j1twr366ib4n) -> Form Health

[Alternate proposal](https://docs.google.com/document/d/1g3cs1x-scTnHv5YbvDrYJk25-YB6KddQ-AH_k9YoAjc/edit) --> Wasabi

[Review presentation](https://docs.google.com/presentation/d/1qG1FYy4jyD2HZGPHrgPZzCY6UA7VSCBogyRkh1NlTGs/edit?_hsmi=92447712&_hsenc=p2ANqtz-8yGFVCi3xVlhNxTWOpIp0hnShhzGRyGmFbpSpchkbYYLDFadcEp6HcOWpsTIhZx2-V4AhEo_NxmbgSZKYezwTe3zR4iQ#slide=id.g8dea7242f3_0_201)

[Best practices manifesto](https://docs.google.com/document/d/1r67tYXuDKGPSdHuu6EMDUpM9Q0EhHlYAyCxRbpMFrd8/edit?_hsmi=92447712&_hsenc=p2ANqtz--QHGV12yoOupziBSHOq_5LAHJzVg-OKo_1_7HZrYVemEQ1ax4nyWpgtFDLLtyteDDH2VZBsW-_q-ovkYgNNTRq6pG82g)

