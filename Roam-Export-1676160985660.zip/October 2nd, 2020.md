[[Wasabi analytics: 9/18/20 - 10/1/20]]

[[Meetings]]: [[Wasabi meeting]]

Attendees:: [[mary mccarthy]][[julie barry]]

Time:: 10:30

Notes::

 Featured in the IDC report

Puts Wasabi in the same category as big 3

Deliverable

Press Release

Landing page

Board meeting

Phenomenal

[[Meetings]]: [[OKR]]s 

Attendees:: [[chris baker]] [[jordan daly]] [[nick watkins]] [[darci nevitt]]

Time:: 09:27

Notes::

{{[[DONE]]}}  KRs I will own: #[[🏔ADK [[Task Management]]]] #/

Define a digital health marketing product (how we help digital health marketing co’s market).

Set up agile marketing process

Look at PM process

mHealth landing page

{{[[DONE]]}} Plan for exporting [[Screaming Frog]] crawl data #[[🏔ADK [[Task Management]]]] #/// [[marketing operations]]

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FP8rGHQoRrc.png?alt=media&token=ca49b0e8-3729-4355-bfec-d8b08e36f55a)

What data needs to be exported? Where should it be sent to?

[[Meetings]]: [[[[1:1s]] with [[darci nevitt]]]]

Attendees:: [[darci nevitt]]

Time:: 15:31

Notes::

