[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Respond to questions from [[sam ellison]]

**Tactical Questions**

What do you think the first draft did right?

Contextualizes the challenges with staÎtistics to tie it into a "higher purpose" (ie - not just building an app to raise money, but building a a digital tool for a population in need).

Touches on the process and what it's __functionally__ like to work with ADK (though a little lighter on what it __feels__ like).

Did a good job discussing a potentially sensitive subject (eg - saying "patients who might be struggling with weight loss" rather than "obese people").

Framing of the solution beyond an app ("The final product is a holistic, on-demand medical service, enabled by a custom mobile application and provider-facing dashboard").

What do you think it did wrong?

Missing info about the founder / more human-side of the challenge - this may not have come up in the interview, though.

Some word choice was redundant (eg - "...to users directly on their smartphone and mobile devices.") or repetitive (eg - "wealth of expertise").

The challenge was underplayed - a mobile app was an existential need in order to realize and validate the founder's vision with real [[feedback]] from users.

We're looking to transition to a new "flow" of content, from "Challenge, Solution, & Why ADK?" to "Purpose, Strategy, and Impact" 

Could have gone deeper on the specific features/functions we built, why we built them, and why we're a good choice if you need something like that (some functionality, like messaging and video, is essentially a template for us at this point.)

In other words, focuses a little too much on the "what" and not the "why" or "how" of our collaboration, the value of which hinges on ADK being a strategic partner rather than an order-taker.

Missed the analytics work we provided, though this may not have been covered in the interview.

The "Why ADK?" section should have touched on the specific value that an ADK team brings to early-stage (but funded) entrepreneurs - goal would be to generalize the value enough at the end so a reader could see how a similar experience to Form Health's would benefit them.

My initial reading on this: the first section is actually pretty nice (with the exception of the title Subhead), but it doesn’t focus enough on the customer in the following sections. Thoughts?

Agree here, plus what was included in the previous answer.

Are there any specific words or phrases that you feel are OFF-brand for ADK?

Not especially. To nit-pick, the last sentence is a little jargon-heavy and the last paragraph personifies the company ("...the company had a rough idea..."), which dehumanizes the story a bit.

Are the section headers set in stone, or can I take a look at the format?

These are actually not set in stone and there can be more or fewer. Interested in your thoughts here, however it's likely we'll standardize all with "Purpose," "Strategy," and "Impact" 

**Background Questions**

What are some of the [[outcome]]s of the product hitting the market? 

The product was able to go to market in 14 new states, the userbase has grown significantly, and most importantly, is [giving people a new sense of hope, understanding, and confidence](https://www.formhealth.co/testimonials).

Number of users? Success stories? How has this benefited the app’s end users?

Some testimonials: https://www.formhealth.co/testimonials

Form Health is doing a great thing, here. What spurred this initiative? What is Form Health’s “Why?”

Obesity is a medical condition, but is being underserved by being treated as a failure of willpower. Form Health was created to make modern medical treatment of obesity more accessible for everyone.

What obstacles/challenges did Form Health face in the creation of this app? What did they learn from their consumers?

Ensuring HIPAA compliance while setting up an analytics stack that allowed for data-driven growth; creating a clear [[product [[vision]]]] and roadmap.

Are there any quotes from Evan Richardson or others on the Form Health team that you got during the process?

Not that I'm aware of / have access to.

Can you clearly define the [[Goals]] Form Health came to you looking to accomplish? Can you tell me a little more about the accomplishment from their POV?

 Broadly, Evan had a vision for a new medical service enabled by technology. He needed proven technical expertise to quickly create a product that they could bring to market in order to learn from users and provide proof for investors. Through our partnership, we produced a functional, delightful app that enables the Form Health promise of accessible modern medical weight loss for everyone. 

{{{[[DONE]]}}}} Follow up with [[matt rapczynski]] for more time to interview 

{{{[[DONE]]}}}} Export quarter to date keyword data about [[Wasabi]] for [[adam freides]]

{{{[[DONE]]}}}} Teach ADK React team SEO best practices 

{{{[[DONE]]}}}} Write [[[[LMT]] Status Update email]]

Similar to [books read by](https://www.booksread.by/), could do apps used by #[[Inspiration for ADK]]

{{{[[DONE]]}}}} Research [[email deliverability]]

{{[[DONE]]}} How will we promote/support [[refine labs]] project? #/

{{{[[DONE]]}}}} Review the Facebook and Google Ads campaigns for [[Museum of Science]] #/

[[Meetings]]: [[Sleeping Dog Properties]] [[interview [[question]]s for [[discovery]]]] with [[matt rapczynski]]

Attendees:: [[matt rapczynski]] [[nick watkins]]

Time:: 12:10

Notes::

 Cost to hire an architect

This is a life-level decision; most people borrow huge amounts of money

![](https://flbuilders.com/wp-content/uploads/2016/05/graphic-1024x448.jpg)

This is a great example, but might be too inflammatory 

becoming a material brokerage firm

has direct connections with chinese manufacturers

can do savings around 30% 

no storage or retail facility - cut out middle men

In that document we made with Ben, I had brainstormed Refine Labs.

#[[halloween costumes]] freddie mercury

#[[Quick Capture]]

[[🌱 The Making of a [[Manager]]]] for the upcoming marketing meeting 

