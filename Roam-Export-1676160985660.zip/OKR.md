Aliases:: okr, OKRs, okrs

Why are [[OKR]]s valuable?

They are a [repeatable system that helps you create a focused hypothesis, measure progress towards it, set a forcing function, and feed learnings back into the first step](((7YO1W9OmF))).

They let you track results on a quantitative basis 

**The ability to track results on a quantitative basis.** Key results are not general or subjective actions you plan to take. They should always include numbers to make it clear how much has been achieved. For example, if Mary’s objective is to improve her sales prospecting skills, one key result might be to spend two hours a week shadowing Jennifer, the team member who demonstrates the most prospecting success.

The should be looked at every quarter, every week, every day. 

**Make it something people look at, every quarter, every week, every day.** This consistency turns goal-setting into a habit and changes how people think about their work and approach their everyday to-dos. “It puts in place natural milestones that make you think about what you need to do next and aim high.”

They are stretch [[Goals]].

**They have to be a stretch.** Most people wouldn’t consider 70% to be a good grade, but for OKRs that’s just about perfect, Davis says. You want your objectives to be ambitious enough to push you beyond your limits. When everyone does this, it forces the tough conversations about what's truly needed to beat expectations." [12](https://firstround.com/review/How-to-Make-OKRs-Actually-Work-at-Your-Startup/)

What is an [[OKR]] in a nutshell?

A high-level **objective** that is aligned to both team and company [[Goals]] and the 3-5 **key results** that help achieve that goal

