Selling the ADK Challenge

https://adkgroup.atlassian.net/wiki/spaces/AS/pages/1509884843/SellingTheADK+Challenge



