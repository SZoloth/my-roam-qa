[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} Assets, etc. for [[[[mHealth]] app kit]] [landing page](https://docs.google.com/document/d/1ZPeyiVseQ4rZF7fe4xjkj43oScZTL360Skv3G6I1YBE/edit) with [[sean riley]] #//

{{[[DONE]]}} Kick off [[agile marketing]] with [[kirsten weinsheimer]] #//

Great internal resource: https://adkgroup.atlassian.net/wiki/spaces/ADK/pages/1358463293/Agile+Project+Development+Best+Practices

{{[[DONE]]}} Update Google Data Studios dashboards #/

Examples: 

[[[funnel]]s](https://datastudiotemplates.com/how-to-create-a-marketing-[[funnel]]-dashboard-for-google-data-studio/)

Making [[funnel]]s

If you want to keep things free GA and Data Studio work well for this. Two things that might help: create a Segment in GA that is based on users completing the first action in your [[funnel]]. Use this Segment in your [[funnel]] report to show only users who have started the first step in your [[funnel]].Next, go to Data Studios. There's a community chart type called "Metric [[funnel]]" by PowerMyAnalytics (it's free) that makes this super easy. Make sure every step in your [[funnel]] is set up as a GA goal and then add those [[Goals]] to your [[funnel]]! Will show total amounts and % for each step.

[Marketing [[funnel]] - detail](https://datastudiotemplates.com/product/marketing-[[funnel]]-ga/)

[[[funnel]] visualization](https://true-metrics.com/data-studio-connector-[[funnel]]graph/how-to/item/1-how-to-build-a-[[funnel]]-in-data-studio)

[All in one dashboard](https://datastudiotemplates.com/product/all-in-one-analytics-dashboard/)

[Last 4 weeks report](https://datastudiotemplates.com/product/google-analytics-last-four-weeks-report/)

Design

Executive Summary + At a Glance

Card + trend

Users

Bounce rate

Conversion rate

[[funnel]]

Website performance

Metrics

Users, Sessions, New users, bounce rate, average session duration, conversions

Details

Devices, Location

Tables

Channels

Pages

Conversion path

Assisted conversions

Channel performance

Google Ads

Metrics

Clicks, Impressions, CTR, Position, Conversions, Cost

Details

Keywords, Ad groups, Campaigns

Google Search Console

Metrics

Clicks, Impressions, CTR, Position

Details

Queries

Brand vs. Generic

Landing page

Facebook



{{[[DONE]]}} Step up [[darci nevitt]] quality for [[Museum of Science]] #//

[[[[organic]] [[linkedin]]]]

https://www.notion.so/LinkedIn-Organic-Playbook-Private-d746189bd6164a76a34696515849cfc1

[[product hunt]]

[How to Launch on Product Hunt](https://www.notion.so/Product-Hunt-Playbook-Private-dfc8a34080ac4b2d9df83efd863ba290)

[[linkedin]] post: it's becoming obvious there's a huge divide growing in marketing. Curious to hear where you land.

On one hand, you have folks like X and X who preach the gospel of simplicity in marketing. Focus on copywriting & creative, measure only bottom of [[funnel]].

On the other hand, you have folks that live and die by [[funnel]] optimizations. Growth hacking. Tweaking landing pages to eke out conversion rate increase that can have huge downstream implications.

Where do you land?

