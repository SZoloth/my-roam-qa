Analytics

Domains

GTC = glenmede.com

GIM = glenmedeim.com

Impactivate = theimpactivate

GC = GlenmedeConnect

[Tickets](((R6ng86lo-)))

[Done here](https://adkgroup.atlassian.net/secure/RapidBoard.jspa?rapidView=497&projectKey=GLEN&view=planning.nodetail&selectedIssue=GLEN-465&issueLimit=100&selectedEpic=GLEN-464)

**Custom events & conversions**

We'll propose a set of events to track with Google Tag Manager, some of which will be used for conversions. Before setting these up, we'll make sure we've included your [[feedback]] so that what we're tracking is valuable to your and your team and how it's labeled is clear.

Example events we'll propose tracking for include:

Video tracking (starts, pauses, completions)

Downloads

Conversions

RFP initiations

We'll also set up site search behavior tracking. An initial review revealed an opportunity for nearly 20 custom events.

**Cross domain tracking**

Glenmede owns a few separate domains. For some, it makes sense to ensure we can track a single user consistently between them, for others we may just need to set up referral exclusions. We'll define and execute this set up.

**Content grouping, custom dimensions, & custom metrics**

We'll extend content tracking capabilities further by implementing custom content groups, based on things like business line, post topic, publish day, blog length, number of images or media, and other groups defined in a discussion with your team.

Custom dimensions let you slice data similarly to content groups. The main differences are that content groupings show aggregate unique views and can be used in the behavior flow. Meanwhile, custom dimensions can be used to filter views and can be used across views. Some powerful examples of custom dimensions focus on user properties, like whether or not they are logged on.

Custom metrics are similar to dimensions except they segment users by quantitative measures. Some examples could be the number of articles read or the number of assets downloaded.

**Data studios template**

We'll wrap everything up with a clean dashboard created in Google Data Studios with views customized for up to 4 stakeholders.

All of this will be built on top of best Google Analytics and Google Tag Manager practices.

**We can help you accomplish all of the above with a budget of 30 hours. **

Let us know if you have any questions, if you want to proceed (I can include this in the Change Order we'll be discussing more tomorrow), and/or if you want to have a call to talk more with Sam!

Thanks!

Notes on [[cross domain tracking]]

[Cross-domain measurement](https://support.google.com/analytics/answer/1033876) is a Google Analytics feature that allows you to see sessions from two related sites (such as an ecommerce site and a separate shopping cart site) as a single session, rather than as two separate ones.

If the flow of your website user experience moves between more than one domain (e.g. __example-products.com__ to __example-checkout.com__), you should set up your Universal Analytics tags to measure those visits as one. Without this functionality, Google Analytics will treat this user as two separate visitors, which will inflate the number of users that appear in your reports. This occurs even if both domains use the same Tag Manager container and Analytics account. 

[source](https://support.google.com/tagmanager/answer/6164469?hl=en)

**Note:** When a user journey crosses from your first domain to your second domain, Analytics interprets that as the user having been referred by your first domain to your second domain, and Analytics creates a new session. If you want to be able to understand user interactions as a single session across multiple domains, you need to [add your domains to the referral exclusion list](https://support.google.com/analytics/answer/2795830)

If you are trying to track users across many different subsections of a single domain, e.g.:

**shopping**.bounteous.com

**www**.bounteous.com

**admin**.bounteous.com

You are **not** interested in cross domain tracking, you are interested in [[subdomain tracking]]. The best way to accomplish this is to add the ‘cookieDomain’ Field To Set and set it’s value to auto, or to use the a Google Analytics settings variable which has this set my default.

**IMPORTANT:** Verify that your domain is configured in your Referral Exclusion list – (bounteous.com in our example above).

Notes [[domain exclusion]] (aka [[referral exclusion]])

Any traffic fro domains included on this list will show up as direct

Good option if you can't add your GA tracking code to the website

