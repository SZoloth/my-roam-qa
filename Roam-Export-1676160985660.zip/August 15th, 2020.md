[[Focus[[*]]]]

"To me focus means four things:
1.  Identifying one longer term meaningful goal (not multiple [[Goals]]/paths in parallel)
2.  Distilling the most important thing you need to be doing right now to make progress towards that goal
3.  Doing that one thing for a long enough period to get information/data
4.  Editing the longer term goal based on the information you receive" [1](https://brianbalfour.com/essays/why-focus-wins)

This is analogous to [[[[strategy]] [[*]]]]  and [[OKR]]

"Smart humans are exceptionally good at creating reasons to justify an option just because they came up with the idea, not because it is the right thing to do." [2](https://brianbalfour.com/essays/why-focus-wins)

"With focus, the decision between multiple options comes down to one simple question.  Which one contributes to our focus the most?  The conversation is forced through a single filter." [3](https://brianbalfour.com/essays/why-focus-wins)

"On our growth team at [[Hubspot]] we focus on one metric in 30 - 90 day periods.  During those periods we are likely coming up with a ton of good growth ideas, but if they don’t contribute to the metric we are focusing on those ideas are put in a backlog and we get back to the task at hand." [4](https://brianbalfour.com/essays/why-focus-wins)

This is [[OKR]] and [[agile]]

"It seems the best way to get nothing done is to try and get everything done at once." [5](https://brianbalfour.com/essays/why-focus-wins)

[[♾️ Mantras]]

"What is the best way to build [[confidence]]?  Progress and learning.  We can see that our actions are actually producing results.  Each result is a proof point that that builds our foundation of belief." [6](https://brianbalfour.com/essays/why-focus-wins)

[[♾️ Mantras]]

"The best path to become a customer acquisition expert is not to try and understand all the different marketing channels at once, but to focus and go deep on one or two." [7](https://brianbalfour.com/essays/why-focus-wins)

"But I think there is one key from above, [[Focus[[*]]]] **leads to faster learning.**  As a result, even if you pick the initial wrong focus the act of focusing produces a higher likelihood that you will pick the right focus next time based on what you learned." [9](https://brianbalfour.com/essays/why-focus-wins)

"Since there is imperfect information, rational arguments can always be made for alternatives.  It is very easy to rationalize taking on another project by thinking it won’t be that distracting or time consuming.  This is especially true when you aren’t the one that is executing (i.e. Investors/Advisors)." [8](https://brianbalfour.com/essays/why-focus-wins)

"If this is true, then it seems that you should **worry less about choosing the “right” focus and concentrate more on having a repeatable system** that helps you:

a.  Absorb available information and distill it into a leading focus hypothesis
b.  Identify the [[assumption]]s in that hypothesis
c.  Identify a way to measure progress against those [[assumption]]s
d.  Set a forcing function (time period) to try and make progress against those [[assumption]]s
e.  Extract the learnings
f.  Feed the learnings back into the first step 

I personally use the framework of [[OKR]]’s for a lot of my personal and team [[Goals]].  I also customized a framework for my growth team specific to growth endeavors." - [brian balfour](https://brianbalfour.com/essays/why-focus-wins)

More relation to [[[[strategy]] [[*]]]] and [[OKR]]

Also ties into [[Cambria Davies]] and her [article on experimentation](https://www.shipsh.it/post/experimentation-process) which contains some relevant docs

She worked with [[Brian Balfour]] at [[Hubspot]] so that makes sense.

"At Swipely, [[OKR]]s are made up of a high level objective, a more detailed description of why that objective is important, a summary of how the objective aligns with the broader [[Goals]] of both the person’s team and the company, and the three to five key results that will help them achieve that goal (see below for examples)." [11](https://firstround.com/review/How-to-Make-OKRs-Actually-Work-at-Your-Startup/) 

"All high-performance [[OKR]] systems have these commonalities:

**The ability to track results on a quantitative basis.** Key results are not general or subjective actions you plan to take. They should always include numbers to make it clear how much has been achieved. For example, if Mary’s objective is to improve her sales prospecting skills, one key result might be to spend two hours a week shadowing Jennifer, the team member who demonstrates the most prospecting success.

**Make it something people look at, every quarter, every week, every day.** This consistency turns goal-setting into a habit and changes how people think about their work and approach their everyday to-dos. “It puts in place natural milestones that make you think about what you need to do next and aim high.”

**They have to be a stretch.** Most people wouldn’t consider 70% to be a good grade, but for OKRs that’s just about perfect, Davis says. You want your objectives to be ambitious enough to push you beyond your limits. When everyone does this, it forces the tough conversations about what's truly needed to beat expectations." [12](https://firstround.com/review/How-to-Make-OKRs-Actually-Work-at-Your-Startup/)

“Everyone’s favorite quadrant is the low-effort, high-impact stuff. But when you continually pick the low-hanging fruit, the branches will stop growing, so this work dries up quickly as your product and team matures.” [13](https://www.intercom.com/blog/first-rule-prioritization-no-snacking/)

"Since there is imperfect information, rational arguments can always be made for alternatives.  It is very easy to rationalize taking on another project by thinking it won’t be that distracting or time consuming.  This is especially true when you aren’t the one that is executing (i.e. Investors/Advisors)." [8](https://brianbalfour.com/essays/why-focus-wins)

“It’s the low-effort, low-impact work that can kill you, because it’s so attractive. Hunter refers to it as “snacking”. It feels rewarding and can solve a short term problem, but if you never eat anything of substance you’ll suffer.” [14](https://www.intercom.com/blog/first-rule-prioritization-no-snacking/)

“This work is easy to justify because “it only took 30 minutes”. And when it achieves nothing useful, it’s easy to excuse because it “took us so little time”. This is not strategy – this is flapping.” [15](https://www.intercom.com/blog/first-rule-prioritization-no-snacking/)

"The default position for a smart team without a clear plan is to snack. When I see teams at startups rushing to copycat the latest feature of the day, or swapping “Sign up now” with “Sign up for free”, I’m always reminded of this lower left. Snacks. Even in their best case, these projects are low impact for the absolute majority of companies." [16](https://www.intercom.com/blog/first-rule-prioritization-no-snacking/)

