AKA #groceries

For week of [[August 16th, 2021]]

[[Tangy Pork Noodle Salad With Lime and Lots of Herbs]]

Tags:: #Recipes

Ingredients::

**1** **teaspoon finely grated lime zest**

**2 ½** **tablespoons fresh lime juice, plus more to taste**

**2** **tablespoons fresh orange juice**

**2** **tablespoons fish sauce, plus more as needed**

**1** **tablespoon honey**

**** **Fine sea salt**

**4** **tablespoons grapeseed or safflower oil**

**½** **cup thinly sliced shallot (1 large)**

**6** **ounces pad Thai or other flat rice noodles**

**2** **garlic cloves, finely grated or mashed to a paste**

**1** **(2-inch) piece ginger, peeled and grated (about 2 teaspoons)**

**1** **Thai or serrano chile, thinly sliced and seeded if you like**

**1** **pound ground pork (or turkey)**

**1** **cup thinly sliced cucumbers**

**2** **scallions, white and green parts, sliced**

**1 ¼** **cups cherry tomatoes, halved**

**1** **cup mung or other bean sprouts (or 1 cup lettuce)**

**1** **packed cup mint leaves**

**1** **packed cup cilantro or basil sprigs, or a combination**

**2** **cups shredded romaine or other crisp lettuce**

**** **Red-pepper flakes, for serving**

**** **Lime wedges, for serving**

Tools::

Source:: https://cooking.nytimes.com/recipes/1020397-tangy-pork-noodle-salad-with-lime-and-lots-of-herbs

:hiccup [:hr]

 

