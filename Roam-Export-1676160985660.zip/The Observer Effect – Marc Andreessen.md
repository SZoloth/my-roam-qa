Author:: [[Sriram Krishan]] interviewing [[Marc Andreessen]]

URL:: https://www.theobservereffect.org/marc.html?mc_cid=13006af3e5&mc_eid=d984c2d93e&utm_campaign=13006af3e5-Benedict%27s+Newsletter+340&utm_medium=email&utm_source=Benedict%27s+Newsletter&utm_term=0_4999ca107f-13006af3e5-70675753

Recommended By::

Tags:: #Articles #Inbox #Readwise #productivity #a16z 

# Notes

The typical day for me right now is quite literally following the calendar very closely. I'm trying to have as “programmed” a day as I possibly can. 

We had decided one of the values of the firm is respect for the people we work with. And part of that respect is - we don't drop balls. We respond quickly and we have SLAs on getting back to people in a specific period of time. 

Also about once a year, I rewrite my personal plan. I just write from scratch what I'm actually trying to do and my [[Goals]] and then line up the activities that are below that. 

The thing I've tried to do the last few years is really ‘barbell’ the inputs. **I basically read things that are either up to this minute or things that are timeless. **

Part of being a firm is - we get to know and talk to a lot of people. So a lot of it, honestly, is face to face conversations. **Often the way you learn about something is because somebody tells you about it. So, the first thing is to be alive and alert in every interaction. **

One of the things I talk a lot about is this concept of ‘strong views weakly held’.I think in any business you do want to commit, you do want to act, you do want to bias towards action. 

