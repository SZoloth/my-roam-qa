summer intern for #[[Museum of Science]]

