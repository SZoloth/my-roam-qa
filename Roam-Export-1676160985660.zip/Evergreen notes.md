Resources::

https://notes.andymatuschak.org/z4SDCZQeRo4xFEQ8H4qrSqd68ucpgE6LU155C

https://notes.andymatuschak.org/z3SjnvsB5aR2ddsycyXofbYR7fCxo7RmKW2be

https://maggieappleton.com/roam-garden

Page prefixes are helpful for scanning and organizing

B: Books

C: Courses

P: Projects

E: Evergreen notes

➽: Original creations

Macros

Use Text Expander, Alfred, or Keyboard Maestro to set macros for metadata

[[Progressive summarization]]

bold key points

highlight really key points

collect evergreen notes and key concepts at the top of my note

Rephrase and re-write ideas in your ow nterms



