Author:: [[lennyrachitsky.com]]

URL:: https://www.lennyrachitsky.com/p/one-team-one-roadmap-issue-27

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

create pages programmatically 

To do these two things well, you’ll need to answer three questions:

What kind of pages should I create?

How do I create these pages programmatically?

What features do I need to create on each page for Google to love it? 

What are people on Google searching for that my business is uniquely able to answer?

Write down all of the unique pieces of information that your business has access to. Strava has popular running routes, Airbnb has unique listings, Pinterest has user-generated images. What do you have? 

What you are looking for is unique and valuable data points that your business/product already has that can be turned into useful web pages. 

For example, Thumbtack has thousands of pages like the best electricians in Seattle, using data that their pros input. 

SEO isn’t about capturing the top keywords — it’s about capturing the long-tail of keywords. 

Your goal should be to niche down when you start, and as you grow in authority, create more pages and move into new keyword spaces. 

figure out what niches and keyword spaces could work best for your business. How? Creativity, imagination, and stealing ideas from your competitors. 

When it’s not obvious, you’ll have to get creative with the data that you have at hand, and figure out what type of searches users are performing that (1) you can answer and (2) will lead to intentful actions (e.g. sign up, book, purchase). 

Now comes the fun part. Using the data points you noted in the previous step, sketch out your ideal web page. Create a page that has all of the information you have at your disposal, for the keyword that you’re trying to target. Here’s a sketch I made for our flower startup: 

As a side note, if you have access to user-generated content, this is the best kind of content to use — it provides natural, keyword-rich content that is useful to both your users and Google. 

make sure to think about how these pages scale based on the quality of the data that you have. Since we’re creating one template to generate potentially hundreds or thousands of pages, you need to think about what the pages look like in the best AND worst-case scenario. For example, Strava’s San Francisco running routes page is going to look a hell of a lot better than their Fresno one, because of the amount of quality data that they’ll have from their users. 

Below is an example of what I’d put together to help me figure out what content I have and don’t have: 

The next step is to think of ways to increase the quality of the data for our lesser-known locations. We can bootstrap the data that’s needed, such as hooking into the Yelp API to pull the local flower shops in cities that are missing that data, or using some of our existing data to craft a workaround 

Typical solutions to internal linking are recommended products, nearby locations, and “other {thing} people liked.” 

Not all keyword spaces are winnable. Know which ones aren’t (travel), and hold off on a serious SEO strategy until you’re further along. 

Create pages that are niche, and once you have a foothold go up the [[funnel]]. 

Simple is better. Don’t overcomplicate. 

Traffic is a vanity metric. Traffic that converts is what you’re after. It’s easy to forget when you’re chasing traffic highs. 

The faster your site is, the better. Your users don’t like slow websites, Google doesn’t like slow websites. 

If your SEO isn’t in good shape, it’s smarter just to ship. 

