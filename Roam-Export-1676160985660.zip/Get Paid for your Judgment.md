Choosing what kinds of jobs, [[[[career]]s]], or fields you get into and what sort of deals you’re willing to take from your employer will give you much more free time. Then, you don’t have to worry as much about time management. I would love to be paid purely for my judgment, not for any work. I want a robot, capital, or computer to do the work, but I want to be paid for my judgment. [1]

[1] [[Naval Ravikant]]. “[[Naval Ravikant]] Was Live.” __Peri[[scope]]__, January 20, 2018. https://www.pscp.tv/w/1eaKbqrWloRxX.

I think every human should aspire to being knowledgeable about certain things and being paid for our unique knowledge. We have as much leverage as is possible in our business, whether it’s through robots or computers or what have you. Then, we can be masters of our own time because we are just being tracked on outputs and not inputs.

{{[[drawing]]}}

[2] [[Naval Ravikant]]. “[[Naval Ravikant]] Was Live.” __Peri[[scope]]__, February 11, 2018. https://www.pscp.tv/w/1MnGneBLZVmKO.

Demonstrated judgment—credibility around the judgment— is so critical. Warren Buffett wins here because he has massive credibility. He’s been highly accountable. He’s been right over and over in the public domain. He’s built a reputation for very high integrity, so you can trust him. People will throw infinite leverage behind him because of his judgment. Nobody asks him how hard he works. Nobody asks him when he wakes up or when he goes to sleep. They’re like, “Warren, just do your thing.”

Judgment—especially demonstrated judgment, with high accountability and a clear track record—is critical. [78]

[78] [[Naval Ravikant]]. “How to Get Rich: Every Episode.” __Naval, __June 3, 2019. https://nav.al/how-to-get-rich.

__We waste our time with short-term thinking and busywork. Warren Buffett spends a year deciding and a day acting. That act lasts decades.__

Just from being marginally better, like running a quarter mile a fraction of a second faster, some people get paid a lot more—orders of magnitude more. Leverage magnifies those differences even more. Being at the extreme in your art is very important in the age of leverage. [2]

[2] [[Naval Ravikant]]. “[[Naval Ravikant]] Was Live.” __Peri[[scope]]__, February 11, 2018. https://www.pscp.tv/w/1MnGneBLZVmKO.

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FNavalmanack%2FMo55FUGGFX.jpg?alt=media&token=288bad68-5609-4f03-ab17-fef62fc34290)

