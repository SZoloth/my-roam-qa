[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} #ADK Marketing Plan #//

Spent like 30m talking to [[chris baker]] about our social media header for [[ADK Group]]

{{[[DONE]]}} Work on IA/Flow/Order of homepage (from the Invision page) for #[[ADK Website Rebuild]] #/

{{[[DONE]]}} Email [[julie barry]] from [[Wasabi]] about [[[[Wasabi]] analytics]] for Migrate with Nate (see Slack chat with [[chris baker]])

{{[[DONE]]}}  Write up a proposal for [[Museum of Science]] (see Slack chat with [[chris baker]])

"draft a proposal for the 2 weeks of acquisition marketing strategy and discovery"

Review MoS meeting

{{[[DONE]]}}  Run through [current site](https://www.putassoc.com/) and take note of quick wins on [[July 8th, 2020]] #Inbox

:hiccup [:hr]

[[Meetings]]: [[National Speed]] check in

Attendees:: [[andrew creek]] [[alex fedorov]] [[sean riley]] [[Fiana Avergon]]

Time:: 10:30am - 10:50am

Notes::

Overcomplicating the [[feedback]]?

[[Meetings]]: [[MIT PEL]] analytics

Attendees:: [[darci nevitt]]

Time:: 11:30am -

Notes::

[[Meetings]]: [[ADK Website Rebuild]] IA

Attendees:: [[jayne hetherington]] [[michael connors]]

Time:: 1:00pm - 1:45pm

Notes::

{{[[DONE]]}} Work on IA/Flow/Order of homepage (from the Invision page) for #[[ADK Website Rebuild]] #/

[[jtbd]]

{{[[DONE]]}} Review the client interviews raw material #/

Introduced to ADK via referral from

Design agency

Unique approach or process

Discovery first

Goal oriented

Integrated team

Strategic

Viewed as a thought partner

"The questions they asked in the initial call were so valuable that we rewrote our RFP based on them"

"They were able to ask questions we hadn't thought about, which was eye opening. We were struck by their ability to listen and understand and catch on quickly, but then add far more value in terms of technical capability and visions."

"They were up front about the timeline when no one else was"

Timing, pace, team, what we expect of you

"I feel like I can text them and ask them any stupid question" 

Needs:

Culture, dynamism, energy

Process

Partnership with clients

What do we **__do__** - what is the engine behind our company?

We are the launchpad for companies - we build the engine companies use to grow

Totally integrated hub to take your business in far through technology

Geek factor

Order

Positioning statement

Testimonial + case study link

Quote, person, link to case study

Approach/process

graphic, text, link

Work

3-5 best case studies + links + link to all

Services

fully integrated partner

Specialty services?

mhealth

startups

About us/clients (logos)

Our culture makes us uniquely capable. Our partners make us successful.

We are X

Our partners are Y

Brand logos

Blogs/content

Contact

Current

case studies

services

approach

about

[[[[career]]s]]

blog

Priority of messages

Imagery and text

[[Meetings]]: CCPA conversation for [[ADK Group]]

Attendees:: [[chris baker]] [[jordan daly]]

Time::

Notes::

[[Meetings]]: [[Getting buy in from leadership]]

Attendees:: [[michael connors]]

Time:: 2:30pm - 3:15pm

Notes::

Looking and listening for things they're not saying

Read non-verbal cues

[[translate]] the double speak

Start with humor to loosen up the conversation - allows them to speak freely

Defuse the situation - let them know they can say no

It's not hurting our feelings when you're needing honest [[feedback]]

Helps avoid people walking back approvals

Make it informal - "all that being said, just tell

They need context of "what do you need from me right now?"

Give framing ahead of time

Be very specific about ask

Bring them into the process

Break down the ask

Sprints and chunks

Get approval about the process - "if i show the info in this way, will it work for you?"

To reduce self-doubt ensure the upfront investment is there that gives you confidence

Go into every single meeting with an objective

Comes from being respectful of other peoples time

Be mindful of your intentions and objectives when talking to others

Stay 2-steps ahead of everybody

When you're not ahead - own it.

Follow the design process: 

inputs

no solutions, judgments, excuses, agenda etc.

diverge alone - brainstorm

what could i do?

converge to a decision about what you're going to do

Can lean on the process -- rehearsing (implicitly or explicitly) is where most of the work __and__ benefit comes

Different from telling yourself a story and saying, "what if?"

4:1 factor - 4 hours of rehearsal (not material prep) for 1 hour of presentation

[[Meetings]]: About #Selling #[[Selling ADK Group]]

Attendees:: [[Dan Tatar]]

Time:: 3:30pm - 4:pm

Notes::

Two different types of selling

Getting in front of people

Closing deals

About closing deals

Where it goes wrong

Talking too much at the opportunity - being too much of a hype man

People think meetings go well if they've talked a lot

Too pushy

Approach every opportunity as:

Love to hear about what you're up to and see if we're even a fit

And if we're not a fit, still want to be helpful

Make referrals, intros, etc.

Be more interested in them than doing business with them

The lead should end up talking more than 50% of the conversation

Never leads with a description of ADK

For deal making: everyone knows that you never want to be the first one to talk

Listening and responding is a position of strength

Instead lead with questions and listening

Potential to practice/lead things for ADK

Lean in to genuine curiosity

Come across as a "let me understand it all"

You want people to not think you're a sales man

Dive into personal topics with questions

Never be pushy

Important to have a personality and "break someone down a little bit"

Two criteria for wanting to do business:

Capability

Likeability (trust)

Being interesting - looking up something online and finding common grounds

Can't be another NESCAC kid - show personality

Be memorable and non-vanilla

Sometimes this is pushing back on them - do something different

Work on personal brand - who you are around Boston and why do people want to meet with you

Similar to: Ted Schleuter, Mike Welts, founder of Love-Pop

When [[Dan Tatar]] was "young":

Hustled - went to everything possible all the time

Venture breakfast, law firm round tables, different lunches every day, red sox, cocktails

Not asking for referrals but saying - "yeah we're working on X, looking for more Y"

Never ask "what do you do" - talk so long and so much

{{[[DONE]]}} Set up another meeting and get on the 1pm tomorrow

{{[[TODO]]}} Set up another meeting with [[Dan Tatar]] about [[Selling]]

