Author:: [[lennyrachitsky.com]]

URL:: https://www.lennyrachitsky.com/p/-community-wisdom-issue-4

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[October 9th, 2020]]

A few tactics I've used successfully:Making sure the WHY of the project is clear to everyone who'll be working on it. It should align to overall company priorities that were hopefully communicated to the whole company. Similarly, the WHY for the deadline should also be clear ideally.For major projects, ask functional leaders to nominate POC who would be responsible/accountable for leading work on this project from that function.Create systems for tracking progress and communication between the cross-functional group working on this. This could be regular email/slack check-ins, meetings, dedicated slack channel, spreadsheet where progress is tracked etc. Generally feel work tends to get done (or at least conflicts are surfaced early) if everyone knows there's a project leader who's going to keep checking in. 

**Tags**: #[[[[influence without authority]]]]

**Note**: [[influence without authority]]

Definitely agree with Archisman: give it a name and get leadership to champion it. Also, finding 1-2 influential members per functional team and telling them that they are the drivers of the project usually gets them to actually drive it in their team. And 100% agree with arbitrary deadlines, as I have saved months by using them also.  

**Tags**: #[[[[influence without authority]]]]

**Note**: [[influence without authority]]

I’d start with Product School and one of Marty Cagan’s intro classes. Reforge is more for mid-[[career]]. 

**Tags**: #[[product management]]

**Note**: Learn product management

### New highlights added [[November 2nd, 2020]] at 7:47 PM

Definitely agree with Archisman: give it a name and get leadership to champion it. Also, finding 1-2 influential members per functional team and telling them that they are the drivers of the project usually gets them to actually drive it in their team. And 100% agree with arbitrary deadlines, as I have saved months by using them also. 

**Tags**: #[[influence without authority]]

**Note**: [[influence without authority]]

