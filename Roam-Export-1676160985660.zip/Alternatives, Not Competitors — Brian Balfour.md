Author:: [[brianbalfour.com]]

URL:: https://brianbalfour.com/quick-takes/alternatives-not-competitors

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

So how do you find your alternatives? You should be doing three things:

Ask your existing customers, what problem does the product solve for them? Get it in their own words.

Then, go to non-customers in your target audience. Ask them "When was the last time you had this problem? Walk me through step by step how you solved the problem."

Then ask yourself, how do you provide a 10X experience to those alternatives. 

