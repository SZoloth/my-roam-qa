**Metadata**

**Source:** https://www.mrporter.com/en-us/journal/the-tribute/forget-dry-january-why-hedonism-is-the-way-forward/4174

**Author:** [[Mr Porter]]

**Tags:** #hedonism, #life,#[[Essays & Articles & Books]]

"Aristippus of Cyrene, a pupil of Socrates who rejected the old man’s prescriptions, spouted the construe this way: pleasure is the goal of life, achieved by maintaining a control of adversity and prosperity – and being altruistic as you go."

