Author:: [[Shreyas Doshi]]

URL:: https://twitter.com/shreyas/status/1276956836856393728

Recommended By::

Tags:: #Articles #Inbox #Readwise #[[[[High Agency]][[*]]]]

# Notes

High Agency is about finding a way to get what you want, without waiting for conditions to be perfect or otherwise blaming the circumstances. High Agency People either push through in the face of adverse conditions or manage to reverse the adverse conditions to achieve [[Goals]] 

Game Changers are not very common and, once discovered, they’re expensive to hire. When you find them, do whatever you can to get them on your team. When hiring, I prefer Go Getters over Frustrated Geniuses. In all cases, the third factor to look for is High Integrity. 

My first recommendation here would be to read the 7 Habits of Highly Effective People, one more time. The framework of Circle of Influence and Circle of Concern is something I’ve gone back to countless times whenever there’s a temptation to recede to a Low Agency mindset. 

Observing and adjusting your [[language]] and self-talk is an important aspect of cultivating High Agency 

