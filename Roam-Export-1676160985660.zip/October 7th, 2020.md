{{[[DONE]]}} Phase 2 for [[Museum of Science]] plan/[[scope]] #[[🏔ADK [[Task Management]]]] #/

## Phase 1: Clean up

Numbers

66,021 contacts

543 properties

2000 possible duplicate contacts

2000 possible duplicate companies

???? internal/test contacts

229 workflows

~800 CTAs

249 forms

600 landing pages

### [[segmentation]]

Segments

By lifecycle stage/engagement for intro/lead/upsell/cross-sell/engagement/win-back campaigns

By role for product

By region/areas affected by different legislation

Decisions to be made

Thresholds and specific criteria for segments

Decisions to be made

What are the MVP properties?

What should be done with non-MVP properties?

What should be done with duplicates?

Pick a best one or merge?

If pick, how to decide?

If merge, need to manage properties

What are the rules for dq'ing a lead?

What forms need to be updated based on changes to properties? 

What workflows need to be updated based on changes to properties?

Follow ups

Need CRM exporting permissions

Connect with HubSpot tech support to get POV on best practices & things to avoid.

## Phase 2: Nurture & Report

### Nurture strategies

Lifecycle nurturing

Need: definitions/goal for each lifecycle stage

Win-back campaign, upsell/cross-sell, nurture, engagement

Other campaigns to think about

Abandoned cart? 

### Reporting

Establish KPIs

Build dashboards

## Phase 3: Polish

What CTAs can be retired?

What workflows can be retired?

What forms can be retired?

What landing pages can be retired?

What lists are outdated/unused?

{{[[DONE]]}} Review #[[ADK email]] from [[jordan daly]] about #[[i[[mercer]]]] campaigns #/

Background

New funding

Carousel ads?

Audience matching

Engagement retargeting

Uploading CRM data

New product to promote (engagement)

Wants to run four new campaigns: compensation, outplacement, cost containment, and engagement

Questions

What is the cost?

These campaigns share similar audiences - is this an issue? If so, what is the resolution?

What could/should we do with more spend?

Retargeting on social or display

CRO

Higher quality creative

{{[[DONE]]}} Questions from [[sean riley]] about #[[[[mHealth]] app kit]] landing page [arc](https://docs.google.com/document/d/1ZIDduMF1gBWL0vf3DhudeT8JpHQdTA8od-WVLiPXfYA/edit?disco=AAAAHBY2lgo&ts=5f764837&usp_dm=true) #/

{{[[DONE]]}} #[[[[mHealth]] app kit]] landing page needs & [[feedback]]: #/ [[🏔ADK [[Task Management]]]]

better assets

re-organized sections

look at og designs, story arc, sean designs

