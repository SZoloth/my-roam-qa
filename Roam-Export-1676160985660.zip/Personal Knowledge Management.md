important concepts

[[Roam Garden]] from [[Maggie Appleton]] and [[Andy Matuschak]]

[[Zettelkasten]]



