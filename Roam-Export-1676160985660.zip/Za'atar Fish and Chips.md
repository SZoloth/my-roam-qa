Tags:: #Recipes #fish

Ingredients::

1 small red [[onion]], finely chopped

4 Tbsp. [[apple cider vinegar]], divided

Kosher [[salt]]

1½ lb. small Yukon Gold [[potatoes]], halved or quartered lengthwise

6 Tbsp. [[EVOO]], divided

1 1¼-lb. skinless, boneless [[cod]] fillet, preferably in 1 piece

1 Tbsp. [[za’atar]]

¾ cup pitted Castelvetrano [[olives]]

½ cup coarsely chopped [[mint]]

Tools::

Source:: https://www.bonappetit.com/recipe/zaatar-fish-and-chips?_ga=2.89701849.317065848.1595695743-1877271032.1595695743

:hiccup [:hr]

Place racks in upper and lower thirds of oven; preheat oven to 425°. Mix onion, 2 Tbsp. vinegar, and a big pinch of salt in a small bowl to combine; let sit at least 10 minutes and up to 1 hour. Drain off vinegar and discard.Î

Meanwhile, toss potatoes and 3 Tbsp. oil on a large rimmed baking sheet; season with salt, then toss again. Arrange in a single layer. Roast on top rack, undisturbed, until browned and crisp underneath, 20–25 minutes. Turn potatoes over and reduce oven temperature to 325°. Place cod on a small rimmed baking sheet and drizzle with 1 Tbsp. oil. Season with salt and sprinkle with za’atar. Slide onto bottom rack in oven and roast until fish flakes easily with a fork and potatoes are browned all over, about 10 minutes.

Stir olives, mint, remaining 2 Tbsp. vinegar, and remaining 2 Tbsp. oil into pickled onion. Serve cod and potatoes topped with olive mixture.

