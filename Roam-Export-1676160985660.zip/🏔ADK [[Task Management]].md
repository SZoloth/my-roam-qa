**Recently assigned (not triaged)**

{{[[query]]: {and: [[TODO]][[🏔ADK [[Task Management]]]] {not: {or: [[/]] [[//]] [[///]] [[Template]] [[Blocked]] [[Delegated]] [[Personal Task Management]] [[query]]]}}}}}

**Top** #/

{{[[query]]: {and: [[TODO]][[🏔ADK [[Task Management]]]] [[/]] {not: {or: [[Template]] [[Personal Task Management]][[//]][[///]] [[query]]]}}}}}

**Upcoming** #//

{{[[query]]: {and: [[TODO]][[🏔ADK [[Task Management]]]] [[//]] {not: {or: [[Template]] [[Personal Task Management]][[/]][[///]] [[query]]]}}}}}

**Later** #///

{{[[query]]: {and: [[TODO]][[🏔ADK [[Task Management]]]] [[///]] {not: {or: [[Template]] [[Personal Task Management]][[/]][[//]] [[query]]]}}}}}

**Delegated** #Delegated[[@]]

{{[[query]]: {and: [[TODO]] [[🏔ADK [[Task Management]]]][[Delegated]] {not: {or: [[Template]] [[Personal Task Management]] [[query]]]}}}}}

**Blocked** #Blocked

{{[[query]]: {and: [[TODO]] [[Blocked]] {not: {or: [[Template]][[Personal Task Management]] [[query]]] }}}}}

:hiccup [:hr]

#[[Quick Capture]]

{{{[[DONE]]}}} For the [[COVID-19 testing app]]: find out who is on it, schedule brief interviews, record answers. 

