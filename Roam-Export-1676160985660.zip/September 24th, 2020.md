#[[Quick Capture]]

potential [[OKR]]s: wasabi, Privafy, React SEO, React analytics, mHealth launch, Gtm, team content

wasabi keywords

LinkedIn updates

[[Newport]]

~~Vineyards~~

https://www.newportvineyards.com/

https://greenvale.com/

~~Bird sanctuary~~

https://www.normanbirdsanctuary.org/coronavirus-update

__Cliff walk?__

**Biking**

https://www.discovernewport.org/things-to-do/outdoor-recreation/bikes-and-vehicles/

Scooter World !!1!

Sail

https://www.newportexperience.com/friday-night-live-sail

https://sail-newport.com/browse-by-theme/sunset-sail/

**Downtown**

Bowen's and Bannister's Wharves

#[[Quick Capture]]

is it better to focus on input or output?

