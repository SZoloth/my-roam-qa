[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Marketing for ADK - Filling lead [[funnel]] #//

Who is looking for Drupal sites?

Look at Drupal built with data

Schools

Bose, BJs

Higher education

What services are they looking for?

Drupal redesign, update, upgrade

Marketing?

Web apps?

Campaign ideas #[[Google Ads Optimization]]

Idea 1 - awareness: case studies #//

Audience: retarget + custom audience + industry-based

roles? CPO, CEO, director of marketing, CMO

emails for drupal: https://docs.google.com/spreadsheets/d/1-sJQjuAUYSQhiXNxhkm_jqzPknCqBKCimIV9DLiuXwM/edit#gid=1505696118

^^Prep ads concept for Maggie^^

https://drive.google.com/drive/folders/12rn6nKg9urARiZ0oZk1qdtPhZ3eaa0mE?usp=sharing

Ads: case studies

**CSB: Accessibility, Drupal, Fintech**

See how Cambridge Savings Bank 

Cambridge Savings Bank is one of Massachusett's most successful community banks. Together, we continued their tradition of being a leader in customer experience with a flexible, accessible site rebuild.

Key results:

Optimized to WCAG 2.0 AA standards.

Collaborated with the Carroll Center for the Blind to go above and beyond for site accessibility.

SEO and site speed improvements that led to a 6% increase in new users and 18% increase in sessions.

**ADK Launching COVID App**

Dr. Mark Albers, a neurologist specializing in memory and olfactory disorders at MGH, is the principal investigator of a study assessing whether less of small may be the best test we have for early detection of COVID-19. Together, we design, developed, and launched a web app for the test in just 2 weeks. The results? 

**ALKU**

**Beyond Insurance**

**Boston School Finder**

**Vyaire**

**HNRG**

Hancock Natural Resource Group saw an opportunity to improve their efficiency.

**Wasabi**

Two of Boston’s most successful entrepreneurs decided to take on Google, Microsoft and Amazon in the cloud storage wars. Together, we’ve taken their digital presence from company announcement to unicorn scale.

Key results:

Highly scalable, integrated, and flexible web platform has enabled Wasabi’s marketing to drive rapid growth.

Architected highly scalable hosting architecture to support lossless A/B testing.

Company has raised $110 million in venture capital to date.

**FireFly**

Two Harvard Medical School professors with busy Primary Care practices saw that the traditional care delivery [[model]] was broken. Together, we developed the product for their virtual-first primary care practice. Along the way, they’ve solved for the gaps they saw in traditional primary care and have built one of Boston’s hottest telemedicine startups.

Key results:

[[translate]]d the founder’s vision into a successful v1 native app with EMR integration.

Supported internal product team recruitment and growth.

Raised 10.2 Million in funding from leading healthcare VC’s Oak and F-Prime.

**Tradehounds**

Founder David Broomhead, known today as “Big Dog” to the 150K+ users of his app, saw an opportunity to create a social and professional network for the trades. Together, we built the product and company and brought them to scale.

Key results:

Designed and built the product from idea to live application with 150k users.

Assisted in raising $3.2 million in seed funding.

Recruited the company’s first product team.

**GTI**

Dr. John Stone, Director of Rheumatology at MGH, had developed the leading measure of steroid toxicity as a pen and paper instrument in his lab. Together, we turned his science into an FDA compliant digital instrument.

Key results:

UX design and development of custom clinical application.

Launched the React/C# clinical app in partnership with MGH and Roche.

Achieved 21 CFR Part-11 compliance.

Creative:

Clients & projects (case studies)

All: retargeting + custom

HNRG

Sales

Process automation

Harvard - JDA

Data throughput

Harvard - Asia Center

???

Cambridge Savings Bank

Accessibility

Vyaire

???

SIKA

???

Boston School Finder

App functionality

Major Decision

App functionality

Beyond Insurance

App functionality

EBH and Wynn [[[[career]]s]]

Harvard - RIJS

Signs of Suicide - SMH

FireKing

Mountain One

ANET ??

Harvard-Yenching Institute

Harvard - HJAS

Spaulding

CEC

Ivy Bank

Year Up

STEM-Act

BWH Surgery Finance

MIT - PEL

MIT - UPOP

Constitutional Revision

[[assumption]] College

Wise Construction

Breakaway

PDFs

[HIPPA](https://www.adkgroup.com/articles/understanding-digital-hipaa-compliance-modern-tech/)

retargeting + custom?

[Drupal](https://www.adkgroup.com/articles/power-drupal-unlocking-hidden-potential-your-cms/)

retargeting

[Smart manufacturing](https://www.adkgroup.com/articles/smart-manufacturing-how-leverage-industrial-iot/)

retargeting + custom

[B2B Sales [[funnel]]](https://www.adkgroup.com/articles/modern-day-b2b-sales-[[funnel]]-influencing-b2b-buyers-through-b2c-strategies/)

retargeting + custom

[[product]] [[road[[map]]]] (https://www.dropbox.com/s/sgz01ip2yp6dqvj/Deciding%20What's%20Next.pdf?dl=0)

retargeting for FTS / design ads

[Enterprise design sprint facilitation](https://www.freshtilledsoil.com/downloads/the-enterprise-design-sprints-facilitation-guide.pdf)

{{{[[DONE]]}}}} Idea 2

Google Ads

MA/KY

Day and time of day part

Focus on agency, service, group, firm

Ad groups

Web design

Web developer

Hosting & maintenance

App design

App developer

Product design

[[[[product]] [[strategy]]]]

Software design

Software development

Digital agency

Awareness campaigns

~~Industry-based ad groups in Google Ads?~~

Too niche

Industry-based LinkedIn ads

How the top {{or: colleges|enterprise|financial institutions}} use ~~Drupal~~ their website to {{or: grow|differentiate|improve customer experience}}

Retargeting visits to

any URL with drupal in it + any case study about Drupal

Lead gen

How the top {{or: colleges|enterprise|financial institutions}} use ~~Drupal~~ their website to {{or: grow|differentiate|improve customer experience}}

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FnIhBD54IRp.png?alt=media&token=3e988b67-1179-4eb9-8cd4-d0abf278d236)

Need to sketch out: 

ads

landing pages

Marketing design

[[[[product]] [[strategy]]]], product design

[[Meetings]]: [[[[1:1s]] with [[darci nevitt]]]]

Attendees:: [[darci nevitt]]

Time:: 3:30pm

Notes::

growth::

PM & Client Relations

wins::

SEO Support

Challenges::

Project planning

Not a big fan

Specific processes

For MoS

Competitor research

Questions for [[1:1s]]::

