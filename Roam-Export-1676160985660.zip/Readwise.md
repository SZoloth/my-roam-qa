On [[September 20th, 2020]] at 6:11 PM Readwise synced 60 highlights from 10 books.

This was your first sync with #Readwise! 🎉

From now on, new books/highlights will sync automatically with a link to your daily notes for the day it synced.

You can [tweak your syncing settings (and filter/add more books to sync) here](https://readwise.io/export/roam/preferences), read more about [how the Roam integration works here](https://help.readwise.io/roam), and as always feel free to reach out to us at hello@readwise.io with any questions

On [[September 20th, 2020]] at 6:24 PM Readwise synced 243 highlights from 26 books.

On [[September 20th, 2020]] at 6:27 PM Readwise synced 2 highlights from 1 book.

On [[September 20th, 2020]] at 9:35 PM Readwise synced 1 highlight from 1 book.

On [[September 21st, 2020]] at 9:07 PM Readwise synced 4 highlights from 1 book.

On [[September 22nd, 2020]] at 8:44 PM Readwise synced 11 highlights from 4 books.

On [[September 29th, 2020]] at 11:41 AM Readwise synced 25 highlights from 2 books.

On [[September 30th, 2020]] at 9:08 AM Readwise synced 5 highlights from 1 book.

On [[October 2nd, 2020]] at 9:20 AM Readwise synced 1 highlight from 1 book.

On [[October 2nd, 2020]] at 5:48 PM Readwise synced 26 highlights from 1 book.

On [[October 2nd, 2020]] at 8:56 PM Readwise synced 4 highlights from 1 book.

On [[October 4th, 2020]] at 9:05 PM Readwise synced 15 highlights from 2 books.

On [[October 7th, 2020]] at 10:52 AM Readwise synced 22 highlights from 1 book.

On [[October 9th, 2020]] at 8:14 PM Readwise synced 3 highlights from 1 book.

On [[October 30th, 2020]] at 8:48 AM Readwise synced 34 highlights from 5 books.

On [[October 30th, 2020]] at 8:53 PM Readwise synced 5 highlights from 1 book.

On [[November 2nd, 2020]] at 7:47 PM Readwise synced 32 highlights from 5 books.

On [[November 17th, 2020]] at 7:46 PM Readwise synced 25 highlights from 5 books.

On [[November 18th, 2020]] at 8:46 PM Readwise synced 2 highlights from 2 books.

On [[November 19th, 2020]] at 12:19 PM Readwise synced 37 highlights from 8 books.

On [[November 22nd, 2020]] at 10:00 AM Readwise synced 25 highlights from 10 books.

On [[November 25th, 2020]] at 11:29 AM Readwise synced 16 highlights from 2 books.

On [[November 29th, 2020]] at 12:31 PM Readwise synced 1 highlight from 1 book.

On [[December 7th, 2020]] at 11:15 PM Readwise synced 8 highlights from 1 book.

On [[January 13th, 2021]] at 11:51 AM Readwise synced 1 highlight from 1 book.

On [[January 13th, 2021]] at 10:30 PM Readwise synced 8 highlights from 1 book.

On [[January 14th, 2021]] at 11:51 AM Readwise synced 3 highlights from 1 book.

On [[January 14th, 2021]] at 10:42 PM Readwise synced 12 highlights from 2 books.

On [[January 15th, 2021]] at 10:46 PM Readwise synced 7 highlights from 1 book.

On [[January 16th, 2021]] at 11:40 AM Readwise synced 11 highlights from 3 books.

On [[January 21st, 2021]] at 8:10 PM Readwise synced 7 highlights from 1 book.

On [[January 22nd, 2021]] at 8:54 PM Readwise synced 3 highlights from 3 books.

On [[January 23rd, 2021]] at 10:11 AM Readwise synced 6 highlights from 3 books.

On [[January 26th, 2021]] at 8:17 AM Readwise synced 6 highlights from 1 book.

On [[January 30th, 2021]] at 11:34 AM Readwise synced 1 highlight from 1 book.

On [[January 30th, 2021]] at 12:34 PM Readwise synced 6 highlights from 2 books.

On [[January 30th, 2021]] at 9:29 PM Readwise synced 45 highlights from 7 books.

On [[January 30th, 2021]] at 11:33 PM Readwise synced 13 highlights from 1 book.

On [[January 31st, 2021]] at 10:08 AM Readwise synced 9 highlights from 3 books.

On [[February 4th, 2021]] at 10:33 AM Readwise synced 3 highlights from 2 books.

On [[February 4th, 2021]] at 5:31 PM Readwise synced 2 highlights from 1 book.

On [[February 4th, 2021]] at 5:34 PM Readwise synced 1 highlight from 1 book.

