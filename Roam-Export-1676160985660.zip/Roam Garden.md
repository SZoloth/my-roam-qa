[[Evergreen notes]]

**Atomic**: captures one single idea concisely and completely

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FJpioZrqwVT.png?alt=media&token=b46e895b-7a51-472b-94a3-1fc47ebd55e9)

**Densely linked**: connected through organic associations, not hierarchical structures

**Imperative and declarative titles**: make titles that are statements, clear instructions, commands, orders, or directions

**Concept-oriented**: Create notes based around concepts and big ideas, rather than specific books, articles, events, and media



