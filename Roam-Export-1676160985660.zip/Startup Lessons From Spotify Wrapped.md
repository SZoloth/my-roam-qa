**Metadata**

**Source:** https://medium.com/@SarahMcBride/startup-lessons-from-spotify-wrapped-3807cb9336a9

**Author:** [[Sarah McBride]]

**Tags:** #spotify, #[[organic growth]], #[[Essays & Articles & Books]]



