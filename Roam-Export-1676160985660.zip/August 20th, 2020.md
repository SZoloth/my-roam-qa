[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Ad creative for [[Museum of Science]] #/  

Google Ads - Headlines

Brand - EiE

EiE - Leading STEM Curriculum

Start STEM Early with EiE

Engineering is Elementary

Build 21st Century Skills

EiE Engineering Design Process

New EiE Integrated Curriculum

Computer Science + Engineering 

EiE - Comp Sci + Engineering

NGSS

With NGSS Aligned Curricula

NGSS Aligned STEM Curriculum

Meet NGSS Science Standards

Get NGSS Aligned Lesson Plans

Hit NGSS Engineering Standards

NGSS Focused STEM Curriculum

STEM curriculum

Build 21st Century Skills

Engineering for Grades 1-5

Engineering for Primary School

Award-winning STEM Curriculum

Elementary School Engineering

For Elementary Classrooms

Fun and Engaging for Students

Applies to Sciences, ELA, Math

Engineering Design Process

NGSS Focused STEM Curriculum

Curricula for Grades 1-5

Project-Based STEM Lessons

Complete Your STEAM Curriculum

Computer Science Curriculum

STEM for teachers

Integrated STEM Lesson Plans

For Elementary Classrooms

Fun and Engaging for Students

Get NGSS Aligned Lesson Plans

Engineering + Comp Sci Lessons

Curricula for Grades 1-5

STEM Resources for Teachers

For Any Level of Experience

STEM projects

Project-Based STEM Lessons

STEM Projects for Elementary

STEM Activities for Elementary

STEM Activities for Kids

Hands-on STEM Activities

Fun and Engaging for Students

Engineering Design Challenges

Engineering + Comp Sci Lessons

Hands-on and Project-based

Engaging STEM Lessons for Kids

Kids' Engineering Challenges

Generic/Proof/Aspirational

Based on 3000+ hrs of Research

Used by 5 million+ Students

Already Used In Your State

For Tomorrow's Problem Solvers

Give Students a Head Start

Google Ads - Descriptions

Develop 21st century skills with STEM curricula aligned to NGSS standards. Learn more.

Includes units, lessons, and activities that apply to ALL STEM related subjects. 

Build 21st century skills with EiE's engineering + comp sci curricula for grades 1-5.

Get all your students engaged in STEM with hands-on lessons developed in line with NGSS.

Our hands-on curricula develop 21st century skills like collaboration and communication.

Hands-on STEM curricula connect to different subject areas and teach 21st century skills.

Create a generation of problem solvers with engaging and easy to implement STEM lessons.

Your school can foster student-centered, inquiry-based learning with STEM activities.

The best integrated engineering and computer science curriculum for elementary students.

Trusted by thousands of teachers and enjoyed by millions of students in every state.

Set students up for success beyond the classroom with real-world STEM challenges.

Award-winning & widely adopted STEM lessons developed by the Museum of Science, Boston.

Simple, fun STEM activities tailored to today's elementary school & tomorrow's world.

Teach your students with the Engineering Design Process to build 21st century skills.

A rich future of engagement with STEM awaits your students with EiE's new STEM curriculum.

The new comp sci and engineering integrated curriculum from EiE is tailor-made for NGSS.

Make your elementary classroom the home of tomorrow's problem solvers & critical thinkers.

World-class STEM resources for teachers that are proven to increase engagement with STEM.

{{{[[DONE]]}}}} Review questions for [[[[Sleeping Dog Properties]] blog]] #/

{{{[[DONE]]}}} Blog topics for [[Jill Starett]] #/ #[[Inspiration for ADK]]

What do you feel most passionately about UX research / [[[[product]] [[strategy]]]]?

What do you think is most misunderstood about UX research / [[[[product]] [[strategy]]]]?

Where do most companies mess up UX research / [[[[product]] [[strategy]]]]?

What are some examples of killer UX research / [[[[product]] [[strategy]]]]?

What's unique about conducting UX research / [[[[product]] [[strategy]]]] for digital health?

What distinguishes good UX research / [[[[product]] [[strategy]]]] from bad UX research / [[[[product]] [[strategy]]]]?

How do you best apply UX research / [[[[product]] [[strategy]]]]? What do you do it without after you've launched the update/new thing?

What's a good way to measure the ROI of UX research / [[[[product]] [[strategy]]]]?

How has COVID changed UX research / [[[[product]] [[strategy]]]]?

A case study of doing user research / [[[[product]] [[strategy]]]] for ADK Group :)

What are the "always true" / first principles of UX research / [[[[product]] [[strategy]]]]?

What client has UX research / [[[[product]] [[strategy]]]] had the biggest impact on?

How do you build a culture around UX research / [[[[product]] [[strategy]]]]?

{{{[[DONE]]}}}} Write brand narrative for {{or: purpose/social good | david vs. goliath | friendly engineers}} by [[August 18th, 2020]] #/

[[Meetings]]: [[ADK]] brand and positioning

 Attendees:: [[chris baker]] [[jordan daly]]

Time:: 2:30pm

Notes::

Championing our clients that are mission driven / built on purpose

We build on purpse.

David vs. goliath has to come out more in process and services

Making engineers more accessible

authenticity & humility & expert & opinionated

not talking about ourselves -- we're here to serve customers and users

we aren't the hero - we're the hero's mentor, friend

The Sam to your Frodo

how that comes out

addressing the audience

together

2nd person / "us"

what can ADK do for you

creative agencies, by contrast, are very self-indulgent

"Built for You"

Everything we do individually is commoditized, the unique value is how we wrap it up and combine it. #[[Inspiration for ADK]]

Your guide to the new agency landscape [[Inspiration for ADK]]

A different type of partnership

Home page

We are {{or: enjoying the patter of rain|soaking up the sun|bundled up in cozy layers}}

Clients

Firefly

Tradehounds

GTI

Wasabi

Why these

We're getting NIH grants, FDA compliant #[[Inspiration for ADK]]

**Healthcare** is the route to leveling up

[[Flagship Pioneering]] as an example

https://www.flagshippioneering.com/

Voice and tone guides need

reference points

grammatical rules

words we don't use

innovative

solutions

brand

client

words we do use

partnership

purpose

impact

alongside

[[translate]]d

supported

encouraged

Building [[resilience]], [[insight]] from [[the profile]] on [[tommy caldwell]] by [[polina marinova]] #confidence

To get better at dealing with the really scary things in life, you need to consistently expose yourself to little bits of [[adversity]] in your everyday. If you create some intentional friction, your mind will be better prepared for any heavy experience you may have to endure in the future.

When you run into little bits of [[adversity]], Caldwell says, you should re-frame it as an opportunity to train for a bigger challenge down the road. If you start thinking of adversity as adventure, life gets just a little more exciting. “If we allow ourselves to be exposed to challenge, then that challenge can energize us and show us who we are,” he says.

On the gap between [[passion]] and [[expertise]], especially for [[creative]] pursuits (by [[ira glass]])

Nobody tells this to people who are beginners, and I really wish somebody had told this to me.

All of us who do creative work, we get into it because we have good taste. But it's like there is this gap. For the first couple years that you're making stuff, what you're making isn't so good. It’s not that great. It’s trying to be good, it has ambition to be good, but it’s not that good.

But your taste, the thing that got you into the game, is still killer. And your taste is good enough that you can tell that what you're making is kind of a disappointment to you. A lot of people never get past that phase. They quit.

Everybody I know who does interesting, creative work, they went through years where they had really good taste and they could tell that what they were making wasn't as good as they wanted it to be. They knew it fell short. Everybody goes through that.

And if you are just starting out or if you are still in this phase, you gotta know it’s normal and the most important thing you can do is do a lot of work. Do a huge volume of work. Put yourself on a deadline so that every week or every month you know you're going to finish one story. It is only by going through a volume of work that you're going to catch up and close that gap. And the work you're making will be as good as your ambitions.

I took longer to figure out how to do this than anyone I’ve ever met. It takes a while. It’s gonna take you a while. It’s normal to take a while. You just have to fight your way through that.

Little nugget on [[decision making]] #decisions from [[benjamin hardy]] on [source](https://rebootspodcast.podia.com/members/posts/32616-using-roam-to-crush-self-doubt)

From a [[psychology]] perspective, it's really smart for [[decision making]] to view your former, your current, and your future self as three different people. #quote

How to [[speak to yourself]] from [reboots podcast](https://rebootspodcast.podia.com/members/posts/32616-using-roam-to-crush-self-doubt) for [[NTNDS]]

The proper way:

We will acknowledge where we blew it today. Quickly, efficiently, and without judgment. Own it.

We will not blame others for the mistakes we made today.

If we need to make an amend to ourselves or to someone else, we will offer guidance on how to make it right the next day.

We will own victories and [[translate]] large and small victories to action steps for our tomorrow selves.

We will address the difficult things on our agenda tomorrow and we will encourage our tomorrow selves with empathy and with confidence that our next day selves are up to the task.

We will show ample grace for our today selves and our tomorrow selves.

We will address our note with a neutral to affectionate salutation. "Dear (next day) (Name)

We will sign our names, "Respectfully" or "Love" (day of the week) (your name)

The process

Add [[NTNDS]] to your Daily Notes page format.

As you close your day, write the note using the communication parameters.

Tag the note with tomorrow's date.

Set up your Tomorrow page.

At the top of your tomorrow page, **create a block embed**.

Type [[NTNDS]] in the double parentheses

When you see the appropriate block, select it.

The next day, when you're ready to work, read the note.

[[roam/js]]

[[template/mtg]]

