{{[[DONE]]}} #[[[[mHealth]] app kit]] landing page needs & [[feedback]]: #/ [[🏔ADK [[Task Management]]]]

better assets

re-organized sections

look at og designs, story arc, sean designs

[[feedback]] by section

## Hero

Better hero image - possibly video? No, not enough time. Table this, though.

Short-term: Screenshots of Mobile app + admin dashboard, abstract shape in background

Medium-term: rotating project-specific screenshots like this from stripe.com/saas:

https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FGcskVaalUb.mov?alt=media&token=f4c8688d-d1c5-4ac6-bbbf-84c5d20804bb

Maybe this from tutorial or this style?

![Woman holding an iPad displaying mHealth dashboard](https://uploads-ssl.webflow.com/5f7f561c41abca3730d16a31/5f7f6843a0530a655164b85a_hero-img-red.png)

Logos in hero section

See: Twilio, Clickup for execution examples

## Section 2: Introducing the mHealth App Kit

Like Stripe homepage

Screenshot example

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2Fp_gH8BmEr9.png?alt=media&token=760084eb-7ead-4c06-8826-8936dac70746)

Assets:

[Patient data management (slide 9)](https://docs.google.com/presentation/d/16hbzAvm_DZrfqrvzrd9btqkRIhqtHU6o084WymKkttE/edit#slide=id.g6ef225ebf7_0_45)

[Image upload ](https://adkgroup.invisionapp.com/d/main?origin=v7#/console/20129767/422866352/preview?scrollOffset=4710)

[History screenshot](https://adkgroup.invisionapp.com/d/main?origin=v7#/console/19006558/396553771/preview?scrollOffset=10993)

[patient charts](https://adkgroup.invisionapp.com/d/main?origin=v7#/console/18195941/432876144/preview?scrollOffset=5030)

[smell test](https://adkgroup.invisionapp.com/d/main#/console/19904626/416644769/preview)

## Section 3: Value prop specifics

The single hero shot with scrolling text looks awesome, but doesn't quite work because we don't have a strong enough hero image/asset yet

Instead, replace this first scrolling section with something like the below, probably dark background? And if we go with an image on the side, would put it on right side to alternate with next section

Clearbit homepage

https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FbYs1xcLZFS.mov?alt=media&token=b418f915-1cd0-424f-90b4-986b83fe3257

Clickup homepage

https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2F1eh5Qosxhs.mov?alt=media&token=b48c31c9-9233-44a6-abd0-d872e859cf95

## Section 4: content section/screens

This is dope. I think we just need a little more context. 

Can we change the text cards on the right to all have the text:

FEATURES 

A better experience for your patients also means better data for your study.

## Section 5: case studies

I think we probably should lead with the featured case study, STAMP. Can we get that section to look closer to [this](stripe.com/saas)? 

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2F7AHbeTi7OP.png?alt=media&token=e2dc7b15-ecd9-482f-8982-9af36251e6c8)

And then when you put the other 3 (with room for 4) case study links + descriptions could we make them smaller/more subservient?

Maybe like SEE MORE CASE STUDIES

Title + logo (lose the descriptive paragraphs)

## Section 6: testimonial

Something simple like:

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FgVUhwQ9jKC.png?alt=media&token=f65aab05-59ee-4495-9709-cf158e260617)

## CTA

Brian Mullen headshot (see LinkedIn) + brief bio + button (leave target blank for now)

{{[[DONE]]}} High level [[scope]] for [[LWDA]] [[🏔ADK [[Task Management]]]] #/

Specific to [[LWDA]]

Errors with current site

No response (3)

Redirects (5)

4xx resopnse codes (4)

Not properly enforcing HTTPS

No images have alt text (1684)

Multiple canonical URLs (255)

Content strategy - pages with <200 words (98)

Sitemap

Technical: [[website migration]] and [[[[CMS]] migration]]

Things to keep in mind

URL structure changes

Meta tags and H1 tags

Service files (robots.txt and XML sitemap)

Structured data

Analytics tracking tags

Process

Crawl

Purpose: 

Benchmark data

Site speed

Keyword ranking

Traffic

Redirects

Highlight any technical issues to avoid migrating

Tools: Google Analytics, Google Search Console, [[ahrefs]], Screaming Frog

Redirect map

Post-launch checklist

[How to audit redirects](https://www.screamingfrog.co.uk/audit-redirects/)

Robots.txt allows crawling

XML sitemap

Meta robots allow indexing

Tracking codes are installed

Canonical URLs 

Open graph

Strategic: Setting up the new content area for success

Sitemap & IA

Design

Keyword research

