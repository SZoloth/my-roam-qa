Today was mostly wrapping up [[paid acquisition]] [[Marketing ]] for [[form health]] at [[ADK Group]]

#[[Accomplishments at ADK]]

I also set up the [[landing page]] for form health

My [[work out]] today was a kick in the ass - but it's good to be back on the horse. 

I did upper body: [[bench press]], [[bent over row]]



#france trip planning

#restaurants to eat at









