Author:: [[aleydasolis.com]]

URL:: https://www.aleydasolis.com/en/search-engine-optimization/optimizing-content-in-category-pages-while-keeping-its-commercial-nature/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

when the ecommerce category pages don’t have any other content at all other than links to the products then it’s really hard for us to rank those pages. 

some amount of text is useful to have on a page so that we can understand what this page is about. 

our algorithms sometimes get confused is when they have a list of products on top and essentially a giant article on the bottom when our algorithms have to figure out the intent of this page. Is this something that is meant for commercial intent or is this an informational page? 

For Google *it is* useful to have some amount of text in category pages to understand what the page is about (as with any other page!) 

Nonetheless, if the text featured at the bottom of the category pages is a “giant article”, informational content that is not aligned with the commercial nature/intent of the category page, it can confuse Google. 

Our goal with category pages should be then to feature information that confirms the features/functionalities/USPs of that particular set of products, clarifies any common doubts about them, informs about any existing offers and why/how the user is in the best place to buy them 

To develop this content we can use the questions received via the Website customer support system, the searches performed within the site search functionality, the usual keyword research tools and more targeted tools like alsoasked.com. 

Confirm to the user what the products they’re looking at are the best at
Clarify any doubts/concerns regarding the products shared characteristics and usage
Inform why they’re at the best place to buy these types of products 

features its products at the top, right after an intro with a short description about their unique characteristics: 

The page starts by introducing their vitamins, explaining what makes them better than others “Fermented for maximum absorption”, “Formulated for your specific health needs”, “Support overall health and wellness”, and then after the products featuring a “Quick Q&A”, answering questions like: 

They start featuring the top products/services
Show you what you can enjoy from if you get any of the offered products/services
They show again products from the top providers/merchants highlighting their testimonials
They show again more benefits to enjoy from if you use these products
They highlight previous customers testimonials so there’s no doubt about the quality of the products 

