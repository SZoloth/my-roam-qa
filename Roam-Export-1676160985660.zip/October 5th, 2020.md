[[website migration]]

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2Fx_TbjsMUFb.png?alt=media&token=89e8b308-1de3-4b36-92ac-c6862e964a6b)

source: https://seeker.digital/website-migrations

https://static.semrush.com/siteaudit-migrations/src/assets/pdf/EN_The_SEMrush_Website_Migration_Checklist.pdf

[[technical seo audit]]

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FRdnKEMBQYy.png?alt=media&token=318cf8b9-535a-4238-9182-dcda5ff25365)

source: https://www.slideshare.net/FayeWatt/how-to-conduct-a-technical-seo-audit-faye-watt-sheffielddm

[[content audit]]

[Checklist](https://docs.google.com/spreadsheets/d/1AGUKCflts74qz-3JbMm1Yzwz2UVABOlYSeI6MT1zwyU/edit#gid=169006592)

{{[[DONE]]}} Kick off [[agile marketing]] #/ #[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} Define [[my [[OKR]]s]] #/

Schedule [[retro]]s and kick offs for every sprint

Schedule daily stand

[[Meetings]]: digital health for adk [[[[mHealth]] app kit]]

Attendees:: [[chris baker]] [[jordan daly]]

Time:: 10:34

Notes::

 3 separate but parallel

New adkgroup.com

ADK mHealth App Kit (mobile app kit platform) [[[[mHealth]] app kit]]

Josie is head of innovation at Brigham - we want everyone research at BWH to know about this?

Pricing structure - licensing fee and very little services

how to stand up v1 with minimal funding and then file for an NIH grant to commercialize, etc.

Do we start to stand up a company voice that's health-first? ADK Health

Start with focusing on positioning, IA, then style tiles

Physicians office resources

HIPAA compliant chat, hosting, UX

Current hypothesis - Webflow

4 personas

Clinical Researchers

eg - STAMP and IMProve

Clinical Applications (Telemedicine / Telehealth)

eg - Firefly

Friends and family, seed, series A

Choosing agency over product team

Pharmaceuticals

eg - GTI(..ish. will be Trojan Horse into space)

21 CFR part 11 (FDA), HIPAA, UX Best Practices for Health Care

Med Devices

no eg, but broadly: tech-enabled medical devices

Logos: Roche, Genentech, grant funding from NIH grants (our team is listed as principal investigators on grants)

{{[[DONE]]}} Marketing team Webflow training #[[🏔ADK [[Task Management]]]] #///

Thesis testing

[[Meetings]]: [[Museum of Science]]

Attendees:: [[Lauren McDonough]] [[melissa rousselle]] [[chris baker]] [[darci nevitt]]

Time:: 11:02

Notes::

 Segmenting HubSpot to better leverage contacts

Resources:

Pay for technical support from HubSpot

History/Misc

HubSpot is at least 4-5 years old

No gatekeeper/owner of process; no admin

Cleaning data:

Dupes, outdated

Some fields may be relevant but very niche

Fields

these used to be open

Assign owners

Integration with SF

Need to clean up owners in SF and HubSpot

Leads being sent to reps no longer with the company

[[segmentation]]

~65000 contacts

Some people have very limited data

No rules for HubSpot lifecycles

Have an email preference center

How to engage with customers?

Cross-sell and upsell

HubSpot: Data & Reporting

Integrations

Databox

Reporting is difficult - [[funnel]]

HubSpot + SalesForce

June 2018, syncing turned off

Because: SF overrides HubSpot

December 2018, syncing turned on

Working fine since then

Now: syncing is working

Process is weaker though

{{[[DONE]]}} Sketch out content hub for [[Privafy]] #[[🏔ADK [[Task Management]]]] #/

content hub link: https://docs.google.com/spreadsheets/d/1NKFXVnnqtkWwHbkXrRKHwyns2m7y-aTG/edit#gid=1566614180

[[Meetings]]: [[[[mHealth]] app kit]]\

Attendees:: [[ben kaplan]]

Time:: 14:01

Notes::

 Tutorial page

[[ben kaplan]] not super stoked about [[refine labs]]

[[Meetings]]: [[APCIA]] analytics

Attendees:: [[aaron crootof]]

Time:: 16:42

Notes::

Lotta issues to follow up on

