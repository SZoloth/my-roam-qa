Tags:: #[[career]]

## To Do's

{{[[DONE]]}} Update [[resume]]

Agile + OKR at ADK for process/PM

[[funnel]] optimization for Form Health

Better integration between dev + analytics/SEO --> ticket templates, presentations, reduction in launch errors 

Market + competitive research for Form Health (uncovered Parsely, though not direct competitor at all)

Scaled from being single marketer to managing team of 4 by developing playbooks and workflows for teammates to learn, optimize, and eventually own

Drawbridge - persona generation and [[[[product]] [[discovery]]]]

Audited LetsGetChecked for a VC partner and advised on growth

CRO

Landing page strategy for Wasabi

A/B testing strategy for Wasabi

Analytics + SEO

Customer journey and nurture strategy for Museum of Science's education branch

Experience setting up, managing, and optimizing paid campaigns on Facebook, LinkedIn, and Google Ads.

Analytics and testing strategy

Segment + [[Amplitude]] for Form Health, CRO (focused on conversion and activation)

Lead site analytics architecture and implementation across clients

{{[[DONE]]}} Update [[cover letter]] template

Lindsey

Hey Lindsey! Love the content you and the TB team has been creating -- hope you're staying sane and whatnot given everything. I was cruising through LinkedIn recently and saw that you liked a post by Nicole Bocskocsky about some open positions at Parsley Health.

There are two that sound like they'd be strong fits: the [Growth Director](https://www.parsleyhealth.com/[[[[career]]s]]/?gh_jid=4126428003) and [Product Marketing Manager](https://boards.greenhouse.io/parsleyhealth/jobs/4084958003). I've spent the last 3 years at ADK growing from an individual contributor to a team lead focused on product marketing and conversion rate optimization. I'd be thrilled to take my experience in house at Parsley Health. 

Is there anyone on their end that you know and would be willing to make an introduction to? I'd love to learn more about the roles and how I can best help their co grow! 

Frances

Hi

Saw posting

I'm currently

I'm super interested in roles and would love to learn more

Would you be open to chatt

{{[[TODO]]}} Update LinkedIn

{{[[TODO]]}} Put together questions to ask

How is the team organized?

What is the experimentation culture like?

What is the growth [[model]]?

What are the top priorities this quarter/year?

Where do you see this role having the most impact?

How has COVID affect the company?

{{[[TODO]]}} Put together answers to common questions

Why leave?

Agency -> in-house. Appreciated the learning opportunities, but learned value of focus/prioritization, which is tough to do on a [[career]] level at an agency. Got exposure to some great companies, but wasn't able to fully control where I spent my time so wound up on some clients in insurance/construction.

Cross-functional collaboration

Focus on "Why" of project

Frame requests in terms of ROI for the business

[[prioritize]] long-term solutions/systems vs. short-term band-aids

Walking in with an overbuilt solution vs. framing an objective to get buy-in 

Developing shared roadmaps that don't just focus on marketing KPIs

Learn as much as possible about the teams and individuals so I can be attune to [[Goals]]

Other tactics that can help move projects forward (eg - naming it & getting a senior-level sponsor to increase visibility)

My story

Managing a small team focused on SEO, content, and analytics. 

Building out processes for A/B testing, pitching to clients, and training their internal teams on them. 

Wins:

Wasabi

Firefly, Form Health

Coaching a DR with no experience in GA/GTM and site analytic into one of our leading analytics resources on the team.

Introducing OKRs

What's your process for X?

Go to market strategy

Optimization and testing

[[funnel]]s and campaigns

Optimizing a [[funnel]]

Project management

## Positions

@ [[Parsley Health]]

[[Parsley Health/Growth Marketing Director]] 

[[Parsley Health/Product Marketing Manager]]

@ [[HipCamp]]

[[HipCamp/Product Manager]]

## Resources

[[Crossing the Canyon: Leading Your First Marketing Team — Reforge]]

https://www.lennyrachitsky.com/p/how-to-get-into-product-management

https://www.lennyrachitsky.com/p/fostering-a-culture-of-experimentation?token=eyJ1c2VyX2lkIjoxMjYyMzcxNCwicG9zdF9pZCI6MjEwOTQ0MCwiXyI6Im1KTVdkIiwiaWF0IjoxNjAyMzY0Mzc3LCJleHAiOjE2MDIzNjc5NzcsImlzcyI6InB1Yi0xMDg0NSIsInN1YiI6InBvc3QtcmVhY3Rpb24ifQ.uHsQoLneMfkqam1QE9M6JifewFFU3rbbRPOnAm57LTI

https://www.lennyrachitsky.com/p/-community-wisdom-issue-2

