Tags::  #[[Topics to help white friends]]

Atlanta Mayor Speech from WSJ

Link

https://www.wsj.com/articles/when-violence-erupted-one-mayor-found-all-the-right-words-11591416001?emailToken=2aa25d1105e747066114a0919b4e4f71tVdiKeCvs5/SLctzgie7SB4QqKIBou5MDRHYaadTQZPL+S3tglunidJZceK0adNRZ87m89cs1EdkW1OW21X3jvfB/x3Dbx9RifnFWMaxTfft+rhYaEbXZV+H6bHnK+hm&reflink=article_imessage_share

Video

https://twitter.com/Atlanta_Police/status/1266543789377806338

Quotes

"As an African-American mother of four, she told them, `You’re not going to outconcern me and outcare about where we are in America. I wear this each and every day. I pray over my children each and every day.`"

"It’s impossible to measure the impact of her words. Within two days, peace had largely been restored in Atlanta, although National Guard troops and a curfew surely helped."

`“You’re not protesting anything, running out with brown liquor in your hands, breaking windows in this city,” she shouted. “When you burn down this city, you’re burning down our community.”`

"Here, at the peak of volume, the mayor offered a better solution. `If you want change in America, go and register to vote,` she said. `Show up at the polls on June 9. Do it in November. That is the change we need in this country.`"

"`In the same way I can’t protect my son…I cannot protect you out in those streets,` she said."

Questions #[[charlie madden]]

Did you watch the speech or just agree with the Op Ed writers opinion?

Have you seen this from a conservative member? Do you think Donald Trump has done anything like this? Do you think he should have? 

Main points of the article

Focus on the destruction

Focus on the fact that she didn't write the speech

[[constructive scolding]]

Ditch the notes

Lose the badge

Be representative of the people you're scolding (in this case, Black) - rather than representative of the people they're protesting against (police, national guard, etc.)

Main issues with the article

It does not focus on - or mention - why the protests started

This speech may have helped quell violence (symptom), but does little to solve the illness (#racism, #[[systemic racism]] and #[[police brutality]])

I disagree with the parts of her speech that delegitimize the protests by telling them `you're not protesting anything`

"Here, at the peak of volume, the mayor offered a better solution. `If you want change in America, go and register to vote,` she said. `Show up at the polls on June 9. Do it in November. That is the change we need in this country.`"

People are using [[protests]] because they fundamentally don't believe this is enough.

The [[protests]] are working. Voting has not.

"`In the same way I can’t protect my son…I cannot protect you out in those streets,` she said."

Gerrymandering and red lining reduces the impact of voting

Shelby Steele On “How America's Past Sins Have Polarized Our Country”

Link

https://youtu.be/mMpQBWH-RwA

Who is the author? [[shelby steele]]

What is the source? [[hoover institution]]

Rough notes

"How America's past sins have polarized our country"

Should be "how __white__ America's past sins"

Taking a knee during the national anthem

400 years of victimization resulted in an identity focused in the idea of blacks as victims

This identity is dislodged from reality

Claims that the NFL protestors "mindlessly" followed without investigating the degree of oppression

Roger Goodell quote about equality

1) It was about police brutality

2) Shelby says Roger cannot have a POV because it's not about football. That football players cannot have a POV because it's not about football. 

^^Shelby arguments:^^ 

Not very much oppression

We've transformed ourselves

The Taking a knee during the national anthem is obsolete

`this is not segregated america. i grew up in segregated america so i know the difference.`

I wonder how widely this is reflected? Or is this the conservative [[intelligentsia]]?

He grew up with segregation, **protested**, and sued. It is now fixed. 

^^We made up for everything at 1964. ^^ After the Civil Rights movements

`here's a huge piece of legislation affirming our commitment to not do this anymore`

brushes over this: `that bill has a lot of problems that have come to hurt us`

but as a `historical gesture`, it was a great `moral acknowledgment`

Shelby acknowledge that MLK Jr. and Rosa Parks are `__genuinely__ great figures` because

They sacrificed

They achieved `something truly great`

We extended Democracy past the barrier of race

There was a point after the Civil Rights movements where black people created an identity called "Blackness"

It was angry, resentful, and separatist

It had the illusion that we would get farther by [protesting] rather than joining the American people

^^America is better than Africa so we're good^^

^^This trip showed him that racial identity is a passive thing, it's not an agent of change.^^

^^Racial identity is a delusion^^

`Black America has been confronted with a new problem: the shock of freedom`

If you have been oppressed you learn to accommodate that

You never have the opportunity to live free

Black people became free in the 60's

Freedom is here. We stopped oppressing you, now it's your responsibility

Freedom caused fear

"What do people do when confronted with their own freedom. They reinvent oppression." 

How do you respond to the argument that racism still exists?

`in 2015, black households at the 20th and 40th percentiles of household income earned an average of 55 percent as much as white households at those same percentiles. That is exactly the same figure as in 1967.` New York Times

^^Response: it's a corruption because, "who says that's because of racism?"^^

`maybe you just don't have the value sets and ideas to thrive in freedom`

"What do people do when confronted with their own freedom. They reinvent oppression." 

It's made up: systemic, microaggressions, white privilege

This is just "the shock of freedom"

All black leadership can think to do is ask for more from the government

The government has given us almost everything and yet we're farther behind

So another keypoint: ^^the government gave Black people what they deserve in the 60s and it's now Black people's fault for everything that follows.^^

^^HE IMPLIES BLACK PEOPLE ARE INFERIOR^^

B/C they're not doing well

^^"If racism exists it should be obvious"^^

In other words, "if I don't see it, it doesn't exist"

`you do not take a person who...has been hobbled by chains and...bring him up to the starting line of a race and then say, "you are free to compete with the others..." Equal opportunity is essential, but not enough.` LBJ

^^"That's not actually about Black people"^^ b/c Black people were coming into freedom.

It's about white guilt

^^This is not guilt, it's the terror of being seen as a racist.^^

"It's now in everybody's elses hands but yours" this is why Black people 

^^Integration at schools was a bad idea and did absolutely nothing^^ ???

social justice is hustling 

The white interviewer points

MLK Jr. and Rosa Parks are `__genuinely__ great figures`

Some of my notes

Is it my place - or any white person's - to say, "yes this black man can speak for the experience of all black people"?

This is essentially gaslighting. The mental and logical gymnastics this man makes to justify his ignorance is appalling. 

His goal was an apology for racism? His argument hinges on the opinion that 1964 was the end of racism.

`this is not segregated america. i grew up in segregated america so i know the difference.`

This video was posted in February of 2018 - I wonder if you have anything relating to the protests we're discussing now?

Ultimately, I think these current protests prove that Shelby is wrong.

Who else have you shared this with? Why? 

Freedom is here. We stopped oppressing you, now it's your responsibility

#whiteprivilege and #[[Trevor Noah]]

I think ultimately it's going be possible to find a battery of opinions and interpretations of numbers to support almost any side. There is a style of thinking that lets you take any argument and turn it into proof that the other side is wrong. What's important to think about is, why are you doing that?

He makes the point that the government had the power to end racism, but not help Black people afterwards. That Black people should use their freedom to get involved in government but not ask the government for help. 

Got to 25m in and ultimately saw enough

https://youtu.be/wOhYqNbXGbE

Tags:: #[[charlie madden]] #[[charlie madden]] #[[Topics to help white friends]]

Email summary

Hey Chuck,

Thanks for taking the time and effort to have these discussions with me. If you're feeling anything how I feel about them, I can imagine they're at least a little draining. But I do recognize their importance and value.

You've exposed me to some viewpoints that I never would have been exposed to. 

With the latest video, Shelby Steele On "How America's Past Sins Have Polarized Our Country”, I've actually come to realize something about the nature of these conversations.

I have a lot of thoughts and opinions on the discussion. And whole-heartedly, 100% disagree with the opinions being shared.

But his rhetoric demonstrated that there will always be a way to find a litany of opinions and ways to interpret statistics to support almost any point. And when there isn't, one can make up concepts like "the shock of freedom" and use that as a blanket position to address any counter argument. In fact, this whole conversation that I watched felt like gaslighting.

In the face of thinking like that, I'm not sure there is a reasonable way forward. 

I've attached some questions this video brought up for me, but feel strongly that it is besides the point. And want to give you the time and space to answer the questions I previously posed. 

For ease of reference, the questions are:

Additionally, the majority of protests stay non-violent, but the media that you've listed specifically will focus on property damage and violence. Why do you think that is?

It's interesting that you focus on buildings lost. It's definitely not good, but I don't really think it's an overreaction to 400+ years of second class citizenship and dehumanization. Is that more important to you than things like freedom of speech, miranda rights, police brutality? What are you defending right now? 

Does the fact that a response was necessary mean that any response was right?

And if you think loss of property and income is such an injustice that it causes you to - even potentially - weigh it against loss of life or rights why do you focus on it now? 

If you've moved beyond those questions, I've attached some questions I had in reaction to the video as a postscript to this email. I also attached my thoughts to the article analyzing the Atlanta mayor's speech skills. 

Like the other questions, you obviously have no obligation to answer them to me. But I do hope you take the time to think about and answer them for yourself.

Some questions about Shelby Steele On "How America's Past Sins Have Polarized Our Country” 

Is it my place to say, "yes, this black man can speak for the experience of all Black people"?

Did he justify his opinions sufficiently enough for your skepticism?

Who else have you shared this with? Why? Who haven't you shared this with? Why not? 

He believes that Black people have equality, freedom and racial parity. Do you think that's the case? Do you think the majority of Black Americans would agree with him?

Re: Roger Goodell quote about equality: 

The kneeling was about police brutality, not "equality" as the people discussed

Shelby said that Roger cannot have a POV it isn't football. Who can have a POV? Why? Why does being a football professional disqualify one from having an opinion on - and standing up for - racial equality?

Shelby states that we are not currently living with racism. I wonder how widely this is reflected among the people equipped to assess that (Black people)?

He heavily implies that it is his opinion that racism was "fixed" in the 60s with the Civil Rights movement. This is the basis of a lot of his following opinions - do you believe that racism was solved in the 60s? 

Shelby acknowledges that MLK Jr. and Rosa Parks are "genuinely great" because they sacrificed and achieved something truly great.

Is Shelby the arbiter of what constitutes "sacrifice" and "greatness"? Why?

Does Colin Kaepernick sacrificing his [[career]] not count? Are his achievements towards awareness of racial injustice not "great"?

 Shelby said that the idea that Black people would get farther by protesting rather than "joining the American people" - given the historic changes that are being made right now as a direct consequence of the protests, do you agree?

Shelby responds to a statistic saying that black households earned an average of 55% as much as white households at similar percentiles of HHI, which is the same since 1967. He says, "who says it's because of racism?...maybe you just don't have the value sets and ideas to thrive in freedom." Assuming he's sharing his opinion as a question, do you agree with it?

He implies that Black people are inferior because they're not doing well after the 60s - do you agree with this?

He believes the LBJ quote was not actually about Black people because Black people were coming into freedom. Why?

He claims it's because LBJ was feeling white guilt, or "the terror of being seen as a racist" - how do you think Shelby knows this? What is his basis to tell us the motivations of a dead white man that explicitly said otherwise?

He mentions surprisingly briefly (though maybe because he can't back it up) that integration at schools was a bad idea and did absolutely nothing. I wonder why he believes this? Especially after his own childhood.

Some reactions to the WSJ article on the Atlanta mayor's speech skilsl

What is the main point of the article? While the bulk of it is about public speaking skills, it uses that as a sort of Trojan Horse to introduce editorialized accounts of the protest - why?

The protests have resulted in a huge amount of systemic change and I hope they continue to. Given that alone (but among other things like gerrymandering and red lining), I think her quote of "If you want change in America, go and register to vote" is condescending and wrong. How do you feel? Do you think people would protest if they felt voting works?

"`In the same way I can’t protect my son…I cannot protect you out in those streets,` she said."

How did we get here? Why can the mayor not protect her constituents from police violence?

About her speaking skills and non violent de-escalation tactics: where else have you seen this? How do you think Trump is doing in regards to this?

If you think this speech was right and effective - why defend violence as an option at all?

