{{[[DONE]]}} $1k/week on lead gen targeting Drupal ($200/day) #Inbox [[ADK Drupal Campaigns]] #/

To Do

{{[[DONE]]}} Change "#1 Full service" in ads

{{[[DONE]]}} Add new ad variation focused around partnerships/listening

{{[[TODO]]}} Test CTA of "talk to Drupal expert"

We speak Drupal __and__ english

{{[[DONE]]}} For [[Dan Tatar]]

Budget

$200/day

Launch date

Today / tomorrow

First report

One week from launch

High level targeting strategy (ad groups)

Launch with broad strategy - these are broad enough to pick up related terms (eg - if someone looks for "fix my drupal UX" or "drupal help desk experts" or "drupal staff augmentation" we'll show up. if we find that people are saerching for something like that, I'll create an ad group targeting that keyword and an ad using that keyword.)

agency and services (eg keyword: `drupal agency`)

design (eg keyword: `drupal designers`)

competitors (eg keyword: `molly duggan`)

Learn what terms people use and engage with

Optimize ads for those, add negative keywords

Optimize landing page

Shortly after launch, create a dramatically different experience to test against

What to expect

Weekly reports with

Spend, leads, cost per leads

Week 1 = learning

Week 2-4 = executing on learnings and testing

Week 5+ = mostly optimization/refining, some big swing tests

Landing page updates

{{[[TODO]]}} Post launch

Set up optimization reminders

Look for queries to keywords

Look for opportunities to improve landing page

{{[[TODO]]}} Ad around specific expert - eg, `Andrew Stowell has X years experience with Drupal. Ask him anything.`

{{[[TODO]]}} Prep for specific pain point ad groups

the pain points that our higher-end drupal clients have are typically UI/UX (my site isn't performing or is hard to use), Maintenance (my current support team is slow to respond or too inexperienced for my needs), compliance related (accessibility/GDPR/etc - I'm looking for a partner that can support my needs) or specialty focused (I need someone who can do drupal localization, etc.)

Goal: "wow that's clever"

Keywords

maintenance, upgrades, issue, customized, help desk

long tail

website?

design, UI, UX

drupal for {{industry}}

Audience

We need people with budgets that need a website that WordPress can't solve

Locations? Can we target everywhere?

Landing page

Offer

Success looks like

Leads in the pipeline

Leads = real project on Drupal

Reaching out with RFPs

Opportunities have:

Defined budget, in service area we provide

B~~A~~NT (budget, ~~authority~~, need, timeline)

Don't measure CPL, measure CPO

$4k

RE: BELOW - **__dont__** do the PM stuff

Needs

{{[[DONE]]}} Keywords

{{[[DONE]]}} Competitor list & research

{{[[DONE]]}} Write the ads

Match offer/CTA to keyword intent 

{{[[DONE]]}} Set up the campaign

{{[[TODO]]}} Present to Chris Baker

{{[[DONE]]}} Align on goal - what is a MQL?

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2Fu8OQdzEMfl.png?alt=media&token=9ee05776-6049-4f93-9105-665c2c53583e)

{{[[TODO]]}} Create the landing page

{{[[TODO]]}} Write it 

Offers

Schedule a call

Chatbot

Email a question

Download free bundle of our latest and best Drupal content

{{[[TODO]]}} Design it

{{[[TODO]]}} Build it

{{[[TODO]]}} Launch

Plan

Account structure

ADK + General

ADK Group

Boston Drupal agency

Louisville Drupal agency

Competitors

Molly Dugan

Drupal

Drupal maintenance

Drupal upgrades

Drupal issues/challenges

Custom Drupal

Drupal agency

