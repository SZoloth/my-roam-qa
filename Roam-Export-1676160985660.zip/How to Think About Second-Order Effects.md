Author:: [[James Stuber]]

URL:: https://jamesstuber.com/second-order-effects/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

How can we become better second-order thinkers?

Ask more questions. Shane Parrish of Farnham Street suggests the following:

What is the range of possible [[outcome]]s?
What’s the probability I’m right?
What’s the follow-on? How could I be wrong? 

The Ten Commandments of Superforecasting are: #[[[[strategy]] [[*]]]]

Focus your time and effort on forecasts that will prove rewarding.

Unpack problems to expose [[assumption]]s, catch mistakes, and correct biases.

Consider the larger category before looking at the particular case.

Revise your beliefs often, and in small increments, to reduce the risks of both over- and under-reacting to the news.

Find merit in opposing viewpoints

Reject the illusion of certainty and learn to think in degrees of uncertainty.

Avoid being either a blowhard or a waffler. Aim to be prudently decisive.

Learn from experience, whether success or failure.

Use precision questioning to bring out the best in others–and to let others bring out the best in you.

Try, fail, analyze, and adjust. And try again.

There are no universally correct commandments, including these. Question everything. 

Sometimes to compensate, we need to over-compensate. Mentally reduce how much importance you give to first order effects, or even try completely ignoring them for a while. Increase how much importance you give to possible secondary effects, to the point of absurdity. 

