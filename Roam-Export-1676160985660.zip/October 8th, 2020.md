[[Meetings]]: [[LWDA]]

Attendees:: [[gabrielle feinsmith]]

Time::

Notes::

Normally marketing outreach cancelled

Large library of recorded talks, video, education

Change from portfolio to education

Year long good campaign for next year

National poll of senior living providers (core client groups)

A lot of publication & education around those results

Be the architect who knows what to do for the future of healthcare and COVID-19

In the next month new site ready to launch

Asset collection

Intro 

Sitemap

Great

Access

Google Analytics 

Google Search Console

{{[[DONE]]}} High level [[scope]] for [[LWDA]] [[🏔ADK [[Task Management]]]] #/

{{[[DONE]]}} Sprint kick off for [[ADK/OKR]]s #[[🏔ADK [[Task Management]]]] #/

For [[Glenmede]] and possible [[i[[mercer]]]]

[[Google Analytics/content grouping]] & [[Google Analytics/custom dimensions]]

We'll extend content tracking capabilities further by implementing custom [[Google Analytics/content grouping]]s, based on things like business line, post topic, publish day, blog length, number of images or media, and other groups defined in a discussion with your team.

[[Google Analytics/custom dimensions]] let you slice data similarly to [[Google Analytics/content grouping]]s. The main differences are that [[Google Analytics/content grouping]]s show aggregate unique views and can be used in the behavior flow. 

Meanwhile, [[Google Analytics/custom dimensions]] can be used to filter views and can be used across views. Some powerful examples of custom dimensions focus on user properties, like whether or not they are logged on.

Custom metrics are similar to dimensions except they segment users by quantitative measures. Some examples could be the number of articles read or the number of assets downloaded.

[Comparison](https://www.bounteous.com/[[insight]]s/2016/01/21/content-groupings-vs-custom-dimensions/) of [[Google Analytics/content grouping]] and [[Google Analytics/custom dimensions]] from [[bounteous]] 

{{[[DONE]]}} [Transfer the confluence page](https://adkgroup.atlassian.net/wiki/spaces/MoS/pages/1962836268/HubSpot+Optimization+[[scope]]?focusedCommentId=1965588519) for [[Museum of Science]] second phase into proposify [[🏔ADK [[Task Management]]]] #/

[[Meetings]]: [[refine labs]]

Attendees::

Time::

Notes::

 LI algorithm change:

Reduce influencers

Increase newbies that post consistently

Text posts perform better than LI

Questions

How do you test algorithm changes?

Text posts: hashtags?

Rule of thumb: 1-3

Search the hashtag and confirm that there's a significant follower count (>10k followers)

No links to external websites

Upload case study to featured section of profile

Link in comments

Avoid re-sharing; LI suppresses shares

Screenshot of post and share that 

Box folder?

Pre-marketing

For podcast, launching mid-November

Pre-marketing

Videos:

Text first this week and next

Import

[[Eric Jorgenson]]

From: Navalmanack.json

[[Kapil Gupta]]

From: Navalmanack.json

[[Choosing to Free Yourself]]

From: Navalmanack.json

[[Be Patient]]

From: Navalmanack.json

[[Foreword by Tim Ferriss]]

From: Navalmanack.json

[[Meditation + Mental Strength]]

From: Navalmanack.json

[[Marcus Aurelius]]

From: Navalmanack.json

[[Vashistha Yoga]]

From: Navalmanack.json

[[How to Get Lucky]]

From: Navalmanack.json

[[Elad Gil]]

From: Navalmanack.json

[[Build or Buy Equity in a Business]]

From: Navalmanack.json

[[Envy is the Enemy of Happiness]]

From: Navalmanack.json

[[Jorge Luis Borges]]

From: Navalmanack.json

[[Now, here is Naval in his own words]]

From: Navalmanack.json

[[Next on Naval]]

From: Navalmanack.json

[[Understand How Wealth is Created]]

From: Navalmanack.json

[[Shed Your Identity to See Reality]]

From: Navalmanack.json

[[Judgment]]

From: Navalmanack.json

[[Naval's Writing]]

From: Navalmanack.json

[[Happiness is Built by Habits]]

From: Navalmanack.json

[[The Meanings of Life]]

From: Navalmanack.json

[[October 1st, 2020]]

From: Navalmanack.json

[[4:]]

From: Navalmanack.json

[[Find Work that Feels Like Play]]

From: Navalmanack.json

[[Jack Butcher]]

From: Navalmanack.json

[[The Present is All We Have]]

From: Navalmanack.json

[[Bio]]

From: Navalmanack.json

[[Zac Gorman]]

From: Navalmanack.json

[[Role]]

From: Navalmanack.json

[[October 8th, 2020]]

From: Navalmanack.json

[[Rational Buddhism]]

From: Navalmanack.json

[[Collect Mental [[model]]s]]

From: Navalmanack.json

[[Get Paid for your Judgment]]

From: Navalmanack.json

[[RoamCult]]

From: Navalmanack.json

[[Choosing to Be Yourself]]

From: Navalmanack.json

[[Happiness Requires Peace]]

From: Navalmanack.json

[[Osho]]

From: Navalmanack.json

[[Every Desire is a Chosen Unhappiness]]

From: Navalmanack.json

[[Find a Position of Leverage]]

From: Navalmanack.json

[[Find and Build Specific Knowledge]]

From: Navalmanack.json

[[Live by Your Values]]

From: Navalmanack.json

[[October 4th, 2020]]

From: Navalmanack.json

[[Company]]

From: Navalmanack.json

[[Matt Ridley]]

From: Navalmanack.json

[[October 6th, 2020]]

From: Navalmanack.json

[[97]]

From: Navalmanack.json

[[How to Think Clearly]]

From: Navalmanack.json

[[Eric's Note (About this Book)]]

From: Navalmanack.json

[[Play Long-term Games with Long-term People]]

From: Navalmanack.json

[[Part I: Wealth]]

From: Navalmanack.json

[[Naval Ravikant]]

From: Navalmanack.json

[[Bonus]]

From: Navalmanack.json

[[Rome]]

From: Navalmanack.json

[[Timeline of Naval Ravikant]]

From: Navalmanack.json

[[Find Happiness in Acceptance]]

From: Navalmanack.json

[[Choosing to Grow Yourself]]

From: Navalmanack.json

[[Jed McKenna]]

From: Navalmanack.json

[[The Almanack of Naval Ravikant]]

From: Navalmanack.json

[[Learn the Skills of Decision-Making]]

From: Navalmanack.json

[[Important Notes on this Book (Disclaimer)]]

From: Navalmanack.json

[[J.D. Williams]]

From: Navalmanack.json

[[Appreciation]]

From: Navalmanack.json

[[Choosing to Care for Yourself]]

From: Navalmanack.json

[[Happiness Requires Presence]]

From: Navalmanack.json

[[3:]]

From: Navalmanack.json

[[Robert Axelrod]]

From: Navalmanack.json

[[Happiness is Learned]]

From: Navalmanack.json

[[Introduction]]

From: Navalmanack.json

[[October 5th, 2020]]

From: Navalmanack.json

[[Welcome]]

From: Navalmanack.json

[[October 7th, 2020]]

From: Navalmanack.json

[[Game Theory]]

From: Navalmanack.json

[[Sources]]

From: Navalmanack.json

[[October 2nd, 2020]]

From: Navalmanack.json

[[Naval's Recommended Reading]]

From: Navalmanack.json

[[Choosing to Build Yourself]]

From: Navalmanack.json

[[Take on Accountability]]

From: Navalmanack.json

[[Success Does Not Earn Happiness]]

From: Navalmanack.json

[[Learn to Love to Read]]

From: Navalmanack.json

[[Happiness is a choice]]

From: Navalmanack.json

[[Part II: Happiness]]

From: Navalmanack.json

[[[[prioritize]] and Focus]]

From: Navalmanack.json

[[Tim Ferriss]]

From: Navalmanack.json

[[October 3rd, 2020]]

From: Navalmanack.json

[[Silicon Valley]]

From: Navalmanack.json

#[[Quick Capture]]

best CRMs for HIPAA compliance [[ADK/blogging]] [[ADK content]] [[Inspiration for ADK]]

