Posting: https://www.parsleyhealth.com/[[[[career]]s]]/?gh_jid=4126428003

Notes

You're an experienced growth marketer with a proven ability to transform conversion rates.

You will drive the customer journey strategy for Marketing and Growth initiatives focused on improving conversion rate.

Create and optimize cross-channel [[funnel]]s, campaigns, and engagement tactics that attract high-intent audiences and drive acquisition.

Partner closely with design, product and growth teams (paid, email, social, editorial) to test and improve content, creative, copy and audience targeting to attract targeted audiences and improve conversion rates.

Lead and optimize landing page strategy, website calls-to-action (CTAs), and lead-generating forms to increase our high-intent lead acquisition and member conversions.

Contribute to website development with a highly technical approach around analytics and testing strategy.

Create, execute, and refine testing roadmaps that directly address conversion [[Goals]] and challenges (ex: revenue, signups, engagement). You will leverage our internal production tools to support your conversion rate optimizations strategies. You’ll run A/B tests to continually measure the performance and share out your key learnings with stakeholders and cross functional partners.

lead omni channel strategies that attract and capture targeted audiences

[[insight]]s-Driven Problem Solving: Can take [[qualitative]] and quantitative customer and competitive inputs to understand and address our targeted user. Data and hypothesis-driven.

Cover Letter



