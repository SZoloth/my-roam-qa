Posting: https://boards.greenhouse.io/parsleyhealth/jobs/4084958003

Notes

You will guide **[[funnel]]** optimization focused on acquisition, and conversion.

You will work with Marketing, Sales, Product, and Design to create and improve high performing **[[funnel]]s** that unlock scalable growth.

You're an experienced product marketer with a passion for **acquisition strategy**, **customer experience**, and technology. You have both deep **technical knowledge** and an ability to **develop engaging experiences that acquires customers**.

Uncover, [[prioritize]] and eliminate conversion tension points through channels, messaging, features, and/or new product ideas.

Identify and advocate for new or improved products and/or features that will create more customer stickiness by lowering conversion hurdles.

Rigorously test growth hypotheses and ensure learnings are proactively shared with company stakeholders.

Perform market and competitive assessments; use [[insight]]s to shape product and marketing prioritization decisions.

Track projects, manage development timelines and organize the daily operations

Create the processes, systems, playbooks, and workflows that allow the team to grow into a scaled function with a measurable positive impact on our overview

Set our go-to-market strategy for new product or feature launches

Pricing

Packaging

Positioning

Distribution

the ability to create a value proposition, messaging frameworks, and product storytelling

Distribution: Can develop omnichannel go-to-market campaigns that attract and educate new audiences

Cover Letter

Hi Daniel,

I recently saw Nicole Bocskocsky's post on LinkedIn about open growth roles at Parsley Health and I jumped on it. I love what your team is doing and would be proud to contribute to your amazing growth.

I'm applying to the Product Marketing Manager position and wanted to give a little context on why I'd be a strong fit for the role:

I have years of experience both setting strategy and executing in marketing positions for high-growth digital health companies.

I developed an A/B testing strategy that drove immediate value for one of our SaaS clients and have been training their team to help them create a culture of experimentation.

I recently designed a go-to-market strategy for the founder of Form Health, who has been able to scale from serving Massachusetts to four additional states and is currently raising money off of that early validation and growth. 

Over the last 3 years, I've had the privilege to work closely with founders to help them create growth systems and processes that they can take and build teams around. Many of these companies have been in the consumer digital health space, which is where my passion has been since college. I've been a fan of what Parsley Health is doing ever since I ran some competitive research on your onboarding process for inspiration for one of my clients about a year ago. I'm extremely passionate about the creating and nurturing a culture of experimentation and am confident that my experience and skills can help Parsley Health reach its [[Goals]]. 

