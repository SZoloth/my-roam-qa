Building Wealth

[[Understand How Wealth is Created]]

[[Find and Build Specific Knowledge]]

[[Play Long-term Games with Long-term People]]

[[Take on Accountability]]

[[Build or Buy Equity in a Business]]

[[Find a Position of Leverage]]

[[Get Paid for your Judgment]]

[[[[prioritize]] and Focus]]

[[Find Work that Feels Like Play]]

[[How to Get Lucky]]

[[Be Patient]]

Building Judgment

[[Judgment]]

[[How to Think Clearly]]

[[Shed Your Identity to See Reality]]

[[Learn the Skills of Decision-Making]]

[[Collect Mental [[model]]s]]

[[Learn to Love to Read]]

