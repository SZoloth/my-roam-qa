#[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} Add [[Glenmede]] analytics tickets to Jira #/ 

[Done here](https://adkgroup.atlassian.net/secure/RapidBoard.jspa?rapidView=497&projectKey=GLEN&view=planning.nodetail&selectedIssue=GLEN-465&issueLimit=100&selectedEpic=GLEN-464)

**Custom events & conversions**

We'll propose a set of events to track with Google Tag Manager, some of which will be used for conversions. Before setting these up, we'll make sure we've included your [[feedback]] so that what we're tracking is valuable to your and your team and how it's labeled is clear.

Example events we'll propose tracking for include:

Video tracking (starts, pauses, completions)

Downloads

Conversions

RFP initiations

We'll also set up site search behavior tracking. An initial review revealed an opportunity for nearly 20 custom events.

**Cross domain tracking**

Glenmede owns a few separate domains. For some, it makes sense to ensure we can track a single user consistently between them, for others we may just need to set up referral exclusions. We'll define and execute this set up.

**Content grouping, custom dimensions, & custom metrics**

We'll extend content tracking capabilities further by implementing custom content groups, based on things like business line, post topic, publish day, blog length, number of images or media, and other groups defined in a discussion with your team.

Custom dimensions let you slice data similarly to content groups. The main differences are that content groupings show aggregate unique views and can be used in the behavior flow. Meanwhile, custom dimensions can be used to filter views and can be used across views. Some powerful examples of custom dimensions focus on user properties, like whether or not they are logged on.

Custom metrics are similar to dimensions except they segment users by quantitative measures. Some examples could be the number of articles read or the number of assets downloaded.

**Data studios template**

We'll wrap everything up with a clean dashboard created in Google Data Studios with views customized for up to 4 stakeholders.

All of this will be built on top of best Google Analytics and Google Tag Manager practices.

**We can help you accomplish all of the above with a budget of 30 hours. **

Let us know if you have any questions, if you want to proceed (I can include this in the Change Order we'll be discussing more tomorrow), and/or if you want to have a call to talk more with Sam!

Thanks!

{{[[DONE]]}} Follow up on Wasabi blog detail optimization

{{[[DONE]]}} Look into [[[[Wasabi]] analytics]] issue from [[mary mccarthy]] about the pricing calc

DCM pricing calculator lost data previous two weeks

Testing notes

Calc slider for storage amount does not fire DCM tag

AW - Calc Export - Price Slider

GA - Pricing Calc Slider

MiQ - Calc Export - Price Slider

TT - Calc Interactions

FB - MMC - Search

FB - PR team - Search

MiQ - 2019 Calc Engagement

Calc slider for percentage downloaded per month does not fire anything

Should it?

Change GA - AB Test - Pricing Hero CTA __triggers__ to only fire on link clicks

Monthly calculator dropdown only triggers

GA - Bill Calc Data Size

MMC - DCM - Pricing tools engagement

Spiceworks - Bill Calc Data Size

TT - Calc Interactions

Monthly calculator input field doesn't trigger anything

Triggers

Bill Calc - TB to PB select

Bill Calc Input Click

Calculator export button

Click on any slider

{{[[table]]}}

Events

GA - Pricing Calc Slider

AW - Calc Export - Price Slider

MiQ - Calc Export - Price Slider

TT - Calc Interactions

FB - MMC - Search

FB - PR team - Search

MiQ - 2019 Calc Engagement

GA - Bill Calc Data Size

MMC - DCM - Pricing tools engagement

Spiceworks - Bill Calc Data Size

Storage slider

x

x

x

x

x

x

x

Calc slider for percentage

x

x

x

x

x

x

x

 

Monthly dropdown







x







x

x

x

Monthly input field

 

Export csv

 

x

x

x

x

x

x

 

x

{{[[DONE]]}} [[[[Sleeping Dog Properties]] blog]] next topics and steps

{{[[DONE]]}} Year end review for [[chris rapczynski]] #///

{{[[DONE]]}} SEO & Analytics for [[Harvard/Yenching]] with [[charlie steinberg]] #/

Totally new site or redesign/platform of existing?

Staging site access

https://adkgroup.atlassian.net/browse/HYI-384

#[[my [[OKR]]s]] #//

{{[[DONE]]}} internal resources page confluence edits 

{{[[DONE]]}} ^^break down tickets^^

{{[[DONE]]}} landing page copy

