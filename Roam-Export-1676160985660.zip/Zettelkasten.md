Resources::

https://notes.andymatuschak.org/z2QvtE9w5zs49x7WUeG8Ut1vywHDLiG2Wkm9p

Review [[effortless output]] from [[nat eliason]]

https://www.youtube.com/watch?v=ljyo_WAJevQ

Zettelkasten

Process:

**Step 1: Take literature notes**

Definition: information you don't want to forget or think you'll use later

Rules:

It should be brief (less than 3 sentences). Be extremely selective

It has to **be in your own words.** No quoting.

When taking notes __while reading__ a physical book create page for it. 

Then nest notes under page numbers

Can nest original quotes & highlights under your literature notes

Physical book page should have attributes for

Literature notes

Quotes & Highlights

**Step 2: Add reference notes & progressive summarization**

Progressive summarization step 

Bold parts that are most interesting

Add links, too

Then, highlight the ^^super^^ important things

When you finish reading, make a reference note at the top of your page (this is metadata attributes)

Author

Summary

**Step 3: Make permanent notes**

Most important step

Go through each note in Step 1 while thinking about how they relate to what you already know

Find connections between each note and your interest, learning, research, and thinking

Goal is __not__ collecting as many notes as possible, but instead expanding or strengthening existing ideas

Questions to ask when making permanent notes

How does this idea fit into what I already know?

Can this be explained by something else?

What does X mean for Y? 

How can I use this idea to explain something else? 

To transform a reference note into a permanent note, make the note a page

At the top of the page add reference metadata

Source

Keywords (include tag for "permanent notes")

Relevant notes

Questions

For questions, nest the answer below the question

Adding keywords is the most important part

Ask yourself: in which circumstances will I want to stumble upon this note? How and when will I use this idea?

Adding relevant notes helps build connections

Go to your "permanent notes" page and scan through references for anything relevant

Filter using keywords

Then tag the page

Add a notes section

Write in proper sentences, not bullet points

**Step 4: Review & repeat**

[[Anki]] method?

Related to

[[Evergreen notes]] & [[Zettelkasten]]

[Link](https://notes.andymatuschak.org/z4AX7pHAu5uUfmrq4K4zig9x8jmmF62XgaMXm)

Progressive summarization

[[Taking Smart Notes]] by [[Sonke Ahrens]]

