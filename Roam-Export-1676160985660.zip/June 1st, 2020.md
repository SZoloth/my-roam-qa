[[🏔ADK [[Task Management]]]]

information architecture for [[ADK Website Rebuild]]

#[[Selling ADK Group]] challenge

[[[[Sleeping Dog Properties]] Marketing Strategy]] Backlog for #SEO

Lead gen ad

Blog revamp

URL audit (https://[[ahrefs]].com/blog/seo-friendly-urls/)

[[ADK Marketing Process]] for #SEO https://nickeubanks.com/keyword-strategy/

smell test is significantly more powerful in predicting covid than any symptom tracker or a fever #[[COVID-19 testing app]]

identified 36/37 correctly based on algorithms

[[Meetings with [[chris baker]]]]

Should I hand off [[National Speed]] to someone else? 

Yes: Set up a plan and hand off

To Darci - hey i was in the og meeting here. 

How do we manage multiple complex multi-audience campaigns at once?

What works in sales? Taking over legacy technology about 6-12 months before they're ready to build the new thing #[[Inspiration for ADK]] #[[Selling ADK Group]]

Onboarding in a lower-commitment manner as a means to getting next projects

Reliable, well-architected support - maintenance/helpdesk/new features

Big agencies don't do it, small shops don't have systems/process scale, offshore is risky

Should not supersede

