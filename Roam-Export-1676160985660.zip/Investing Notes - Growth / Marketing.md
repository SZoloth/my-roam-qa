# **Meta**

**Tags:** #[[Growth marketing[[*]]]], #investing, #vc, 

**Company:** #letsgetchecked

**People:** [[andrew chen]], [[jeff chang]], [[nik sharma]]

**Friends:** Nelson, Charlie

**Sources:** [Roman DTC Metrics](https://medium.com/ro-co/dtc-metrics-explained-29ff99ff5657), [Cohort retention rate](https://www.growthengblog.com/blog/the-best-metric-for-determining-quantitative-product-market-fit), [Investor Metrics](https://andrewchen.co/investor-metrics-deck/)

# Questions

Who are your competitors?

[everlywell](https://www.everlywell.com/)

Quest diagnostics

[Freenome](https://www.freenome.com/)

[Healthlabs](https://www.healthlabs.com/)

[stdcheck](https://www.stdcheck.com/)

[Thriva](https://thriva.co/)

[Medichecks](https://medichecks.com/)

[23andMe](https://www.23andme.com/)

mylabbox

stdexpress

[SH:24](https://sh24.org.uk/)

Healthline (organic traffic)

What happened September-October 2019 that caused your organic traffic to plummet?

What do you own that's proprietary?

How are you using aggregated, anonymized, proprietary data?

What is revenue [[model]] / growth equation?

What is your rate of growth experimentation?

Any recurring revenue opportunities?

Or repeat purchase behavior?

What is your marketing org chart?

How are you incentivizing/building in referrals?

WoM?

Why is your product/service significantly better than alternatives?

Any lead capture? Email list? Text list?

# Metrics

Make sure to break these down by segments (geographic, acquisition source, test type, demographics)

AOV

LTV

CAC

ROAS

Payback period

the time it takes to recuperate the cost of an ad spend through revenue

net dollar retention (if relevant)

Conversion [[funnel]] by segments

EBITDA margins - unit economics

Gross margin

basic unit economics (average sale price / price to produce / price to produce package ship etc)

Retention rate

Revenue growth

Precedent transactions of companies similar to yours

See what ebitda multiples those were purchased at that fit a similar growth and margin profile

## Predictive Growth [[model]]s: Loops ([[andrew chen]])

## Acquisition

How does one cohort of new users lead to the next cohort?

UGC + SEO for companies like: Yelp, Houzz

Paid marketing for companies like: Blue Apron, Casper, Uber

Viral for companies like: Dropbox, Instagram, LinkedIn

What is your paid marketing loop in detail?

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FMV-LoAIj6q?alt=media&token=90e35afb-852c-43c1-8081-4fd13ebff92e)

Example from Uber above

What is your acquisition mix?

signups or orders broken down by channels/loops and by time period (ideally weeks)

looking for

dominant channels to be proprietary and repeatable

low platform risk

mix of 33/33/33 - organic, viral loop, seo loop

What is your acquisition loop quality

Acquisition sources broken down by:

CAC / AOV

Payback period

Conversion rate

^^SEE ROMAN DTC METRICS^^

## Engagement

Most similar loop = personalized content (zillow, credit karma, netflix)?

Looking at [[notifications]] (emails)

Volume and triggers

Company initiated vs. UGC

CTR decay over time

## DTC Metrics ([Roman](https://medium.com/ro-co/dtc-metrics-explained-29ff99ff5657))

**CAC** = cost per ad / number of people who completed purchase

Want to see [[funnel]] for each acquisition source (eg: impressions, clicks, add to cart, purchase)

Calculate conversion rate

**AOV** = total dollars spent by a __cohort__ of customers, divided by the number of **orders** (not customers)

### Margin

Product margin: cost of goods sold (COGS) / gross sales price

**(AOV - COGs)/AOV = product margin**

### Gross Margin

Gross margin: cost of sales (COS) / gross sale price

Cost of sales = direct costs attributable to production of goods or supply of services (cost of labor & materials, shipping, packaging, fulfillment)

**Gross margin = (AOV - Cost)/AOV**

### ^^Contribution margin^^

Net profit after __all__ variable costs associated with selling a product or service are deducted from revenue generated (includes discounts and [[refund]]s)

**Contribution margin = (AOV - Total cost - Average discount)/AOV**

### Retention

**Monthly order retention by cohort**

Number of orders per month

**Payback period**

Time it takes for a cohort to payback in **contribution dollars** the amount it cost to acquire the same group of members

Numbers needed by month:

Orders

Revenue

Contribution dollars

Total contributed

CAC

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2Frt9Pb1T4NQ?alt=media&token=2b1cef00-7c21-44bf-82d5-c3407318e619)

**LTV**

Cumulative contribution dollars over the course of an entire relationship with a customer

LTV/CAC = number of years the person has been a customer

**Net Revenue Retention**

Net revenue = revenue remaining after all discounts, credits, and allowances are applied

Gross revenue does not include those things

Goal: NRR>100%

**Net Profit per Member per Cohort**

Difference in LTV per customer per month

Example excel sheet: https://drive.google.com/drive/u/0/folders/1R7gzOTlGqCExkg1xOhFznq2IFQs5XJAV



## Metrics for assessing channel performance ([[Demand Curve]])

Google Ads

Cost

Impressions

Clicks

CTR

Avg CPC

Conversions

definition of primary conversion(s)

Cost / conv.

Conv. rate

Conv. value

Conv. value / cost

All conversions

Cost / all conv.

All conv. value

All conv. value / cost

View-through conv.

Facebook

Campaign/ad set name

Errors

Delivery

Budget

Amount spent

Reach

Cost per website purchase

WEbsite purchases

Cost per unique outbound click

Unique outbound clicks

Unique outbound CTR

Frequency

Leads (Form)

# Access

Google Analytics

Google Search Console

Stripe

Intercom

Acquisition/marketing platforms

Ads

Emails



Hotjar

pitch deck

SEO tools

