# Now, here is Naval in his own words...

### Background

I grew up in a single-parent household with my mom working, going to school, and raising my brother and me as latchkey kids. We were very self-sufficient from a very early age. There was a lot of hardship, but everyone goes through hardship. It did help me in a number of ways.

We were poor immigrants. My dad came to the US—he was a pharmacist in India. But his degree wasn’t accepted here, so he worked in a hardware store. Not a great upbringing, you know. My family split up. [47]

[47] [[Naval Ravikant]]. “Ep. 31—[[Naval Ravikant]]—AngelList (2 of 2).” Interview by Kevin Weeks. __Venture Studio__, 2016.

My mother uniquely provided, against the background of hardship, unconditional and unfailing love. If you have nothing in your life, but you have at least one person that loves you unconditionally, it’ll do wonders for your self-esteem. [8]

[8] __Killing Buddha__ Interviews. “Chief Executive Philosopher: [[Naval Ravikant]] On Suffering and Acceptance.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/7/naval-ravikant-ceo-of-angellist; “Chief Executive Philosopher: Naval Ravikant On the Skill of Happiness.” __Killing Buddha,__ 2016. http://www.killingbuddha.co/blog/2016/2/10/chief-executive-philosopher-naval-onhappiness-as-peace-and-choosing-your-desires-carefully; “Chief Executive Philosopher: Naval Ravikant On Who He Admires.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/19/naval-ravikant-on-who-he-admires; “Chief Executive Philosopher: Naval Ravikant On the Give and Take of the Modern World.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/23/old-bodies-in-a-new-world; “Chief Executive Philosopher: Naval Ravikant On Travelling Lightly.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/9/19/naval-ravikant-on-travelling-lightly; “Naval Ravikant on Wim Hof, His Advice to His Children, and How He Wants to Look Back on His Life.” __Killing Buddha,__ 2016. http://www.killingbuddha.co/blog/2016/12/28/naval-ravikant-on-advice-to-his-children.

We were in a part of New York City that isn’t very safe. Basically, the library was my after-school center. After I came back from school, I would just go straight to the library and hang out there until they closed. Then, I would come home. That was my daily routine. [8]

[8] __Killing Buddha__ Interviews. “Chief Executive Philosopher: [[Naval Ravikant]] On Suffering and Acceptance.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/7/naval-ravikant-ceo-of-angellist; “Chief Executive Philosopher: Naval Ravikant On the Skill of Happiness.” __Killing Buddha,__ 2016. http://www.killingbuddha.co/blog/2016/2/10/chief-executive-philosopher-naval-onhappiness-as-peace-and-choosing-your-desires-carefully; “Chief Executive Philosopher: Naval Ravikant On Who He Admires.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/19/naval-ravikant-on-who-he-admires; “Chief Executive Philosopher: Naval Ravikant On the Give and Take of the Modern World.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/23/old-bodies-in-a-new-world; “Chief Executive Philosopher: Naval Ravikant On Travelling Lightly.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/9/19/naval-ravikant-on-travelling-lightly; “Naval Ravikant on Wim Hof, His Advice to His Children, and How He Wants to Look Back on His Life.” __Killing Buddha,__ 2016. http://www.killingbuddha.co/blog/2016/12/28/naval-ravikant-on-advice-to-his-children.

We moved to the US when we were very young. I didn’t have many friends, so I wasn’t very confident. I spent a lot of time reading. My only real friends were books. Books make for great friends, because the best thinkers of the last few thousand years tell you their nuggets of wisdom. [8]

[8] __Killing Buddha__ Interviews. “Chief Executive Philosopher: [[Naval Ravikant]] On Suffering and Acceptance.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/7/naval-ravikant-ceo-of-angellist; “Chief Executive Philosopher: Naval Ravikant On the Skill of Happiness.” __Killing Buddha,__ 2016. http://www.killingbuddha.co/blog/2016/2/10/chief-executive-philosopher-naval-onhappiness-as-peace-and-choosing-your-desires-carefully; “Chief Executive Philosopher: Naval Ravikant On Who He Admires.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/19/naval-ravikant-on-who-he-admires; “Chief Executive Philosopher: Naval Ravikant On the Give and Take of the Modern World.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/23/old-bodies-in-a-new-world; “Chief Executive Philosopher: Naval Ravikant On Travelling Lightly.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/9/19/naval-ravikant-on-travelling-lightly; “Naval Ravikant on Wim Hof, His Advice to His Children, and How He Wants to Look Back on His Life.” __Killing Buddha,__ 2016. http://www.killingbuddha.co/blog/2016/12/28/naval-ravikant-on-advice-to-his-children.

My first job was with an illegal catering company in the back of a van delivering Indian food when I was fifteen. Even when I was younger, I had a paper route and I washed dishes in the cafeteria.

I was a totally unknown kid in New York City from a nothing family, an “immigrants trying to survive” situation. Then, I passed the test to get into Stuyvesant High School. That saved my life, because once I had the Stuyvesant brand, I got into an Ivy League college, which led me into tech. Stuyvesant is one of those intelligence lottery situations where you can break in with instant validation. You go from being blue collar to white collar in one move. [73]

[73] @ScottAdamsSays. “Scott Adams Talks to Naval...” __Peri[[scope]], __2018. https://www.pscp.tv/w/1nAKERdZMkkGL.

At Dartmouth, I studied economics and computer science. There was a time when I thought I was going to be a PhD in economics. [8]

[8] __Killing Buddha__ Interviews. “Chief Executive Philosopher: [[Naval Ravikant]] On Suffering and Acceptance.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/7/naval-ravikant-ceo-of-angellist; “Chief Executive Philosopher: Naval Ravikant On the Skill of Happiness.” __Killing Buddha,__ 2016. http://www.killingbuddha.co/blog/2016/2/10/chief-executive-philosopher-naval-onhappiness-as-peace-and-choosing-your-desires-carefully; “Chief Executive Philosopher: Naval Ravikant On Who He Admires.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/19/naval-ravikant-on-who-he-admires; “Chief Executive Philosopher: Naval Ravikant On the Give and Take of the Modern World.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/23/old-bodies-in-a-new-world; “Chief Executive Philosopher: Naval Ravikant On Travelling Lightly.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/9/19/naval-ravikant-on-travelling-lightly; “Naval Ravikant on Wim Hof, His Advice to His Children, and How He Wants to Look Back on His Life.” __Killing Buddha,__ 2016. http://www.killingbuddha.co/blog/2016/12/28/naval-ravikant-on-advice-to-his-children.

Today, I’m an investor, personally, in about two hundred companies. Advisor to a bunch. I’m on a bunch of boards. I’m also a small partner in a cryptocurrency fund because I’m really into the potential of cryptocurrencies. I’m always cooking up something new. I always have a bunch of side projects. [4]

[4] Ravikant, [[Naval Ravikant]] and Shane Parrish. “Naval Ravikant: The Angel Philosopher.” Farnam Street, 2019. https://fs.blog/naval-ravikant/.

All that, of course, in addition to being the founder and chairman of AngelList. [4]

[4] Ravikant, [[Naval Ravikant]] and Shane Parrish. “Naval Ravikant: The Angel Philosopher.” Farnam Street, 2019. https://fs.blog/naval-ravikant/.

I was born poor and miserable. I’m now pretty well-off, and I’m very happy. I worked at those.

I’ve learned a few things, and some principles. I try to lay them out in a timeless manner, where you can figure it out for yourself. Because at the end of the day, I can’t quite teach anything. I can only inspire you and maybe give you a few hooks so you can remember. [77]

[77] PowerfulJRE. “Joe Rogan Experience Episode 1309—[[Naval Ravikant]].” June 4, 2019. YouTube video, 2:11:56. https://www.youtube.com/watch?v=3qHkcs3kG44.

