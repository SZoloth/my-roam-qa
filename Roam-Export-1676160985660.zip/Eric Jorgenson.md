**Metadata**

Company:: Zaarly

Role:: Product Strategist

Bio:: Eric is a Product Strategist at [Zaarly](https://zaarly.com/) and writer. His business blog, [Evergreen](https://medium.com/evergreen-business-weekly), has educated and entertained more than one million readers since 2014. He is on a quest to create—and eat—the perfect sandwich.

