[[Wasabi analytics: 10/2/20 - 10/15/20]]

For [[[[Wasabi]] analytics]]

SEO

Weakening on: "s3 compatible" & "cloud storage pricing"

Look into Bing

Review recommendations in gdocs made for @Michelle forever ago

Most common conversion paths include:

home, pricing, FAQs/Help

1st step of sign up flow (clicking to land on /sign-up) is at 4.97% -- can we improve that?

2nd step of sign up flow (completing form on /sign-up) is at 62% -- can we improve that?

Can we figure out why?

/connectivity-options and /backup-and-recovery have relatively strong conversion rates -- can we drive more traffic? or take content and turn into landing page?

What is /rcs conversion rate for sales? conversion rate for people that landed there?

Segment + [[Amplitude]] -- how are product analytics handled?

How is lead nurturing being tracked?

Likely: hubspot

Had an issue with time management on OKRs #[[darci nevitt]]

Feeling very far behind & haven't done anything

Hasn't made any progress, repeated some mistakes even though she was coached on the path forward

{{[[DONE]]}} For [[Museum of Science]] experiments and optimizations #/ [[🏔ADK [[Task Management]]]]

Focus on Google Ads, but can also include: landing page, email

{{[[DONE]]}} Updated dash for [[Museum of Science]] #/

[[Meetings]]: [[Boston School Finder]] update

Attendees:: [[rana kannan]] [[brooke griswold]] [[chris baker]]

Time:: 14:33

Notes::

 Re-org'd at Boston Schools Fund

Finder is now more under Fund

[[rana kannan]] COO at Boston Schools Fund

[[latoya gayle]] has moved on to an entrepreneur in residence role

[[Goals]] for this year: What is Finder? in the long run

Short-term [[Goals]]:

Keep it updated, accurate, and a good experience

Doing a big data update of the schools

Enrollment season in January

Two immediate [[Goals]]:

School data

MCAS was canceled so there are no school or state level data or tiers

Re organize a lot of the data for COVID

Some of it is irrelevant because people can't do a lot of it

Start to show:

MCAS trends

Percentile data

[[Meetings]]: [[[[1:1s]] with [[darci nevitt]]]]

Attendees:: [[darci nevitt]]

Time:: 15:31

Notes::

Feels like she's slipping and changing in a bad way

Not sure if she's a weenie or might not be cut out to work

MoS

Adding value in a presentation

Budget

Yottaa

Wasn't prepared before a meeting with the client

**Had a brief meeting internal but didn't understand**

Specific:

Putting a shopify app on LI

**Question: How to target shopify?**

Do know how to do some things

What I don't like:

I don't have enough time to do things but even given enough time I dont know what to do

Feels like she should have courses + knowledge beforehand

Learning

Not sure she can teach herself with more time

Would rather have buffer time in tune with the task

[[i[[mercer]]]]

Recommendations in an audit Gdrive folder that [[darci nevitt]] set up

