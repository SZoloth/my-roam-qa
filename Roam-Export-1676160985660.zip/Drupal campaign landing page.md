#[[ADK Drupal Campaigns]]

Outline Final

Nav bar

Why now?

How we work with you

Other resources

CTA: Schedule a conversation

Hero

Copy

In a few months, your website may stop receiving security updates. Are you prepared?

See how {{or: Harvard|MA companies|KY companies}} {{or: is|are}} preparing their website for Drupal 9.

Get a clear path to upgrading that fits your company. And a team that can execute it. 

Make your website more secure, faster, and easier to manage by upgrading to Drupal 8.

Securing and improving your website doesn't have to be painful. You just need to work with the {{or: nerds|experts|tech leaders}}, not an ad agency.

Get a clear path to upgrading that fits your company. And a team that can execute it. 

Does your CMS feel sluggish? Hard to use? If you're using Drupal 7, that's why. It also means you have a potential security risk.

100,000+ other companies are using the safer, faster, more flexible version of your CMS.

Get a clear path to upgrading that fits your company. And a team that can execute it. 

Plan to take advantage of Drupal 8 (and 9). Before Drupal 7 gets discontinued.

100,000+ other companies are using the safer, faster, more flexible version of your CMS.

Talk with a Drupal development expert, trusted by top {{or: MA|KY}} companies

Get a clear path to upgrading that fits your company. And a team that can execute it. 

Drupal 9 is launching soon. Drupal 7 (and 8) are approaching the end of life. What should you do?

100,000+ other companies are using the safer, faster, more flexible version of your CMS.

Talk with a Drupal development expert, trusted by top {{or: MA|KY}} companies

Get a clear path to upgrading that fits your company. And a team that can execute it. 

Upgrade your {{or: CMS|site}} to the latest version of Drupal, painlessly. 

100,000+ other companies are using the safer, faster, more flexible version of your CMS.

Secure and improve your website seamlessly. Work with the {{or: nerds|experts|tech leaders}}, not an ad agency.

Get a clear path to upgrading that fits your company. And a team that can execute it. 

Talk with a Drupal development expert, trusted by top {{or: MA|KY}} companies

The latest version of Drupal improves the security, speed, and flexibility of your site.

But upgrading is closer to building a new site. See why that's worth it. 

Images

If Harvard or client examples: logo, illustration

If "talk to an expert": headshot of Andrew/Aaron

Otherwise: Drupal logo + abstract illustration (maybe reference "8")

Logo cloud/bar/whatever (must be visible on landing - including on mobile)

FedEx, Harvard, GE Healthcare, HNRG, Titleist, Toyota, Vyaire, Mercer

Certified on Drupal.org

Stylized quote from Dries: "The best way to be ready for Drupal 9 is to keep up with Drupal 8 updates." - Drupal founder [Dries Buytaert](https://www.drupal.org/blog/plan-for-drupal-9)

Why upgrade now?

**Security:** Drupal 7 will be more vulnerable to {{or: hacks|breaches|attacks}} when it reaches its end-of-life, which is fast approaching.

**Savings:** The latest versions of Drupal make development faster, meaning you save on day-to-day operating and maintenance costs.

**Speed:** Drupal 8 and 9 have performance improvements that increase site speed - which means improved UX, SEO, and conversion rates.

**Accessibility:** Out of the box improvements to accessibility and enhanced [[multilingual]] capabilities let you give more people a better experience with your brand. 

**Site management:** The admin experience has been radically improved to make managing content quicker, easier, and more intuitive.

Stylized HNRG quote: “We've drastically cut down on the amount of staff needed to operate or to facilitate the license purchasing and renewal process. We've processed well more than $1 million through this platform.” — Solutions Architect, Hancock Natural Resource Group

Interstitial CTA: Not sure what your next step should be? Talk to a Drupal architect, not a sales person. 

Schedule a call.

An efficient process built on decades of experience with leading companies.

We get to know you and your audience as if we were part of your company. 

Strategy, design, development and {{or: SEO|marketing}} experts collaborate with you to create a plan fit to your needs and resources.

A multi-phased, agile approach ensures your upgrade is efficient, has minimal disruptions, and sets you up for growth.

You can take advantage of a long-term partner, who will offer support, training, maintenance, hosting, upgrades, and more post-launch.

“Their work on the Drupal project is outstanding...At this point, they likely know our products better than some of our employees...That effort distinguishes them from other vendors. I encourage other companies to engage them; they’re the perfect partner.” — SIKA, Director of Digital Marketing

Alternative: “I was so impressed with how well they got to know us and our clients. We felt throughout the entire process (and even now!) that they truly care about our success and want to remain a valued partner. The whole process never felt transactional -- it felt like a relationship. I would recommend ADK to anyone that was looking to make a meaningful investment in their web presence.” — Ashley Correll, Beyond Insurance Chief Operating Officer

Learn more about upgrading to Drupal 8

[A non-technical intro to Drupal and some of it's advanced capabilities](https://cms.adkgroup.com/sites/default/files/2019-07/Non-Technical%20Guide%20to%20the%20Drupal%20CMS_1_0.pdf)

[Learn more about the technical steps to prepare your site ](https://www.adkgroup.com/blog/upgrading-drupal-8-10-essential-site-prep-tips/)

[What's the upgrade process like?](https://www.adkgroup.com/blog/steps-upgrade-drupal-7-drupal-8/)

Getting to Drupal 8 (and 9) is involved, but worth it.

It's more than a simple upgrade, and digital agencies that are often times little more than a re-branded ad agency simply aren't equipped to do your site justice. 

You need the nerds that live & breathe Drupal. You need the proven experts  name-brand companies rely on.

And you can talk with one (live! for free!) about all of your Drupal upgrade problems and questions. 

(Aaron or Andrew headshot)

Outline Drafts

Nav bar

Hero

Header

In a few months, Drupal 7 will stop receiving security updates. Are you prepared?

In a few months, your website may stop receiving security updates. Are you prepared?

Upgrade your Drupal site to make it more secure, faster, and easier to manage

Make your website more secure, faster, and easier to manage by upgrading to Drupal 8.

Will your website be secure when Drupal 7 gets end of lifed?

Is your team ready for Drupal 7 to get discontinued?

Be ready for when Drupal 7 gets discontinued.

Plan to take advantage of Drupal 8 (and 9). Before Drupal 7 gets discontinued.

Your website is nearing its [[expiration]] date.

Does your CMS feel sluggish? Hard to use? If you're using Drupal 7, that's why. It also means you have a potential security risk. 

What's your least favorite part of your CMS?

What's your biggest complaint with your current website? 

Upgrade your {{or: CMS|site}} to the latest version of Drupal, painlessly. 

Drupal 9 is launching soon. Drupal 7 (and 8) are approaching the end of life. What should you do?

Subheader

100,000+ other companies are using the safer, faster, more flexible version of your CMS.

{{or: Harvard | MA companies | KY companies}} worked with ADK to design, build, and secure their complex Drupal website. See {{or: why|how}}

See how {{or: Harvard|MA companies|KY companies}} {{or: is|are}} preparing their website for Drupal 9.

Securing and improving your website doesn't have to be painful. You just need to work with the {{or: nerds|experts|tech leaders}}, not an ad agency.

Get a clear path to upgrading that fits your company. And a team that can execute it. 

The latest version of Drupal improves the security, speed, and flexibility of your site. But upgrading is closer to building a new site. See why that's worth it. 

Talk with a Drupal development expert, trusted by top {{or: MA|KY}} companies

Get a team of seasoned Drupal leaders, developers, designers, marketers, and project managers at your service. All under one roof.

Get a free 30m chat with one of our Drupal experts to help answer questions, plan for an upgrade, or solve your thorny technical problems.

Secure and improve your website seamlessly. Work with the {{or: nerds|experts|tech leaders}}, not an ad agency.

Image

Headshot of {{or: Andrew|Chris|Aaron}}

Illustration (Drupal logo)

Client hero

Social proof

Logo cloud

FedEx, Harvard, GE Healthcare, Titleist, Sika, Toyota, HNRG, Vyaire, Mercer

Testimonials

Results

“We've drastically cut down on the amount of staff needed to operate or to facilitate the license purchasing and renewal process. We've processed well more than $1 million through this platform.” — Solutions Architect, Hancock Natural Resource Group

“The web app received tons of positive [[feedback]] from hundreds of our sales staff around the world. The interface is a contemporary, user-friendly tool that we can now use to more effectively communicate highly technical information to customers.” — Mark Rush, Technical Director of Sales, General Electric

Process

“ADK Group has done exceptionally well in managing our account. I’ve been extremely satisfied with how diligent they are. Every deliverable that the team was responsible for arrived on time according to the original project timeline that they proposed.” — Solutions Architect, Hancock Natural Resource Group

“I was so impressed with how well they got to know us and our clients. We felt throughout the entire process (and even now!) that they truly care about our success and want to remain a valued partner. The whole process never felt transactional -- it felt like a relationship. I would recommend ADK to anyone that was looking to make a meaningful investment in their web presence.” — Ashley Correll, Beyond Insurance Chief Operating Officer

“Their work on the Drupal project is outstanding. The team collaborated with our marketing department to understand our complex set of products, markets, and business units. One principal conducted market research to enhance his team’s solution. At this point, they likely know our products better than some of our employees. We’re impressed by the time they invested to gain that knowledge. That effort distinguishes them from other vendors. I encourage other companies to engage them; they’re the perfect partner.” — SIKA, Director of Digital Marketing

Certified on Drupal.org

Why now?

Why upgrade now?

"The best way to be ready for Drupal 9 is to keep up with Drupal 8 updates." - Drupal founder [Dries Buytaert](https://www.drupal.org/blog/plan-for-drupal-9)

Reasons

Drupal 7 is nearing end of life and will stop receiving security updates. Meaning Drupal 7 websites will soon be vulnerable.

More efficient development means you can save money on day-to-day operating and maintenance.

Performance improvements that can improve UX, SEO, and conversion rates.

Better accessibility and [[multilingual]] capabilities help you give more people a better experience with your brand.

A much easier - and more enjoyable - CMS to manage. The CMS is now mobile responsive for admins, so you can make adjustments from your phone or tablet.

Results testimonial

CTA:

Not sure what your next step should be? Talk to a Drupal architect (not a sales person).

Set up a free chat

Our process

An efficient and battle-tested process built on decades of experience and trusted by leading companies.

We get to know you, your services, and your audience as if we were a new part of your company.

We have experts in all core competencies required for successful tech projects in house and available for you.

Our multi-phased approach ensures an efficient project with minimal disruptions and an eye towards your growth. 

Our experts make sure your content and SEO is fully preserved (or improved).

Our clients love that we provide long-term maintenance, hosting and upgrades long after launch.

We provide {{or: New England's|Kentucky's}} highest level of technical expertise, even when addressing security, accessibility, and SEO concerns. 

Process testimonials

Resources

[A non-technical intro to Drupal and some of it's advanced capabilities](https://cms.adkgroup.com/sites/default/files/2019-07/Non-Technical%20Guide%20to%20the%20Drupal%20CMS_1_0.pdf)

[Learn more about the technical steps to prepare your site ](https://www.adkgroup.com/blog/upgrading-drupal-8-10-essential-site-prep-tips/)

[What's the upgrade process like?](https://www.adkgroup.com/blog/steps-upgrade-drupal-7-drupal-8/)

Footer CTA

The bottom line: Getting to Drupal 8 is involved, but worth it.

It's more than a simple upgrade, and digital agencies that are often times little more than a re-branded ad agency simply aren't equipped to do your site justice. 

You need the nerds that live & breathe Drupal. You need the proven experts  name-brand companies rely on.

 And you can talk with one (live! for free!) about your biggest Drupal problems and questions. 

(Aaron or Andrew headshot)

Notes and drafts #[[Drupal 7 to 8 upgrade blog]]

Drupal 7 end of life is X years/months away. But prep needs to start now. Why?

Drupal 7 to 8 is much more than upgrade - it's an overhaul. 

There's a major shift / advancement in technology going from 7 to 8.

This is also an important opportunity - to rethink your website. The core, the engine is being replaced. Major structural changes that you may have been considering can be incorporated

The upgrade is an investment and should be undertaken if you plan on growing and improving your website.

The difference between a rushed upgrade made in reaction to a looming deadline, and using this as an opportunity is planning and preparation

If you're adding new features - are you investing in a dying platform?

If you're considering new features it may make more sense to rebuild on Drupal 8.

