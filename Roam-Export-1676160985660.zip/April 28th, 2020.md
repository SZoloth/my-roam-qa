[[🏔ADK [[Task Management]]]]

[[ADK Drupal Campaigns]]

{{[[DONE]]}} [[Drupal campaign landing page]] #[[ADK Drupal Campaigns]]

Current

Source from: [JDA](https://adkgroup.atlassian.net/wiki/spaces/JDA/pages/1417904344/Drupal+7+to+8+Everything+You+Need+to+Know) + [Molly Duggan](https://upgrade.mollyduggan.com/how-does-it-work-upgrade-to-drupal-8)

Why D7 -> D8

D7 will stop receiving security updates

Other companies (nearly 100k) are already using the safer, faster, more flexible Drupal 8. 

Make the switch before D7 becomes obsolete.

Proactively prepare for D9

Better content management (mobile)

Development is more efficient, so you save money on day-to-day operating and maintenance

Performance improvements. Faster means better UX and SEO

Improved accessibility and [[multilingual]] capabilities - give more people a better experience.

interstitial quote

"The best way to be ready for Drupal 9 is to keep up with Drupal 8 updates." - Drupal founder [Dries Buytaert](https://www.drupal.org/blog/plan-for-drupal-9)

Why ADK

D7 -> D8 is complex. You need nerds, not a marketing agency. 

D7 to D8 is more than an upgrade

Upgrading to Drupal 8 is closer to building a new website than previous upgrades

We've done X for companies like Y and Z.

{{MA}} enterprise leaders trust ADK Group to design, build, and secure complex Drupal-based websites

Fast, reliable, minimal disruptions, complete (preserve or improve SEO), project management and strategic support, dedicated support afterwards, security, accessibility

What the process will be like // How we ensure success // The process we used on 

Audit + Discovery

Plan + Design

Implementation

Launch

Continuing support

Resources // Offers

Want to talk with a Drupal architect or project strategist?

What's your biggest complaint with your current Drupal website?

{{[[DONE]]}} Campaign

Ad copy

**Prospecting**

What pain points does D8 solve?

Clunky UX to WP

Easier content management

Mobile-responsive admin interface

Manage your website from your phone or tablet

Drupal 7 will stop receiving security updates

More efficient development so lower day-to-day operating costs

Improved templating

Increased application security

Using twig template engine

Newer APIs

Performance improvements --> UX + SEO, [[multilingual]] capabilities

Improved caching increases speed

Future proof: easier to upgrade to D9 in 2021

Improved accessibility 

D7 to D8 is more than an upgrade

D8 is so much more advanced that it needs to be rebuilt from the ground up

"The best way to be ready for Drupal 9 is to keep up with Drupal 8 updates." - Drupal founder [Dries Buytaert](https://www.drupal.org/blog/plan-for-drupal-9)

Is your Drupal website secure? 

Are you prepared for Drupal 7's end of life?

In a few months, Drupal 7 will stop receiving security updates. 

Other companies (nearly 100k) are already using the safer, faster, more flexible Drupal 8. 

Make the switch before D7 becomes obsolete.

**Retargeting**

D7 -> D8 is complex. You need nerds, not a marketing agency. 

We've done X for companies like Y and Z.

{{MA}} enterprise leaders trust ADK Group to design, build, and secure complex Drupal-based websites

Upgrading to Drupal 8 is closer to building a new website than previous upgrades

Fast, reliable, minimal disruptions, complete (preserve or improve SEO), project management and strategic support, dedicated support afterwards, security, accessibility

Ad Creative:

Drupal 7 is nearing it's [[expiration]] date

[[COVID-19 testing app]]

Web app tracking

Events

What [[language]] the user is using

CTA clicks

Start COVID Smell Test (hero)

After finishing the test

Watch video

Call about questions

Click for more info about COVID smell test ID#

Submit participant information

Help

Pagination

General design notes

CTAs move locations?

No way to contact during test

Assuming answers are stored in db

[[ADK Marketing Process]]

Landing page design

Landing page writing

[[ADK Marketing Needs]] #[[ADK enterprise campaign]]

Target number of leads?

Target audience: one level below the decision maker --> the internal influencer

VP or below

Likely not experienced with software

Want safety, but need to save money

Motivations: solve problems, have answers without risking reputation

Want to be driving change

Want to be able to back up answers to questions about our legitimacy

What is goal of the campaign?

Content needed: end to end guide to custom enterprise software success

Is this co-created with a Gartner?

{{[[DONE]]}} Create value props based on persona

[[wish list]]

Loftie alarm clock

Rowing Blazers croquet stripe rugby

J.Press Shaggy dog sweater

Clark's Wallabees

Birkenstocks

[[Article: How Rand Fishkin Launched SparkToro]] #Articles #[[Rand Fishkin]] #[[Moz]] #SparkToro #Drafts

Email series

Content

2 Minute demo

Tying to a charity

Freemium product

1 week plan

similar to [[ahrefs]]

