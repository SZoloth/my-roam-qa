[[🏔ADK [[Task Management]]]]

[[Navigation and IA]] #[[ADK Website Rebuild]]

[[ADK SEO Process]] #[[ADK Marketing Process]]

[[Google Analytics App + Web]]

{{[[DONE]]}} Sam schedule kick off meeting ADK drupal retargeting

{{[[DONE]]}} Sam schedule time for darci to review google app + web

{{[[DONE]]}} Sam schedule time for nick to review drupal lp tomorrow

**Sam ideate and collect ADK marketing strategies/tactics**

#[[a/b test]] for #Wasabi 

Should we test the whole homepage or different components?

https://docs.google.com/document/d/1Um09I771xnSu4VZ7fNcRWwkN0s9D7bhZeBc_GSnrzeo/edit#

[[Topics to help white friends]] #race

**single parent homes**

**death by police white or black**

https://twitter.com/JoeBerkowitz/status/1265755642196897793?s=20

**police inciting violence**

https://twitter.com/thisdiegolopez/status/1267643161968607234

https://twitter.com/springer/status/1267685430985662466?s=20

https://twitter.com/sweeeetdee_/status/1267319103167107072?s=20

https://twitter.com/DylanGelula/status/1267940264913469442?s=20

**trump racist**

**riots**

https://www.instagram.com/p/CA2r7EGpn3Q/?igshid=i8jvc46dix8r

https://twitter.com/aStatesman/status/1267135399874478080?s=20

https://twitter.com/kenklippenstein/status/1267245027916492802?s=20

https://twitter.com/kenklippenstein/status/1267249907863257093?s=20

https://twitter.com/tomakeupwityou/status/1266920326182641670?s=20

**understanding**

https://www.instagram.com/p/CA2-FvPhv7W/?igshid=18oa8refedgkv

https://twitter.com/jvizzle757/status/1266771496480968704?s=20

#education

daily podcast

votesaveamerica

police brutality spectrum tweet

you can support the protests without the looters in the same way you can support the police without the racists


