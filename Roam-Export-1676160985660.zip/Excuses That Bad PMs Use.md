Author:: [[twitter.com]]

URL:: https://twitter.com/realcharleslee/status/1276179235783102464

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

8. “I have too much on my plate” A great PM [[prioritize]]s high leverage tasks and manages their time. 

