Author:: [[worldpositive.com]]

URL:: https://worldpositive.com/a-modern-guide-to-lean-okrs-part-iii-8f6a43c7b8d3

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 22nd, 2020]]

A key rule with all OKRs, but particularly personal ones, is to remember that this is about setting out your most important [[Goals]] and results, not just “all important actions.” For many, this feels like a chance to enumerate the vast number of projects you’re involved with or actions you take in any given period. That’s not what this is about. That might fall into a weekly managerial reporting process, but it’s not what OKRs are all about. These objectives and key results should show the true measure of your success over a given period. 

