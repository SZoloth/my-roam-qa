**Meta:**

#[[Essays & Articles & Books]] to turn into notes to reference for blog posts. Also includes #[[webinar]]

**Sources to be transferred to notes**

[[Demand Curve]] notes that live in Dropbox Pages and in gitbook

[[[[Segment]] [[growth]] Talks]]

[[Startup Lessons From Spotify Wrapped]]

[[High Output [[management]]]]

[[🌱 The Making of a [[Manager]]]]

[[Scale Organic Traffic]]

[[Growth Case Study: Segment]]

