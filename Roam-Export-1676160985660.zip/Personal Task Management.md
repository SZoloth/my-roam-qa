**Recently assigned (not triaged)**

{{[[query]]: {and: [[TODO]][[Personal Task Management]] {not: {or: [[/]] [[//]] [[///]] [[Template]] [[Blocked]] [[Delegated]] [[query]]]}}}}}

**Today** #/

{{[[query]]: {and: [[TODO]][[Personal Task Management]] [[/]] {not: {or: [[Template]] [[query]]]}}}}}

**Upcoming** #//

{{[[query]]: {and: [[TODO]] [[Personal Task Management]][[//]] {not: {or: [[Template]] [[query]]]}}}}}

**Later** #///

{{[[query]]: {and: [[TODO]] [[Personal Task Management]][[///]] {not: {or: [[Template]] [[query]]]}}}}}

**Delegated** #Delegated[[@]]

{{[[query]]: {and: [[TODO]] [[Personal Task Management]][[Delegated]] {not: {or: [[Template]] [[query]]]}}}}}

**Blocked** #Blocked

{{[[query]]: {and: [[TODO]][[Personal Task Management]] [[Blocked]] {not: {or: [[Template]] [[query]]]}}}}}

