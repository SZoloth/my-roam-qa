Tags::

#[[Sleeping Dog Properties]], #[[[[Sleeping Dog Properties]] blog]]

Target [[outcome]]s

New business in non-Boston MA areas

Tactics to get there

Ads

Google Ads

Home Offices

Facebook

https://www.bostonmagazine.com/sponsor-content/10-expensive-custom-home-projects-boston-sleeping-dog/

https://www.bostonmagazine.com/sponsor-content/8-gorgeous-home-projects-inspire-space-sleeping-dog-properties/

Pinterest

SEO

URL audit (https://[[ahrefs]].com/blog/seo-friendly-urls/)

Blog revamp

Email collection for SDP

Sign up form

Contact drip

Content

Location specific service landing pages

At a minimum this is needed for both SEO and PPC

More services pages

Architect pages

Glossary of terms

Keywords

Inspiration Hub

Guides for SDP

Conversion rate

How did you hear about us? in the form

More reviews, quotes, testimonials, awards

Clear CTA - 

Lead Gen - Block Renovation case studies

https://assets.ctfassets.net/q9rxrblsu2zi/dva0AJkvlAlI3Q1DQk5mz/e784a360c8f5223f0a8f4e1a5cbf0565/200316_CaseStudies.pdf

Lead Gen - Quizzes

What design style is right for you?

Other

What are services like Fini Concierge that really only rich people use?

Process

Location specific service landing pages

What are the location-service pairs? Needs definition

Content / design needs:

Intro paragraph

Contact info

Trust factors

No obligation

Certifications

Awards

Testimonials

What makes SDP different?

White glove

Attention to detail

25 years of experience

Leadership

Interactive portfolio of relevant projects

FAQs

Before you hire OR FAQs

Questions to ask __winchester__ __kitchen re[[model]]ers__

Clear CTA and with a valuable offer

Add "how did you hear about us?" to the form (or contact flow)

Google ads for home office

Google / Facebook ads for location-specific service landing pages

Blog / SEO work set up work

URL audit

Blog design organization revamp

Email collection for SDP

Content creation

