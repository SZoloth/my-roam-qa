Distribution of content (microcontent) by UXBlake

![](file:///var/folders/8f/5v65q6pd2rs1l_h3vcb8pnj40000gp/T/TemporaryItems/(A%20Document%20Being%20Saved%20By%20screencaptureui%2033)/Screen%20Shot%202020-09-14%20at%209.24.30%20AM.png)

What we need instead is a spatial meta layer for notes on the OS-level that lives across all apps and workflows. This would allow you to instantly take notes without having to switch context. Even better yet, the notes would automatically resurface whenever you revisit the digital location you left them at. From [Julian's post on a meta layer for notes] (https://julian.digital/2020/09/04/a-meta-layer-for-notes/) #Articles #Notes #[[Product Ideas]]

[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Review the Facebook and Google Ads campaigns for [[Museum of Science]] #/

[[Meetings]]:  check in with [[darci nevitt]]

Attendees:: [[darci nevitt]]

Time:: 09:59

Notes::

Set up retargeting in FAcebook

Set up HubSpot campaign

Define the UTM parameters pattern

**Facebook**

CBO for ^^conversions^^ - $45 / day

Are ^^conversions^^ set up to be tracked by FB?

Set up retargeting

How should we structure the campaign?

One adset with super audience and 3-5 ads

Roughly, how to set up #CBO campaign in [[facebook]]

In which case, run a/b tests through their tool OR just ^^trust [[CBO]]^^:

Conversion, #CBO, Cost Cap around CPA of ---???

Minimum budget = cost cap (CPA) * 7.14 * # of ad sets

Goal: <30% of money spent in the learning phase

Campaigns should have a theme (angles/value props, offers, SKUs)

Ad set level for #CBO

Broad audience = unconstrained (functionally LAL)

exclude: existing customers, web traffic 30 days

Interests

Same exclusions

Web traffic remarketing

Cost cap should be lower than prospecting

Adsets in #CBO should have 3-5 ads

Each ad should have optimized placement creative

**Google Ads**

turn off search network + display on the search campaign

budget is super super low

broad match keywords switched to phrase match

STEM for teachers keywords only have one keyword.......

Gmail campaign?

**Emails**



**Landing Page**

Set up HubSpot campaign

{{{[[DONE]]}}}} Teach ADK React team SEO best practices  #[[React SEO]]

[[Meetings]]: [[React SEO]] meeting

Attendees:: [[harold sipe]] [[kenneth daily]]

Time::

Notes::

Some notes

[[APCIA]] 

Talk to PM about issue

Create crawlability test for pre-launch

This is what you test & verify and this is how

For website, for React

Questions for background

What's the client?

What's the framework / rendering?

What is the best guess at issue?

What has been tested?

Tools for testing

URL inspection in GSC

[Mobile-Friendly Test](https://search.google.com/test/mobile-friendly)

First step: mobile-friendliness test

Main purpose: shows potential issues with your site on mobile devices

For testing local env, use a tool like ngrok.io to get a publicly available URL

Once the test is completed, you'll see:

a screenshot of your page as Googlebot's smartphone crawler would see it

the page's rendered source code

 if some of the content is missing or the page doesn't render the way you'd expect you can check recommendations

or you can dive in deeper by looking at the detailed report that shows which resources have been loaded and all JS blocks

[Rich Results Test](https://search.google.com/test/rich-results)

Lighthouse can help too

Some background about these tools:

Why "approximately"?"

These tools have a 5-second timeout that the renderer doesn't

These tools pull resources in real-time, rather than cached like the renderer does

Screenshots in the tools show pixels painted, which Google doesn't see in the renderer

When are the tools useful?

To see if content is DOM-loaded: the HTML shown is the rendered DOM

Will show you resources that may be blocked and console [[error message]], which are useful for debugging

The tools

URL inspection in GSC

[Mobile-Friendly Test](https://search.google.com/test/mobile-friendly)

[Rich Results Test](https://search.google.com/test/rich-results)

Checklist (WIP) for debugging & best practices

Is Googlebot allowed to crawl JS?

Do we have a proper sitemap?

Is link markup proper?

Google can pull resources links (CSS, JS, etc.) from `<link>`, but links to other pages need to be '<a>'

**Link markup that works:**

`<a href=”/page”>simple is good</a>`

`<a href=”/page” onclick=”goTo(‘page’)”>still okay</a>`

**Link markup that does not work:**

`<a onclick=”goTo(‘page’)”>nope, no href</a>`

`<a href=”javascript:goTo(‘page’)”>nope, missing link</a>`

`<a href=”javascript:void(0)”>nope, missing link</a>`

`<span onclick=”goTo(‘page’)”>not the right HTML element</span>`

`<option value="page">nope, wrong HTML element</option>`

`<a href=”#”>no link</a>`

Button, ng-click, there are many more ways this can be done incorrectly.

Are title tags, descriptions, and alt tags following best practices?

Is expected code and content being shown in HTML response?

Recommended test: [Mobile-Friendly Test](https://search.google.com/test/mobile-friendly), GSC URL Inspector

Are we using [file versioning or fingerprinting to generate new file names when significant changes](((rBcy2EZ6L)))?

Are we showing different content to users based on their location?

Are we serving different content to different user-agents? (but not for [[dynamic rendering]]) 

Is the JS updating only parts of the DOM?

Are we lazy loading content (instead of just images)?

Are we Using fragment URLs with hashes (#) instead of the History API?

Related: are we changing URLs when content is updated via History API?

Are we relying on data persistence to serve content?

Renderer does not retain state across page loads so don't rely on data persistence to serve content.

Ensure that your application uses [feature detection](https://developer.mozilla.org/en-US/docs/Learn/Tools_and_testing/Cross_browser_testing/Feature_detection) for all critical APIs that it needs and provide a fallback behavior or polyfill where applicable.

Make sure your content works with HTTP connections (not WebSock or WebRTC)

Potential (general) solutions

An alternative: Dynamic rendering

There’s also the option of [Dynamic Rendering](https://developers.google.com/search/docs/guides/dynamic-rendering), which is rendering for certain user-agents. This is basically a workaround but can be useful to render for certain bots like search engines or even social media bots. Social media bots don’t run JavaScript, so things like [OG tags](https://[[ahrefs]].com/blog/open-graph-meta-tags/) won’t be seen unless you render the content before serving it to them.

Important resource: [Google Dev Guide to JS SEO](https://developers.google.com/search/docs/guides/javascript-seo-basics)

{{{[[DONE]]}}}} How do we test for [[React SEO]] websites? #/

{{{[[DONE]]}}}} What are best practices for building [[React SEO]] websites? #/

{{{[[DONE]]}}}} Prep for [[1:1s]] with #[[Meetings with [[chris baker]]]] #[[[[LMT]] Status Update email]]

Pre-meeting prep notes:

What's the best use of our time today?

Setting OKRs to better understand: expectations, [[Goals]], and be able to track against something

What's top of mind for me?

ADK marketing and [[refine labs]]

Ideal [[outcome]]: RL will work as it should and supplement/be supplemented by promotion.

What's hard about getting there: Locking down the time to put together a strat; it could be the case that RL works fine in a vacuum, in which case would need to reassess.

What's the best course of action for it: Define deliverables, put time in calendar.

EiE

Ideal [[outcome]]: The campaign launches without a hitch and starts generating leads effectively.

What's hard about getting there: Lack of experience, lack of process.

What's the best course of action for it: Double check everything, take note of mis-steps/challenges.

General lowered confidence in own and team's abilities

Ideal [[outcome]]: Recalibrate expectations and use this as motivation to: improve frameworks, focus, and performance.

What's hard about getting there: Locking down the time.

What's the best course of action for it: The marketing summit, hopefully. 

Setting up frameworks and best practices

Ideal [[outcome]]: We have a series of docs in Confluence that define best practices for our areas of expertise in marketing, starting with those that other teams rely on (eg - React SEO)

What's hard about getting there: Locking down the time

What's the best course of action for it: Put time in calendar.

Note: OKRs would help on all of the above (esp. locking down time) because they would be clear definition of priorities, which helps focus.

How can Chris help me?

Help align on priorities

Help align on expectations from those priorities

Help define [[career]] growth plan

Evergreen questions for Chris

What opportunities do you see for me to do more of what I do well? What do you think are the biggest things holding me back from having greater impact?

What skills do you think a hypothetical perfect person in my role would have? For each skill, how would you rate me against that ideal on a scale of 1-5?

How am I tracking towards expectations? What are the biggest changes I could make to improve?

How did you approach setting standards, frameworks, best practices for the PM org?

[[Meetings]]: #[[Meetings with [[chris baker]]]] #self-development

Attendees:: [[chris baker]]

Time:: 16:58

Notes::

 What's my next phase of growth and impact?

Where is ADK going as a business?

Question to ask:

What am I great at? Where can I carve out a niche? In order to deepen rather than widen

What would an OKR for: data + analytics?

Analytics implementations: more robust and more efficient

Give customers more for less

{{[[DONE]]}} **What would an** [[OKR]] **look like for: post-launch product growth?** #/

What is the packaged set of kick ass deliverables

What are the services?

What is the process?

How long / much money does it take?

What are the deliverables?

Two tiers of accelerated learning/growth

Metrics for each stage of AAARRR, how we meet them, how we measure them

What would an OKR for: A/B testing and CRO?

Areas of SME

SEO

Concern with SEO: 

less on product, more on marketing

smaller impact

A/B testing and CRO

Lack of big wins isn't an indictment of my efforts directly, necessarily

**Marketing team is good, competent but doesn't have an approach, theory, philosophy or process** #team-development

**How to architect React web apps for SEO**

**ADK marketing**

Refine Labs

Website

Copywriter

{{{[[DONE]]}}}} Positive vs negatives for #ADK site being on #Webflow

Pros

Super easy for marketing to manage

Cheaper to build and update from a resource stand point

Practice on the platform

Ease of template creation/management across client landing pages as well

Cons

Might turn off some techy site visitors

Would need to have some sort of explainer post and/or "wink" (note in the code)

Cost?

I dont think we've tested it for security/vulnerability

Unclear how easy/hard it might be to switch out of in the future.

you do not have access to FTP, cPanel, or an htaccess file

collaboration gets expensive

