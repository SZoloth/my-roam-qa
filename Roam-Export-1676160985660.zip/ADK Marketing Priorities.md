[[June 19th, 2020]]

{{[[DONE]]}} Report on Drupal campaign to leadership (Revisit [[June 22nd, 2020]])

{{[[DONE]]}} Launch the [[form health]] Illinois campaign

{{{[[DONE]]}}}} Post CSB case study #Blocked

{{[[DONE]]}} Post the STTR blog [[nick watkins]]

{{[[DONE]]}} Check in with [[chris baker]] on status of ALKU blog

{{[[DONE]]}} Share Escher and DCF with [[Tim Lupo]]

{{{[[DONE]]}}}} Update adkgroup.com footer

{{[[DONE]]}} Give [[cody learned]] the task of replacing "client" with "partner" or the client's name in [all non-b[[Log in]]stances on adkgroup.com](https://www.google.com/search?sxsrf=ALeKk00kk23Sc8__Lw0qdrhFGnEfxHi00g%3A1592517316816&ei=xOLrXqOmMYqkytMP36e8sAk&q=site%3Ahttps%3A%2F%2Fwww.adkgroup.com+%22client%22&oq=site%3Ahttps%3A%2F%2Fwww.adkgroup.com+%22client%22&gs_lcp=CgZwc3ktYWIQAzoGCAAQBxAeUNgSWN91YIN6aABwAHgAgAFfiAHPBZIBAjEwmAEAoAEBoAECqgEHZ3dzLXdpeg&sclient=psy-ab&ved=0ahUKEwijmN6nrYzqAhUKknIEHd8TD5YQ4dUDCAw&uact=5)

{{[[DONE]]}} Gather next steps for [[ADK Marketing Priorities]]

{{[[TODO]]}} Follow up with [[chris baker]] about above in context of [[ADK Marketing Project Management]]

{{[[DONE]]}} Provide [[feedback]] in invision comments on [[ADK Website Rebuild]] designs

[[June 22nd, 2020]]

{{[[DONE]]}} Gather next steps for [[ADK Marketing Priorities]]

{{[[TODO]]}} Follow up with [[chris baker]] about above in context of [[ADK Marketing Project Management]]

{{[[DONE]]}} Provide [[feedback]] in invision comments on [[ADK Website Rebuild]] designs

{{[[DONE]]}} Jot down notes for Post-launch process for PMs: why getting clients onto Clutch is so important

{{{[[DONE]]}}}} Produce meta-report on Google Ads campaigns for [[ADK Marketing Needs]] #//

{{{[[DONE]]}}}} What to do with new [[ADK Marketing Assets]] from [[Dan Tatar]] #//

{{[[DONE]]}} Strategize and brainstorm for [[ADK Website Rebuild]] around:

{{[[DONE]]}} Plan more structured management for [[darci nevitt]]

{{[[TODO]]}} Plan for $300 [[Google Ads]] credit for [[ADK Marketing Priorities]]

