**Metadata**

**Tags:** #organic, #[[Growth marketing[[*]]]], #[[✍️ blog-post]], #[[✍️ blog-post]],[[marketing]], #SEO, [[social media]], #retargeting, [[email marketing]]

**Status:** #published, #[[to update]]



Yesterday, Google announced widespread support for #AMP across Gmail, Yahoo, Outlook, and Mail.Ru.

AMP for email was announced as a closed beta about [a year ago](https://www.blog.google/products/g-suite/bringing-power-amp-gmail/), but the public release announced on [the AMP blog](https://blog.amp.dev/2019/03/26/building-the-future-of-email-with-amp/) officially adds email to a growing list of AMP-enabled media available for marketers: websites, “stories” (think SnapChat or Instagram stories, but in mobile Google search results), and advertisements.

__AMP is an open source code library that was ostensibly created with the goal of encouraging web developers to produce experiences that load faster on mobile devices. In the case of web pages, these are cached on Google's own servers, rather than your own. __

The AMP code framework is about as controversial as things get in the digital marketing world, where the more critical side sees it as an [unnecessary](https://techcrunch.com/2018/02/13/amp-for-email-is-a-terrible-idea/) and [potentially disastrous forfeiture of control](https://medium.com/@danbuben/why-amp-is-bad-for-your-site-and-for-the-web-e4d060a4ff31), while its champions cheer it [because it’s faster](https://www.wired.com/2016/02/googles-amp-speeding-web-changing-works/) for users and, well, [that’s](https://www.semrush.com/blog/to-amp-or-not-to-amp-what-is-best-for-your-website/) [mostly](https://moz.com/blog/amp-digital-marketing-2018) [it](https://www.ampproject.org/about/benefits/).

Most of the developers at our digital agency are open source zealots. This meant that my early requests to bring AMP-enabled pages to our most content-savvy partners (__editor’s note: we love you, content-savvy partners!__) were met with cringes. However, part of what makes us tick as a company is working to push our partners to the bleeding edge of technology in order to reap strategic rewards (we believe in [the first-mover advantage](https://en.wikipedia.org/wiki/First-mover_advantage)).

That doesn’t mean we blindly adopt the latest trend just because it’s the next big thing. Rather, because we deal with a such a wide variety of businesses and challenges we approach emerging technologies with an understanding of its greater context. To get to that end, we explore questions like, Where did it come? Why does it exist? Who benefits from it?

## GOOGLE’S [[strategic moat]]

In terms of its core (search) business, Google is consistently working to [do 2 things](https://stratechery.com/2015/aggregation-theory/):

Atomize content that was previously aggregated by large publishers to make it easier to match with Google’s users' search intents, and

Use data about how people interact with that atomized content to enable advertisers to target audiences on an increasingly micro scale.

Within this [[model]], the first initiative represents Google’s supply-side. Google gets free access to the content it aggregates (it does not pay any companies that create the content for the right to index it) and mostly does not create any of its own content. By improving the overall #UX of content consumption, Google becomes the de-facto “supplier” for most of the internet’s content, even though Google owns almost none of that supply and does not actually produce the supply. That allows it to supersede traditional publishers and create a more “meritocratic” (in quotes because Google quantifies the merit) platform where anyone can create content that can be viewed billions of times over.

This also allowed Google to aggregate the demand for content: it created a virtuous cycle where more searches created more competition for higher quality content that could be indexed by Google, which led to more people using the search engine, which in turn led to more use of the search engine (there’s another loop in there around their search algorithm, but we’ll save that tangent for another article). Google became the de facto place people come to when looking for most forms of content, which gives it a huge competitive advantage when selling advertising based on the data that it owns. This can be considered one of Google’s strategic moats, explaining why this is such an existential consideration.

At the scale that Google operates on, its competitors are not so much other search engines (although DuckDuckGo is __beginning__ to look like a__ minor__ threat), but rather other content aggregation platforms – Facebook and Amazon being among the most threatening.

What’s the advantage that those other content aggregation platforms have that Google does not?

They all are exclusive owners of __both__ the supply-side and the demand-side. Content created on Facebook is owned by Facebook, leaving it open for Facebook to manipulate however it wants (consider the state of [Facebook organic performance by 2018](https://bonseyjaden.com/truth-facebook-organic-reach-2018/), when Facebook favored ads much more heavily than organic content so it can [remain free](https://youtu.be/n2H8wx1aBiQ?t=30)).

![](https://bonseyjaden.com/wp-content/uploads/2018/04/facebook-organic-reach-2018.jpg)](https://bonseyjaden.com/truth-facebook-organic-reach-2018/)

We see similar patterns across paid CTR on Google searches (which are almost always a zero-sum game):



[![](https://images.sparktoro.com/blog/wp-content/uploads/2018/10/js-paid-ctr-2016-2018-1024x506.gif)](https://sparktoro.com/blog/google-ctr-in-2018-paid-organic-no-click-searches/)

This trend is not accidental. Google is actively working to increase its advertising power (and maintain [dominance in the face of new competitors](https://www.bloomberg.com/news/articles/2018-09-19/amazon-increases-ad-market-share-at-expense-of-google-facebook)), the success of which can be approximated by paid CTRs. All signals (recent product launches, changes to the search algorithm, etc.) point to Google trying to achieve this by creating a [walled garden](https://searchsecurity.techtarget.com/definition/walled-garden) for the search product.

### Google’s Walled Garden for Search

Florent Crivello begins an [article about the importance of demand](https://florentcrivello.com/index.php/2018/10/22/own-the-demand/) by laying out the different parts of a typical internet search:

Your search engine of choice

Your browser

Your operating system

Your computer or mobile device

Your Internet service provider

“(a bunch of WAN stuff)”

The search engines internet service provider

The search engines own tech stack

Content being served

All of these represent opportunities for a company to both control the experience of the search and collect exclusive data about it that can be sold to advertisers. So how much of the search experience could Google own?

Right now, it has the ability to own the whole experience, __except for the content it’s serving:__

Entities

Google Product

Search engine

Google

Browser

Chrome

Operating system

Android, Chrome OS

Computer or mobile device

Chromebooks, Android

ISP

Google Fiber, Google Fi

Content



### How AMP serves Google & Gmail

That last hole is what AMP will help Google fill. No single content creator could possibly create enough high quality content to be reasonably dominant across a well-made search engine. However, if you get the majority of content creators to __build for your platform__ (as YouTube, Reddit, Facebook, TikTok, Instagram, and most other ad-driven platforms for user-generated content), then you can fill the content gap at scale.

Because AMP pages (and presumably stories, ads, and emails) are hosted on Google’s servers, AMP encourages content creators to hand-over control of their content to Google. For email, replace the choice of search engine with choice of email service provider (ESP) and you get the same story. In the case of AMP, this would include all ESP’s that support the technology: Gmail, Outlook, Yahoo, Mail.Ru. In fact, Google has been trying to monetize Gmail for a long time – the most notable shift was the introduction of native Gmail ads within Google AdWords (now called Google Ads) back [in 2015](https://adwords.googleblog.com/2015/09/native-gmail-ads-arrive-in-adwords.html).

With the platforms owning demand (Gmail and Google Search), AMP begins to give Google control over the supply .

![](http://4.bp.blogspot.com/-FyaSaPt35X8/WoMx9nEYkAI/AAAAAAAABtY/qQ919d_SmG89hp-yN4GAUwjmzgM8_kkZwCK4BGAYYCw/s1600/GmailAMP-Pinterest-Blog-01%2B%25281%2529.gif)



Because AMP for Google allows for pretty robust in-email conversions. marketers will view this as an opportunity to increase the ROI of email marketing (and it may do that!), while helping Google expand its walled garden.

### How important is owning an entire experience for Google?

In addition to the investments it has made in products and services to capture the search experience, it also makes easily quantifiable purchases that fill other gaps in the search experience. For example, the popularity of iOS devices represents a huge threat to the ownership of the experience. Android phones are certainly popular, but Google is looking for market dominance that mirrors its position in the search engine market. That’s why payments being made to Apple to be the default search engine on Safari on iPhone, iPad, and Mac devices are predicted to rise 33% to $12 billion in 2019, per [Rod Hall, an analyst at Goldman Sachs](https://www.mobilemarketer.com/news/goldman-apple-will-charge-google-12b-to-be-default-search-engine-in-2019/538469).

## WHAT DOES AMP DO FOR MARKETERS?

While AMP as a framework is a pretty thinly-veiled tool to help-marketers-help-them, the benefits should not be discounted. Furthermore, when a company with the influence Google has set its sights on a trend, the company is (a) **generally** not wrong, and (b) a catalytic force that increases the adoption of those trends. That does not mean that AMP is inevitable and that you should make the (often costly) move to supporting it.

### Should you implement AMP pages?

Instead of making a knee-jerk decision, weigh the strengths and weakness thoughtfully in the context of your business and your marketing [[Goals]].

### Strengths of AMP

If executed properly, it increases mobile page performance. This, as many marketing publications will tell you, can help lower bounce rates, increase conversion rates, and improve sales.

It creates engaging experiences. Google is pushing hard to keep the user within its ecosystem, and is incentivizing that with more interactive emails and search results.

It is a potential differentiating factor for your marketing. Some of your competitors will adopt it, other’s wont.

### Weaknesses of AMP

Less visibility for your on-site advertisements.

Less control over the style and design of your website.

Less traffic to your domain.

More complicated and limited analytics.

Are you an ecommerce website with hundreds of thousands of visits and transactions per day? Minute changes in page speed can have outsized impacts on your revenue. Is your business built around an SEO-based growth loop (like Pinterest, Zillow, or other aggregators)? AMP may be able to help. Does your company partake in more casual blogging? You probably won’t need to implement AMP. Some companies should move almost their entire website onto AMP templates, while others would only benefit from creating a single AMP-enabled template.

### Should you implement AMP emails?

AMP for email unlocks a range of interesting capabilities that can set your emails apart from competitors (it's unclear how spam filters will react to this), as outlined in [Google's product blog](https://cloud.google.com/blog/products/application-development/amp-for-email-developer-preview). These include familiar AMP capabilities like [amp-carousel](https://ampbyexample.com/components/amp-carousel/), [amp-form](https://ampbyexample.com/components/amp-form/), [amp-bind](https://ampbyexample.com/components/amp-bind/), [amp-list](https://ampbyexample.com/components/amp-list/), as well as others.

At the time of writing, Google launched with a pretty broad range of email partners: SparkPost, Litmus, Twilio Sendgrid, and Amazon's SES and Pinpoint. But unless you have developers building your emails, you won't be able to easily use AMP in your emails yet. Dominant email marketing platforms like [Constant Contact](https://www.google.com/search?q=constant+contact+amp&rlz=1C5CHFA_enUS751US751&oq=constant+contact+amp&aqs=chrome..69i57.1962j0j4&sourceid=chrome&ie=UTF-8), [MailChimp](https://www.google.com/search?rlz=1C5CHFA_enUS751US751&ei=a8KcXMqeMKO4ggfV_K3ACA&q=mailchimp+amp&oq=mailchimp+amp&gs_l=psy-ab.3..0i20i263l2j0.76158.77011..77189...0.0..1.336.930.8j3-1......0....1..gws-wiz.......0i71j0i67j0i7i30j0i7i10i30j0i10i30j0i30j35i304i39j0i13.fPfkz3S_Su8), and even [SalesForce](https://www.google.com/search?rlz=1C5CHFA_enUS751US751&ei=0MKcXPXlDKW4ggfwsZK4Bg&q=salesforce+amp+email&oq=salesforce+amp+email&gs_l=psy-ab.3..33i160.6777.10225..10600...1.0..0.102.596.6j1......0....1..gws-wiz.......0i71j0i67j0i20i263j0i10j0j33i22i29i30j33i299.olMPQkJCQCI) do not yet support AMP templates, but likely will soon.

If you wanted to explore AMP in your email marketing, how would that you go about doing that?

Read up a bit more [about AMP email mark up](https://blog.amp.dev/2019/03/26/building-the-future-of-email-with-amp/)

Review the [AMP for email documentation](https://www.ampproject.org/docs/interaction_dynamic/amp-email-format)

Give your developers a chance to practice in the [AMP for email sandbox](https://playground.amp.dev/#runtime=amp4email)

Make sure [Google approves your email](https://developers.google.com/gmail/ampemail/register)

To allow your organization to __receive__ dynamic emails (like viewing the latest comments on Google docs within a single email), have your Gsuite admin [follow the steps outlined here](https://gsuiteupdates.googleblog.com/2019/03/dynamic-email-in-gmail-beta.html).

Also, more broadly speaking, there will be an initial stage where people are pushing limits, figuring out best practices, and failing with this new tool. This can be considered a grace period for more agile companies, or a learning period for companies that are a little more cautious.

The bottom line is that, like any investment in marketing technology, there isn’t a universal right or wrong approach. The value your company would realize from a technology like AMP depends on things like your growth loop, market segment, budget, and the rest of your tech stack.

__In my current role as [Lead Marketing Technologist at ADK Group](https://www.linkedin.com/in/samuelzoloth/), I watch emerging technical marketing trends, like AMP for email, and approach them from a strategic standpoint to give our partners informed recommendations on what to [[prioritize]] and how to best leverage new technology.__

__If you have any thoughts, comments, questions, about anything related to marketing, growth, and emerging tech trends please let me know! I love discussing common pain points, creative applications of technology, and complicated growth challenges.__

