For #[[[[Grow and Convert]] Content Strategy]]: with a clearer definition of who we're targeting, start to think about best ways to reach them (eg - linkedin groups)

For more #[[Inspiration for ADK]]

What is End-to-End Product Development?

Ties into: Your guide to the new agency landscape [[Inspiration for ADK]]

Offshoring

What it is

Cost/Benefit Analysis

Discovery Phase

Designing for Healthcare

What does good App maintenance include?

What does good website maintenance look like?

What is proactive maintenance?

Can enterprise be agile?

Who are McKinsey/[[Deloitte]]/Accenture competitors? Alternatives?

Building a team vs. Building a product: which to do first

For startups

How VCs evaluate startups

Pre-Seed: Team

Post-seed: Metrics

Why Hire an end-to-end product development agency?

Building a tech team

How do you retain engineers

Building a product organization

ADK Playbook

References

 the Thoughtbot Playbook

and the Master Playbook in G Drive

Sections

For Startups specifically

Metrics to track

For subscription products

What benchmarks investors are looking to see

[list of examples here](https://thoughtbot.com/playbook/measuring/subscription-metrics)

Analytics

AARRR Framework + aha moment

[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} check up on facebook campaign #[[form health]] #/

{{{[[DONE]]}}}} Exercise from [[refine labs]]: update linkedin profile to mirror [Justin Wheeler](https://www.linkedin.com/in/wheelerjustin/) #///

Major theme: End-to-end product development for healthcare, startups, midmarket, and enterprise

Is "start ups" an industry? 

Complete "LinkedIn Accelerator" program?

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2F2z7QSAk3gD.png?alt=media&token=56f3435c-e505-4a11-b7df-aeb08ad00d4a)

{{[[DONE]]}} Look into the "Accessibility Primer" from [[Catherine Shively]] #[[Inspiration for ADK]] #///

{{[[DONE]]}} [GBFB]([[Greater Boston Food Bank]]) case study (part 2?) [relevant slack message](https://adkgroup.slack.com/archives/CFF49C8HH/p1599072735061600) [[Inspiration for ADK]] [[[[ADK]] case studies]] #//

{{[[DONE]]}} Where are the spam form submissions coming from on adkgroup.com? #///

{{[[DONE]]}} Collect everything that's finalized about [[ADK]] marketing information into one place here #///

{{[[DONE]]}} Start collecting what people are looking for in the form submissions on adkgroup.com [[Inspiration for ADK]] #///

Eg - redesigning a website based on branding guidelines

Inclusions: UX/UI, sitemap architecture, SEO-focused content templates with flexibility

website launch and post-launch support

{{{[[DONE]]}}}} Review [[Sleeping Dog Properties]] blog posts from [[nick watkins]] #/

Might need to push for an interview time with [[matt rapczynski]]

worked on [[September 9th, 2020]]

{{{[[DONE]]}}}} Review resumes from [[heather mccormmack]] for the [[[[hiring]] a copywriter]] push #//

{{{[[DONE]]}}}} [[Wasabi]] [a/b test](https://docs.google.com/document/d/1g3cs1x-scTnHv5YbvDrYJk25-YB6KddQ-AH_k9YoAjc/edit) recap #/

To calculate conversion rate: 

Divide pageviews of RCS that came from Pricing by pageviews of Pricing page 

Results

Control pricing pageviews: **10,507**

RCS from pricing: 353

CTR from pricing to RCS = 3.35%

Variant pricing pageviews: **11,449**

RCS from pricing: 508

CTR from pricing to RCS = 4.44%

Difference: 32.54%

{{[[DONE]]}} Review the FDA / Part 11 Compliance from [[Miranda (Collette) Ahern]] [[Inspiration for ADK]] #///

Is it about 21 cfr?

[[Meetings]]: catch up about [[Sleeping Dog Properties]] and [[[[hiring]] a copywriter]]

Attendees:: [[heather mccormmack]]

Time:: 11:12

Notes::

 Chris and Heather interviewed a couple of people and liked them

[[outcome]]: prepare case studies for them to write as an assessment and draw up a contract for them

Will need to connect with Heather when these people are decided on so she can draw up a contract

Re: [[Sleeping Dog Properties]]

Some of the blog posts from Nick are not as interesting and deep

surface level and salesy

Might need to say we need more info from Matt

Need something like "the 3-5 questions to test your contractor on their expertise"

Two new blog posts to work on this month

how much to hire an architect

how much to re[[model]] a bathroom

[[Meetings]]: Marketing Team meeting

Attendees:: [[darci nevitt]] [[jordan daly]] [[nick watkins]]

Time:: 14:02

Notes::

[[Wasabi]] case study update #[[[[ADK]] case studies]]

Wonky logos on [[[[ADK]] case studies]]

Note to [[nick watkins]]: CMS is flexible enough to add more images

{{{[[DONE]]}}}} For ADK Marketing team: do we want to handle marketing engagements alone  or just wrap them into dev projects [[🏔ADK [[Task Management]]]]

#[[Quick Capture]]

how to make humility interesting? [[[[ADK]] ad creative]]

this site was built by: 3 strategists, 2 designers, 1 PM, 5 developers, 2 greyhounds, **and 1457 users** #[[[[ADK]] ad creative]]

Moulin Rouge with #[[emma zoloth]]

maybe visit #[[emma zoloth]] and plan intro with #[[Ally Portocarrero]]

