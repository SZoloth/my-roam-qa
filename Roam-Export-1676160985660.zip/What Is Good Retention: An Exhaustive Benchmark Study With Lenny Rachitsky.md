Author:: [[Casey Winters]]

URL:: https://caseyaccidental.com/what-is-good-retention

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

Why is retention so damn important?
Why are Lenny and I spending so much time researching retention? Because it is the single most important factor in product success. Retention is not only the primary measure of product value and product/market fit for most businesses; it is also the biggest driver of monetization and acquisition as well. 

Make the product more valuable: Every product is a bundle of features, and your product may be missing features that get more marginal users to retain better. This is a journey for feature/product fit. 

Connect users better to the value of the product that already exists: This is the purpose of a growth team leveraging tactics like onboarding, emails and [[notifications]], and reducing friction in the product where it’s too complex 

Create a new product: Struggling to retain users at all? You likely don’t have product/market fit and may need to pivot to a new product. 

