Tags:

#telemedicine, #telehealth, #coronavirus, #mHealth, [[virtual health]]

Benefits of Telemedicine During Coronavirus

Intro

“CIOs at health systems are thinking about, “How do I extend my care team that’s already strained in terms of resources, and mitigating some of the risks of their exposure,’” said [[Arielle Trzcinski]], senior analyst at Forrester Research Inc.’s health-care practice. ([source = WSJ article](https://www.wsj.com/articles/coronavirus-prompts-hospitals-to-fast-track-telemedicine-projects-11583876313))

“This is a kind of turning point for [[virtual health]],” Dr. Shah said. “We’re actually seeing how it can be used in a public health crisis.” ([source = NY Times article](https://www.nytimes.com/2020/03/11/health/telemedicine-coronavirus.html))

Dr. Shah = emergency room physician at Rush University Medical Center, Chicago

“The use of #telemedicine is going to be critical for management of this pandemic,” said Dr. Stephen Parodi, an infectious disease specialist and executive with The Permanente Medical Group, the doctors’ group associated with Kaiser Permanente.([source = NY Times article](https://www.nytimes.com/2020/03/11/health/telemedicine-coronavirus.html))

Recent bill passed by the House on Wednesday, March 11 to combat Coronavirus approved $8.3 billion in emergency aid. This included about $500 million that allows Medicare providers to use #telehealth for people 65 and older.

"In particular, the legislation gives the U.S. Department of Health and Human Services (HHS) secretary the authority to waive or modify certain telehealth Medicare requirements when the President has declared a National Emergency, or the HHS Secretary has declared a Public Health Emergency, as [Sec. Alex Azar did in January(www.phe.gov)](https://www.phe.gov/emergency/news/healthactions/phe/Pages/2019-nCoV.aspx)" [(source = AAFP article)](https://www.aafp.org/journals/fpm/blogs/gettingpaid/entry/coronavirus_testing_telehealth.html)

"According to [[Mercer]]’s annual survey, by 2019, #telehealth services were available to nearly 90% of employees of large companies, though fewer than 10% were using it." ([source = click2houston, should find Mercer survey](https://www.click2houston.com/health/2020/03/13/many-consider-using-telemedicine-programs-as-coronavirus-concerns-grow/))

Also a chance to shoutout/caveat that Mercer is a client of ours.

Protects patients

Ensures healthy people don't come into contact with others

Allows high risk individuals, like elders, who need a doctor's attention or have a routine visit scheduled to get it without traveling to a hospital that may be hosting the infection.

"St. Luke’s University Health Network in Pennsylvania is testing a videoconferencing tool targeting older patients, the most vulnerable to coronavirus, who don’t use the hospital’s mobile-device based #telemedicine tools and prefer using a desktop or laptop." ([source = WSJ article](https://www.wsj.com/articles/coronavirus-prompts-hospitals-to-fast-track-telemedicine-projects-11583876313))

Protects doctors

Allows doctor to work remotely in some cases

Doctors who may be self-quarantining because of recent travel can still see patients. This helps ensure there's less of a shortage of doctors during this time of stress on the medical system. 

Mitigates risk

Allows doctors to assess the risk ahead of time, and gives them advanced warning so they can set up preparation

"When Rush admitted a student last week who was believed to have the virus, the hospital was able to prepare for his arrival by clearing the ambulance bay of people and vehicles to protect patients and hospital staff from possible infection. Taken to an isolation room, he was examined by Dr. Paul Casey, an emergency room physician, and a nurse, both in protective gear." ([source = NY Times article](https://www.nytimes.com/2020/03/11/health/telemedicine-coronavirus.html))

Allows experts to "telecommute" and be in multiple places at once

Infectious disease specialists can be consulted easily. 

More efficient (saves time, reduces commuting, and saves resources)

extends the care team

Allows for more valuable triaging

Which in turn allows critical hospital resources to be focused on cases that are high importance

"The screening process at many hospitals includes gathering information based on questions unique to the coronavirus outbreak, such as places a patient has visited, or who they have been in contact with." ([source = WSJ article](https://www.wsj.com/articles/coronavirus-prompts-hospitals-to-fast-track-telemedicine-projects-11583876313))

Testing for coronavirus with telemedicine

Not possible to test for coronavirus remotely. 

Looking ahead

Connected devices and kits? "health rooms" (like gyms or home offices but for virtual health checks)

XR?

Other applications of digital solutions

Dashboards that speed triage

Navigators that help orient people (welcome app with Brigham?)

Might allow for a better way to reach specific patient populations

CRM + digital health app = personalized health messages automated at scale?

People to talk to

[[Dan Tatar]]

[[Andy Ellner]]

[[Jeff Greenberg]]

Background on telemedicine

What it is

HIPAA compliance

Insurance coverage?

Plans do typically cover telehealth as an alternative to going to an emergency room or urgent care center

Not a replacement for in person care - this is not meant to discourage anybody from seeking care.  

Promoting

Promote post on social

PPC

