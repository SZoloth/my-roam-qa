Author:: [[felixjamestin.com]]

URL:: https://www.felixjamestin.com/post/a-mental-[[model]]-of-motivation

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 21st, 2020]]

Motivation depends on 3 aspects – your initial state, the vision/end-state you want to reach and the path along the way. 

1. Initial state = expectancy + skills + resources

Expectancy: your belief in achieving an [[outcome]] if you put in the effort – i.e. if i do x, then y will happen. this is a function of your self-image and of past success.
Skills: the set of skills you need for the goal.
Resources: this includes time, money, etc. 

End state = better you + better world

Better you: you after you reach your goal; a you that’s more skilled, popular, rich, etc.
Better world: how your goal impacts the world. this larger purpose is what is commonly referred to as meaning. 

The path = [[feedback]] + empathy + control

[[feedback]]: the knowledge that you're making progress towards your goal.
Empathy: the knowledge that others have experienced similar challenges.
‍Control: the freedom you have to take your own decisions along the path. 

