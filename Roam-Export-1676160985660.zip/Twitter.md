Author:: [[twitter.com]]

URL:: https://twitter.com/rohit_jindal29/status/1276771656535400448

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

2/ Advice that will improve almost any writing: Cut half the words. Don't write anything you wouldn't say. 

3/ Studying history helps you predict the future by teaching you which things are old enough to be permanent. 

