Three types of landing pages

Home

Product

Ad landing page

# Optimizing Landing Page #Copy

Conversion = Desire - Labor - Confusion

To **increase desire:** Entice readers with value

To **decrease labor:** Ensure every word and design element on your page is clear and of high value. The more words and images you have, the more visitors struggle to figure out what matters

To **decrease confusion:** Be highly specific and consistent in your messaging. Every vague statement you make forces visitors to think more about your intentions and less about how your product improves their life

Best way to **decrease labor and confusion** is to __say a lot with a little__:

Get to the **best copy variation**

Every word on the page must exist for a reason. 

Write a dozen variations until you find the most enticing and concise one

**Don't pitch every value prop in full**

Stick with the value props that most entice your ideal customers

The more copy on the page --> the less people read

**No sales fluff**

Avoid words like: revolutionary, incredibly powerful, best-ever, etc.

Instead, specifically describe exactly how you're unique

Use the exact [[language]] your customers use

The **exception**: "modern" performs well in copy (but only if your product feels modern)

**Minimize scrolling**

Give reader key value props before they have to scroll

There are exceptions - sometimes longform works

Construct a narrative

Many visitors read the landing page top to bottom like a story so there needs to be cohesiveness from one section to another

# Writing the landing page

## Hero Section

Hero sections contain: header, subheader, CTA (optional), image (optional), social proof (optional)

### The Header

What makes a good header?

It's descriptive & concise

If the visitor reads nothing else on your page, they'd still know who you are and why they should use you 

Look at the header as the first sentence in an essay about your product/service

Should get straight to the point

Two step copywriting process for headers

1) Hook with a feature (the "what") then 2) tell them why that matters to them (the "why")

**1) Identify a compelling feature that captures the product's purpose**

What feature will get most people who read it thinking, "I want that!"

**How to**: List out all of the novel features of your product, then choose the feature(s) that **best represent the high-level purpose** of your product and are **most compelling**

**2) State the high-level purpose** (optional)

Usually the __most compelling value proposition__ from the list

Only required if the purpose of the your product/service is not completely self-evident by the feature alone

# Landing page structure

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FuHP3NGGsoF?alt=media&token=792be6ed-821c-42a3-8159-b57567ec94fc)

## Nav bar

Logo, links to key sections of the page, (sometimes links to other pages on your site), and a CTA

Sticky

