__Happiness, love, and passion…aren’t things you find—they’re choices you make.__

Happiness is a choice you make and a skill you develop.

The mind is just as malleable as the body. We spend so much time and effort trying to change the external world, other people, and our own bodies—all while accepting ourselves the way we were programmed in our youths.

We accept the voice in our head as the source of all truth. But all of it is malleable, and every day is new. Memory and identity are burdens from the past preventing us from living freely in the present. [3]

[3] [[Tim Ferriss]]. __Tribe of Mentors: Short Life Advice from the Best in the World__. New York: Houghton Mifflin Harcourt, 2017. https://amzn.to/2U2kE3b.

