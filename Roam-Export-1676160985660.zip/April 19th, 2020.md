Started [[Roam Course Notes]]

Beginning with [[daily notes]]

Basic ideas are to free-flow jot down what you're doing or planning on doing

Start in [[daily notes]] and then jump into anything

Allows you to create a journal

And creates hubs on what you're working on

`control + shift + d` takes you back to daily notes

Now focusing on [[to dos]]

slash "to do" turns the block into a to do

`command+return` does the same thing, faster

Once you've made to do's, you get a "to do" and done" page

Bucket future to dos under a block

For each one use `/ date` to open the date picker and associate the to do note with a specific daily note in the future

Visually, can use `command+alt+number` for headings

`command + period` when selecting a block shifts focus to blocks

eg - if you were to press that command on the parent block all you would see is that block, this block and the next one

`command + comma` zooms out

Every block included as a child in a parent that links to a page can be viewed on that page

using the **sidebar**

use multiple pages at once

to access:

hold down `shift + click on link` to open a new page in the sidebar

[[Goals]]

Shift [[Notion]] marketing tracker into [[Roam]]

Use [[Roam]] for ingesting marketing articles

Use [[Roam]] for ingesting the advice I've given on [[Demand Curve]] Slack channel

Use [[Roam]] for notes on the blogging for B2B course by [[ahrefs]]

Capture notes on the go

[[Roam]] added quick capture

First page is quick capture

Notes taken here need to by sync'd 

Reference blocks

One way: `hold down alt and drag the block where you want it`

Another way: press `(( ))` double parentheses

Using images in [[Roam]]

drag and drop files

copy and paste files

Recommendations: 

tag the images

Nest the images under context with tags

Context menu

Can be brought up on any block by `right clicking` on a bullet

[[Roam]] for [[Personal Knowledge Management]]

Create tags for different [[Metadata]]

On the Metadata page, create the templates for each type of page

When you create a new page, tag Metadata, shift+click it to open it in sidebar, then copy and paste the relevant metadata from the sidebar into your page

Don't put the "metadata" tag in there

{{[[DONE]]}} The above has been done

Articles

Read in [[instapaper]]

Highlight everything that looks interesting

Copy and paste into "reading notes"

Optional

Archiving in Instapaper

[[Readwise]] syncs with [[instapaper]] to grab your highlights

Readwise exports to Evernote

[[Progressive summarization]] ^^important^^ for My [[Note Taking Process]]

Source: [[Tiago Forte]]

Steps

Bold anything in the highlights that **stands out**

Highlight anything that's ^^really^^ important

Then shift the highlights under a "Notes" header

Add a "Summary" header at the top of the page

Summarizing knowledge into [[Head Pages]] for [[Note Taking Process]]

Find tags with tons of references

Begin to summarize big ideas

Under each idea, add bullet ponits

Open up source notes in the sidebar and drag in relevant answers

Taking Video notes

Use the video metadata

Timestamp notes

About the day

Helped bake a banana bread with [[Ally Portocarrero]]

Ordered groceries online using the script for Amazon

Worked amazingly

Watched "Outbreak" with Dustin Hoffman

Played Halo 3 with [[Alex Seibel]]

Planned out the [[ADK Marketing Needs]]

Realized we don't need HubSpot Pro

Will need: [[MailChimp]] upgrade, [[Clearbit]], heavy design and medium dev resources

