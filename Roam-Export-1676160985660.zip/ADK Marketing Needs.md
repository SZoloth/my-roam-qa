Metadata

Source:

Tags: #Clearbit #Hubspot #MailChimp #[[Inspiration for ADK]] #[[Selling ADK Group]]

Strategic level

Firmographic target definition

^^Apply tactics to each level of interaction^^

**Awareness**

Paid prospecting campaigns

Channels

LinkedIn

Needs

Audience(s) definition

Copy writing + Message

Creative

Images

Videos

Landing page

Offer

Cold outreach email campaigns

Needs

Audience definition

Copy writing

Strategy (flow)

Offer

**Consideration**

Paid remarketing campaigns

Channels

LinkedIn

FB/IG

Google Display

Needs

Audience(s) definition

Copy writing + Message

Creative

Images

Videos

Landing page

Offer

Email follow up / nurture

Strategy (flow)

Copy writing

Offers

**Intent**

**Evaluation**

**Decision**

**Expansion**

Tactical level

[[remarketing campaigns]]

Social + traditional (Google?)

Define what the audiences are (eg - drupal pageviews)

Define what the messages are (eg - the power of Drupal with the UX of WP)

CMS training**

Create the ads

Images

Copy

Create the offer

Downloadable?

Schedule time with one of our experts?

How do we take people off of remarketing who have emailed us?

Can MailChimp do this?

Prospecting campaigns

LinkedIn

Define the audiences

Define the messages

Create the ads

Images

Copy

Create the offer

Downloadable

Clutch (?)

Cold outreach

Define the audiences

Define the flows

Write templates

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FPIAfk4WnfR?alt=media&token=49a51d94-bff9-40e7-acd3-ad8284c78b3b)

Content / SEO

Plan

Write

Case studies

Updating pages

Industries (add university)

Email nurtures

Define flows

From downloads

Lead scoring 

Can we capture company? Can we force company [[hubspot consideration]]

Can be done through [[Clearbit]] API with [[MailChimp]]?

Write flows

Design templates

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FPIAfk4WnfR?alt=media&token=49a51d94-bff9-40e7-acd3-ad8284c78b3b)

Guest interviews on podcasts

Find list of podcasts

Write outreach strategy

Run it

Weak points with current methods

Landing pages

A/B testing - likely not enough volume for this to be super valuable though

How do we take people off of remarketing who have emailed us?

Lead scoring 

Start a project form to HubSpot

