{{[[DONE]]}} Audit marketing team and self in prep for [[ADK marketing summit]] #/ #team-development #self-development

[[Meetings]]: [[Glenmede]] analytics

Attendees:: [[Michelle Smith]] [[will rainbow]] [[alex fisher]] [[darci nevitt]] [[keri lubanski]]

Time:: 15:00

Notes::

[[will rainbow]] leads the digital team

[[alex fisher]] helping with analytics and reporting

GA, GDS, SF ([[pardot]])

Joined content team - how content is performing?

[[keri lubanski]] not digital team

joined [[Glenmede]] 5 years ago

Set up manually and URL strings were not set up optimally

Current state of GA

3 distinct business lines 

Site is becoming more conversion oriented - within each business line more CTAs, conversions, etc.

Effective dashboards and reports 

No [[Goals]] set up in GA - track different conversions

Benchmarks 

How to measure thought leadership?

Engagement

Example spreadsheet

[[pardot]] conversions for form

SF may be overengineered

Wanted to aggregate all data

Glenmede Connect - separate site

3rd party application

back and forth

Crossdomain tracking with Impactivate

For [[September 22nd, 2020]]

{{[[DONE]]}} Audit marketing team and self in prep for [[ADK marketing summit]] #/ #team-development #self-development

This is also sort of prep the [[OKR]] part of the meeting

{{[[DONE]]}} Wasabi SEO strategy from [[Wasabi analytics: 9/4/20 - 9/17/20]] #//

{{[[DONE]]}} Talk to Chris about time off

{{[[DONE]]}} [[refine labs]] profile optimization homework #/

{{[[DONE]]}} Post the MVP design blog

