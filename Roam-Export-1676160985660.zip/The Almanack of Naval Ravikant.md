**Metadata**

This book collects and curates [[Naval Ravikant]]'s wisdom from Twitter, Podcasts, and Essays over the past decade. The wisdom of [[Naval Ravikant]], created and edited by [[Eric Jorgenson]], with illustrations by [[Jack Butcher]], and a Foreword by [[Tim Ferriss]].

Source: https://www.navalmanack.com/

This project is a public service by [[Eric Jorgenson]], run on [donations](http://omella.com/o/9Bufa).

You can purchase a physical copy of the book on Amazon in [hardcover](https://www.amazon.com/gp/product/1544514220/ref=as_li_qf_asin_il_tl?ie=UTF8&tag=ericjorg-20&creative=9325&linkCode=as2&creativeASIN=1544514220&linkId=4c35e27541ee0c5c3a63aff40608d29e), [paperback](https://www.amazon.com/Almanack-Naval-Ravikant-Wealth-Happiness/dp/1544514212/ref=tmm_pap_swatch_0?_encoding=UTF8&qid=&sr=) or [Kindle](https://www.amazon.com/Almanack-Naval-Ravikant-Wealth-Happiness-ebook/dp/B08FF8MTM6/ref=tmm_kin_swatch_0?_encoding=UTF8&qid=&sr=).

[[Introduction]]

[[Important Notes on this Book (Disclaimer)]]

[[Foreword by Tim Ferriss]]

[[Eric's Note (About this Book)]]

[[Timeline of Naval Ravikant]]

[[Now, here is Naval in his own words]]

[[Part I: Wealth]]

Building Wealth

[[Understand How Wealth is Created]]

[[Find and Build Specific Knowledge]]

[[Play Long-term Games with Long-term People]]

[[Take on Accountability]]

[[Build or Buy Equity in a Business]]

[[Find a Position of Leverage]]

[[Get Paid for your Judgment]]

[[[[prioritize]] and Focus]]

[[Find Work that Feels Like Play]]

[[How to Get Lucky]]

[[Be Patient]]

Building Judgment

[[Judgment]]

[[How to Think Clearly]]

[[Shed Your Identity to See Reality]]

[[Learn the Skills of Decision-Making]]

[[Collect Mental [[model]]s]]

[[Learn to Love to Read]]

[[Part II: Happiness]]

Learning Happiness

[[Happiness is Learned]]

[[Happiness is a choice]]

[[Happiness Requires Presence]]

[[Happiness Requires Peace]]

[[Every Desire is a Chosen Unhappiness]]

[[Success Does Not Earn Happiness]]

[[Envy is the Enemy of Happiness]]

[[Happiness is Built by Habits]]

[[Find Happiness in Acceptance]]

Saving Yourself

[[Choosing to Be Yourself]]

[[Choosing to Care for Yourself]]

[[Meditation + Mental Strength]]

[[Choosing to Build Yourself]]

[[Choosing to Grow Yourself]]

[[Choosing to Free Yourself]]

Philosophy

[[The Meanings of Life]]

[[Live by Your Values]]

[[Rational Buddhism]]

[[The Present is All We Have]]

[[Bonus]]

[[Naval's Recommended Reading]]

[[Naval's Writing]]

[[Next on Naval]]

[[Appreciation]]

[[Sources]]

