[[🏔ADK [[Task Management]]]]

Idea 1 - awareness: case studies #//

[[Meetings]]: [[[[1:1s]] with [[darci nevitt]]]]

Attendees:: [[darci nevitt]]

Time:: 9:30am

Notes::

 Wins:

EiE presentation

Best part: 

Felt good and practiced in what was presented

Done better:

Questions were difficult

Challenges:

[[Goals]]:

Next week:

[[Meetings]]: [[Wasabi analytics: 8/7/20 - 8/20/20]] #[[Wasabi meeting]]

Attendees:: [[mike welts]] [[brooke kwasny]] [[mary mccarthy]] [[jordan daly]]

Time::

Notes::

Wasabi

Week over week growth

250-300 channel partners / month

over 50% of customers are >100tb

CCPA / GDPR

Focus against Dell EMC, netapp, HP

RCS [[model]] is key value

intercept people looking to move to cloud from on prem

Channel has only traditionally sold hardware boxes

RCS puts a SKU on a cloud to sell like a hardware box

2022 100% channel

50% by EoY

channel recruitment

[[Personal Task Management]]

{{{[[DONE]]}}}} Prep grocery list for VH #/

{{{[[DONE]]}}}} Chat with [Em]([[emma zoloth]]) about VH #/

