Author:: [[Julie Zhuo]]

Source:: https://sloanreview.mit.edu/article/how-to-become-a-strategic-leader/

Recommended By:: 

 Tags:: [[[[strategy]] [[*]]]]. [[🌱 The Making of a [[Manager]]]]

No. 1. Create alignment around what wild success looks like:

This sounds obvious but can be hard to do in practice. As a litmus test, ask yourself this: Imagine that your team is wildly successful in three years. What does that look like? Write down your answer. Now, turn to your neighbor and ask him or her the same question. When you compare your answers, how similar or different are they? #team-development

No. 2. Understand which problem you’re looking to solve for which group of people:

Understanding the ecosystem around the problem. Problems don’t exist in a vacuum. There are likely many other people out there who are also obsessed with solving any given problem. How are they approaching it? What’s being done well and done poorly? Which groups of people are being ignored? Where are the opportunities for a better approach?

Understanding a problem well means also understanding your competition and understanding the systems around which this problem exists. Do your research — competitive analyses, jobs to be done, audience [[segmentation]], market sizing, etc. This work is what creates confidence in future ideas and what gives us a framework to evaluate them.

Understanding which problems suit your unique strengths and weaknesses. You can’t solve every problem equally well — so what problems can you solve better than anyone else? What are you or your team really good at? And what are your weaknesses?

No. 3. [[prioritize]]. And cut: Prioritizing is really hard because most of us hate saying no. #[[Focus[[*]]]]

The question to ask isn’t “What more can we do to win?” or “How can we make sure none of the things we’re juggling are failing?” Instead, ask “What are the one, two, or three most important things we must do, and how can we ensure those go spectacularly?”

I tell my team that when the discussion becomes “Should we ship this mediocre thing, or should we spend additional time that we don’t have to make it better?” the battle has already been lost. The thing we failed to do weeks or months ago was to cut our [[scope]] aggressively enough. Either a feature or initiative matters — in which case, make it great, don’t make it mediocre — or it doesn’t. And if not, don’t work on it in the first place.

Author:: [[sloanreview.mit.edu]]

URL:: https://sloanreview.mit.edu/article/how-to-become-a-strategic-leader/

Tags:: #Articles #Inbox #Readwise

Newsletter::

### Highlights first synced on [[December 7th, 2021]]

“A good strategy is a set of actions that is credible, coherent, and focused on overcoming the biggest hurdle(s) in achieving a particular objective.”

