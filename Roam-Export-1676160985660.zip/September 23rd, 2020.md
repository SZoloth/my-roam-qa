[[Meetings]]: ADK Marketing Summit

Attendees:: [[chris baker]] [[jordan daly]] [[nick watkins]] [[darci nevitt]]

Time:: 09:56

Notes::

##  Agenda

### ADK Company Growth Strategy

Background

Company is growing into million-dollar-deal range on a national scale.

Marketing and selling services is difficult

Need to build a brand

Performance marketing is not driving strong ROI

Where we're going

Be more vocal about who we are (podcast, LinkedIn)

Two stories to bring to market

1) Focused on Healthcare narrative

Built differentiated portfolio, background, and expertise

Example targets: UPMC, Mayo Clinic, Kaiser Permanente

[[Dan Tatar]] meeting innovation centers

2) Generalist product development narrative

Emphasize **end-to-end product development** over commoditized markets of individual products (websites, marketing, apps)

Instead, focus on the lifecycle or journey of a product

These two stories are emerging and diverging

Initial thought: Healthcare = division of ADK

Experience with highly regulated areas are transferable (we win deals in financial services b/c of experience with healthcare)

Differentiation

Overlap of skills

Tag line: Idea to Impact

Take unformed ideas and turning it into a product that's in the market accomplishing [[Goals]].

The values that ADK provides customers to resolve pain points

Bring a new product to market

Marketing = IA, customer personas, pain points

Build a digital health application

Improve an existing product

Marketing = analytics, a/b testing, CRO

Create a digital experience

__Questions__

Narrative part of business =/= brand?

Will someone looking at this know 

###  Sate-of-the-state on ADK Marketing

**Revenue**

How to measure ROI?

Contribute more to quality of work that rest of team is doing.

Billable retainers are flat or down

Doing less of the SEO + social + tiny engagements

**Core Areas of Expertise**

**Positioning**

If pure marketing: tune up/level up the last 20% of a company's marketing

**Weaknesses**

Have been struggling to win marketing-only engagements.

We lack a proven process.

As a stand-alone marketing team, we're less differentiated. But as a part of the team it helps us stand out. 

SEO and PPC worlds have gotten saturated / commoditized

### Vision & Mission Development

**Vision & Mission statement development**

Front door and back door for all future product engagements.

**SWOT exercise**

**Strength**

Quick learners

SEO + Content

Technical SEO

Collaboration

[[feedback]] + criticism

A/B Testing

Analytics

**Weakness**

[[scope]] creep

Process and operations

Structured onboarding

**Process**: Making sure we don't repeat mistakes, capturing repeatable processes, setting up systematic [[feedback]], possibly team learning. 

Project management

Creative

**Opportunity**

Build a more agile approach to marketing

More architecture

Specialization

**Threat**



### Measuring Success

**Team OKRs**

Drupal CMS design

**Individual OKRs**

Vertical specific specialist

### Follow up / Next Steps

## Misc

Share Refine Labs with team

[[Meetings]]: [[[[mHealth]] app kit]] GTM

Attendees:: [[ben kaplan]] [[brian mullen]]

Time:: 12:00

Notes::

 Background

mhealth app kit reached v.2 

documentation completed

Need to create an FAQ

Tutorials guide

Private YouTube channel 

built a demo

launching at 5 hospitals with the most basic version of the app

10 question questionnaire, dashboard

RA-Ab-v multi-site landing page

client relationship

Looking to define:

Target customer (ICP)

Assets needed

Timeline (if possible)

Anything else I'm missing!

Deliverables

Landing page for mHealth App Kit

Page for app resources (public or private?) - viewable by a link

mhealth.adkgroup.com

Process management standpoint

Single source of truth for landing page

Pain: GDrive isn't organized

Don't know strategy

Define target customer

Interview current customers

Dr or CIO? Operational staff? 

Mass Bio on September 30th is doing digital conference?

What other 

