Tags:: #Recipes #pasta

Ingredients::

__For the pesto__

200g [[basil]] leaves

50g [[parsley]] leaves

120g [[mint]] leaves

25g [[stale bread]], finely crumbled

2 [[garlic]] cloves, chopped

3 tbsp [[EVOO]]

50g freshly grated [[parmigiano reggiano]] cheese

1 tbsp sea [[salt]]

__For the pasta__

1 tbsp coarse [[salt]]

600g fusilli [[pasta]] or other short pasta

Freshly grated [[parmigiano reggiano]] cheese, to serve

Tools:: [[blender]], [[food processor]]

Source:: https://www.mrporter.com/en-us/journal/lifestyle/chefs-home-cooking-pesto-pasta-massimo-bottura-1275856

:hiccup [:hr]

In a blender or food processor, combine the basil, parsley, mint, breadcrumbs, garlic and five ice cubes. Pulse until finely chopped. Add the olive oil, cheese and salt, and pulse to incorporate.

Bring a large pot of lightly salted water to a boil over medium heat. Add the fusilli and cook until al dente. Toss the pasta with the pesto. Sprinkle with the grated parmigiano and serve.

