[[🏔ADK [[Task Management]]]]

For [[Wasabi]] - What do we know about the user in terms of conversions?

Primarily occur on Home, Pricing

This is likely because these are the highest intent people (searching branded terms + pricing terms = lowest in the [[funnel]] or farthest in the decision making journey)

Otherwise, almost exclusively on various documentation/longform blog pages

Exceptions: sign up page, s3 compatible storage page, veeam page

Primarily returning users 

Help Docs + Pricing FAQs

Use cases that are being sought out: Backup and Recovery, Content Delivery

Interested in but not converting on: 11 9's durability blog

Paid landing pages succeed only through sheer volume

Eg - /hot-cloud-storage-offer had 20k sessions but only 108 conversions

vs. S3-compatible-storage, had similar sessions but 1,305 conversions

vs. help/docs had ~1/2 sessions, and 3x conversions

vs. back up and recovery = less than 1/2 sessions, 148 conversions

**Themes**

S3 compatible and other AWS-related intents are super valuable

Conversions primarily occur on high intent pages or pages people return to (vs. have their first visit on)

Home (high intent)

Pricing (high intent)

Help and Help/Docs (repeat)

Pricing/FAQs (repeat)

About (repeat)

Help/Downloads (repeat)

What is Wasabi (repeat)

Resources (repeat)

How Cloud Storage (repeat)

Suggests this is highly researched, high consideration

Exceptions (decent amount of primarily new users, looking for solutions, converting relatively high, and at or above highest conversion rates)

[S3 compatible storage](https://wasabi.com/s3-compatible-cloud-storage/)

[Backup and Recovery](https://wasabi.com/backup-and-recovery/)

Flip side of this is Tape to Cloud, which had similar traffic but almost 0 conversions in comparison (also had much higher percentage of MIQ traffic)

People come back to documentation to convert

[PDF download page (on prem vs cloud "break free from the herd")](https://wasabi.com/on-prem-storage-vs-cloud-storage/) performed surprisingly well for free trials

["Classic" landing pages](https://wasabi.com/get-30-days-wasabi-free/) with more basic info performed better

Help/Docs outperforms both of these and the 

Few people are talking to sales unless forced to (RCS)

[Get 30 days wasabi free](https://wasabi.com/get-30-days-wasabi-free/) CRUSHED [hot cloud storage offer](https://wasabi.com/hot-cloud-storage-offer/)

Animated hero

More data in hero

Action-oriented and solution-focused copy (vs a feature, like price)

Single CTA and action throughout page

Same footer CTA

Use cases that are being sought out: Backup and Recovery, Content Delivery

Supporting blog: "backup vs archiving doesn't matter with wasabi"

Press Releases had pretty high conversion rates

Unlimited free egress pricing plan

1st European data center

Launch

Partners have pretty high conversion rates (cloudberry, packet, cloudflare, veeam)

**Recommendations**

Give people a focused experience while presenting important information (but doing so clearly)

People care about

Pricing

Documentation

Solutions

Backup and recovery

Content delivery

S3 compatibility

Mac/Windows compatibility

What Wasabi is

Partners

Connectivity options

Improve solutions-oriented landing pages

Highlight popular use cases like backup and recovery

Remove sales form

Animation?

Table of contents / interior nav bar

Improve documentation / knowledgebase UX

Improve partner pages (underway)

Homepage is very important real estate

Need to be careful to treat it like a homepage, not an advertisement

Eg - "head in the clouds" hero dropped the conversion rate from 6.7% to 5.4% or from 501 weekly free trials to 330.

[[Major Decision]] landing page

[[Major Decision Value Props]] #[[Major Decision]]

(Major Decision is the only way to) Get unfiltered, uncensored answers that can't be found

online

on campus tours (canceled)

from admissions offices

Get unfiltered answers/advice from real students

Get your first conversation free

What if you had a college mentor from your top college choices who could tell you everything they wished they'd known before enrolling? 

You can ask things like...

Combine Mary Clare + Lili Orozco videos 

See why High School seniors Mary Clare and Lili used Major Decision to {{x}}

Hero

Header

Get a college student from your top schools to answer all your questions about college life. 

Major Decision is the only place to get unfiltered, real, honest answers from college students.

For a limited time, sign up to Major Decision and schedule a free conversation with a student. Get answers to things like:

What do you wish you had known before enrolling?

What's your biggest regret from freshmen year? 

What was the best decision you made freshmen year?

What are the best intro classes? 

And anything else you're interested in!

Design

Section options

Alternating row

Featured Video or 3 videos (featured looks better though)

3 Icon gateway

email sign up

staggered list for how it works

WYSIWYG? for featured benefits

Accordion for FAQs

email sign up

[[Meetings with [[chris baker]]]] #[[chris baker]] #[[ADK Group]]

For [[COVID-19 testing app]]

Plan to track analytics that would feed future product iterations

Marketing

PR person planned

Less than 1 month from conception to launch

Rapid iteration through mHealth platform

COVID testing looking at expanding nationally and internationally

Instead of Major Decision work - Put Demand Curve Exercises into Confluence for: #[[ADK Marketing Process]]

Personas

Value props

Landing page

Strategy section

Peer review for copy b/c no one can do it in vacuum

Pull from dropbox notes

{{[[DONE]]}} Send Drupal campaign for review by EOD tomorrow

{{[[DONE]]}} Send Demand Curve / ADK process for review by 1pm on Wednesday

[[Notes: Converting the Unconverted]] from [[Albacross]] by [[Marcus Svensson]]

You need to identify the anonymous visitors that are valuable

First, you need to define what "valuable" is

This is known as your ICP (ideal customer profile)

People who convert are either {{high intent, ICP}} or {{high intent, not ICP}}

The revenue on the table are people who did not convert but have {{high intent, ICP}}

How to create your [[ICP]]

Of your customers, who is paying the most? Who is getting the most value?

Eg - who gets a positive ROI quickest?

Create a list of top 10 customers, what firmographic attributes do they share?

Location

Technology

Size

Industry

Roles

Revenue

Behavior that signifies high [[purchase intent]]

Returning to pricing page

Longer than average session duration (but shorter than absurd)

Definitions

Exclude converted/form inputs

Pricing page visits >0

Product page visits >0

Session duration >00:59

Relevant traffic sources (organic, paid, direct)

Create an [[outbound outreach strategy]]

