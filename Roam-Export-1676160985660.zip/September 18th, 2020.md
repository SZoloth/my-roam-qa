Look into [[APCIA]] analytics to

Details

Classify difference between browser usage for Unfiltered and Reporting

Time range: 1/1/20 - 9/13/20

Questions that came up

Why are ((a4gzDyAHX)) __lower__ for Unfiltered than Reporting?

One possibility: Filtered is excluding all hits from known bots and spiders and Reporting is not

How do we filter out [[APCIA]] employees from the Unfiltered view?

Is there a page that employees only hit?

Data and metrics:

Total users on [[APCIA]]

Unfiltered: 305,691

Reporting: 523,770

Request about ADK site org from Chris in Marketing General

[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} Publish ADK blogs #//

{{[[DONE]]}} Wasabi SEO strategy from [[Wasabi analytics: 9/4/20 - 9/17/20]] #//

{{[[DONE]]}} [[[[mHealth]] app kit]] GTM plan #/

[[Meetings]]: [[[[1:1s]] with [[darci nevitt]]]]

Attendees:: [[darci nevitt]]

Time:: 15:18

Notes::

growth::

{{[[DONE]]}} Create a presentation about GTM and analytics for React devs

Tickets

Challenges & Frustrations::

Being pessimistic

Email from KHJ

Don't have fun and stressed at work

question::

[[feedback]]/Reflections::

