Author:: [[[[ahrefs]]

URL:: https://[[ahrefs]].com/blog/javascript-seo/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

Good: 

Bad: 

Googlebot doesn’t take action on webpages. They’re not going to click things or scroll, but that doesn’t mean they don’t have workarounds. For content, as long as it is loaded in the DOM without a needed action, they will see it. I will cover this more in the troubleshooting section but basically, if the content is in the DOM but just hidden, it will be seen. If it’s not loaded into the DOM until after a click, then the content won’t be found. 

Google doesn’t need to scroll to see your content either 

Google doesn’t paint the pixels during the rendering process. 

each site has its own crawl budget, and each request has to be [[prioritize]]d. Google also has to balance your site crawling vs. every other site on the internet. Newer sites in general or sites with a lot of dynamic pages will likely be crawled slower. Some pages will be updated less often than others, and some resources may also be requested less frequently. 

Google loads each page stateless, so they’re not saving previous information and are not navigating between pages. 

Devs can fix this by updating the state using what’s called the History API, but again it may not be a problem. Refresh the page and see what you see or better yet run it through one of Google’s testing tools to see what they see. 

View-source is going to show you the same as a GET request would. This is the raw HTML of the page. 

Inspect shows you the processed DOM after changes have been made and is closer to the content that Googlebot sees. It’s basically the updated and latest version of the page. You should use inspect over view-source when working with JavaScript. 

Google’s testing tools like the URL Inspector inside Google Search Console, Mobile Friendly Tester, Rich Results Tester are useful for debugging. Still, even these tools are slightly different from what Google will see. 

these tools also differ in that they’re pulling resources in real-time and not using the cached versions as the renderer would. The screenshots in these tools also show pages with the pixels painted, which Google doesn’t see in the renderer. 

The tools are useful to see if content is DOM-loaded, though. The HTML shown in these tools is the rendered DOM. You can search for a snippet of text to see if it was loaded in by default. 

The tools will also show you resources that may be blocked and console [[error message]] which are useful for debugging. 

The [[ahrefs]] Toolbar also supports JavaScript and allows you to compare HTML to rendered versions of tags. 

Any kind of SSR, static rendering, prerendering setup is going to be fine for search engines. The main one that causes problems is full client-side rendering where all of the rendering happens in the browser. 

Social media bots don’t run JavaScript, so things like OG tags won’t be seen unless you render the content before serving it to them. 

**Tags**: #[[technical seo]] #[[SEO]]

If you were using the old AJAX crawling scheme, note that this has been deprecated and may no longer be supported. 

A couple of issues I repeatedly see when working with JavaScript websites are that titles and descriptions may be reused and that alt attributes on images are rarely set. 

All the normal on-page SEO rules for content, title tags, meta descriptions, alt attributes, meta robot tags, etc. still apply. See On-Page SEO: An Actionable Guide. 

Don’t block access to resources. Google needs to be able to access and download resources so that they can render the pages properly. In your robots.txt, the easiest way to allow the needed resources to be crawled is to add: 

User-Agent: Googlebot
Allow: .js
Allow: .css 

Change URLs when updating content. I already mentioned the History API, but you should know that with JavaScript frameworks, they’re going to have a router that lets you map to clean URLs. You don’t want to use hashes (#) for routing. This is especially a problem for Vue and some of the earlier versions of Angular. 

for a URL like abc.com/#something, anything after a # is typically ignored by a server. 

With JavaScript, there may be several URLs for the same content, which leads to duplicate content issues. 

The solution is simple. Choose one version you want indexed and set canonical tags. 

For JavaScript frameworks, these are usually referred to as modules. You’ll find versions for many of the popular frameworks like React, Vue, and Angular by searching for the framework + module name like “React Helmet.” Meta tags, Helmet, and Head are all popular modules with similar functionality allowing you to set many of the popular tags needed for SEO. 

You have a couple of different options for error pages: 

Use a JavaScript redirect to a page that does respond with a 404 status code 

Add a noindex tag to the page that’s failing along with some kind of [[error message]] like “404 Page Not Found”. This will be treated as a soft 404 since the actual status code returned will be a 200 okay. 

JavaScript frameworks typically have routers that map to clean URLs. These routers usually have an additional module that can also create sitemaps. You can find them by searching for your system + router sitemap, such as “Vue router sitemap.” 

just find the system you use and Google the system + sitemap such as “Gatsby sitemap” and you’re sure to find a solution that already exists. 

SEOs are used to 301/302 redirects , which are server-side. But Javascript is typically run client-side. This is okay since Google processes the page as follows the redirect. 

You’ll want to lazy load images, but be careful not to lazy load content. This can be done with JavaScript, but it might mean that it’s not picked up correctly by search engines. 

