There is actually nothing but this moment. No one has ever gone back in time, and no one has ever been able to successfully predict the future in any way that matters. Literally, the only thing that exists is this exact point where you are in space at the exact time you happen to be here.

Like all great profound truths, it’s all paradoxes. Any two points are infinitely different. Any moment is perfectly unique. Each moment itself slips by so quickly you can’t grab it. [4]

[4] Ravikant, [[Naval Ravikant]] and Shane Parrish. “Naval Ravikant: The Angel Philosopher.” Farnam Street, 2019. https://fs.blog/naval-ravikant/.

You’re dying and being reborn at every moment. It’s up to you whether to forget or remember that. [2]

[2] [[Naval Ravikant]]. “[[Naval Ravikant]] Was Live.” __Peri[[scope]]__, February 11, 2018. https://www.pscp.tv/w/1MnGneBLZVmKO.

__“Everything is more beautiful because we’re doomed. You will never be lovelier than you are now, and we will never be here again.” —Homer, The Iliad__

I don’t even remember what I said two minutes ago. At best, the past is some fictional little memory tape in my head. As far as I’m concerned, my past is dead. It’s gone. All death really means is that there are no more future moments. [2]

[2] [[Naval Ravikant]]. “[[Naval Ravikant]] Was Live.” __Peri[[scope]]__, February 11, 2018. https://www.pscp.tv/w/1MnGneBLZVmKO.

__Inspiration is perishable—act on it immediately.__

