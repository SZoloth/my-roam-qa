Author:: [[siegemedia.com]]

URL:: https://www.siegemedia.com/creation/content-development

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

Content creation aims to create better content than what exists—whether that be the shareability aspect, answering searcher intent, or building a more complete piece of information. 

When analyzing content take note of:

Posts that generated the most links.
Posts with keywords that rank in the top three organic results of the SERP.
Posts that rank on page two or greater.
Existing content gaps between you and your competitors. 

Ideally, you’ll marry the easy-win gaps in competitor content with a proven promotable concept in a receptive outreach market. 

Segmenting into these groups helps visualize potential content and uncover existing posts that can be optimized to boost rankings. 

Essentially, you’re looking for proof that an initial idea is worth the investment. You can do this in a few ways—but we’ll talk specifically about social proof. 

social proof is when a comparable website, whether that be domain authority or its offering, has created a similar piece of content and seen success. 

Social proof can be repins, retweets, upvotes, linking root domains (LRDs) and everything in between. What to avoid here is validating an idea with something that looks like social proof, but isn’t. 

Here we see websites that have a similar offering, relatively low domain authority and plenty of links that show people are interested in this topic. 

Better still, is that one of the posts generating significant links is relatively thin with some stock imagery. 

By creating content that answers more questions, is more visually appealing or more user friendly—you’re adding value to what already exists. 

May I present to you, being human: 

Believe it or not, 50 personalized emails will go much further than 150 mass-sent emails. That’s because most people on the internet have been around and see through link-building schemes. 

Instead, you need to bring them relevant and useful content that they recognize as helpful to their audience. Not every piece of content needs to be promoted, nor should it. Top-[[funnel]] assets are more linkable than bottom-[[funnel]] ones, and the value of those links continue to accrue long-term. 

