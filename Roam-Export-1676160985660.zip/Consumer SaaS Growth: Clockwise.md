#[[✍️ blog-post]]

Other case studies:

Superhuman

Notion

## What's driving the #[[Growth marketing[[*]]]] of enterprise #SaaS?

While reading Andrew Chen's [essays on growth hacking](https://andrewchen.co/)*, he described the current state of growth he'd weave in the usual suspects: #virality, #SEO, content marketing, and [[nfx/network effects]]. 

A pattern began emerging overtime, that was also being reflected in my work running #B2B marketing for a variety of clients at [[ADK Group]].

More and more [[enterprise software]] #startups

That Next Big Thing is the Consumerization of Enterprise Products and it's the confluence of three concepts:

**Bottoms-up adoption**

**[[product-led]] growth**

**Network effects combined with virality**

Read on to learn more about each of these concepts.

Then, see them in action in a case study for [Clockwise](https://www.getclockwise.com/), a gamified/social calendar for company teams that I believe will see explosive growth over the next quarter.

## 1. Bottoms-up adoption of enterprise software

Over the last few years, adoption and purchasing decisions at enterprise companies have shifted from being exclusively top-down to being bottoms up.

But how did this happen and why is it important for the consumerizaion of enterprise software?

### From technical complexity and strict budgets...

Money and security. These were the two biggest barriers to smaller teams making their own purchasing decisions.

Proliferation of marketing channels. Quick adoption -> quick proof - > quick funding.

Because companies didn't have brand or top of [[funnel]] awareness, they needed sales teams. and to justify sales teams, they needed to pull in customers with high annual contract values (ACV).

### ...To [[product-led]] companies & freemium [[model]]s

New generation in the workforce that is digital-native. They're more aware of what a good product should look and feel like because they interact with them pretty much hourly throughout the day.

Founders of companies are also trending towards product and software people, who are naturally inclined to approach growth problems through the lens of the product vs. sales or even marketing.

It's worth noting that the products that best capitalize on this are more horizontal - meaning they are useful for any team.

How are SaaS companies capitalizing on bottoms-up adoption?

## 2. [[product-led]] growth

Traditionally, B2B software purchase decisions were top-down and required heavy involvement from the IT department. Because of this, B2B software companies invested heavily in enterprise sales teams. These sales teams would try to lock enterprise companies into long-term contracts.

Now, however, we're seeing companies with no formal sales teams reach incredible scale.

![https://samzoloth.files.wordpress.com/2019/07/bvp-state-of-cloud-2019-growth-arr.jpeg](https://samzoloth.files.wordpress.com/2019/07/bvp-state-of-cloud-2019-growth-arr.jpeg)

Source: [State of the Cloud 2019](https://www.bvp.com/atlas/state-of-the-cloud-2019#Growth-ARR), from Bessemer Venture Partners

What do all of the above companies have in common?

Every one of them began with no formal sales teams. Dropbox is the fastest SaaS company to $1B in revenue run rate with 600+ million users

Slack, DropBox, Asana, Atlassian (all self serve) -- Clockwise actually leans on slack. Vs. Oracle. Also important to note that each of the example companies (with the exception of maybe Atlassian) eventually invested in a direct sales team. But the broad awareness, and rapid adoption of a paid version at consumer -speeds allows these companies to get to that scale quickly and efficiently quickly

Growth is built it into the usage and output of the product. What do I mean by that? Look at the [[esignature]] company DocuSign. They provide a great "single player" experience where you can get the full benefit of the product without bringing other people onboard to the platform by allowing even people who don't pay for DocuSign to sign a document.  Even so, the output lends itself naturally to viral adoption. You see a document come in, you like the experience, you get it for yourself, you start sharing with your department, you send out more agreements and the cycle starts again.

The growth comes purely out of using the product and is predicated on the company creating a good UX.

Key factor: engagement. How many users are getting to the "a-ha" moment of the product? and how often are they getting it? The more people use it, the more opportunities they have to bump into the two key growth engines.

## 3. Network effects & Virality

(dropbox: announce on a large platform like Hacker News or Product Hunt and build in a mechanism that rewards people for inviting others)

Does your network get exponentially better with every incremental addition of a new user? Slack is an obvious example.

Clockwise as a case study for consumerized B2B growth

Bell curve principles for their landing page (what would I change or test?)

can grow by increasing adoption within a company or expanding to new companies 

Recommendation: focus on the use cases that have outsized roles in scheduling internal and external meetings. Internally, that could be people like PMs and externally that could be someone in sales.

Monetization routes

Cap the tools and features that admins want (Slack is a good example of this) 

## Can't limit users per team

What did I like about it?

Was just playing around with the **[Clockwise](https://www.linkedin.com/company/17926327/)** app and am pretty excited by some of the built-in growth mechanics.

Things like: branding the work calendar, connecting to slack updates, and creating team metrics (to encourage invites when it's empty and competition when it's full)...

These all have the potential for really powerful viral growth!
Have you seen any other B2B apps/chrome extensions that do this?

Clockwise acquires user --> user syncs calendar/Slack --> teammates see "❇️Focus Time (via Clockwise)" in shared calendars/Slack --> teammate asks user about it & user is incentivized to recruit teammate (clockwise becomes a more powerful tool with more of your team onboard by introducing more fluidity in scheduling) --> rinse & repeat.
Still provides a relatively valuable single-player mode (auto-booking focused time with flexibility, personal stats), but probably not truly stand alone.

![https://s3-us-west-2.amazonaws.com/secure.notion-static.com/dc239067-0959-4898-80b7-18fa9211db4a/Clockwise-invite-team-screenshots.png](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/dc239067-0959-4898-80b7-18fa9211db4a/Clockwise-invite-team-screenshots.png)

![https://s3-us-west-2.amazonaws.com/secure.notion-static.com/ff5a5357-8a0d-4303-be3b-597fc5ffddea/what-is-focus-time-clockwise.png](https://s3-us-west-2.amazonaws.com/secure.notion-static.com/ff5a5357-8a0d-4303-be3b-597fc5ffddea/what-is-focus-time-clockwise.png)

What are some good growth mechanics that is has?

see my linkedin post

see email about heather from Clockwise

