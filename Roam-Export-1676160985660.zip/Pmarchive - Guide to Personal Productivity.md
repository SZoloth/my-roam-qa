Author:: [[pmarchive.com]]

URL:: https://pmarchive.com/guide_to_personal_productivity.html

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

I sit down at my desk before I go to sleep, pull up my Todo List (which I keep in Microsoft Word's outline mode, due to long habit), and pick out the 3 to 5 things I am going to get done tomorrow. I write those things on a fresh 3x5 card, lay the card out with my card keys, and go to bed. Then, the next day, I try like hell to get just those things done. If I do, it was a successful day.

People who have tried lots of productivity porn techniques will tell you that this is one of the most successful techniques they have ever tried. 

Do email exactly twice a day -- say, once first thing in the morning, and once at the end of the workday.
Allocated half an hour or whatever it takes, but otherwise, keep your email client shut and your email [[notifications]] turned off. 

First, always finish each of your two daily email sessions with a completely empty inbox. 

Second, when doing email, either answer or file every single message until you get to that empty inbox state of grace. 

