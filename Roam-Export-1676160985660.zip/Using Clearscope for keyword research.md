Reference

Source: [[bernard huang]] [[clearscope]]

Keywords: [[keyword research]] [[content planning]] [[[[content]] [[strategy]]]] [[SEO]]

Relevant notes:

Notes:

Main ideas

Outdated ways of thinking: keywords & pillars

keywords are replaced by topics or intent

pillars are replaced by content that best matches search intent

Glossary

[[search intent]]

[[pillar]]



