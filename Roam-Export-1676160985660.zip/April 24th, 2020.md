[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} high priority

Drupal resources opening up according to [[aaron crootof]]

what are biggest challenges and limitations

[[prioritize]] requests

primarily back end

**Requests**:

[Speed up site publishing time](https://adkgroup.atlassian.net/browse/ADKCW-1049)

And [show progress bar](https://adkgroup.atlassian.net/browse/ADKCW-1052)

Could [npm build tasks](https://adkgroup.atlassian.net/browse/ADKCW-821) be related?

[Opt-in for future communications on project form](https://adkgroup.atlassian.net/browse/ADKCW-1141)

[[[[career]]s]] page](https://adkgroup.atlassian.net/browse/ADKCW-344)

[Articles pages should have headers not divs](https://adkgroup.atlassian.net/browse/ADKCW-1136)

[Preview posts](https://adkgroup.atlassian.net/browse/ADKCW-754)

[Announcement banner](https://adkgroup.atlassian.net/browse/ADKCW-1132)

[Additional context](https://adkgroup.atlassian.net/browse/ADKCW-1139)

[ADKCW-1123](https://adkgroup.atlassian.net/browse/ADKCW-1123) not sure what this is but sounds important

[ADKCW-1078](https://adkgroup.atlassian.net/browse/ADKCW-1078): adkgroup.com/api

Ability to hide/remove components from the site

Without leaving the header behind

Without breaking the site

[EG - toggle on/off the Download CTAs on article pages](https://adkgroup.atlassian.net/browse/ADKCW-1148)

Investigate media library load time

Convert all site media/objects to pull from Media Library

Set up API relationship between MailChimp and Clearbit

[ADKCW-1070](https://adkgroup.atlassian.net/browse/ADKCW-1070): Category "pages" for the blog

Replace all headers with editable fields (eg - [ADKCW-1008](https://adkgroup.atlassian.net/browse/ADKCW-1008))

[ADKCW-1084](https://adkgroup.atlassian.net/browse/ADKCW-1084): Update replyto email on all web forms (?)

Might be redundant if we're handling via MailChimp

[Related](https://adkgroup.atlassian.net/browse/ADKCW-1149) - customize the confirmation email by page, not form (or use variables)

[Constrained featured images ](https://adkgroup.atlassian.net/browse/ADKCW-476)on the blog landing/index page

[Banish infinite scroll](https://adkgroup.atlassian.net/browse/ADKCW-1064)



Drupal linkedin campaign

Major Decision retargeting + Major Decision marketing strategy

{{[[DONE]]}} [[SBIR blog]] for [[ADK/blogging]]

Should start with [[clearscope]] then create outline for Jen + Brian

Connected with [[brian mullen]] on slack - he shared a powerpoint 101 

React Blog

[[[[ADK]] case studies]] for

[[Woodford]]

in progress by [[Jen Keefe]]

[[Cambridge Savings Bank]]

interview scheduling with [[Jen Keefe]]

[[Beyond Insurance]]

interview scheduling with [[Sanjay Salomon]]

[[Boston School Finder]]

interview scheduling with [[Sanjay Salomon]]

[[Privafy]]

interview scheduling with [[Jen Keefe]]

[[Vyaire]]

interview scheduling with [[Jen Keefe]]

[[form health]]

interview scheduling with [[Sanjay Salomon]]

IoT Blog - published

Published, still needs images from [[Jessica Medina]]

[[ADK Marketing Needs]] related to [[ADK Marketing Collab with [[chris baker]] ([source](https://docs.google.com/document/d/1WTygbD96y-KTspT_dAwsFSi9HT3xHUtPYj7u77r5Ilg/edit?ts=5ea1e191#))

[[Daily ADK Notes]]

[[Segment]] for [[form health]] meeting with [[jeremy weiskotten]] and [[jess lopez mora]]

Reference sheet - [[form health - product analytics data taxonomy]] ([source](https://docs.google.com/spreadsheets/d/1TbSGOx87PChHFc0FnLyqNzTf7-D4ypLZdwcmoTHlzvU/edit#gid=1718547277))

Potentially changing sign up flow

Send over Invision file for FH form 

jeremy to reach out Alex F

Goal: 

track page by page

Update history

Use Segment build a custom page track event

payment page

do they get past?

App download

No form field for coupon code yet

From Jess

Via phone consultation - julia is signing the person up over the flow

in this case: disable [[funnel]] tracking 

parameter in URL or use different URL for advisor sign ups

For Calendly - meeting scheduled only

Pass parameter to Calendly via buttons (segment anonymous IDs)

Consideration for flow:

Moving email capture to beginning of flow after BMI

What would it take to make this change?

Pull zip code instead of state (secondary)

Customer.io for email

BAA

Stripe integration not working on staging

why is it broken? jeremy to follow up with kirsten

Weekly meeting with [[aaron crootof]] on [[ADK Group]]

Clearbit

IP address tracking for ADKCW

would need to come from server logs

Form issue with HubSpot

Drupal resources opening up

what are biggest challenges and limitations

[[prioritize]] requests

primarily back end

