Source:: [[jon clark]]

Notes:: [[ADK React Blog Notes]]

Google Docs Link:: https://docs.google.com/document/d/1pqa2q2WY12e_IifA9KhVJ5H9rCY97O_W_M77wW2aFYE/edit?usp=sharing

## Introduction

If you're looking to make your app cross-platform compatible, modernize an old app, or build an entirely new app it's highly likely you should be looking for an __experienced React Native team__.

For years, ADK Group has been building mobile applications for organizations like Massachusetts General Hospital, Firefly Health, ALKU, Brigham and Women's Health, OnTrac, and more. These apps are relied on to make life easier, make businesses more efficient, and make people healthier and happier - at massive scale. 

Something all of these applications have in common is invisible to most people. It's the codebase. Every one of these apps is built using React Native.

We love React Native because it saves us time, saves our clients money, and lets our clients build on top of it easily (extend it?). It also lets us deliver fast, engaging, and delightful experiences to our clients' users no matter what platform they're using. 

React Native is our programming [[language]] of choice for mobile apps and we'll recommend it most of the time. In fact, one of our current projects, a COVID-19 testing app developed in partnership with MGH is being built by our developers leveraging our mHealth platform, which is built in React Native.

### Executive Summary

This article will answer:

How does your developers' choice of programming [[language]] affects business [[outcome]]s?

What makes React Native "better" than other [[language]]s?

But if you want the quick and dirty summary: The [[language]] used to build your mobile application has profound implications for how expensive and easy it is to build and maintain. Based on decades of experience, we've found that React Native is the best option for our clients 



## Why The [[language]] Your App is Built In Matters

Like any product, the materials you use to build an app define many of the characteristics of the app. (__opportunity to link to SPA pages__)

The code your app is built in should be considered an existential question to your company. Code choice ultimately impacts how much it costs to build your application, who can use your app, how they can use your app, and how much it costs to maintain, debug, and update your app.

Because of that there are certain characteristics a development [[language]] should have:

Extensibility

Efficiency

Endorsement

### Extensibility and flexibility:

Here extensibility is both deep (will this [[language]] allow me to grow my app in the ways I envision? In ways I haven't thought of yet?) and wide (will this [[language]] allow me to reach the majority of my target audience?).

You want your app to be written in a [[language]] that allows other developers to onboard and start building, updating, maintaining, etc. as quickly as possible. That rules out [[language]]s like Objective-C, which was a powerful codebase created by Apple, but was so unique that its barrier to adoption was too high.

You also want an app that is supported by the platforms your customer is using. If you're building a mobile app, this means your [[language]] should be usable by both Apple and Android users, which brings us to our next characteristic...

### Efficiency and speed

In 2014, Apple released Swift as a successor to Objective-C. Swift is powerful __and__ much easier to learn because it uses syntax similar to Javascript. In fact, it's popularity is large due to the degree to which it resembles Javascript. However, it only works on iOS. Meaning if you wanted to reach the ~40% of US mobile phone owners using Android you'd need to rebuild your entire application in another [[language]]. 

Better, then, to find a programming [[language]] that works for as many of the top platforms as possible. You'll end up with one codebase, which makes building an app significantly more efficient because you can write once for multiple platforms. 

One codebase also reduces your cost of ownership. Your developers will have only one area where they'll need to manage bug fixes, upgrades, and new builds. Less of your development resources will go towards repetitive tasks and more can be used on higher ROI opportunities.

The math here is simple. Say your developers use purely native [[language]]s (like Java for Android, Swift for iOS, and Javascript for web) to create an app that can be used on mobile and web. Inevitably, a bug gets identified and needs to be patched. Fixing that bug on all your codebases will take 3x as long (and be 3x as expensive) as fixing it in a single codebase.

Cost of ownership is also affected by market supply and demand for developers of certain code [[language]]s. In other words, as discussed in the following section, popularity matters.

### Endorsement and adoption

Your coding [[language]] of choice should have broad endorsement. It should be widely used by developers, so that you have flexibility for finding a great development team (__link opportunity__) (and for replacing that team __if you need to fire them__). 

When looking for a development team, you'll likely run into developers or teams specializing in (or stuck) using outdated codes. The risks you hope to avoid here are that high specialization and rarity of skills leads to difficulty hiring. You'll face two challenges: higher prices and more time spent finding and vetting development teams.

A primary example of this is Kobol. Legacy Kobol code is now being reassessed. This [[language]] is so old that most modern developers don't know it. Therefore, when apps built on it need upgrading or updating it's exponentially harder to find the team that can solve that problem.

You can also easily find groups of developers dedicated to the newest, shiniest option. These zealots dismiss proven [[language]]s in favor of newness of the sake of newness. And sometimes the code chosen here may be performant. But often times it has too many flaws or is simply too immature to be trusted for applications that need to survive rapid scaling, be relied on for critical procedures and research, or both.

Your ideal programming [[language]] should strike a balance between widespread adoption, recent advancements, and implicit endorsement from trusted sources. An easy heuristic here is, "if it's good enough for X (MGH, SalesForce, Tesla) it's good enough for my company." In other words, you want your app to be built on code that is __leading__ edge, rather than __bleeding__ edge.

## Why We Use React Native for Mobile Apps

Ultimately, we only use React Native when it's right for the [[Goals]] of our clients. But because React Native effectively meets the above criteria, that's true for 99% of our projects.

React Native provides our customers with the highest ROI on their investment in our developers and technical leaders. It allows us to write one line of code for every major platform, fix bugs efficiently, and create code that lends itself exceptionally well to being handed off to internal teams if those resources become available. 

It allows us to build apps like ALKU Everywhere, Firefly Health, (MGH App), and more that perform at scale, delight users, and withstand massive usage - all at an affordable and competitive cost. 

Mentioned earlier, the [[COVID-19 testing app]] that we are in the midst of building with MGH is being built on React Native. It's being trusted to provide massively scalable testing for an incredibly important healthcare application. 

Ultimately, building our team around React Native was a calculated bet - that paid off for us and, more importantly, is paying off for our clients who need high-performing, engaging, and scalable mobile applications. 

