[[Morning Pages]] 

__Don't forget Gratitude!__

{{word-count}}

 A phrase popped into my head in the morning: "The television will not be revolutionized" - which is neat, but can't really go with anything. Like, the television will definitely be revolutionized, and is being revolutionized already.

Thinking about what to do today. [[Ally Portocarrero]] wants to do some cleaning and stuff, which I'm down for. I'm glad she's on top of that stuff #Gratitude

Additionally, I could watch/play AoM, wrap up the note transfer for [[Good Strategy Bad Strategy]], play some Halo, do some reading on [[Grow and Convert]]

Something to think about for [[Drawbridge]]: the issues with programmatic advertising and fake clicks (inspired by [this article](https://www.wired.com/story/she-helped-wreck-the-news-business-heres-her-plan-to-fix-it/))

An industry hurting for ad dollars: news

"An analysis of newspaper and magazine publishers in the US, United Kingdom, Australia, and Japan [concluded](http://www.theguardian.com/media/2020/jan/20/uk-publishers-losing-digital-ad-revenue-due-to-content-blacklists) that overblocking deprived them of $3.2 billion of digital revenue last year."

"But social media’s algorithms make it easy to amplify inflammatory content—and programmatic advertising makes it simple to monetize."

"And for every Breitbart or Zero Hedge, there are thousands of straight-up fraudulent sites designed simply to attract clicks, either from bots or human users duped into visiting the URL."

"In a 2018 survey by Digiday, 43 percent of media buyers said they avoid news content at least sometimes."

You wouldn't have to worry about "brand safety" and "ad verification"

More data around the inefficiency of programmatic advertising https://www.isba.org.uk/news/time-for-change-and-transparency-in-programmatic-advertising/

Plus think about the types of consumers that would be most likely to use [[Drawbridge]]: superfans. They're likely already on email lists and don't really care or think it's worth it.

A goal would be to get them to unsubscribe from email lists so that the discounts would exist only in [[Drawbridge]], but that's at odds with what advertisers want

I'm assuming that an email address is more valuable than a customer that's raised their hand - it would be to me.

This is more related to [[ADK]] branding:

"To the contrary, one [recent study](http://www.comscore.com/[[insight]]s/Presentations-and-Whitepapers/2016/The-Halo-Effect-How-Advertising-on-Premium-Publishers-Drives-Higher-Ad-Effectiveness) found that the “halo effect” of advertising on a set of established, respected news sites led to a massive increase in “brand lift,” a measure of warm consumer feeling, compared to ads that ran across the rest of the internet."

[News outlets that experienced layoffs and paycuts](https://www.poynter.org/business-work/2020/here-are-the-newsroom-layoffs-furloughs-and-closures-caused-by-the-coronavirus/) - potentially some good opportiunities for [[hiring]] a freelancer for [[ADK]]

This [checklist for Google E-A-T](https://docs.google.com/spreadsheets/d/12-F9Z4NzDADOFRQtOiN-CtjY2aaqj-R5CcrJNCuTha4/edit?mc_cid=da6dc2d490&mc_eid=3b9e72382c#gid=0) Should be included in my [[[[ADK Marketing Strategy]]: [[[[content]] [[strategy]]]]]] that comes out of things like [[animalz]] and [[[[Grow and Convert]] Content Strategy]]

[thread by @AmandaMGoetz](https://twitter.com/@AmandaMGoetz/status/1295393675481153538) ⬇︎

How to build a [[marketing plan]] from 0-1: beginner’s guide #[[ADK Marketing Strategy]]

// thread 🧵

Reminder: a marketing plan is NOT a brand strategy.

Brand strategy is WHY you will win.

Marketing plan is HOW. The plan is the levers you will pull to hit your [[Goals]].

A simple marketing plan contains 3 components

1/ Brand [[Goals]] / OKRs

2/ Strategy TL;DR

3/ Channel strategy / [[Goals]] / OKRs

Who &amp; how:

It should be done top-down / bottoms up.

What does that mean? It starts with the marketing leader (or CEO) creating  # 1 and # 2.

Then the channel owners create # 3 and give to leader.

Leader confirms all are aligned.

How often?

I like to create Marketing plans quarterly to enable teams to iterate based on the needs of the business, customer and changing marketing landscape.

A note on OKRs

OKRs are part of the marketing plan.

O = objective

KR = key result (tangible measurement)

You will have over-arching brand [[Goals]] for the department and [[Goals]] for each team / channel.

*OKRs do not contain tactics! This is a common mistake

Brand OKR Ex:

I want to increase brand awareness (O)

as measured by 10% increase in recall by women ages 20-29 through quarterly third party survey (KR)

Try to limit to 2-3 objectives for focus.

Strategy TL;DR

Now that you have your brand [[Goals]], it’s helpful to do a strategy TL;DR.

I frame it as the 3-4 levers you will use to achieve that brand goal.

It’s like going on a road trip. The [[Goals]] are the destination and the strategy is how you plan to get there.

For example:

We will achieve our Q4 brand [[Goals]] via:

influencers for earned media

Releasing 2-3 PR [[insight]] papers

Focus on Twitter engagement / channel growth

This top-down strategy shows where the team is focusing major energy that quarter.

Next up: Channel OKRs

So you now know the destination (brand [[Goals]]) and high-level directions you get there.

Now each team/channel gets to plan their own road trip.

Each team/channel will create their own OKRs in order to move the needle on the brand [[Goals]].

Note on [[Goals]]:

It’s important to get alignment on WHAT [[Goals]] to track weekly vs. monthly and do we have the tools to measure them.

I don’t like tracking more than 3-5 top line metrics.

Ex:

PR metrics:

Top tier Placements

Impressions

SOV (against competitive set)

Last stop: channel strategy

Each channel will create their strategy TL;DR to communicate HOW they will hit their OKRs.

Again, you will try many things over the course of a month and quarter. This is the elevator pitch of what big levers you want to pull.

Hope this is helpful!

What other MarketingMonday threads would you like to see next?

[[[[Grow and Convert]] Content Strategy]]: About [[[[user]] [[research]]]] [source](https://growandconvert.com/marketing/conducting-user-research/)

Knowing your customer means knowing:

Their biggest challenges as they relate to your service

Their questions that they have before they know they need your service

What they'll research when they have a need for your prodct

What sites they use to educate themselves about your industry

Where they go for advice about your services: Google? A friend? An influencer? A magazine? A book? Television?

They objections they have to your service

Your competition; both direct and indirect

Some [[insight]]s gleaned about ThinkApps, which is related to ADK Group, that they used to make [this page](http://thinkapps.com/how-we-work/?utm_source=GrowandConvert&utm_medium=youdontknowyourcustomerpost&utm_campaign=userresearch):

When it came to software development, there was a lack of trust in the industry. **Many people had been screwed over by development firms, developers on sites like **[**UpWork**](http://www.upwork.com/)**, and outsourced developers. **Sometimes people had spent $60k-$100k to only be left with an uncompleted project.

Many development companies **didn’t provide visibility into the development process. **Developers were known to not give access to source code and sometimes even let clients see the product until it was finished.

Many people complained about** a lack of communication. **Sometimes clients would contact their developers for several weeks before getting a response.

Companies were concerned about their IP and **development firms stealing their ideas.**

**Project timelines by development companies were typically over promised and under delivered** – this sometimes greatly impacted clients as they had pre-planned launches.

Example questions:

How did you discover ADK Group?

How would you feel if you could no longer use ADK Group?

What would you likely use as an alternative to ADK Group if it were no longer available?

What's the primary benefit you have received from ADK Group?

Have you recommended ADK Group to anyone?

Why/Why not?

How did you describe us to other people?

What type of person do you think would benefit most from ADK Group?

How could we improve ADK Group to better meet customer needs?

1. Why did you initially visit ADK Group?

2. What’s your biggest challenge when it comes to product and marketing strategy?

3. What other product and marketing strategy blogs do you frequently visit? (separate them by commas)

4. What type of articles on ADK Group do you wish there were more of?

Example survey email template:

NAME,

Wanted to send you a quick note to say how much (we/I) appreciate having you as a customer.

We know we’re not perfect, and in an effort to continuously improve our (product/service), I’d love if you could take 5-10 minutes to fill out this survey about us: LINK

The survey is short – x questions, and I‘d really value your [[feedback]].

Thanks in advance.

Best,

Your Name


Run this survey across the top 20% of customers, then the other 80%

[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Get the [homepage story arc](https://docs.google.com/document/d/1SHH4JhrJ75k8uo3mDKChvnpFxXSeMWEtiPffigVt0hg/edit?ts=5f3ece84) details into the #hiring [freelance copywriter evaluation](https://docs.google.com/document/d/1ysq67G2CccNlzLuqjSnx_-z_i_P3QZsH6Ij18V5JIDs/edit#heading=h.eq6gmeqfth9o) #[[ADK Hiring]] #[[[[hiring]] a copywriter]]

This also relates to the [[[[Grow and Convert]] Content Strategy]]

Our values

Authentic

Humble

Expert

Opinionated

Not Harry Potter or Frodo, but Dumbledore or Gandalf

We are a global technology team with a unique culture rooted in philanthropy, technology, and adventure. We measure our impact by the long-term relationships that we build. We believe success in technology and business requires integrity, humility, and respect for others.

Our operating mantra is: expertise without ego

What makes us unique is how we combine and present our individual services and expertise

words we don't use

words we do use



