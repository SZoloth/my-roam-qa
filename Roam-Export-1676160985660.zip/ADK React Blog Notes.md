Source:: [[jon clark]]

Target Date::

Tags:: #[[blogging]] #[[✍️ blog-post]] #ADK/blogging #[[ADK React Blog]]

Progress Status:: #draft

Google Doc::

# Main concepts

ADK and React

About React

About coding [[language]]s

# Notes

Generic / Intro

What's the most recession-proof code [[language]]?

Now more than ever, every line of code matters. Efficiency matters. ROI matters. You can't afford to duplicate code and manage multiple codebases if you don't need to.

Mentioned earlier, the [[COVID-19 testing app]] that we are in the midst of building with MGH is being built on React Native.  

Based off tech using for Olfactory for parkinsons and alzheimers

Working with Albers lab, Mark Albers

scratch n' sniff - loss of smell is a symptom

2 studies (UK and Iran) strongest predicting symptom of COVID is loss of smell

2x as strong as predicting COVID as fever

launched last saturday at BWH

In a clinic at Chelsea

Launching at MGH

working on taking this worldwide

But even in the best of times, we opt for React Native for mobile apps. 

Why is code [[language]] so important?

Example with Kobol: 

Legacy Kobol code is now being reassessed. This [[language]] is so old that most modern developers don't know it. Therefore, when apps built on it need upgrading or updating it's exponentially harder to find the team that can solve that problem.

Bleeding edge code is shiny, but dangerous

Better to work with leading edge code, which is the best modern solution. Finds the balance between recent advancements and being tested. This is especially important for clients in the healthcare space. If it's good enough for MGH to use on clinical applications it's likely good enough for you.

Why React Native?

React maximizes ROI for our customers, which gives us a competitive edge. It means we can build complex mobile applications like [[ALKU]] Everywhere and [[Firefly]] Health that perform at scale, withstand unprecedented usage, and delight users -- all for costs that allow our partners to unlock high ROI and growth.

Don't need to maintain two code bases

Fix a bug in one place

Saves money on maintenance

Saves money on development

Reduces the total cost of ownership

Write once for all platforms

Integrates with native code if/when its needed

React does double duty. For each line of code written, it supports both Google's and Apple's operating systems, Android and iOS respectively.

But that's not entirely true. React actually does __triple__ duty, because it works on the browser. This allows you to build a [[PWA]] and/or a native app using the same [[language]]. Makes transitioning from one to another easier. 

React performs well. It runs natively.

Recompiling, extensible.

Primary uses: 

make your app cross-platform compatible

modernize an old app

build a new app

Resources

Case studies from Facebook

Performance benchmarks

Popular apps built on React Native

Facebook, Instagram, Pinteret, Skype, Uber, Tesla, Wix, Walmart, Bloomberg, Tencent QQ (China's largest messaging platform wtih 829m+ active accounts), SalesForce, and more

The 3rd party community is vibrant

Swift and Android Java have __more__ developers, but that's because they're relatively old compared to React.

How did ADK choose React Native

We had previously been using Angular and Cordova

When React Native was assessed, in addition to the previously listed benefits, it had all the makings of a strong platform: re-usable code, could train developers to get into native, allowed us to use the same tools that could be posting and distributing native apps in the app store.

Ultimately, it was a calculated bet. And it payed off. Since investing in this, we've been able to build out training in curriculums. This has resulted in rapid scale up of developers that joined as juniors and were very quickly able to output enterprise grade code. It's been one of the key factors in our growth to nearly 100 employees this past year. 

How does ADK implement React Native?

We built our team around it. 

When is native code required? What are potential drawbacks?

Of course, our best practices are never set-in-stone. We need to be able to adapt to diverse requirements. And we're aware of limitations of React Native.

Native code is better for an exceptionally performant or low-level piece of hardware

While React Native still integrates 99% of the time, there are still cases where native coding is required.

When you're working closely with GPS, bluetooth, or the camera and there isn't a React Native __wrapper__

If you're licensing a library from a 3rd-party vendor. These can __interop__ with a React Native bridge or [Native Modules ](https://reactnative.dev/docs/native-modules-ios)

Ultimately, it's never an either/or choice between React Native vs. native coding [[language]]s

The biggest drawback is that it has to play catch up to SDKs that Google and Apple put out. Keeping pace with Google and Apple can be difficult, but the open source community has been able to so far

When software updates come out, Apple and Google make it backwards compatible

As React gets more mature, it gets better. But staying up to date is difficult and expensive. To protect our clients, we pin to a specific version and only undergo upgrades when the changes to the SDKs are big enough.

History of React Native

How did React go from science project to mainstream?

JS is the [[language]] of the browser, which is the de facto operating system of the internet. That makes JS the [[language]] of the internet. 

We're benefitting from that crossover to native apps ^^(???)^^

In the late 80s Apple was using [[Objective-C]], which was exceptionally powerful. 

Jon developed using this. Found that the syntax was radically different from other [[language]]s.

Drawback: super powerful, but hard to work with.

As a result of drawbacks, Apple invented [[Swift]], which did well.

It used a c-like or javascript-like syntax, that was familiar to developers

That's the reason it was successful - it was a function of how closely it got to Javascript.

Meanwhile, React is successful because it __is__ Javascript

