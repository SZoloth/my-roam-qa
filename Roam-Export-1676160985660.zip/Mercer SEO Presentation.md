Tags:: #Mercer #SEO #[[ADK SEO Process]]

Questions from client: How to optimize a web page: Where should I start?

What are the key basic elements a content owner should consider to change on a page? Images, layout, CTA buttons?

How to figure out what our visitors are searching for?

How to make sure the page is accessible to both search engines and humans?

How to get other websites to link to the page (if necessary)?

How to optimize a page containing PDF files (gated content)?

What is Google’s advice about URLs? Should they be short or long? Why?

Image optimization.

Mercer struggles promoting their branded products that have names that aren't SEO-friendly

[Doc to review](https://docs.google.com/presentation/d/1_t-fla1j7t23z_k7wvWXzxPxtoIP-TkE56CYpY-2dhQ/edit?ts=5ee0f1cd#slide=id.g3ac8bbdbf8_0_150)

Example

SEO is the process of ensuring your content gets found by people looking for it on search engines.

The best way to do that is to combine the following:

keyword research

high quality content

and technical optimizations

Keyword research

Figure out what visitors are searching for

High quality content

Intent matching + solving

Layouts

Optimizing for gated content*

paywalls?

E-A-T

Technical optimizations

URLs

Metadata

Image optimization

Structured data

Internal linking

Applying this to creating a new page

Applying this to optimizing an existing page

