[[Meetings]]: [[OKR]] for marketing team

Attendees:: [[darci nevitt]] [[nick watkins]] [[jordan daly]] [[chris baker]]

Time::

Notes::

 Mission:

Dan / Chris discussing digitla health as focus

acquiring new customers?

developing a digital health product marketing practice

Next steps:: #[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} Pick 2 KRs to own as O's

{{[[DONE]]}} Set up KR ownership meeting

{{[[DONE]]}} Define [[my [[OKR]]s]] #/

{{[[DONE]]}} Put in hours for september [[🏔ADK [[Task Management]]]] #/

[[Meetings]]: [[i[[mercer]]]]

Attendees:: [[darci nevitt]] [[jordan daly]]

Time:: 13:00

Notes::

Access:

GA

GTM

GSC

General audit

{{[[DONE]]}} UTMs

Referral exclusions

eCommerce

Testing product check out flows

User-ID

Analytics filters and settings

eCommerce technical set up audit

[[Museum of Science]] tracking

Time frame: 9/1 - 9/30

HubSpot

Landing page: 114 total submissions

Campaign:

Emails sent: 100

Landing page submissions: 119

Melissa's list: 78 contacts

Facebook: 35

Google ads: 8

#[[Quick Capture]]

frickin Mercer utm stuff 

