Notes from: https://[[ahrefs]].com/blog/javascript-seo/ #[[ahrefs]]

Notes

There are key differences between the downloaded GET request (by the crawler), the actual rendered page (by the renderer), and some of the testing tools

**Any kind of SSR, static rendering, and prerendering setup is going to be fine for search engines**

The main issue is full client-side rendering where all of the rendering happens in the browser

Useful infographic

https://[[ahrefs]].com/blog/wp-content/uploads/2020/06/google-rendering-on-the-web-infographic.jpg

Process for [[crawling]] [[React SEO]]

1) Crawler sends GET requests to server, which responds with headers and contents of the file

Can be HTML, JS, CSS, XHR, API, etc.

2) During processing, Google pulls out ^^links^^ to other pages and files needed to build the page and adds them to the crawl queue

Google can pull resources links (CSS, JS, etc.) from `<link>`, but links to other pages need to be '<a>'

**Link markup that works:**

`<a href=”/page”>simple is good</a>`

`<a href=”/page” onclick=”goTo(‘page’)”>still okay</a>`

**Link markup that does not work:**

`<a onclick=”goTo(‘page’)”>nope, no href</a>`

`<a href=”javascript:goTo(‘page’)”>nope, missing link</a>`

`<a href=”javascript:void(0)”>nope, missing link</a>`

`<span onclick=”goTo(‘page’)”>not the right HTML element</span>`

`<option value="page">nope, wrong HTML element</option>`

`<a href=”#”>no link</a>`

Button, ng-click, there are many more ways this can be done incorrectly.

Semi-impt: internal links added with JS will __not__ get picked up until __after__ rendering

Not a cause for concern in most cases, though.

**Every file Google downloads will be aggressively cached; Google will ignore your cache timings.**

Duplicate content may be eliminated or de[[prioritize]]d from the downloaded HTML before getting rendered

 ^^RISK^^: esp with app shell [[model]]s, very little content and code may be shown in the HTML response

If multiple pages on the same site display the same code, or if pages display the same code on multiple websites, they may be treated as duplicates and not get rendered.

Here is when Google follows directives, and Google will follow the most restrictive ones by default (eg `noindex` overrides `index`)

3) Render

Where Google processes the JS and any changes to the DOM made by JS

How: Google uses a headless Chrome browser on the latest version

__There is no fixed timeout for the renderer__. What they are likely doing is something similar to what the public [Rendertron](https://github.com/GoogleChrome/rendertron) does. They likely wait for something like `networkidle0` where no more network activity is occurring and also set a maximum amount of time in case something gets stuck or someone is trying to mine bitcoin on their pages.

[source](https://[[ahrefs]].com/blog/javascript-seo/)

**WRS flattens the** [light DOM and shadow DOM](https://developers.google.com/web/fundamentals/web-components/shadowdom#lightdom). If the web components you use aren't using [<slot> mechanism](https://developers.google.com/web/fundamentals/web-components/shadowdom#slots) for light DOM content, consult the documentation of the web component for further information or use another web component instead. For more information, see [best practices for web components](https://developers.google.com/search/docs/guides/javascript-seo-basics#web-components).

**The renderer relies heavily on cached resources**

File versioning or fingerprinting to generate new file names when significant changes are forces Google to downloaded the updated version of the resource for rendering

What Googlebot sees

Googlebot doesn't take action on webpages (no clicks or scrolls or submissions, etc.)

As long as the content is loaded in the DOM without a needed action, Googlebot will see it

Eg - if the content is in the DOM but hidden, it will be seen

**If it's not loaded into the DOM until after a click, the content won't be found**

Googlebot doesn't paint pixels during rendering

Potential pitfalls that lead to differences in what Google sees

localized content

user-agent detection

When JS updates only parts of the DOM

lazy loading content

Using fragment URLs with hashes (#) instead of the History API

Renderer does not retain state across page loads so don't rely on data persistence to serve content.

Ensure that your application uses [feature detection](https://developer.mozilla.org/en-US/docs/Learn/Tools_and_testing/Cross_browser_testing/Feature_detection) for all critical APIs that it needs and provide a fallback behavior or polyfill where applicable.

Make sure your content works with HTTP connections (not WebSock or WebRTC)

Tools that show you (approximately) what Google sees

Why "approximately"?"

These tools have a 5-second timeout that the renderer doesn't

These tools pull resources in real-time, rather than cached like the renderer does

Screenshots in the tools show pixels painted, which Google doesn't see in the renderer

When are the tools useful?

To see if content is DOM-loaded: the HTML shown is the rendered DOM

Will show you resources that may be blocked and console [[error message]], which are useful for debugging

The tools

URL inspection in GSC

[Mobile-Friendly Test](https://search.google.com/test/mobile-friendly)

[Rich Results Test](https://search.google.com/test/rich-results)

Testing and troubleshooting

History API may be able to help update the state (?)

View-source shows what a GET request gives you (raw HTML of the page)

Inspect shows you the processed DOM after changes have been made and is __closer to what Googlebot sees__

Google cache is __not reliable__

A __quick__ test is to search for a snippet of your content in quotes.

An alternative: Dynamic rendering

There’s also the option of [Dynamic Rendering](https://developers.google.com/search/docs/guides/dynamic-rendering), which is rendering for certain user-agents. This is basically a workaround but can be useful to render for certain bots like search engines or even social media bots. Social media bots don’t run JavaScript, so things like [OG tags](https://[[ahrefs]].com/blog/open-graph-meta-tags/) won’t be seen unless you render the content before serving it to them.

How to make your JS site SEO-friendly

For on-page SEO, pay attention to: duplicate titles and descriptions, alt tags on images

Make sure crawling of resources is allowed

In robots.txt you can add the following:

`User-Agent: Googlebot Allow: .js Allow: .css`

Change URLs when updating content

This can be done with History API

Do not use hashes (#) for routing

Make sure canonical tags are set for pages to reduce duplicate content risk

For 404 error pages, you have a couple of different options:

Use a JavaScript redirect to a page that does respond with a 404 status code

Add a noindex tag to the page that’s failing along with some kind of [[error message]] like “404 Page Not Found”. This will be treated as a soft 404 since the actual status code returned will be a 200 okay.

JS frameworks __typically__ have routers that map to clean URLs

These routers usually have an additional module that can create sitemaps (eg - "React router sitemap")

You’ll want to lazy load images, but be careful not to lazy load content. This can be done with JavaScript, but it might mean that it’s not picked up correctly by search engines.

All from [[Martin Splitt]]

Notes from: [Make React apps discoverable in search](https://www.youtube.com/watch?v=rKgF0rf009c)

First step: mobile-friendly test

__Make sure links are all a tags__

Second step: make sure titles and descriptions are accurate and unique

To do this, you can use the `<Helmet>` component for title, URL, and metatags

Two ways of indexing: first doesn't run JS (indexing) and second (rendering) does, but may not happen (??)

if your content changes frequently or your site is large: make your content available in the first wave of indexing (without JS)

Other bots (besides Google) might not execute JS at all

Dynamic rendering: only serving pre-rendered to bots

Notes from: [How Google indexes JS sites](https://www.youtube.com/watch?v=LXF8bM4g-J4&list=PLKoqnv2vTMUPOalM1zuWDP9OQl851WMM9&index=2&t=0s) 

JS requires the rendering stage, Googlebot executes JS when rendering the page

But this rendering stage is expensive so it can't always be done immediately

Googlebot can execute JS on your site but it can take longer to appear or update in search

How long? Depends on many different factors and there are no guarantees

Testing and debugging JS sites for search

First step: mobile-friendliness test

Main purpose: shows potential issues with your site on mobile devices

For testing local env, use a tool like ngrok.io to get a publicly available URL

Once the test is completed, you'll see:

a screenshot of your page as Googlebot's smartphone crawler would see it

the page's rendered source code

 if some of the content is missing or the page doesn't render the way you'd expect you can check recommendations

or you can dive in deeper by looking at the detailed report that shows which resources have been loaded and all JS blocks

You should also use GSC

Shows which pages are indexed by Google search

URL inspection shows individual page data

Also, Lighthouse (esp. for speed)

Dynamic Rendering (best for SPA with high frequency of changing content)

Deliver client-side to users, while pre-rendering for crawlers

How to: {{[[video]]: https://www.youtube.com/watch?v=CrzUP6MmBW4&list=PLKoqnv2vTMUPOalM1zuWDP9OQl851WMM9&index=9&t=0s}}

Deploy rendertron

Set up cache

Install express and rendertron middleware

Write small express server to host webapp

Add rendertron middleware and use default user agent list, but also add googlebot to also use it for google search

Set up the middleware

Request the SPA so that the cache can serve pages without waiting for the headless browser to run

From https://rubygarage.org/blog/seo-for-react-websites

Dynamic rendering: only serving pre-rendered to bots

Pre-rendering isn't great for pages with frequently changing data b/c they need to be rebuilt every time content is changed

[[Meetings]]: 

Attendees:: [[aaron crootof]] [[harold sipe]] [[kenneth daily]]

Time:: 14:05

Notes::

 Google is not reading a single React site

Rendering React

Static rendering is the best

React = client-side = google crawlers has to render

# Sam's understanding of React SEO

## Rendering

Any of the following __should__ make a React app crawlable: server-side rendering, static rendering, prerendering, hybrid rendering and dynamic rendering

Note - not sure if there is some redundancy here.

React-related SEO issues tend to occur when all of the rendering happens in the browser or client side.

Eg - social media bots don't run JavaScript, so things like Open Graph tags won’t be seen unless you render the content before serving it to them.

Image

![](https://[[ahrefs]].com/blog/wp-content/uploads/2020/06/google-rendering-on-the-web-infographic.jpg)

## How does Google crawl and index?

![pasted image 0](https://[[ahrefs]].com/blog/wp-content/uploads/2020/06/pasted-image-0.png)

1) Crawler sends GET requests to server, which responds with headers and contents of the file.

This is the same content that's shown when you view the `source` of a page. It's essentially the raw HTML (this is in contrast to using the inspector, which shows you the processed DOM after changes have been made and is __closer__ to what Googlebot "sees")

2) During processing, Google pulls out **links** to other pages and files needed to build the page and adds them to the crawl queue.

Google can pull resources links (CSS, JS, etc.) from `<link>`, but links to other pages need to be '<a>'

Examples of link markup that works or doesn't:

Link markup that works:

`<a href=”/page”>simple is good</a>`

`<a href=”/page” onclick=”goTo(‘page’)”>still okay</a>`

Link markup that does not work:

`<a onclick=”goTo(‘page’)”>nope, no href</a>`

`<a href=”javascript:goTo(‘page’)”>nope, missing link</a>`

`<a href=”javascript:void(0)”>nope, missing link</a>`

`<span onclick=”goTo(‘page’)”>not the right HTML element</span>`

`<option value="page">nope, wrong HTML element</option>`

`<a href=”#”>no link</a>`

Button, ng-click, etc...there are many more ways this can be done incorrectly.

Note: Every file that Google downloads will be aggressively cached; Google will ignore your cache timings.

Duplicate content may be eliminated or de[[prioritize]]d from the downloaded HTML before getting rendered.

This creates a risk, especially with app shell [[model]]s, because very little content and code may be shown in the HTML response, which would lead to thin or duplicate content.

3) Rendering done by WRS (web rendering services)

This is where Google processes the JS and any changes to the DOM made by JS

How? Google uses a headless Chrome browser on the latest version

__There is no fixed timeout for the renderer__. What they are likely doing is something similar to what the public [Rendertron](https://github.com/GoogleChrome/rendertron) does. They likely wait for something like `networkidle0` where no more network activity is occurring and also set a maximum amount of time in case something gets stuck or someone is trying to mine bitcoin on their pages.  [source](https://[[ahrefs]].com/blog/javascript-seo/)

**WRS flattens the** [light DOM and shadow DOM](https://developers.google.com/web/fundamentals/web-components/shadowdom#lightdom). If the web components you use aren't using [<slot> mechanism](https://developers.google.com/web/fundamentals/web-components/shadowdom#slots) for light DOM content, consult the documentation of the web component for further information or use another web component instead. For more information, see [best practices for web components](https://developers.google.com/search/docs/guides/javascript-seo-basics#web-components). 

Because the renderer relies heavily on cached resources, file versioning or fingerprinting to generate new file names when significant changes are made  forces Google to download the updated version of the resource for rendering.

Googlebot doesn't take action on webpages (no clicks or scrolls or submissions, etc.)

Googlebot doesn't paint pixels during rendering

If it's not loaded into the DOM until after a click, the content won't be found

## Common pitfalls

Link markup that does not work.

If JS updates only parts of the DOM.

Lazy-loading content (not images).

Using fragment URLs with hashes (#) instead of the History API.

Not having unique URLs, titles, descriptions for different pages. 

Blocking crawling of .JS or .CSS resources (often in robots.txt)

Relying on data persistence to serve content.

Renderer does not retain state across page loads.

Your application does not use [feature detection](https://developer.mozilla.org/en-US/docs/Learn/Tools_and_testing/Cross_browser_testing/Feature_detection) for all critical APIs that it needs and doesn't provide a fallback behavior or polyfill where applicable.

Your content doesn't work with HTTP connections.

Specific to 404 errors, you can use a JS redirect to a page that __does__ respond with a 404 status OR add a noindex meta robots tag to the page that’s failing along with some kind of [[error message]] like “404 Page Not Found.” (this will be treated as a soft 404, though, since the actual status code returned will be a 200 okay).

## Tools that can help you show (approximately) what Google sees

First, why "approximately"?"

These tools have a 5-second timeout that the renderer doesn't.

These tools pull resources in real-time, rather than cached like the renderer does.

Screenshots in the tools show pixels painted, which Google doesn't see in the renderer.

So when are the tools useful?

To see if content is DOM-loaded: the HTML shown is the rendered DOM.

They will also show you resources that may be blocked and console [[error message]], which are useful for debugging.

So what are the tools recommended by Google?

URL inspection in Google Search Console

[Mobile-Friendly Test](https://search.google.com/test/mobile-friendly)

