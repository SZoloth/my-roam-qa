Tags:: #SEO #[[[[content]] [[strategy]]]] #content #[[ADK SEO Process]]

Define [[Goals]] for content

Examples

Website traffic growth?

Number of qualified leads in the sales pipeline?

form conversions, email subscriptions, sales (online and offline)

Engagement

Comments, shares, forwards, links

Greater share of voice / awareness?

Positive brand perception among potential customers? Existing customers?

traffic, views, downloads, social shares, referral links

From [[Blogging for business]]

Traffic is often really just a vanity metric (unless your business is ad-driven)

Primary goal should be acquiring new customers by bringing in highly targeted audiences

What is your organic customer [[funnel]]?

Eg - 

Visit

Subscribe or download

Purchase

Need to look at different attribution [[model]]s (first-touch attribution) and multi-channel [[funnel]]s

Source:: [See Think Do Care Win](https://www.kaushik.net/avinash/see-think-do-care-win-content-marketing-measurement/) by [[avinash kaushik]]

Page depth

Per visit goal value

% Assisted conversions

Visitor loyalty

Conversion rate

Profit

Source:: [Track content engagement with GTM](https://www.simoahava.com/analytics/track-content-engagement-via-gtm/) by [[Simo Ahava]]

Has a recipe for measuring on page engagement with GTM scripts, a calculated metric, and a custom report

Source:: [Track content with enahnced ecommerce](https://www.simoahava.com/analytics/track-content-enhanced-ecommerce/) by [[Simo Ahava]]

