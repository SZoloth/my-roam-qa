[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} #ADK Marketing Plan #//

{{[[DONE]]}} Schedule some time with [[Dan Tatar]] and [[chris baker]] to propose next round of investments (Summer Campaign) #Inbox

Internal / Lifecycle Marketing

Referrals, upsells, email marketing, staying in front of current partners

Notes: Brand-building, awareness, 2x or 3x our content

Interviews with clients

Focus on creative projects and products

What works in sales? Taking over legacy technology about 6-12 months before they're ready to build the new thing #[[Inspiration for ADK]] #[[Selling ADK Group]]

{{{[[DONE]]}}}} What to do with new [[ADK Marketing Assets]] from [[Dan Tatar]] #//

Inspiration - study and ask

Targets

**[EPAM](https://www.epam.com/)**

**Tools** & research

No Google Ads

Strategies / offerrings:

Software products (eg - reportportal.io & https://www.epam.com/drillpad)

Homepage

Positioning statement

Recent news (slider)

**Services (links)**

Content grid (case studies, blogs, news, etc.)

**Social proof - Results**

Social proof - # of partners (not clients)

[[[[career]]s]]

Contact

Locations

**Brands**

Channels from `how did you hear about us?`

Event, Industry analyst, client reference, partner, search, social network

drafting press releases about our work with Global 2000 clients and pitching tech bloggers and trade reporters about our technology capabilities and industry expertise. I work with my global team to develop content for clients, lead generation, industry events and internal employees (in the form of case studies, brochures, white papers and thought leadership blogs).

websites, whitepapers, accelerators, one-pagers, flip books, PowerPoint presentations, investor decks, and trade show materials, and Instagram standards (internal and external).

Facebook

389 blogs

**[Ness Engineering](https://www.ness.com/)**

Homepage

Positioning statement

5 links to content

Solutions/Areas of expertise

Capabilities

Social proof (analysts)

[[[[career]]s]]

Contact

HubSpot

195 blogs

social media strategies, articulating Ness's vision

linkedin ad?

**[[[Slalom]]](https://www.slalom.com/)**

Homepage

Positioning statement + link to thoughts on current events

Another positioning statement (more literal)

News (reaction to BLM)

Case studies

Tech partners

About [[Slalom]]

Blogs

Contact 

google ads

management, boutique, strategy consultants

facebook

[[pardot]]

linkedin [[webinar]] ads

branded packages/products: https://www.Slalom.com/moonshot

Notes from iv with sangeeta prasad

One is clearly articulating who we are and why we are different. We need to articulate this in a simple, clear way so people can remember it.

Tried off-the-wall stuff (similar to [[Migrate with nate]]) like cartoons

https://www.russellreynolds.com/[[insight]]s/the-99th-floor/pages/default.aspx

comparison/sales pages

https://www.[[Slalom]].com/[[insight]]s/why-hire-consulting-firm-marketing

**Dept**

Homepage

Positioning video

About us

Case studies

Services

About us

Blog

[[[[career]]s]]

Offices

Google ads

facebook

[[pardot]]

linkedin ads

whitepapers

https://www.deptagency.com/en-gb/download/whitepapers/how-b2b-manufacturers-can-quickly-launch-d2c/?utm_source=linkedin&utm_medium=cpc&utm_campaign=gb-download-wp-b2b-d2c

https://www.deptagency.com/en-gb/download/whitepapers/cms/?utm_source=linkedin&utm_medium=cpc&utm_campaign=gb-download-wp-cms-2020

covid tracking app

case studies

video case studies

maybe worth reading: https://www.deptagency.com/case/achieving-double-digit-growth-via-a-full-[[funnel]]-media-strategy/

WhatsApp newsletter - via text

partnerships with google, amazon,salesforce, sitecore

**Cognizant**

Homepage

All content

linkedin ads

campaigns/branded packages with: landing page, white paper, [[webinar]]

google ads

ton of content (208 + 224 )- ~300 monthly organic traffic

[[pardot]]/[[marketo]]

**Accenture**

Technology homepage

Brief position

COVID service

COVID content

About us

Services

Partners

Case studies

Blog

Awards (analysts)

News

[[[[career]]s]]

linkedin ads

hub pages like: https://www.accenture.com/fi-en/about/company/coronavirus-business-economic-impact

SEO hub pages: https://www.accenture.com/us-en/[[insight]]s/artificial-intelligence-summary-index

ton of organic traffic

1,150 "[[insight]]s" --> content MACHINE

huge google ads spend on very TOFU keywords (what is single payer healthcare, customer loyalty programs, single payer healthcare)

**Willowtree Apps**

Homepage

Positioning + client logos + contact CTA

Blogs

Case studies

About (case studies, [[[[career]]s]], about us)

About

Services

Download report

Tech partners/certifications

Content (analyst review + blog post)

Portfolio/Contact

facebook + hubspot

linkedin ads

analyst report

whitepapers: frameworks, templates, [[model]]s, [[webinar]]s

**PDFs to lead gen ads**

also a lotta SEO - 2.2k monthly traffic

438 blogs

For [[SEO]] [[career]]

- I was brought into WillowTree to develop SEO as a new practice discipline within the lifeblood of WillowTree.

- Developed & actively managed technical SEO documentation for web engineers, technical requirements managers, test-engineers.

- Built out SEO best practice guidelines for content development, research & strategy, and other teams.

- Developed & conducted new SEO training for adoption across multiple departments over 3 office locations.

- Built and oversaw technical SEO requirements and their implementation for existing and greenfield client projects

- Worked with client stakeholders to ensure SEO was aligned with their business [[outcome]]s, and helped facilitate client's internal workflows adapted to SEO best practices.

- Aligned with internal project engineering, design, and strategy teams to present project & SEO status updates for client executive team.

- Coached business development teams on selling SEO as a service and assessing websites of new & existing prospects.

Thoughtbot

Homepage

Positioning + CTA

Case studies

Services

Service highlight

Clients

Testimonial + case study

About

Industry highlight

Resources

Contact

google ads

hubspot

37,000 organic traffic. wow.

also a content machine - 1,417 posts but also videos, podcast, etc.

side projects

relevant 'nar: https://thoughtbot.com/events/website-redesign-workshop

follow up with automated emails

linkedin ads: [[webinar]]s, case studies,

Process

What can we learn from **tools** like [[ahrefs]], Wappalyzer, etc. 

**Sign up** for dummy account & review 

Take note of "how did you hear about us"

Are there any **case studies about** the company?

Are there any **interviews** with leadership about growth?

Reach out to people

[[refine labs]] process

CRM / lead nurture

social media ads and adwords

email marketing

content strat

[[thoughtbot]] process

Summary:: (review for [[ADK Website Rebuild]]) #Inbox

Started with an audit

Voice and tone

Design

Accessibility

Established main buyers profile

Interviewing past clients

Building profiles

What is our differentiator

What do we do, what's the value we provide?

How does that impact who our brand is?

Conducted timeline-based jobs to be done style interviews

Establish and document long-term website [[Goals]] and success metrics

What is the site manifesto?

Metrics: bounce rate, conversion on forms, session duration, pages per visit, organic sessions

[Document voice and tone](https://thoughtbot.com/playbook/our-company/brand/voice-and-tone)

[[outcome]]s and thoughts

Invest in smart content - some SEO, some thinkboi, some downloadables

blog a lot about what we know - tap internal teammates (see email to #[[chris baker]] ) 

what blogs did i promise a little while ago (guide to custom apps? or something?) #[[ADK content]]

our playbook

https://thoughtbot.com/playbook

referrals: https://www.quora.com/What-is-best-web-development-firm-in-Boston-and-what-does-their-pricing-look-like

promote case studies, services, blogs on linkedin & google ads

retarget to relevant case studies or services

what are our unique advantages?

some have other sites our products, others have branded packages ("moonshot")

Most have 200+ blogs

"why hire X" type blog posts

[[Slalom]] CMO is known for trying off-the-wall things, like a comic strip for insurance

Dept leverages partnerships & PDF downloads

Cognizant has ~400+ blogs, but ~300 monthly organic traffic

accenture has 1000+ [[insight]]s and drives traffic to these TOFU / info 

willowtree has 438 blogs and a ton of monthly traffic (2.2k)

As a team, we rally around three distinct areas in the client journey map: Prospecting, Pursuit, and Expansion. A few responsibilities across our team include: identifying new relationships and opportunities, nurturing ongoing relationships with client stakeholders, contracting agreements, writing proposals, pitching our services to prospective clients and more!

Our newly formed Marketing team works closely with Business Development and other WillowTree teams on B2B initiatives, thought leadership programs, social media, our WillowTree website, and more! Our team drives client flow, awards, and potential candidates to WillowTree.

"[[insight]]s Reports"

that bring current thinking and clear definition to problems that many leaders are tackling. Customer Experience continues to be a hot topic and for good reason, 80% of customers say CX is as important as a company's product or service.

thoughtbot has 1500 blogs and 37k organic traffic

Over the next 5 days - pour gas on sales and marketing like crazy

Pouring gasoline

Case studies, services, blogs: AW, display, LinkedIn, Retargeting

Content

$7k / mo for Growth Machine

Google ads

Custom apps

Websites

Drupal

Design

[[ADK Website Rebuild]] #Inbox

{{[[DONE]]}} for [[ADK Website Rebuild]] The content priority right now is determining the shape of industries v. “tech solutions” — and how we want to handle conceptually. ([ticket link](https://adkgroup.atlassian.net/browse/ADKWPW-31))

{{[[DONE]]}} Strategize and brainstorm for [[ADK Website Rebuild]] around:

{{[[DONE]]}} Need to come back with POV on best strategy for targeting Cambridge [[Sleeping Dog Properties]] [[[[Sleeping Dog Properties]] Marketing Strategy]]

Assess difficulty/competition of cambridge

{{[[DONE]]}} hey! just wanted to follow up on [[MIT PEL]] #analytics -- did you/team have a chance to review the custom analytic tags that we set up? 

{{[[DONE]]}} Reach out to [[shareon begley]] author of STAT news article about COVID-19

{{[[DONE]]}} Set up GA filters for #APCIA ([ticket](https://adkgroup.atlassian.net/browse/AP-2479))

{{[[DONE]]}} Review comments from [[shae allison]] re: #APCIA

{{[[DONE]]}} Review [[Tim Lupo]]s [[feedback]] on case studies for #[[ADK content]] & share with [[Sanjay Salomon]] #/

{{{[[DONE]]}}}} For [[July 13th, 2020]]: work through #[[LMT Managing]] list #Inbox #///

:hiccup [:hr]

[[Meetings]]: [[ADK Website Rebuild]]

Attendees:: [[jayne hetherington]] [[michael connors]] [[maggie o'connor]] [[shae allison]]

Time:: 3:00pm - 3:21pm

Notes::

{{[[DONE]]}} How are the table of contents for articles currently created? automatic or manual?

[[Meetings]]: [[Selling ADK Group]] regroup

Attendees:: [[ben kaplan]] [[jordan daly]] [[nick watkins]] [[darci nevitt]]

Time:: 3:30pm - 4:20pm

Notes::

Is it worth it to engage the wider team in sales/marketing efforts to position everyone as experts? What's the ROI? If positive, what's phase 2?

Proposal:

Squads with squad leaders

Next steps

Define:

Cadence

Content 

Investment

Ask team how they want to engage - 

What would make you most likely to engage?

What are your consumption habits?

What content have you shared in the past?

What's holding you back from posting?

open email newsletter

aggregates interesting content

requests links to be featured

q&a

share

Aside:

LinkedIn strategy

:hiccup [:hr]

#[[wish list]] [Tevas](https://www.teva.com/men-sandals/terra-fi-5-universal/1102456.html?dwvar_1102456_color=GBRC#start=1&cgid=sale) 

