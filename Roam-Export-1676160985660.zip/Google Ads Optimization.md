Tags:: #[[Google Ads]], #[[Google Ads Report]]

Important to remember

[[🏔ADK [[Task Management]]]] for [[Google Ads Optimization]]

{{{[[DONE]]}}}} Create a log

{{{[[DONE]]}}}} Run thru basic optimizations #//

{{{[[DONE]]}}}} Sketch landing pages #//

{{{[[DONE]]}}}} Create a more proximate conversion to optimize towards #//

**Process for optimizing**

**Create a log**

Include what you changed & why

## Review every time

**Review Search Terms**

When: every time

Time range: last period to today

To **find & add negative keywords**

Campaign -> Ad Group

Review **search terms**

Select keywords that are off topic or too low on ladder

Add as negative keywords to campaign

Make the negative keyword as broad as possible

Trim down to just the offending word(s)

Click save and repeat for all ad groups

To **find positive keywords**

In search terms, select all keywords relevant to your product that you aren't already targeting

Click add as keyword (just not as broad match)

Save

**Optimizing keywords**

When: every time

Time range: at least the last 14 days

Adjust current keywords

If manual bidding

look for keywords **below the first page bid** & increase if it's not outrageously high relative to your CPA and conversion rate

look for well-performing keywords that are not at the max **search impression share** (column) increase the bid (and budget)

if a keyword is performing OK or poorly, check if any devices or demographics are performing well in the ad group and narrow to those

if no segment is performing well, reduce the bid

if, after a couple of weeks of optimizations, the kw is still performing poorly & you've already spent more than your target CPA since making major optimizations, pause it entirely

If on automatic bidding, Google will handle individual optimizations and bidding

Pause any keywords that consistently cost more than your target CPA

Add more keywords

Keep on the lookout for new keywords and ad groups to test

Create new landing pages

If some keywords perform better than others it might be worth creating a landing page that focuses on those keywords

This increases Quality Scores & hopefully conversion

Once you build the new page, duplicate your best performing ads and point them there

Set a reminder to review these

**Optimizing Ads**

When: every time

Time range: at least last 14 days

Procedure: look at (a) how Google has [[prioritize]]d ads (b) their relative performance and use that to make new ad copy variations

Pause ads that Google basically stopped showing and create variations based on the top performers

Steps

Sort the ads in an ad group by ascending **% served**

Turn off those with <5-10% Served

Sort by descending **Cost**

Look for ads with high cost and low conversions

Pause them if others are performing > 20% better

Sort by ascending Cost / Conv

Duplicate top performers and make a change to one or more of the parts of the ad (description, headline 2, display URL path, etc.)

Add any entirely different variations you can think of inspired by the best performers

**Quality score**

When: every time

Procedure: Quality score

Made up of

**CTR**

**Landing page experience**

Ad relevance

Landing page exp. below average?

Check: speed, relevance, clarity, engagement (GA filter by paid traffic)

Ad relevance below average?

Check: keywords too broad, keywords in the group not grouped tightly enough, keyword used in ad copy

Expected CTR below average?

Check: ad copy

**Ad Groups**

When: __check__ every time, but only edit as last resort

If after optimizing search terms, targeting, keywords, and ads the ad group isn't working, pause it

If some ad groups are significantly outperforming others, try creating a specific landing page to the underperforming group

**Campaigns**

When: __check__ every time, but only edit as last resort

Only if all the ad groups are failing or you want to [[prioritize]] a better performing campaign

## Review once a month

**Ad extensions**

When: Once a month

Time range: at least 30 days

Even if added originally at the account level, you'll want to optimize at campaign/ad group

^^**important:**^^ note the avg cost per conversion for each campaign/ad group you optimize extensions scream to tell whether the new one led to better or worse performance

Procedure

Go to campaign or ad group

Take note of average CPA for the campaign or ad group

Click ads & extensions in left nav

Click Extensions

Make note of the avg CPA for extension types by scrolling down to bottom and looking at cost/conv

Pick an **extension type** (eg - callout)

Make a list of the best performing extensions (CPA, ROAS)

Add these directly to the campaign/ad group

This will override all of the extensions added at the account level for this campaign/adgroup so only the selected top performers show for it

Come up with variations of the top performers and add them to the campaign/ad group directly

Repeat for all other extension types you have running

Repeat for all other campaigns/ad groups

**Demographics, location and ad schedule**

When: Once a month

Time range: at least 30 days

Procedure

Select an ad group (campaign if optimizing locations)

Change time range to at least 30 days

Click on **Demographics, Location** or **Ad schedule** in the sidebar

Optimize

If bidding manually: adjust bids up or down depending on relative performance

If bidding automatically: turn off what consistently costs more than your target CPA

Repeat for the other categories (including **Age, Gender, HHI** and Combinations)

Repeat for all other campaigns/ad groups

**^^important:^^**Consider breaking out different demographics and locations into separate campaigns and ad groups if theres a drastic difference in performance

Also gives you greater control over budgets, keywords, ad copy, and landing pages for the different segments

**Device**

When: Once a month

Time range: at least 30 days

Procedure:

Select ad group

Change time range to at least 30 days

Click **Devices** in sidebar

If one of devices is performing significantly worse, test your landing page with that device

If it's **__not__** a usability issue, optimize normally and consider turning off or lowering bids on that device

Other notes

**What is the alpha-beta campaign structure?**

Alpha-beta is our preferred structure. It’s where you have two campaign types: one that uses BMM keywords, and the other that uses exact match keywords.

The exact match keywords greatly increase the Quality Score of your ads and therefore perform much better. The BMM campaigns mine for longer-tail keywords that perform well so that they can then be added to the exact match campaign equivalent (and added as a negative keyword to the BMM campaign).

We find this structure greatly improves Quality Score and overall account performance. The BMM helps with discovery while the exact match assures the lowest CPA’s and highest volumes.

We recommend using this structure whenever possible.

Running Log

[[[[Google Ads Optimization]] Log]]: [[July 24th, 2020]]

**Drupal**

Data

Spent: $146.15

Impressions: 763

Clicks: 6

CTR: 0.8%

CPC: $24.36

Added a new ad specifically targeting the most-searched keyword (drupal hosting). If this doesn't improve CTR will pause that keyword.

**Action item**: I know there was a desire to pour gasoline on here. Drupal has a relatively limited [[scope]] (relatively small # of people searching for it). If we're ok with website leads that may not be Drupal (eg - WordPress leads), I can add an ad group targeting broader terms (eg - "web agency," "website developers", etc.) for people that don't know they need Drupal.

**Design for FTS**

Set up a structurally similar campaign, except targeting design related terms and driving to relevant [fts.com](http://fts.com/) pages.

With a budget of $200/day the predictions for August are:

45k impressions

1.4k clicks

$2.5k spend

3.0%

avg CPC: $1.83

**Action item: **If that budget's approved I can get it going.

[[[[Google Ads Optimization]] Log]]: [[August 4th, 2020]]

Reporting period: 07/27/20 - 08/03/20

Data:

**FTS Design Campaign**

Launched, so no WoW comparison data

Campaign data:

Spend: $1,560

Impressions: 21,600

Clicks: 247

CTR: 1.14%

CPC: $6.30

CPL: $1,560

Lead = Aishwarya Easwaran, looking for a UI designer for a website / learning platform (Project Starquest)

Ad groups

UX Design Agency

Website

UI Design Agency

Digital / Generic (eg - "product design companies", "design agency")

Mobile App Design

**Drupal campaign**

Campaign data:

Spend: $1,260

Impressions: 657

Clicks: 21

CTR: 3.2%

CPC: $59.85

CPL: N/A

Ad groups:

Shifted down to just Drupal + developers, services, agency

**Testing campaign**

Recently launched: "Website developer", "Accessibility & Compliance", "Digital agency", "Mobile app developer", and "Web app developer"

Too early to tell

Immediate next steps:

Continue adding negative keywords

Refresh ads

Future next steps:

Review search terms for keyword opportunities

[[[[Google Ads Optimization]] Log]]: [[August 6th, 2020]]

Ideas:

Ad group for case studies 

Ad group for marketing

{{{[[DONE]]}}}} Add extensions, sitelinks, etc.

Get interesting people to talk about relevant subjects

Shift to alpha-beta?

Campaign:: ADK - Proving Ground

All:

Added extensions

Ad Group:: Accessibility & compliance

Notes:: 

Likely too many commoditized results

Landing pages very transactional

Opportunity to differentiate?: discuss your problems, with real people, talk to someone, get a manual review 

Search terms::

Changes::

Added:: 

search terms are phrase match keywords

Removed:: 

training

checker

color

limit 

Ads::

Added new headlines to the RSA

Added new expanded text ad

Quality score::

web accessibility standards

low CTR --> ad copy 

web accessibility design

ad copy + landing page

web accessibility audit

ad copy + landing page

ada website compliance lawsuit

ad copy

Ad Group:: Digital agency

Notes::

Showed up for an "automotive digital agency"

automotive digital agency

may be too niche/templated (like hospitality)

Most results for "digital agency" are digital **marketing** agencies

We can differentiate by saying full service, not just marketing, etc.

city-based searches: should we just target local? 

"choosing a digital agency" is an interesting angle 

how to choose the right digital agency - a guide

what is a digital agency?

a couple of searches for pages (pricing, about us)..

Search terms::

Changes::

Added:: 

"digital agency" +in +boston

"digital agency" +in +louisville

digital strategy agency

full service

full stack

Removed::

advent health provider

dublin

templates

australia

price sheet

what does digital agency do

Ads::

Added expanded text ad

Add new headlines to RSA

Quality score::

Pretty much __definitely__ need a new landing page

Ad Group:: Mobile app

Notes::

Note enough data for search terms

Search terms::

Changes::

N/A 

Ads::

Added headlines to RSA

Added a new expanded text ad

Quality score::

"top mobile app development companies" landing page irrelevance

Ad copy improve for CTR

Ad Group:: Web app

Notes::

Add PWAs --> new ad group?

Search terms::

Changes::

Added::

+progressive +web +app +designer

+progressive +web +app +developer

Ads::

Added a PWA specific expanded text ad

Quality score::



Ad Group:: Website developer

Notes::

Differentiation: small teams. full stack. design, strategy, dev

Search terms::

Changes::

Added::

Removed::

jobs

netherlands

wix

portfolio

how to become

how to find clients

pakistan

free

freelance

summary text 

reddit

course

work as

philippines

India

tools

conference

Ads::

Added new headlines to RSA

Added a new ad

Quality score::

Could improve the landing page

The expected CTR is consistently low 

[[[[Google Ads Optimization]] Log]]: [[August 10th, 2020]]

New structure launched

C: web sites

web design

web design agency

web design company

web design firm

website design agency

website design company

website design firm

web design experts

website design experts

web development

web development agency

web development company

web development firm

website development agency

website development company

website development firm

web developer experts

website developer experts

C: design

UI/UX design

UI design agency

UI design company

UI design firm

UI design experts

UX design agency

UX design company

UX design firm

UX design experts

UI/UX design firm

UI/UX design agency

UI/UX design company

UI/UX design experts

C: web apps

web apps design

web app design agency

web app design firm

web app design company

web app design experts

web apps dev

web app development agency

web app development firm

web app development company

web app development experts

pwa design

progressive web app design agency

progressive web app design firm

progressive web app design company

progressive web app design experts

pwa design agency

pwa design firm

pwa design company

pwa design experts

pwa dev

progressive web app development agency

progressive web app development firm

progressive web app development company

progressive web app development experts

pwa development agency

pwa development firm

pwa development company

pwa development experts

C: mobile apps

mobile apps design

mobile app design agency

mobile app design firm

mobile app design company

mobile app design experts

mobile apps dev

mobile app development agency

mobile app development firm

mobile app development company

mobile app development experts

native app development agency

native app development firm

native app development company

native app development experts

C: digital

digital product design

digital product design agency

digital product design firm

digital product design company

digital product design experts

digital product dev

digital product development agency

digital product development firm

digital product development company

digital product development experts

software design

software design agency

software design firm

software design company

software design experts

software dev

software development agency

software development firm

software development company

software development experts

digital agency

digital agency

digital strategy agency

digital firm

full service digital agency

full service digital firm

C: competitors

website design

jumping jackrabbit

website development

thoughtbot

appnativ

Paused

ADK - Proving Ground

Drupal: Search Network

FTS - Design

Remaining

C: digital

need landing pages:

software design

software dev

C: web sites

hosting & maintenance

C: competitors

[[[[Google Ads Optimization]] Log]]: [[August 11th, 2020]]

Added non-MA and KY state/city names to negative keyword list

Reasoning: we can't compete as well with people looking for agencies in specific locations

