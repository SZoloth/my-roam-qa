To improve [[apartment]], improve my [[backyard]]

Ways to improve [[backyard]]

[[gardening]]

[[outdoor furniture]]

Notes on improving my [[backyard]]

[[NOTES for SEO tactic: Glossaries]] blog post 

Using [[Roam Course Notes]]

#[[Quick Capture]]

for [[backyard]]: hammock, vine, chair 

