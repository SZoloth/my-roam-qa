Tags:: [[ADK Website Rebuild]]

Pomo::

{{POMO}}

{{POMO}}

{{POMO}}

+7:26

{{POMO}}



Inspiration

**[[Slalom]]**

What We Do

Who We Are

[[insight]]s

[[[[career]]s]]

**[[Slalom]] Build**

About

Our Work

What We Do

[[[[career]]s]]

Build As a Service

Sub-nav

The Blueprint

News

**Upstatement**

Work

Who We Are

Contact

Sub-nav

Services

Jobs

Events

Engineers

**Metalab**

About

[[[[career]]s]]

Contact

Blog

__Note__: The homepage is just a list of case studies

**Thoughtbot**

Services

Case Studies

Resources

Our Company

**Rightpoint**

Work

Thought

Company

Solutions

[[[[career]]s]]

**Ness Digital Engineering**

Solutions

Capabilities

Approach

About Us

[[insight]]s & News

[[[[career]]s]]

Contact Us

**Rootstrap**

Services

Our Work

About Us

Blog

Needs for ADK

Services / Solutions / What We Do

Design

UX Design

UI Design

Customer Research

Design sprints

Discovery

Development

Websites

Web applications

Mobile applications

Managed hosting & maintenance

Growth

[[[[product]] [[strategy]]]]

SEO

Analytics

Content marketing

Performance marketing

Conversion Rate Optimization

Integrated

Digital Transformation

Custom applications

Customer Experience

CTO in a box

Spatial Computing 
(AR, VR, MR, XR)

Smart eCommerce

Digital Manufacturing & IoT

Startups

CTO in a box

Hiring

Launch/Go-To-Market

Industry Specialization

Healthcare and Life Sciences

Manufacturing

Higher Education and Education Technology

Financial Services

Legal services

Insurance

Non-Profit

SaaS and High-Tech

Food and beverage / Consumer goods

Social Media

Work / Our Work / Case Studies / Portfolio

Services

Design

Build

Grow

Integrated

Industries

About / Who We Are / Company

Company / Mission / Purpose

Mission / Purpose / Story

Team

Awards

Locations

Our Approach

[[[[career]]s]]

[[insight]]s / Resources

Articles / [[insight]]s

Whitepapers

Contact

Can we group case studies by solutions?

High volume content

Resources

Option 1: content type

Articles or [[insight]]s

Guides

Videos

Option 2: audience

Site owners

App owners

Marketers

Product owners

Option 3: categories

Design

Development

Marketing

Blogs

Case studies

SEO landing pages

specific pages, with internal linking

Missing services

Holistic

Digital transformation 

Customer experience

Cutting Edge / High tech

Spatial computing

Smart Manufacturing and IoT

Startup bundle

CTO

Hiring

Launch

Custom applications

Drupal

**Are these sections of content on a page or separate pages? (partially dependent SEO needs and content requirements)**

Do we want to surface sub navigation through a nav menu or in-page content?

Meeting check in with #[[jayne hetherington]], #[[jenna bantjes]], and #[[chris baker]] on [[June 2nd, 2020]]

"Portfolio" sounds small - what about "work" or "case studies"?

