Author:: [[sloanreview.mit.edu]]

URL:: https://sloanreview.mit.edu/article/with-[[Goals]]-fast-beats-smart/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 22nd, 2020]]

[[Goals]] can drive strategy execution but only when they are aligned with strategic priorities, account for critical interdependencies across silos, and enable course corrections as circumstances change. 

[[Goals]] should be embedded in frequent discussions; ambitious in [[scope]]; measured by specific metrics and milestones; and transparent for everyone in the organization to see. 

OKRs consist of two parts. Objectives are short descriptions of what you want to achieve. 

The power of specific, ambitious [[Goals]] to improve the performance of individuals and teams is one of the best documented findings in organizational psychology, and has been replicated in more than 500 studies over the past 50 years. 

Compared to vague exhortations like “Do your best,” a handful of specific, ambitious [[Goals]] increases performance of an average team or individual to the 80th percentile of performance. 

Adding a set of metrics for each goal and providing frequent [[feedback]] on progress can further improve results. 

