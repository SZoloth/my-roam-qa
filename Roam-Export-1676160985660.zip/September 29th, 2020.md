[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} [[React SEO]] and [[Screaming Frog]] testing

Resource: [[Screaming Frog]] [article on crawling javascript websites](https://www.screamingfrog.co.uk/crawl-javascript-seo/) with a **client-side approach**

To configure, click on the Configure dropdown in the top bar

Robots.txt > settings > Ignore robots.txt but report status

This means it should be able to crawl behind staging sites blocked by robots.txt directives like `Disallow`

Set user-agent to Googlebot (Smartphone)

Set up API access: Google Search Console, Pagespeed [[insight]]s

Spider > Rendering and change "Rendering" to "Javascript"

Spider > Crawl > ensure all resource links are ticked

If resources are on a different subdomain or root domain then `check external links` should be ticked

Spider > Extraction > tick boxes for store HTML and store rendered HTML

SF can crawl thru the normal authentication we have on staging, but you need to manually enter the credentials within SF

SF can __also__ crawl through webform authentication but **this is dangerous**

To crawl any site with [[Screaming Frog]] that has a webform authentication, you'll need to create a user with **read-only access** and use that info to [[Log in]]

Why read-only? [This post](https://www.screamingfrog.co.uk/crawling-[[password]]-protected-websites/) goes into more details, but basically [[Screaming Frog]] will click on __every__ link indiscriminately, meaning it can mess up the site. 

To read

The AJAX tab includes only pages using the old AJAX crawling scheme specifically, not every page that uses AJAX

Outlinks will not exist if they cannot be rendered or seen

Review the `Blocked Resource` filter in the Response Codes tab: if JS, CSS, or images are blocked by robots.txt this will impact rendering, crawling and indexing.

For the tests

One normal WP site (SDP, Wasabi)

React site or components: APCI.org or Prolearn.mit.edu or bostonschoolfinder.org

[[Meetings]]: [[React SEO]]

Attendees:: [[aaron crootof]] [[harold sipe]] [[kenneth daily]]

Time:: 11:31

Notes::

 Solution for [[APCIA]]: hybrid



{{[[DONE]]}} Prep for [[OKR]] workshop #/

My own OKRs for team and self:

Team OKRs

Brainstorm

Buckets

Build ADK brand and awareness

Content Strategy

Refine Labs

Focus on mHealth

Processes + Operations

Organization support

Drupal CMS design?

(React) SEO 

(React) Analytics

Braindump

Position ADK as the leader in mid-market and healthcare end-to-end product development

Create an [Atlas](https://stripe.com/atlas) or [Growth Masters](https://growth.segment.com/) for digital health

Publish the most engaged-with newsletter on digital health

Launch an awareness campaign around top 3 target hospital networks

Increase brand awareness for ADK

Increase branded organic and direct traffic to adkgroup.com by X%

Create an [Atlas](https://stripe.com/atlas) or [Growth Masters](https://growth.segment.com/) for digital health

Launch a co/partner marketing strategy ([[webinar]], podcast, etc.)

Zero project launches with an SEO or Analytics error

Publish our SEO process for websites

Publish our Analytics process for websites

Publish our Analytics process for apps

Define the ADK Agile Marketing Process

Zero project launches with an SEO or Analytics error

Develop a go-to-market product for ADK

3 clients using our A/B testing framework

ADK Marketing is the front door for all future engagements

Drive X new leads per month for ADK

Marketing member at 80% of kick off meetings

Increase branded organic and direct traffic to adkgroup.com by X%

ADK Marketing is the back door for all current and future engagements

Existing marketing retainers are set up for success with clear OKRs fit to their budgets

Existing clients have been identified and pitched on marketing retainers

Zero project launches with an SEO or Analytics error

Self OKRs

Brainstorm

Brain dump

Create a world-class analytics team

Develop a go-to-market product for ADK

Zero project launches with an SEO or Analytics error

3 clients using our A/B testing framework

Buckets:

Specialize in: 

~~Technical SEO~~

**Analytics**

A/B Testing and CRO

GTM

Focus on client wins:

Wasabi

Process + Operations

React SEO

React Analytics

Go to market

for mhealth

MVP

Meeting

Set up 

a shared Google Doc

Structure of the session

Intro

OKR for the meeting

Goal: 

No more than 3 team objectives with no more than 3 key results each

One individual/personal development OKR and 1-2 OKRs tied to the team OKRs

Level set: This is first time, won't be perfect. 

Set objectives: team

Present the proposed objectives (under the team mission/vision)

Now we need to discuss and [[prioritize]]

Reminder of what makes a good objective

Guiding questions

Does this feel like it has a finish line?

Is this feasible within our timeframe?

Is there a simpler way to say this?

Is this describing the problem to solve or the solution we’ll try?

Are these the most important problems we can solve?

Set KRs: team

For each Objective, brainstorm in shared doc to come up with the metrics of the KRs (don't worry about the actual number, you can use a placeholder like X%)

Guiding questions

Can we measure this today?

Is this metric fast-moving enough that we’ll see it change in our timeframe?

Is there a simpler way to say this?

Could this metric be confused with a similar one? Do we need to be more specific?

Once that's set for each Objectives, set the actual magnitudes

Assign owners for each KR --> these become individual O's

Final review: aim is to get everyone fully committed, even if they disagree

Guiding questions

Do you think these are possible in the timeframe?

Is it possible to achieve the objective without hitting the key results?

Is it possible to hit the key results and still not achieve the objective?

Next steps

How we'll track, when we'll check in 

[[Meetings]]: [[Drawbridge]] discovery presentatin

Attendees:: [[Jill Starett]] [[jayne hetherington]] [[alex fedorov]] [[mike ohara]] [[Carolina Escobar]] [[sean riley]] [[patrick o'quinn]] [[quin o'hara]]

Time:: 12:02

Notes::

[[Meetings]]: [[i[[mercer]]]] Google Analytics Migration

Attendees:: [[darci nevitt]] [[jordan daly]] 

From [[i[[mercer]]]]

[[stephanie henegar]]

product owner of imercer

[[angela davenport]]

marketing manager

[[geoff anderson]]

technical product manager imercer, content + publications

Time:: 12:59

Notes::

Have been working on GA for about a year

Nick + Jordan compared WebTrends + GA, ~5% difference 

Why are we here:

Visits, page visits, etc. declining

Reviewed historical data in WebTrends and its not matching anything

Numbers in WebTrends are much higher than GA (2x)

Filters, bots, blocking, etc. differences

Mercer implemented zscaler instead of VPNing

YoY revenue from the site dropped 50%

Never had confidence in GA revenue attribution -- **why?**

GA dramatically underreporting and not attributing it to campaigns

Known issue with WebTrends guest checkout path with a pixel that wasn't fire, is now

Tracking purchases by logged in user

GA was breaking on imercer [[Log in]] page because it wasn't on imercer domain

Maintenance pages are internal only

Corporate SSO [[Log in]], used by several applications

Just add to referral exclusion

GA is saying that the split between new/returning (75/25) users is very different from bounceexchange

Could this be because clients are no longer accessing from offices

Cookie [[expiration]] dates

[[Log in]] vs. guest user check out

User-ID

Not currently using UTMs

United Connect phone numbers? 

{{[[DONE]]}} Follow up on [[Meetings]]: [[i[[mercer]]]] Google Analytics Migration #//

[Meeting notes from](https://adkgroup.atlassian.net/wiki/spaces/MCR/pages/1937703134/2020-09-29+Meeting+notes) [[jordan daly]]

{{[[DONE]]}} Review [[National Speed]] [request](https://adkgroup.atlassian.net/wiki/spaces/NS/pages/1739292785/National+Speed+-+Functional+Specifications+Document?focusedCommentId=1937703185#comment-1937703185) from [[Fiana Avergon]] #///

{{[[DONE]]}} Review [[darci nevitt]] [tickets](https://adkgroup.atlassian.net/secure/RapidBoard.jspa?rapidView=497&projectKey=GLEN&view=planning&selectedIssue=GLEN-363&epics=visible&issueLimit=100) for [[Glenmede]] Analytics #/

{{[[DONE]]}} Review [[darci nevitt]] [content auditing process doc](https://adkgroup.atlassian.net/wiki/spaces/ADK/pages/1937408265/Process+Content+Auditing) #///

{{[[DONE]]}} Review the [[Sleeping Dog Properties]] blog posts from [[nick watkins]]: [general contractor pricing](https://docs.google.com/document/d/1D8T8gnhO7qPYCUwfuNcda-d7kv42_6b6K4Y10zVgO1c/edit) and [bathroom addition costs](https://docs.google.com/document/d/1t_PIn9-sWCK0CbLTSlxL_LUUV0MXiGOpsE1DI4teSgg/edit) #/



