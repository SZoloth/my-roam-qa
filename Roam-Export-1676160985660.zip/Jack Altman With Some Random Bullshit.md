Author:: [[twitter.com]]

URL:: https://twitter.com/jaltma/status/1277373268220014594

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

Remember that the grass is always greener, and lots of people probably wish they were in your shoes too. Play your own game. 

It’s easy to get messed up worrying what other people are thing about you. Good news! No one’s thinking about you. 

Exercise, eat well, sleep enough. Meditate, get a coach, or get therapy. Finally, invest in your family and friends not only as enjoyment, but as a way to stay rock solid no matter the ups and downs of your work. 

