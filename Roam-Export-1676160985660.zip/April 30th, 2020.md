{{[[DONE]]}} edit this [[import from notion]] #Notion #imports

[ADK LMT Objectives](https://www.notion.so/587c46eedeb541b69c1fa2b65fa8abf4)

[ADK Group Lead Gen Tracker](https://www.notion.so/ADK-Group-Lead-Gen-Tracker-f31091914e474d2f8cedbc1ea92acd90)

# 4/1/20

universities are life savers

LGC discussion [LGC | Lets Get Checked](https://www.notion.so/LGC-Lets-Get-Checked-55cb52d416e34857891586da413579cd)

Ask Jill to work with FTS about documentation of agile sprint work (images, screenshots)

put together outline in google docs of questions and bullets

# 3/16/20

## Form

Reducing complexity for marketing campaigns

1 campaign

2 simplified landing pages

Driving just to meetings

Set up questions: medication vs. general, price tolerance?, what tier/plan?

Limit budget

Use current creative

Drive to multiple landing pages

define [[Goals]] ahead of time

define timeline

## ADK + COVID

process automization and digitization - creates resiliency

ALKU, Spantech, HNRG

"now's the time to bring processes online"

telehealth

## ADK marketing

team summit in KY

re: marketing organization — what is our 1 year plan? (ROAM)

hire a writer: very creative, not content

## Instapage

Low ball

How do we monetize?

# 2/28/20

Help Darci find her strengths & weaknesses

Help her learn marketing

new tools

Help her learn client interactions

Team [[Goals]]

Create processes for our areas of expertise (analytics, reporting, SEO, PPC, strategy)

lunch and learn

playbooks

# 2/25/20

## [[Goals]] & Expectations

At a high level my goal is to create a high-performance growth team together (sounds easy right?). Below I've focused on what great/success looks like to me, since this also pretty clearly defines what an opposite [[outcome]] would be. I tried to include skills needed, what success looks like, and a very subjective and fairly arbitrary assessment of where I see you today in case that helps you as you think about where to focus.

**The team feels empowered and motivated**

Skills needed: empathy, listening skills, strong [[feedback]], being a manager-doer, teambuilding

What success looks like: Strong manager [[feedback]] in annual reviews, employee retention, and strong "esprit de corps" on the team overall.

Your rating today: needs improvement. We've touched on this a bit, but I think this is the area where you have the most room for growth, but that's OK since it's one of the hardest to master.

**Our skills and competencies grow in new ways, and current skills and competencies become more scalable**

Skills needed: interviewing, hiring, and training (coaching/teaching/adult education)

What success looks like: A hockey analogy is apropos here - we have a solid first line that I trust to execute while out "on the ice". Right now that's you, me, and Jordan (post-Amber's departure). Great equals our second and third lines becoming strong, viable options by building a playbook that more people can successfully implement.

Your rating today: Meets expectations. You've been instrumental in helping set up Bridget, Nick, and others to contribute at a higher level. Jordan has gotten better because of your work with him. Focus on setting up Darci and seeing what she can carve out, then let's discuss the next person to onboard.

**Growth/marketing/analytics drive revenue growth and new engagements**

Skills needed: solution selling, networking, thought leadership

What success looks like: We're winning consulting engagements specifically for these services that are then leading to UI/UX, dev, etc. [[scope]]s.

__Why__

Your rating today: Meets expectations but on the way to exceeding. You now have the skills, the depth of experience, and the confidence to present as an expert to customers. Now it's about getting out there, building a network, building marketing channels to bring in growth engagements, etc.

# 2/17/20

## Variable compensation

Question:

$100 for proposals

$500 for deals

Look into percentage of deal flow

Previous/current is:

$500 for all new ADK deals >$10k

$1,000 for all new ADK deals >$100k

Modern cat / dog

channels to monetization

ecomm

affiliate

subscription

ads

email

Community/UGC

Work with Rick to assess opportunity

[adkgroup.com](http://adkgroup.com)

pain points

requirements

wish list

# 1/20/2020

Nick SEO question to CB

Chat w/ AC re: management

Also maybe AF

Domain expertise:

Analytics

SEO

Content strategy

Growth strategy

CRO

Transfer

SDP to Nick

Wasabi to JD

CAPA to AH

Writing for the blog to JD & Nick - ask, would you two prefer being held to one blog post every two weeks? Or one outline per week? Both?

Hey guys, I realized I sort of delegated this without actually asking your preferences, etc and that sucks - I'm sorry. How would you most like to contribute to the ADK blog? Actually writing blogs? Creating outlines? Both? I don't yet know what really gets you going so if you could also let me know __why__ you chose your answer I'd love to hear!

How to:

Ask - Would you be willing to take ownership of this account? It's been hurting because of murky ownership & I haven't been able to give it enough of my attention and don't think I will. I think you'd be great for it. I'd still be available for support whenever/however and will likely chime in sporadically with ideas and questions b/c I'm like that - but ultimately it's success would be your responsibility. Is that something that you'd be excited about?

Think about:

How I give [[feedback]]

Personal case studies to grow

Form

ADK Group

# 1/2/2020

Form health:

Influencers, PR, etc.

BrainSell

needs to be more template/component focused

ADK marketing

Kick off - to get a template/playbook for campaigns like drupal + CCPA

Scaling marketing and analytics beyond me

GaaS

Form health as a growth case study

Growing ADK - visibility, lead flow,

see FTS for what they did

# 12/23/19

End of year comp chat

Variable comp / bonus / commission

Salary

$82 → $90k for 2020 base (<10%)

Build value

Startup growth

Hope is that ADK marketing catches momentum

Amber back Jan 7th

Bottom out marketing engagements —> what's the niche/specialization?

high growth startups?

medical?

Or do we have a junior person take over?

med device?

Marketing case studies

[[feedback]]

You can’t say I didn’t do any work for profit earning clients - we agreed multiple times that that’s what was distracting me from doing things like ADK and FH. Plus, I brought in plenty of leads. Plus, i wouldn’t have agreed to have this be my focus if it was going to be held up as a strike against me....either there must have been value because it was a top-down decision, or the top was wrong — either way, it doesn’t make sense to not earn more??

## 12/4/19 to do

[ ]  Vyaire 2020 (ecomm + digital)

[x]  Vyaire landing page

[x]  Form acquisition

[x]  FTS plan out in [JIRA](https://adkgroup.atlassian.net/projects/ADKFTS)

[ ]  PVFY: CRO

[x]  ADK blog post - iot

[ ]  ADK demand curve: onboarding

[ ]  Major decision: CRO

[x]  ADK social media review

FTS

Contract potentially signed this week

Talk to Alex about plan and messaging

AC to give access to jira board

ADK sales

pre qual leads w/ different tiers of work and quality

automated lead form email response from Dan asking lead: role and budget range

dan maps out landscape of development partners and competitive ecosystem

<$50k on a website: you get 1-2 people, the designer is a dilettante, and the developer is efficient but not scalable.

$50-150k middle market (us): teams of specialists that have a process and collaborative skill. More scalable product and more specialized expertise

$150+k high end (big ad agencies like digitas): certain companies can't afford not to use a big name, certain companies need a 30-person team to drive success and that's only a couple of

Form

on pause

# 11/6/19

Form - check in scheduled

What gaps to fill?

Types of work for Ryan + Bridget

Analytics + GTM

Type of work for Amber

Paid acquisition

Clutch reviews

BI

CCK

Harvard

SIKA

branding campaign w/ Kertis

## Brian Kramer w/ Vyaire

# 10/30/19

BrainSell

copy write first

finalize assets first

presentations

[ ]  assign ADK copy updates to Jordan

[ ]

## strategy playbook

**Web content exercise**

Asset ideation, card sorting, and content prioritization

**Webpage storyboarding exercise**

Homepage, product, and additional pages as needed

**Roles, responsibilities, and next steps for GA launch**

# 10/15/19

## To Do

[ ]  ADK value props

[ ]  Form landing page

[ ]  FTS GTM plan

[ ]

ADK [[feedback]]/user testing

get in front of clients/network to grab [[feedback]] on copy/design:

What questions do you still have?

What do you like?

What do you dislike?

What raw skills/production tasks would I want to offload to a client application associate?

Data studios

Technical SEO

Monthly report generation

# 10/2/19

## Action items

Sam to prepare high level marketing strategy for ADK

Includes: what we're doing, why we're doing it, what the tone we're going for is, and any gaps that we'd need to fill with hires

Questions for CB:

I've done this 2 times before, what needs to be different?

Should this basically be what I'm creating with Demand Curve?

Sam to send RFP follow up questionnaire to MIT

Need: contact

Sam to draft marketing update email for September

### To Do list

[x]  Update demand curve materials (personas, value props) based on target service of drupal web apps

[x]  ADK drupal competitors

[x]  Prepare a FreshTilledSoil acquisition GTM plan

[x]  Copywrite for BrainSell designs - landing page review from demand curve

[ ]  FORM Health demand curve

[x]  Reach out to Brian at Vyaire about walking through dashboard, SEO - float an invitation to visit

[x]  Follow up w/ CB and or DT about taking on an analyst/intern/associate role for investments/acquisitions

[x]  Write a September Marketing Org in review email to show CB (__on hold until DC gets back to me__)

[ ]  ADK CMO vs. Client Growth Lead

## Remaining questions

Demand Curve

What service for ADK?

Prioritization

ADK DC

What channel for ADK?

WP

**Drupal web apps**

HNRG

Major Decision

Beyond Insurance

JDA

Not SIKA

Boston School Finder

STEM act now

React web app (span tech)

PCIAA

Startup product

ADK marketing strat prezzo from DC plan

ADK <> FTS GTM strat

PR, redirects, messaging to their customers, messaging to our customers

MIT RFP follow up

FORM Health DC

Personal growth

ADK vs. Client marketing

Does ADK need a CMO?

Managing people vs. being specialized contributor

For ADK - managing people

For senior strategist - more specialized contirbution

Think about skills and interst

Hiring the job description

## Notes & [[feedback]]

For IE vulnerability we need to

Define QA chain of command

Segment MC list by things like

Location

Role

Industry

Marketing monthly report

Email for September

# 9/10/19

startups have roadblocks to us being their growth partner

New person

GTM — Jason

SEO basics

Social Media

analytics + paid

**Cobble together job description + ask Lindsay (thoughtbot) for her network**

Responsibilities:

Pull from:  job descriptions for SEOs/Analytics, other marketing agencies, what can help me scale?

SEO basics

GTM stuff

2-3 years experience

Work from LMT emails that I'd want to delegate:

MMB

Reviews + referrals process automation?

GTM tagging

Analytics event mapping

Implementation in GTM

ADK social

CRM operations?

General CMS work - content entry, QA etc

One-off marketing reports - eg: brand benchmark for Vyaire, content audits (maybe - I do enjoy this / can do it pretty efficiently)

SEO audits?

Other

Paid search and paid social campaigns

Campaign config + account set up

Management, testing, optimization

Content and writing

Examples

[Digital marketing associate - Warschawski](https://www.warschawski.com/jobs/digital-marketing-associate/)

[Analytics associate - Warschawski](https://www.warschawski.com/jobs/analytics-associate/)

good and live > perfect and unpublished

strategic writer

## 8/19/19

Have Travis get terry off SF

ADK website

[](https://www.rocket[[insight]]s.com/)https://www.rocket[[insight]]s.com/

[](https://www.deptagency.com/en-us/)https://www.deptagency.com/en-us/

[](https://venturepact.com/mobile_app_price_calculator)https://venturepact.com/mobile_app_price_calculator

BrainSell

**Sprint cadence, spending, report for ADK marketing**

**Bi-weekly email**

**By September**

Focusing on ADK vs. Mobile apps vs. Wasabis for [[career]] trajectory

Live GTM sesh

Design/Strat Ops

**Work on formalizing the growth/marketing packages**

[Forge.ai](http://Forge.ai)

CoS

Kingsley Montessori??

## 8/7/19

Clutch

FairShot

Kyle from ALKU

Mercer

Vyaire

Wasabi

HUAC - Stacy from Heather

[[Santander]]

Web5 - 3 months from now (October)

CSB

Yottaa

Startups - Bariatric (form)

Next FireFly/VoteD

What is the go-to-market / growth kit?

How do we scale up referrals?

6-10 leads

Blog post - Announcing Ray in Toronto

OKRs - ADK, Startup Growth Kits, Vyaire/Wasabi

Objectives:

## Drive awareness for ADK's services + fill the sales pipeline

Develop a growth marketing process / template system

Timelines, market priming (waitlists)

Wasabi: Turn Wasabi into ADK's Best SEO Case Study

Technical

Content

Vyaire: Best Digital Transformation Case Study

Engagements per day

Sales operations to combine marketing & sales

Win system/process automation or sales enablement app

Contracts from digital channels

MMB - what can we get out of this? How can we have Nick do these?

## 8/5/19

[ ]  Set up a dashboard review meeting with Deb for Vyaire

Product and digital transformation first, marketing second

Take note of what areas I would like the most help with from a job perspective

basic GTM

PPC

Less MMB type projects - don't say yes to these yo

Vyaire:

2 products to launch in Q4

Look at metrics of the email

OKRs

ALKU game on app applied to other roles/industries

## 7/1/2019

### Sam notes

Track to hit CMO / Growth lead

Tatar re: Wellist and general sales → lead flow

Hours for Nano, HPHC, BDRY, FireKing

DemandCurve training ($1k off if apply before July 4th)

Investment from SDP: $4k in July + extra $2k in ad budget (currently at $1.5k)

Im passionate, have learned from these guys, they're best in the biz — we can work together and take everything to the next level

1 month intensive, costs: $4k of services from us and them and >$2500 of ad spend to invest get [[feedback]] and see impact

What you're getting: 40-80 hours of time, focused attention from consultants that would normally cost you close to $10k

Tell story of the instructors

Pilot ad strategies across a number of channels we haven't yet used

Also: Jessica + Bryan

Questions for demand curve

Non compete?

Multiple clients at once?

Demandcurve notes

concerned about a threat

look at unprofitable keywords, ads desktop vs. mobile

## Vyaire

Drive awareness

Drive concept of "digital connectivity" — more touches with clinicians throughout the day

Social channels & content

SIKA retro

### Notes from CB:

BrainSell strategy going well

ADK Growth work

[ ]  Monthly wins in an email to: Chris, Dan, Jon

## 6/5/2019: Personal branding, Products, Drupal + Marketing Quarterly Prezzo

Ray is onboarded in Toronto

How does ADK take advantage of personal brands? Making individuals thought leaders

Jon = tech

Amy = health

Chris = med device

Sam = startup growth

Travis/Terry = manufacturing

Project pipeline

Full through late July

VoteD ending

Looking for: TradeHounds, ALKU, Span Tech (product-projects)

Quarterly check in with Tatar

Vision

Team

Money

ROI

[[Goals]] + objectives

[[model]] out

What we need from you

Quarterly meetings w/ Tatar

Blockers

Drupal

Are you still using Drupal 7? newsletter

HubSpot

MailChimp vs HubSpot vs SalesForce vs Frankenstein

Focused and tactical B2B marketing tools

