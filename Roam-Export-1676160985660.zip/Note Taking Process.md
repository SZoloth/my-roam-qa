Steps:

Save your article in [[instapaper]] for easy highlighting and referencing

Keep a [[Head Pages]] for your article open to add ideas you have under an "__Ideas__" header

Tag each idea block with the title of the head page

Copy and paste these highlights in to a [[Head Pages]] for your article

Go through highlights and **bold** anything that stands out

Go through again and ^^highlight^^ anything that's really important

Organize these notes under a "__Notes__" header

Add a "__Summary__" header on top and summarize the main points in your own words

Drag ideas out of your __Ideas__ section into more relevant pages

Sources of concepts/ideas 

[[Progressive summarization]] ^^important^^ for My [[Note Taking Process]]

Source: [[Tiago Forte]]

Steps

Bold anything in the highlights that **stands out**

Highlight anything that's ^^really^^ important

Then shift the highlights under a "Notes" header

Add a "Summary" header at the top of the page

How to take [[smart notes]] for [[Note Taking Process]]

Whenever you read you should write down ideas and notes in a notebook (or the book)

Add the ideas to a page ASAP under an "Ideas" header

Tag each idea block with the article title

Drag ideas to more/other relevant pages

Summarizing knowledge into [[Head Pages]] for [[Note Taking Process]]

Find tags with tons of references

How to take [[smart notes]] for [[Note Taking Process]]

Whenever you read you should write down ideas and notes in a notebook (or the book)

Add the ideas to a page ASAP under an "Ideas" header

Tag each idea block with the article title

Drag ideas to more/other relevant pages

Reinforcing with [[spaced repetition]]

https://notes.andymatuschak.org/z4eXdSMJFv2qVGXSUEKH4vdcHBrLHcFY1ZGfC

https://notes.andymatuschak.org/z2gqazXUkf9qyFjMQg4W3dw6yegnAJszvDywN

