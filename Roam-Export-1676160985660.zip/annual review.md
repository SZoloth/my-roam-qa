meta:: #[[Lenny Rachitsky]] #[[firstround.com]]

source:: https://firstround.com/review/the-power-of-performance-reviews-use-this-system-to-become-a-better-manager/

# [[annual review]]s template

{{year}}

Current role::

Rating::

Accomplishments::

Peer [[feedback]]::

Superpower::

High-level [[feedback]]::

Development area 1::

Summary::

Concrete examples and peer [[feedback]]::

Concrete suggestions::

What wild success in this area looks like::

Development area 2::

Summary::

Concrete examples and peer [[feedback]]::

Concrete suggestions::

What wild success in this area looks like::

Potential next role::

Potential timeline::

# process

## Collect data

Gather data from peers and self-assessment

Start at least one month ahead

While waiting for above [[feedback]], start crystalizing your own opinion:

What did they do well?

What is holding them back?

What are the one or two most critical development areas for them to focus on over the next cycle?

## Start fleshing out each of the sections in the [[annual review]]s template

**Accomplishments**: 

Collected from: self review, peer [[feedback]], and your own notes

Criteria: meaty, tangible accomplishments

For example, write “Hit team’s [[Goals]]” and “Shipped project X on time and under budget," not “Held a great meeting” or “Went to three conferences."

Also include: some of the best positive peer [[feedback]] collected

**Superpower**:

Designed to help individuals flex what they're good at instead of focusing on compensating for weaknesses

Describe their biggest superpower, and how they can flex it further.

Examples: storytelling, execution, galvanizing a team

**High level [[feedback]]**:

Summarize the report's performance in a short narrative (4-6 sentences)

Describe: how far they've come, then a sentence or two about how they did this cycle, and ending on a high-level overview of what they need to focus on next

**Development areas**:

Consider the following questions:

What is **most** holding the person back from the next level? If your company has a leveling system, leverage it to explain your thinking.

Do any clear themes emerge from the peer [[feedback]] or self-review?

If your company does calibration, is there a key issue you’re hearing from other managers? Even if it’s not something you agree with, it’s something you’ll need to address.

Make sure you still identify important development areas for even the highest of performers. No matter how amazing someone is, there’s almost always something they can focus on to get to the next level.

Examples include: reliable execution, increasing code quality, and more succinct verbal communication

Focus on **two** areas that are **concrete**

In the summary sections you are making it clear __what__ the opportunity is, __why__ it's important, and __how__ to concretely improve it

Summary = __what__

Here’s an example: __“Your team has lacked a clear strategy for the past six months. Without a strategy, it’s unclear to your team how all of the work they’re doing fits together, and it makes it hard for anyone outside of your team to understand why you’re prioritizing the things you’re prioritizing.”__

Concrete examples

 Include quotes from peer [[feedback]] that support those points, and any examples you can recall where this caused a problem, led to a complaint, or came up in a meeting. ^^Build a habit to note these instances throughout the year.^^

Concrete suggestions

What do you suggest they concretely do to significantly improve at this skill? Be direct, ambitious and constructive.

You can include: articles and books to read, people to talk to, and things to experiment with.

Leverage the superpower and other strengths

Examples

For example, if their development area is around verbal communication, a suggestion could be “Take a public speaking workshop.” 

If their development area is around improving execution,” a suggestion could be “Have a weekly check-in with your team where everyone reviews timelines, blockers, and priorities.”

If their development area is around hitting deadlines, a suggestion could be “For the next five projects, spend extra time estimating the work.”

What "wild success" looks like

Don’t underestimate your reports by letting them settle for good enough. Work backwards from what the perfect next six to 12 months would look like, and describe that in this section.

**Timeline to next level**:

Three common milestones

__So close:__ These people are right on the edge but didn’t quite make it. I use an estimate of six to 12 months (assuming you meet every six months to evaluate performance), and when appropriate verbally share that it’s likely much closer to six months.

__Just got promoted: __These people are not too worried about reaching the next level, so be super realistic about how long it’ll likely take. I normally say 12 to 18 months.

__Doing fine: __This is the most common case, and it’s generally going to be six to 12 months.

## Prepare for the meeting

Schedule

Schedule 45m on the calendar for the meeting

Schedule a 30m buffer beforehand to rehearse and prep

Prep your narrative

Script out how you're going to walk through the review

Here's an example conversation flow:

Intro

Lighten the mood and check in with how they're doing

Then share important context:

This is a conversation and it's perfectly ok to fire off questions and thoughts as we go through it together

Remind them how seriously you take these opportunities to talk about [[career]] development, highlighting how much time and effort you’ve put into it.

Share a brief agenda of the meeting, touching on how you’ll walk through the review and leave plenty of time for Q&A.

Rating

Walk through doc

Focus on details in development areas

Share the rating

Try to share the rating as early as possible. If it's not amazing, address that but don't dwell on it.

Dive in

Walk through the doc

If you sent it ahead of time, and the person read it, then just hit the big points.

Pause and ask if everything makes sense or if they disagree with anything

Spend at least 30m going over the details in the development area

When you get to tough stuff, I’d encourage you to be open and vulnerable. When possible, share personal experiences of when you yourself worked on these very same development areas, what struggles you had, and how you overcame them.

The more this feels like you are on their side and there to help them succeed (instead of judging or berating them), the more likely they’ll accept the [[feedback]].

Some common reactions to watch out for & what to do about them

Defensive or upset: Hear them out and __truly listen__ to their point

It's possible you missed or misinterpreted something

If it starts going in circles try to zoom out and move on to the next point

Goes quiet: This is common & ok b/c they will be in listen and process mode

But, if it feels too quiet, simply point it out, e.g. “I’m noticing you’re really quiet, I just want to make sure this is all making sense? Any thoughts or questions before we keep going?”

Looks dejected or overwhelmed: when there's a lot of information or a negative review

Slow down, keep checking in and find out what's going on with your direct report.

Sometimes they take it much harder than they need to. Sometimes they have other stuff going on in their life that’s showing up here. Come back to the human-to-human connection and don’t worry about getting through every nuance and detail of the review.

Leave time for discussion

Open it up for questions & thoughts:

Try to give this at least 5m

Is there anything your report disagrees with? Is there anything they want to dive into further? Is there any more clarity you can give around expectations for the next cycle?

Try not to linger here too long if there isn’t anything pressing, especially if things seem to be in a good place. Often folks need time to process and think about everything they’ve heard, and you can follow up on it in future 1:1s.

Follow up action plan

Turn the discussion into an action plan to channel all the ideas, motivation, and momentum into an ongoing structured discussion

Ask your report to list 5-7 concrete actions they want to work on over the next 12 months within 7 days of the conversation

Make sure they also include what they need from you to be successful (with your input)

The list should be made up of concrete suggestions you noted in their performance review, things your report personally wants to work on, and things that your report needs from __you __in order to be successful.

![](https://s3.amazonaws.com/marquee-test-akiaisur2rgicbmpehea/avDgOlgSR2GEOxflQaJl_Screen%20Shot%202019-07-17%20at%202.43.34%20PM.png)

Outro: end on a high note if possible

Send ahead

On the day of the chat, email the annual review doc a few hours ahead of time

^^This isn’t always a great idea^^, particularly if the report will be very surprised or disappointed with the review, so do what feels right for your situation.

## Follow up

The performance conversation isn't the end - it's the beginning of the development process

### Create a 2-sided action plan

Ask your report to list 5-7 concrete actions they want to work on over the next 12 months within 7 days of the conversation

Make sure they also include what they need from you to be successful (with your input)

The list should be made up of concrete suggestions you noted in their performance review, things your report personally wants to work on, and things that your report needs from __you __in order to be successful.

![](https://s3.amazonaws.com/marquee-test-akiaisur2rgicbmpehea/avDgOlgSR2GEOxflQaJl_Screen%20Shot%202019-07-17%20at%202.43.34%20PM.png)

### Schedule a 1-hour monthly check in (call it "Monthly [[career]] Coaching" to distinguish from 1:1s)

Step back from the day-to-day and focus on [[career]] and performance development

Remind your report ahead of each meeting to update their spreadsheet with a status and any new discussion items they’d like to make time for.

During this meeting:

Check in to see how they're making progress on development areas

Make sure they have everything they need in order to move the ball forward

Ensure the list of action items they're focusing on is still the right list

The meeting should be mostly you listening, asking questions, and (when really necessary) offering suggestions. Your report should lead the meeting — go through each item in the action plan, share a brief update, and align on the status color.

### Between chats:

Keep track of instances where your report did well, didn’t do well, or generally did something noteworthy.

Share these things with your report in real-time as much as you can, or in weekly 1:1s, but also save them in a running file.

For example, “July 10th - Ran an excellent meeting with senior execs,” or “Sept 3 - Put together a very strong strategy for Q3,” or even [[feedback]] from others (“Jan 4th - Spike shared with me how impressed he is with Jane’s ability to run a meeting.”)

Meeting overview

Quick intro to the process (start with your description, review peer [[feedback]], align on designation and, if time, get in to goals for next year)

How did you feel your year went? What went well? What could have gone differently?

Review last year's goals

Let's talk about peer [[feedback]] - what did we hear from colleagues about your performance?

Designation - what's the [[feedback]] that drives it?

While waiting for above [[feedback]], start crystalizing your own opinion:

What are your goals?

