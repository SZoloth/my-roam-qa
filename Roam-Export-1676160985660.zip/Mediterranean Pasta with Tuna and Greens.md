Tags:: #Recipes #pasta

Ingredients::

1 6 oz can of [[tuna]], preferably packed in olive oil

2 tbs [[capers]], drained

¼ cup pitted [[olives]], chopped

Handful of [[arugula]], [[spinach]] or [[dandelion greens]], torn into pieces

½ can [[chickpeas]], drained

Zest of 1 [[lemon]]

2 tbs [[lemon]] juice

¼ cup [[EVOO]]

½ tsp [[salt]] and [[pepper]] to taste

½ tsp [[red pepper flakes]], optional

½ lb pasta, long noodles like [[spaghetti]] or [[fettuccine]]

¼ reserved pasta water

Handful of fresh [[dill]] or [[parsley]], chopped

Fresh grated [[parmesan]] cheese to finish

Tools:: 

Source:: https://equalparts.com/blog/pasta-tuna/

:hiccup [:hr]

STEP 1

Bring salted water to a boil in your Big Pot.

STEP 2

While water is boiling, drain tuna and place it in a Prep Bowl. If using thick cut tuna (suggested), break apart into flakes with a fork.

STEP 3

Add capers, olives, torn pieces of greens, and chickpeas or other vegetables to the tuna. Mix together with lemon zest, lemon juice, and olive oil. Add salt and pepper and optional red pepper flakes from some extra kick.

STEP 4

When pasta is done cooking, make sure to reserve ¼ of water and drain noodles. Add hot pasta immediately to the Prep Bowl, combine well with the tuna mixture.

STEP 5

If pasta seems dry then start to slowly add reserved liquid. Transfer to a serving bowl and top with fresh herbs and a sprinkle of cheese if desired.

