[Sheet](https://docs.google.com/spreadsheets/d/1DLa1ckKibJ--WpbHlU116JYm1bs-EVBzqNa5HA69DXs/edit?usp=sharing)

[[June 2020 Hours]]

[[July 2020 Hours]]

