[[🏔ADK [[Task Management]]]]

[[Meetings]]: [[National Speed]] check in re: client [[feedback]]

Attendees::

Time:: 9:45am - 10:00am

Notes::

Client [[feedback]]

"It seems the general observation is that pillar pages are not being used during navigation like we anticipated. The hierarchy is correct as far as the informational relationships are concerned, but having the user click through seven pages to get where they can reach the package details is not what we were envisioning. I can see the drop rate going through the roof with how it is currently proposed.**I will put together some mockups for your team**, to better exemplify our goal. The idea is the Manufacturer>[[model]]>Generation would all be on one pillar page, with the ability to ‘jump ‘ to a specified manufacturer section by clicking on a menu at the top of the page - maybe below the breadcrumb area. See our slide deck for examples of navigation that we like, ie Chevrolet & Nissan. Once the viewer has scrolled and determined the Manufacturer>[[model]]>Generation they want to see, they would then click the generation icon. They would then be brought to the page where they would select the sub[[model]] & induction choice – maybe we can utilize another pillar page here and find a way to minimize clicks/screen loads.For the actual vehicle pages where we want to display the packages, this should be a pillar page also. The packages should not have their own separate page. I will create a mockup for your team for this as well.I am thinking there might be a conflict where we need customizable content(templates) all on one pillar page together – is that a valid issue? Or do you guys think you can make that work?"

Sam interpretation

Text

mfg/[[model]]/gen on one page with mfg being one of the jump links

they had previously wanted these to be graphics (icons)

within mfg section you see [[model]]s & gens

this will be “visual” --> [[translation]]: product photography (i think)

where gens are links to sub[[model]]+induction page. Likely gens would be grouped by [[model]]s.

that page (sub[[model]]+induction) likely follows that hierarchy: induction types grouped by sub[[model]] where sub[[model]]s are links to vehicle page

vehicle pages have both/all packages on them

keeping in mind one of the OG [[Goals]] that: `Prospective customers will need to be able to interact with the site at any point to submit a sales inquiry via web form.`



Images

 ![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2Fj_-1H5LDUP.png?alt=media&token=b5af5047-8e95-4f80-8475-1ce9ff46313d)

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2F7a-7eTkLlV.png?alt=media&token=d712806f-2606-4f75-a411-138f1dec028a)

Drawbacks

now my critique/[[feedback]] is that the mfg+[[model]]+gen page and the sub[[model]]+induction page are going to be harder to make SEO performant

it also reduces opportunities to address one of their stated [[Goals]] of `Our existing and prospective customers need to be able to find answers to any questions they might have, easily via our guided vehicle menus.`

IMO dedicated pages with resources like we were planning better equip NS to provide answers to questions they might have

What if the user only knows the generation - not the sub[[model]]?



[[Meetings]]: [[Mercer SEO Presentation]] part 2

Attendees::

Time::

Notes::

[[Meetings]]: imercer SEO issues

Attendees:: [[jordan daly]] [[eric brown]]

Time:: 30m

Notes::

[[Meetings]]: [[ADK Website Rebuild]] stand up

Attendees:: [[michael connors]] [[jayne hetherington]] [[maggie o'connor]]  [[shae allison]] [[jenna bantjes]]

Time:: 3:00pm - 

Notes::

Voice and tone updates ([devmconnors.com/gm](http://devmconnors.com/gm/))

Structure: 

Headline (punchy + emotional)

Imagine the future.

Subheader (payoff, grounded description)

(Together,) We can build it.

CTA

What is the core story/impression you want to give

[[jtbd]] per page

Maybe just going with very text-heavy first

hey.com, thebrowser.company, runway.com

Blog

Treatment of images - can be super subtle like a red stripe

webinar: [[thoughtbot]] marketing websites

{{[[DONE]]}} Do [[ADK Hours]]

{{[[DONE]]}} [[email inbox]] from [[jess lopez mora]] re HHI campaign for #[[form health]] ([link](https://mail.google.com/mail/u/1/#inbox/FMfcgxwJWXWLwwXhvbZNSGTrzwtqrZDx))

{{[[DONE]]}} Management work

{{[[DONE]]}} hey! just wanted to follow up on [[MIT PEL]] #analytics -- did you/team have a chance to review the custom analytic tags that we set up? 

from [[Michelle Smith]]

{{[[DONE]]}} #[[email inbox]] from [[Sleeping Dog Properties]] and [[heather mccormmack]] re: zoho ([email link](https://mail.google.com/mail/u/1/#inbox/FMfcgxwJWXbqFvrvXzkZRPlBCJLQWsnM))

Zoho updates: https://www.zoho.com/crm/whats-new/

Web forms

https://www.zoho.com/crm/web-forms.html?src=whats-new

Attritbution

https://www.zoho.com/crm/marketing-attribution.html?src=whats-new

General

Customer [[segmentation]]

Actually: lead scoring should be used

Helps for territory management

Webform analytics and testing

This doesn't unlock any new relevant capabilities

It could be useful if we were producing landing pages with unique forms en masse, though. 

Marketing attribution

If we run Google Ads again we should definitely consider the integration

We should look into this a bit closer! Might just be UTM code integration

Cohort and quadrant analysis

Cohort: Not useful unless you have subscribers / repeat purchasers

Quadrant: could be useful for your sales org, depending on how disciplined you are and what you want to learn.

CommandCenter

Could be interesting for email campaigns - nurture flows, updates, even project status updates. 

Prediction builder

Might be useful for targeted sales outreach? Could be interesting to predict things like likelihood to close based on project type, size, location, etc. Gives a slight boost to prioritizing incoming leads.

Zia for email

Might be helpful for your sales org

Wizards

Could facilitate data input for your sales org

Multiple sales pipelines

Could help split between different business lines

Services and appointments

Sounds like it's not available, but worth keeping an eye on

Call customization

Could help sales calls, not yet available



{{[[DONE]]}} Set up GA filters for #APCIA ([ticket](https://adkgroup.atlassian.net/browse/AP-2479))

:hiccup [:hr]

#Inbox

{{{[[DONE]]}}}} Write out the Clear[[scope]] blog outlines for marketing for [[ADK content]] #///

{{[[DONE]]}} Capture for [[ADK Marketing Process]]: #///

Assessing why a website's organic traffic is tanking

Process for optimizing existing content

{{[[DONE]]}} Turn survey questions into ADK brand for post-[[Mercer SEO Presentation]] follow up

https://www.sogosurvey.com/survey-templates/events/presenter-[[feedback]]-survey/

http://www.tamuc.edu/facultyStaffServices/trainingDevelopment/Documents/Survey.pdf

https://www.surveymonkey.com/r/Event-[[feedback]]-Survey-Template

{{[[DONE]]}} Review [[Tim Lupo]]s [[feedback]] on case studies for #[[ADK content]] & share with [[Sanjay Salomon]] #/

{{[[TODO]]}} Move the [[ADK Drupal Retargeting]] campaign forward ([landing page](https://adkgroup.invisionapp.com/share/BRXV3OPQ79M#/screens/423185819))

{{[[TODO]]}} ADK email for content round up

{{[[DONE]]}} for [[ADK Website Rebuild]] The content priority right now is determining the shape of industries v. “tech solutions” — and how we want to handle conceptually. ([ticket link](https://adkgroup.atlassian.net/browse/ADKWPW-31))

{{{[[DONE]]}}}} [[clutch]] review for MSI from #Delegated[[ryan pearse]]

{{[[DONE]]}} set up [[[[ADK]] case studies]] for MSI: interview [[michael connors]]

{{[[DONE]]}} #[[Choice]] Industries vs. solutions for [[ADK Website Rebuild]]

Options:: 

Decision::

Results::

[[Personal Task Management]]

Focus on themes

[[[[High Agency]][[*]]]]

[[[[strategy]] [[*]]]]

[[management]]

[[Growth marketing[[*]]]]

[[Hey recovery codes]]

9K3EH-Z5Z8Q

AGNY6-TBXFV

S040O-KV0P4

GB9JT-I3LER

NW3Z5-BZPDE

XBW1K-I5WZJ

WC7SG-6QFKU

3V7E5-K7LG4

To do query

{{query: {and: [[TODO]] {between: [[today]] [[last month]]}}}}

