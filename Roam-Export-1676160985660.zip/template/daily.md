[[Daily Journal]] for DATE

[[Morning Routine]]

[[Morning Pages]] 

__Don't forget Gratitude!__

{{word-count}}

[[What are you grateful for?]]

[[What do you want the day's highlight to be?]]

[[Daily affirmations]]

[[What's on your mind?]]

[[What help could you ask for to solve your biggest challenge?]]

[[Daily Habits]]

{{[[TODO]]}} Meditate 10 minutes

{{[[TODO]]}} Cold shower

{{[[TODO]]}} Lift or run

{{[[TODO]]}} Read

[[Evening Routine]]

[[What did you do today? How did it make you feel?]]

[[What did you learn today?]]

[[How would you rate today? ]]

{{[[slider]]}}

[[How could you have made today even better?]]

[[What are your priorities for tomorrow?]]

