Tags::

#APCIA

[[APCIA]] business objectives?

increase knowledge of industry

improve reputation among consumers?

Be the go-to resource for information and education for insurers

Position as the trusted voice, proactive advocates, and thought-leaders

General notes from SZ

Inspiration from other members-only sites or sites with members areas

Nytimes

The Hustle

HBR

Chat / conversational UI

Instagram / Youtube for humanity and video

Twitter for breaking news and analysis

LinkedIn for influencers

Need firmographic breakdown of current audience -- [[APCIA]] is B2B

current and ideal

ABM? [[personalization]] / customization?

Position as a teacher --> what tools do teachers use?

Quizzes, summaries, flashcards, study groups

Seed on instagram

Native and display ads

display = acuity

native = inpowered

[[discovery]] activities

Workshop

Demonstrate diversity

Review industry research

Review client docs

About #APCIA

Viewed as the trusted spokesperson and resource of the industry

Provides vital real-time information to insurance agencies (**not** consumers)

Can influence the direction of local, regional, and national policies in the insurance indusry

lobbyists

Offers wide range of talent development opportunities: [[webinar]]s, conferences, and apprenticeships

Prioritizing diversity

Desire to expand media mix across multiple channels to increase audience engagement

Shift to video

Audience/persona

Comparative review of industry landscape (competitive review)

Insurance Journal

The Institutes Insurance Research Channel

AAA

NAIC

Insurance Information Institute

Analytics review

Google Analytics and Sprout Social

Twitter is big

Social media review

Site review

SEO audit

Just a basic meta audit

[[discovery]] [[outcome]]s

No distribution [[model]]

No emotional content

Insurance agencies need to [[prioritize]] awareness - how can #APCIA support that?

Can #APCIA facilitate mobile/digital tools for insurance agencies?

[[[[strategy]] [[*]]]] [[outcome]]s

Content

Pillars

Tone/Voice/Style guidelines

Channel plan

Cadence

Measurement and optimization framework

Content strategy

Positioning anchors are values and intentions that directly address identified issues with the brand

eg: audiences see insurance as faceless --> warmth, care, and compassion becomes a positioning anchor

anchors = compassion, expertise, and accessibility

Positioning anchors align with content categories

promotional = compassion

Awareness and branding

Emotion and stories

Pushed out

Tone = warm, human, sympathetic, affirmative

thought leadership = expertise

Proactive advocacy rooted in data and [[insight]] from established voices

Tone = trustworthy, informative, confident, willing

solution oriented = accessibility

Solve problems and provide guidance to insurance-related pain points

Tone = dependable, objective, friendly, informative

Voice = consistent personality, while tone = attitude to the content/topic

conveyed through choice of words and level of formality

Table of contents

Discovery

Business Objectives

Approach

Discovery

Detailed findings

Building consumer audience

Moving forward

Strategy

Establishing our fundation

Content framework

Digital recommendations

Organic social media

Paid media

Measurement framework

Next steps

Appendix

