Author:: [[mercatus.org]]

URL:: https://www.mercatus.org/bridge/commentary/great-reset-marc-mndreessens-recent-exhortation-to-build-is-exactly-right

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

big political and scientific institutions to react. These institutions are a legacy of the 20th century: they worship process and move with bureaucratic deliberation. 

The public was aware of the mounting death toll, and of the institutional confusion that seemed unable to prevent it. The variance between a public riding the speed of light and elites lost in a labyrinth of proceduralism fatally eroded the credibility and authority of the latter. 

