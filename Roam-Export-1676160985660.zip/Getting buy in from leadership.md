**Tags:** #Articles #[[✍️ blog-post]]

**Status:** #draft

Intro

I struggle a lot with presenting to and getting buy-in from people senior to you. I figured (a) I'm not alone and (b) other people have figured this out better than I have. So I asked them. 

Below is a summary of conversations I've had with a few internal teammates that I've seen excel at presenting to, and getting buy-in from, people senior to you.

Before the meeting

Define your objective. Make sure you have a clear goal from the meeting. Not only will this help you form a crisp, clear ask, but it will also demonstrate respect for the other person's time. 

Also double check with yourself: do you really need leadership for this? Get a peer's opinion as well, that's what we're __all__ here for. 

Forming the ask

Make it specific and clear so that the recipient can quickly understand what you need from them. 

Boil the possible response down to "yes" or "no." If it's open ended, it's much easier to say "no" to. And remember, anything other than a hard "yes" is a really a "no."

Subtle, but important about this is that it means never just approach with a problem and have your question be, "how would you solve this?"

Instead, bring them a POV/solution that they can react to. 

This also means breaking down the ask. 

Share context ahead of time

Give framing and context ahead of time. If you can send over what you're going to talk about a day or two before a meeting you give the recipient a chance to absorb the information on their own time. Then they can have a more nuanced reaction and come better prepared with questions. 

If appropriate, give yourself time to rehearse. One of the people I talked to follow a 4:1 principle: for every 1 hour of a presentation, you should rehearse 4 hours. 

If you're creating a presentation, don't be afraid to recruit a designer to help. 

To rally support around your cause, connect with the people that surround the decision maker - the lieutenants. Ask these people for advice about what you're presenting to get their perspective and buy in. 

Throughout the meeting

Focus on understanding

Pay attention to non-verbal cues: fluctuations in tone, shifts in attention, etc.

At the start of the conversation

Help make everyone feel comfortable

These tips apply to really any meeting or interaction with someone. 

Start with humor if you can - make a concerted effort to connect on a positive emotional level before diving in to work.

Also defuse the situation early by making it very clear that you're open to [[feedback]], even if it's negative. In fact, you'd welcome it and see it as a gift. 

The most valuable thing you can get is honest [[feedback]], so make sure they know it won't hurt your feelings.

Making the ask

Reframe and summarize what you sent ahead of time

Get their approval about the review process. Ask them if the way you're presenting a plan, deck, design, etc. will work for them.

