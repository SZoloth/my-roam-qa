[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Update COVID blog and email #/

Check slack from [[Dan Tatar]]

Finalize [this draft](https://docs.google.com/document/d/13FtPEtzPE6lXhoKapTk8FXnPwqTM7ic4fCiv0fFR6Tc/edit#)

{{{[[DONE]]}}}} Send [COVID blog](https://docs.google.com/document/d/13FtPEtzPE6lXhoKapTk8FXnPwqTM7ic4fCiv0fFR6Tc/edit#) and [email](https://us7.admin.mailchimp.com/campaigns/edit?id=4316464)  #/ [[August 21st, 2020]]

{{{[[DONE]]}}}} [[[[Google Ads Optimization]] Log]]: [[August 13th, 2020]]

New campaign to test: Competitors

web design

jumping jackrabbit

web dev

Rise

digital product

Crema

Important note: Bid strategy still learning for 3 more days

Priority: negative keywords

Campaign:: MA/KY_design

Ad Group:: UI/UX design

Search terms::

Added "startup cost" as negative keyword

Added `ux design consulting agency` as keyword

Ads::

Added and tweaked some of the RSA headlines

Added a new ETA

Quality score::

Campaign:: MA/KY_digital/software

Ad Group:: digital agency

Notes::

Should think about a digital marketing agency

Search terms::

Removed

florida

recruitment

digital marketing

open a

digital law firms

Ad Group:: digital product design

Notes::

Super weak performance - unrelated ads

Threw up some new ads that are more related



Ad Group:: digital product dev

Notes::

Added some new headlines

Campaign:: MA/KY_mobile apps

Ad Group:: mobile app design - ADK

Notes:: people just straight up aren't searching for this frequently

Ad Group:: mobile app dev

Notes:: people just straight up aren't searching for this frequently

Campaign:: MA/KY_web apps

Nothing changed; super low search volume

Campaign:: MA/KY_websites

Ad Group:: web design



{{[[DONE]]}} ADK ad campaign landing pages for: #Blocked

Software design

Software dev

Hosting & Maintenance

Incloude our HelpDesk?

Onboarding in a lower-commitment manner as a means to getting next projects

Reliable, well-architected support - maintenance/helpdesk/new features

Big agencies don't do it, small shops don't have systems/process scale, offshore is risky

{{{[[DONE]]}}}} Write brand narrative for {{or: purpose/social good | david vs. goliath | friendly engineers}} by [[August 18th, 2020]] #/

{{[[DONE]]}} COVID app #[[[[ADK]] case studies]] #//

Interview team

{{{[[DONE]]}}}} Setting up retargeting on:

Google

FB/IG

{{{[[DONE]]}}}} Positioning / messaging strat for [[Museum of Science]] #/

{{{[[DONE]]}}}} Write the landing page

**Navbar**

Our Mission | About the Curriculum | FAQs | ^^CTA^^

Alignment to standards

Determine investment

Success Stories

Distance learning

Teacher support

Not just about training teachers, but training trainers for a sustainable implementation.

Teachers to coaches 

Flexible professional development programs that build confidence and excitement in your teachers.

Easy to implement and integrated directly with your existing science curriculum, with built-in connections to other subjects like Math, ELA, Art, and more. 

Professional 

Free resources

With a vast library of free resources and professional development workshops EiE gives your teachers everything they need to become the heroes your students deserve. 

https://info.eie.org/eie-stem-funding-guide

https://eie.org/eie-curriculum/resources-educators

**Hero**

**Headers**

The secret to STEM excellence? Start early.

Make your district a leader in STEM education.

The curriculum proven to create standout STEM students.

Create the next generation of {{or: problem solvers|scientists|engineers|entrepreneurs|role [[model]]s|big thinkers|critical thinkers}}.

Increase engagement, performance, & interest in STEM.

Give your students a head start in STEM.

Your students will become curious, confident problem-solvers.

For the future {{or: engineers|computer scientists|problem solvers|critical thinkers|entrepreneurs|role [[model]]s|scientists}} in your classroom. 

Empower your students with hands-on experience. Encourage engagement with engineering.

Where tomorrow's {{or: problem solvers|scientists|engineers|entrepreneurs|role [[model]]s|big thinkers|critical thinkers}} are made.

Make an investment in your students' future, today. 

A STEM curriculum that equips your students with skills for the future. 

"When I saw the creative thinking the students had in solving the problems I felt like drop the mic, my job is done. How do I clone this?" [source](https://info.eie.org/implement-k-8-engineering)

Engaged in the learning, critical thinking, they're thinking bigger about the world, not just memorizing vocabulary or doing multiple choice but they're problem solvers and real-world thinkers

Teachers excitement, enthusiasm, comfort in ability to teach, and excitement when students do well

Not only hits the engineering standards and greatly supports the engineering design process, but every EiE unit also ties to a science content standard. So it's almost a 2 for 1 for our teachers 

They can hit science standards, engineering standards while developing critical thinking and 21st century skills that your students can be practicing 

Engage all of your learners, whatever they're [[language]] is because its grounded in solving real-world problems.

**Subheaders**

The nation's leading engineering curriculum for grades 1-5.

The only integrated Computer Science and Engineering program for grades 1-5 designed so to help you achieve NGSS and state standards. 

Proven to create standout STEM students.

Proven to improve STEM scores, without overloading teachers.

The only integrated engineering and computer science curriculum, with hands-on lessons that build 21st century skills.

Engineering & Computer Science Essentials blends 

**Image**

**CTA**

Watch intro video

**Proof**

Endorsed by the director of the NSF

Used in all 50 states by thousands of districts and millions of students.

Full coverage of NGSS requirements - in one program.

Research-backed and proven to improve your student's STEM performance.

By the numbers

All 50 states

5 million+ students

44,000+ educators

Based on 3,000+ hours of development and research

[Award](https://eie.org/engineering-elementary/eie-award-winning-curriculum-project)-winning curricula and videos

McGraw Prize in Education, 2017 K-12 Category Winner 

IEEE 2015 Educational Activities Board (EAB) Pre-University Educator Award

AASL 2015 “Best Website for Teaching and Learning”

District Administrator Magazine 2014 “Readers’ Choice Top 100 Product”

[Testimonials](https://eie.org/overview/testimonials)

Former Director of the NSF: "The [EiE] curriculum [developed by the Museum of Science] is a great tool to involve children in science and engineering at their own level so that they are excited about and enjoy learning.”

Co-directors of STEM Education Center, University of Minnesota: “EiE curricula provide socially and culturally relevant contexts for students through their well-designed storybooks and their engaging engineering design challenges. Students who experience EiE lessons continue to talk about the characters from the storybooks and the design challenges for a long time after the conclusion of the lessons." 

Former CEO, DuPont: "[EiE] literally starts in first grade, and it’s the greatest little modules at the appropriate level for the grade level. That’s what’s needed. Because by the time a kid gets to eighth grade, it’s almost too late.”

"Engineering is Elementary** teaches students the thinking and reasoning skills they need to be successful learners and workers**. It also creates the optimism that every problem can be solved, which is relevant to any subject area. These skills and attitudes are important for **our kids’ future**."

"How do I clone this in 33 more buildings?" 

**Interstitial CTAs**

**Headers**

**Button text**

**Mission / About EiE**

EiE is using research-backed methods to help districts raise awareness, achievement, and access to STEM education for historically underrepresented groups. 

Our goal is to create a generation of problem solvers and engaged citizens by changing how students see themselves and others.

We were born out of one of the most beloved science and technology institutions in the nation, Boston's Museum of Science. 

**Course preview**

Your students deserve more than multiple choice. 

The only integrated Computer Science and Engineering program for grades 1-5 designed so to help you achieve NGSS and state standards. 

__Did you know?__ Computer Science is more reliant on [[language]] skills than math/numeracy skills. But even more than math or [[language]] skills combined, are the core problem-solving and learning aptitude skills that all subjects rely on [citation](https://www.nature.com/articles/s41598-020-60661-8)

After thousands of hours of development and research, EiE has designed a curriculum that turns an education in computer science and engineering into an engaging bedrock of core critical thinking and problem solving skills for primary school students of all backgrounds. So you can meet standards while creating tomorrows standout students.

Based on a unique Engineering Design Process that empowers students to develop the critical thinking and problem solving skills applicable to all subjects. [See the process in action](http://eie.org/overview/engineering-design-process) 

What's included

Unique combinations of narrative and design challenges engage the whole child in a way that input/output curricula cannot. Dragging and dropping code supports a superficial understanding, but only open-ended, experiential challenges teach the "__why__" and the "__how__" that foster critical thinking, problem solving skills, and a passion for STEM among all your students.

A thoughtfully designed Teacher Guide that turn your teachers into coaches, even if they have no engineering experience. 

detailed **lesson plans**

useful tips for **lesson prep** and materials management

**background content** (engineering, science, AND social studies)

**learning [[Goals]]**

unit specific **vocabulary list**

classroom-tested **duplication masters **AND** student **planning worksheets****

**data-collection worksheets** AND **reflection worksheets**

research-tested **assessment sheets** to evaluate student progress.

EiE storybooks that integrate ELA and social studies into your engineering and science lessons, while building personal connections. 

Unique combinations of narrative and design challenges engage the whole child in a way that input/output curricula cannot

Your students will create connections with characters that are just like them, solving a real-world problem with engineering and computer science.

EiE materials kits

Because the projects are hands-on, you'll get unit-specific Materials Kits (or be able to build your own using the lists in included in your Teacher Guide).

[Video about materials](https://eie.org/eie-curriculum/eie-curriculum-components)

**FAQs**

Investment

We've worked tirelessly to make EiE one of the most affordable curricula packages, with flexible purchasing options so that we can help as many students as possible. 

Implementation

Do I have to do both?

Alignment to standards

Support for distanced learning

Other free resources

[[Meetings]]: Search for copywriter with [[Demand Curve]]

Attendees:: [[aadil razvi]]

Time:: 2:00pm

Notes::

Minimum of $2.5k

Grow and convert - $8k / month

Senior freelancer rates start around $125/hr

[[Meetings]]: check in with [[darci nevitt]]

Attendees:: [[darci nevitt]]

Time::

Notes::

Very stressed and overwhelmed

Follow up with JD about ProLift urgency

{{{[[DONE]]}}}} MIT UPOP set up

For MoS

Budget across channels?

Messaging for emails, ads, and landing page?

