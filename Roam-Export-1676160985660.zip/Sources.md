[1] [[Naval Ravikant]]. “[[Naval Ravikant]] Was Live.” __Peri[[scope]]__, January 20, 2018. https://www.pscp.tv/w/1eaKbqrWloRxX.

[2] [[Naval Ravikant]]. “[[Naval Ravikant]] Was Live.” __Peri[[scope]]__, February 11, 2018. https://www.pscp.tv/w/1MnGneBLZVmKO.

[3] [[Tim Ferriss]]. __Tribe of Mentors: Short Life Advice from the Best in the World__. New York: Houghton Mifflin Harcourt, 2017. https://amzn.to/2U2kE3b.

[4] Ravikant, [[Naval Ravikant]] and Shane Parrish. “Naval Ravikant: The Angel Philosopher.” Farnam Street, 2019. https://fs.blog/naval-ravikant/.

[5] [[Tim Ferriss]]. __Tools of Titans: The Tactics, Routines, and Habits of Billionaires, Icons, and World-Class Performers__. New York: Houghton Mifflin Harcourt, 2016.

[6] [[Tim Ferriss]]. “The Person I Call Most Often for Startup Advice (#97).” __The Tim Ferriss Show__, August 18, 2015. https://tim.blog/2015/08/18/the-evolutionary-angel-naval-ravikant/.

[7] [[Tim Ferriss]]. “[[Naval Ravikant]] on The Tim Ferriss Show— Transcript.” __The Tim Ferriss Show__, 2019. https://tim.blog/naval-ravikant-on-the-tim-ferriss-show-transcript/.

[8] __Killing Buddha__ Interviews. “Chief Executive Philosopher: [[Naval Ravikant]] On Suffering and Acceptance.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/7/naval-ravikant-ceo-of-angellist; “Chief Executive Philosopher: Naval Ravikant On the Skill of Happiness.” __Killing Buddha,__ 2016. http://www.killingbuddha.co/blog/2016/2/10/chief-executive-philosopher-naval-onhappiness-as-peace-and-choosing-your-desires-carefully; “Chief Executive Philosopher: Naval Ravikant On Who He Admires.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/19/naval-ravikant-on-who-he-admires; “Chief Executive Philosopher: Naval Ravikant On the Give and Take of the Modern World.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/2/23/old-bodies-in-a-new-world; “Chief Executive Philosopher: Naval Ravikant On Travelling Lightly.” __Killing Buddha__, 2016. http://www.killingbuddha.co/blog/2016/9/19/naval-ravikant-on-travelling-lightly; “Naval Ravikant on Wim Hof, His Advice to His Children, and How He Wants to Look Back on His Life.” __Killing Buddha,__ 2016. http://www.killingbuddha.co/blog/2016/12/28/naval-ravikant-on-advice-to-his-children.

[9] Joe DeSena. “155: It’s All About Your Desires, Says AngelList Founder [[Naval Ravikant]].” __Spartan Up!__, 2019. https://player.fm/series/spartan-up-audio/155-its-all-about-your-desires-says-angel-list-founder-navalravikantunder-naval-ravikant.

[10] “[[Naval Ravikant]] was live.” __Peri[[scope]]__, April 29, 2018. https://www.pscp.tv/w/1lDGLaBmWRwJm.

[11] [[Naval Ravikant]]. Twitter, Twitter.com/Naval.

[12] [[Naval Ravikant]], “What the World’s Smartest People Do When They Want to Get to the Next Level,” interview by Adrian Bye, __MeetInnovators__, Adrian Bye, April 1, 2013. http://meetinnovators.com/2013/04/01/naval-ravikant-angellist/.

[13] “Episode 2—Notions of Capital & [[Naval Ravikant]] of AngelList,” Origins from SoundCloud. https://soundcloud.com/notation-capital.

[14] “[[Naval Ravikant]]—A Monk in [[Silicon Valley]] Tells Us He’s Ruthless About Time.” __Outliers with Panjak Mishra __from Soundcloud, 2017. https://soundcloud.com/factordaily/ep-06-naval-ravikant-angellis.

[15] [[Naval Ravikant]] and Babak Nivi. “Before Product-Market Fit, Find PassionMarket Fit.” __Venture Hacks__, July 17, 2011. https://venturehacks.com/articles/passion-market.

[16] Peter Cohan. “AngelList: How a Silicon Valley Mogul Found His Passion.” __Forbes__, February 6, 2012. https://www.forbes.com/sites/petercohan/2012/02/06/angellist-how-a-silicon-valley-mogul-found-his-passion/#729d979bbbe6.

[17] [[Naval Ravikant]]. “Why You Can’t Hire.” __Naval__, December 13, 2011. https://startupboy.com/2011/12/13/why-you-cant-hire/.

[18] [[Naval Ravikant]]. “The Returns to Entrepreneurship.” __Naval__, November 9, 2009. https://startupboy.com/2009/11/09/the-returns-to-entrepreneurship/.

[19] [[Naval Ravikant]]. “Build a Team That Ships.” __Naval__, April 27, 2012. https://startupboy.com/2012/04/27/build-a-team-that-ships/.

[20] [[Naval Ravikant]]. “The 80-Hour Myth.” __Naval__, November 29, 2005. https://startupboy.com/2005/11/29/the-80-hour-myth/.

[21] [[Naval Ravikant]]. “The Unbundling of the Venture Capital Industry.” __Naval__, December 1, 2010. https://startupboy.com/2010/12/01/the-unbundling-of-the-venture-capital-industry/.

[22] [[Naval Ravikant]]. “Funding Markets Develop in Reverse.” __Naval__, December 1, 2010. https://startupboy.com/2010/12/01/funding-markets-develop-in-reverse/.

[23] Babak Nivi. “Startups Are Here to Save the World.” __Venture Hacks__, February 7, 2013. https://venturehacks.com/articles/save-the-world.

[24] Babak Nivi. “The Entrepreneurial Age.” __Venture Hacks__, February 25, 2013. https://venturehacks.com/articles/the-entrepreneurial-age.

[25] [[Naval Ravikant]]. “VC Bundling.” __Naval__, December 1, 2005. https://startupboy.com/2005/12/01/vc-bundling/.

[26] [[Naval Ravikant]]. “A Venture SLA.” __Naval__, June 28, 2013. https://startupboy.com/2013/06/28/a-venture-sla/.

[27] Babak Nivi. “No Tradeoff between Quality and Scale.” __Venture Hacks__, February 18, 2013. https://venturehacks.com/there-is-no-finish-line-for-entrepreneurs.

[30] [[Naval Ravikant]], “An interview with [[Naval Ravikant]],” interview by Elad Gil, __High Growth Handbook__, Stripe Press, 2019. http://growth.eladgil.com/book/cofounders/managing-your-board-an-interview-with-naval-ravikant-part-1/

[31] [[Tim Ferriss]]. “Tools of Titans—A Few Goodies from the Cutting Room Floor.” __The Tim Ferriss Show__, June 20, 2017. https://tim.blog/2017/06/20/tools-of-titans-goodies/.

[32] Peter Delevett. “[[Naval Ravikant]] of AngelList Went from Dot-Com Pariah to Silicon Valley Power Broker.” __The Mercury News__, February 6, 2013. https://www.mercurynews.com/2013/02/06/naval-ravikant-of-angellist-went-from-dot-compariah-to-silicon-valley-power-broker/.

[33] Lawrence Coburn. “The Quiet Rise of AngelList.” __The Next Web__, October 4, 2010. https://thenextweb.com/location/2010/10/04/the-quiet-rise-of-angellist/.

[34] Conny Loizos. “His Brand Burnished, [[Naval Ravikant]] Plans New Fund with Babak Nivi.” __The PEHub Network,__ November 5, 2010.

[35] Babak Nivi. “Venture Hacks Sucks Now, All You Talk About Is AngelList.” __Venture Hacks__, February 17, 2011, https://venturehacks.com/articles/venture-hacks-sucks.

[36] Jason Kincaid. “The Venture Hacks Startup List Helps Fledgling Startups Pitch Top Angel Investors.” __TechCrunch__, February 3 2010. https://techcrunch.com/2010/02/03/startuplist-angel-investors/.

[37] Babak Nivi. “1.5 Years of AngelList: 8000 Intros, 400 Investments, and That’s Just the Data We Can Tell You About.” __Venture Hacks__, July 25, 2011. https://venturehacks.com/articles/centi-sesquicentennial.

[38] Eric Smillie. “Avenging Angel.” __Dartmouth Alumni Magazine__, Winter 2014. https://dartmouthalumnimagazine.com/articles/avenging-angel.

[39] Babak Nivi. “AngelList New Employee Reading List.” __Venture Hacks__, October 26, 2013. https://venturehacks.com/articles/reading.

[40] Babak Nivi. “Things We Care About at AngelList.” __Venture Hacks__, October 11, 2013. http://venturehacks.com/articles/care.

[41] Gary Rivlin. “Founders of Web Site Accuse Backers of Cheating Them.” __The New York Times__, January 26, 2005. https://www.nytimes.com/2005/01/26/technology/founders-of-web-site-accuse-backers-of-cheating-them.html.

[42] PandoDaily. “Pandomonnthly: Fireside Chat with AngelList Co-Founder [[Naval Ravikant]].” November 17, 2012. [[YouTube]] [[video]], 2:03:52. https://www.youtube.com/watch?v=2htl-O1oDcI.

[43] [[Naval Ravikant]]. “Ep. 30—[[Naval Ravikant]]—AngelList (1 of 2).” Interview by Kevin Weeks. __Venture Studio, __2016.

[44] Paul Sloan. “AngelList Attacks Another Startup Pain Point: Legal Fees.” CNet, September 5, 2012. https://www.cnet.com/news/angellist-attacks-another-startup-pain-point-legal-fees/.

[45] [[Naval Ravikant]]. “[[Naval Ravikant]] on How Crypto Is Squeezing VCs, Hindering Regulators, and Bringing Users Choice.” Interview by Laura Shin. __UnChained__, November 29, 2017. http://unchainedpodcast.co/naval-ravikant-on-how-crypto-is-squeezing-vcs-hindering-regulators-and-bringing-users-choice.

[46] [[Naval Ravikant]]. “Introducing: Venture Hacks.” __Naval__, April 2, 2007. https://startupboy.com/2007/04/02/introducing-venture-hacks/.

[47] [[Naval Ravikant]]. “Ep. 31—[[Naval Ravikant]]—AngelList (2 of 2).” Interview by Kevin Weeks. __Venture Studio__, 2016.

[48] AngelList. “Syndicates/For Investors.” https://angel.co/syndicates/for-investors#syndicates.

[49] [[Tim Ferriss]]. “You’d Like to Be an Angel Investor? Here’s How You Can Invest in My Deals...” __The Tim Ferriss Show, __September 23, 2013. https://tim.blog/2013/09/23/youd-like-to-be-an-angel-investor-heres-how-you-can-invest-in-my-deals/.

[50] Sarah Buhr. “AngelList Acquires Product Hunt.” __TechCrunch, __December 1, 2016. https://techcrunch.com/2016/12/01/angelhunt/.

[51] Kurt Wagner. “AngelList Has Acquired Product Hunt for around $20 Million.” __Vox__, December 1, 2016. https://www.recode.net/2016/12/1/13802154/angellist-product-hunt-acquisition.

[52] Ryan Hoover. “Connect the Dots.” __Ryan Hoover, __May 1, 2013. http://ryanhoover.me/post/49363486516/connect-the-dots.

[53] “[[Naval Ravikant]].” __Angel__. https://angel.co/naval.

[54] Babak Nivi. “Welcoming the Kauffman Foundation.” __Venture Hacks, __October 5, 2010. http://venturehacks.com/articles/kauffman.

[55] “Introducing CoinList.” __Medium, __October 20, 2017. https://medium.com/@coinlist/introducing-coinlist-16253eb5cdc3.

[56] Marc Hochstein. “Most Influential in Blockchain 2017 #4: [[Naval Ravikant]].” __CoinDesk__, December 31, 2017. https://www.coindesk.com/coindesk-most-influential-2017-4-naval-ravikant/.

[57] Zoe Henry. “Why a Group of AngelList and Uber Expats Launched This New Crowdfunding Website.” __Inc.__, July 18, 2016. https://www.inc.com/zoe-henry/republic-launches-with-angellist-and-uber-alumni.html.

[58] “New Impact, New Inclusion in Equity Crowdfunding.” __Republic, __July 18, 2016. https://republic.co/blog/new-impact-new-inclusion-in-equity-crowdfunding.

[59] AngelList. “Done Deals.” https://angel.co/done-deals.

[60]  [[Naval Ravikant]]. “Bitcoin—the Internet of Money.” __Naval, __November 7, 2013. https://startupboy.com/2013/11/07/bitcoin-the-internet-of-money/.

[61] Token Summit. “Token Summit II—Cryptocurrency, Money, and the Future with [[Naval Ravikant]].” December 22, 2017. YouTube video , 32:47. https://www.youtube.com/watch?v=few99D5WnRg.

[62] Blockstreet HQ. “Beyond Blockchain Episode #3: [[Naval Ravikant]].” December 5, 2018. YouTube video, 6:01. https://www.youtube.com/watch?v=jCtOHUMaUY8.

[63] [[Naval Ravikant]]. “The Truth About Hard Work.” __Naval, __December 25, 2018. https://startupboy.com/2018/12/25/the-truth-about-hard-work/.

[64] “Live Stories: The Present and Future of Crypto with [[Naval Ravikant]] and Balaji Srinivasan.” __Listen Notes, __November 16, 2018.

[65] Blockstack. “Investment Panel: [[Naval Ravikant]], Meltem Demirors, Garry Tan.” August 11, 2017. YouTube video, 27:16. https://www.youtube.com/watch?v=o1mkxci6vvo.

[66] Yang, Sizhao (@zaoyang). “1/Why Does the ICO Opportunity Exist at All?” August 19, 2017, 1:43 p.m. https://twitter.com/zaoyang/status/899008960220372992.

[67] [[Naval Ravikant]]. “Towards a Literate Nation.” __Naval, __December 11, 2011. https://startupboy.com/2011/12/11/towards-a-literate-nation/.

[68] [[Naval Ravikant]]. “Be Chaotic Neutral.” __Naval, __October 31, 2006. https://startupboy.com/2006/10/31/be-chaotic-neutral/.

[69] AngelList. “AngelList Year in Review.” 2018. https://angel.co/2018.

[70] [[Naval Ravikant]]. “The Fifth Protocol.” __Naval, __April 1, 2014. https://startupboy.com/2014/04/01/the-fifth-protocol/.

[71] “Is Naval the Ravikant the Nicest Guy in Tech?” __Product Hunt__, September 21, 2015. https://blog.producthunt.com/is-naval-ravikant-the-nicest-guy-in-tech-7f5261d1c23c.

[72] [[Naval Ravikant]]. “Life Formulas I.” __Naval, __February 8, 2008. https://startupboy.com/2008/02/08/life-formulas-i/.

[73] @ScottAdamsSays. “Scott Adams Talks to Naval...” __Peri[[scope]], __2018. https://www.pscp.tv/w/1nAKERdZMkkGL.

[74] @Naval. “[[Naval Ravikant]] was live.” __Peri[[scope]]__, February 2019. https://www.pscp.tv/w/1nAKEyeLYmRKL.

[75] “4 Kinds of Luck.” https://nav.al/money-luck.

[76] Kaiser, Caleb. “[[Naval Ravikant]]’s Guide to Choosing Your First Job in Tech.” __AngelList, __February 21, 2019. https://angel.co/blog/naval-ravikants-guide-to-choosing-your-first-job-in-tech?utm_campaign=platform-newsletter&utm_medium=email.

[77] PowerfulJRE. “Joe Rogan Experience Episode 1309—[[Naval Ravikant]].” June 4, 2019. YouTube video, 2:11:56. https://www.youtube.com/watch?v=3qHkcs3kG44.

[78] [[Naval Ravikant]]. “How to Get Rich: Every Episode.” __Naval, __June 3, 2019. https://nav.al/how-to-get-rich.

[79] [[Naval Ravikant]]. Original content created for this book, September 2019.

[80] [[Eric Jorgenson]]. Original content written for this book, June 2019.

