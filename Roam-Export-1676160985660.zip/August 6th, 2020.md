[[🏔ADK [[Task Management]]]]

[[Meetings]]: HBS app [[[[ADK]] case studies]] interview

Attendees:: [[Tim Lupo]] [[Jill Starett]]

Time:: 11:00am

Notes::

Hit on

Who was on the team

What the [[Goals]] were

Broader context - talk about the client

What the [[outcome]] was

Biggest challenges

What'd you learn

Guiding principles/experience you leaned on

Designing your life initiative --> new course

fluidity in communication and deliverables

broad and open ended to narrow in

are we working on the right things? 

treated as rapid prototyping

a lot of ideas and narrow down

one challenge was that the audience needed incentive

not just a survey tool

came to the team with long list of ideas

how did you [[prioritize]] --> began to unpack ideas

mechanisms for engagement

{{[[DONE]]}} Write HBS app #[[[[ADK]] case studies]] #///

{{{[[DONE]]}}}} For [[August 7th, 2020]]: ramp up Drupal-related spend

Where are they going to make the decision? How are they finding it out?

Drupal case studies

Industry ad groups

random idea: 

based loosely on understanding of what PinDuoDuo is --> "buy with a friend & save X%" button

when you and a friend purchase the same product a discount is applied

help facilitate/distribute bulk purchases --> costco?

CostCo makes money on membership tho, so would this membership [[model]]

difference is that the product is not a platform but more like Klarna, something ecomm stores install on their sites

[[Personal Task Management]]

{{{[[DONE]]}}}} Learn [[Zettelkasten]] method

{{[[DONE]]}} Add notes for [[Good Strategy Bad Strategy]] #/

