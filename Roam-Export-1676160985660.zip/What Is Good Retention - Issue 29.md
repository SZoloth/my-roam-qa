Author:: [[lennyrachitsky.com]]

URL:: https://www.lennyrachitsky.com/p/what-is-good-retention-issue-29

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

Let’s define user retention as the % of users who signed up and are still active (i.e. using the product, making a purchase, posting a photo) six months later. 

Consumer Transactional: ~30% is GOOD, ~50% is GREAT 

Enterprise SaaS: ~75% is GOOD, ~90% is GREAT

This includes companies such as Salesforce, Workday, and ADP that primarily sell a subscription product to large enterprise companies (i.e. over 1000 employees). 

Let’s define net revenue retention rate as the company’s monthly recurring revenue (MRR) one year ago divided into the current MRR from that same group of customers. Essentially, how much revenue are you driving from a cohort of customers over time. 

Enterprise SaaS: ~110% is GOOD, ~130% is GREAT

This includes companies such as Salesforce, Workday, and ADP that primarily sell a subscription product to large enterprise companies, roughly over 1000 employees. 

**Tags**: #[[retention]] #enterprise #SaaS #B2B

