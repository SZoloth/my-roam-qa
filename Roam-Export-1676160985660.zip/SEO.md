SEO strategy: Persona, Intent, Topic, UX, Content, Conversion

Notes from reforge

{{[[query]]: {and: [[Reforge]] [[seo-content]]}}}

# Big ideas

Effective SEO requires product changes

Three "types" of SEO:

programmatic

reverse engineer other sites that work

clustering keywords by topic

page types

category pages

brand, subcategory, etc

item pages

q&a, forum, UGC

editorial

usually the best but depends on categories 

look at queries and the types of pages that rank

masterclass, dotdash, nerdwallet, hubspot, upwork, healthline

technical

internal link arch, tags, page speed, etc 

one of the best quick wins here, though is optimizing internal links

Tech audits are overused

They're generally just a list of bugs to fix. Generally what clients want is growth. They want a strategic approach to technical health in part, but even so people tend to overindex on tech audits. This is because growth primarily comes from programmatic and/or editorial SEO.

[SEO is meant to both qualify and prime people, more than directly drive conversions](((-TYfNrtWb)))

{{[[video-timestamp]]: 00:18:44}} the main page types that tend to rank: category, listicle, product page, article, homepage

# Process

1. ## Assess opportunity
Tools:: SimilarWeb, Ahrefs

Steps::

Audit your own site

Is the addressable market large enough to be interesting to you?

Look at competitors (both direct and indirect): how much traffic are they getting?

Remember: Don't just like at keywords; don't just look at search volume

2. ## Create an SEO strategy based on topics & personas
The SEO opportunity is about targeting the **persona** [(eg: instead of targeting only people looking for you, also target people who might get value from you)](((seMmxP4IF)))

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FrB5k6Epjo5.png?alt=media&token=62846c3a-68b7-431e-aa08-8bcb70d5d07b)

[You need](((K9a45AEKl))): topical authority, the right pagetype (UX), premium content, and something that drives users to act/convert __on their intent__. 

You're [compared directly against your next competitors](((JV0AI5G_C))). It's about having relatively better authority, ux, content, conversion compared against the other results that __are ranking__. [The more you fulfill the users' intent, the better you'll rank](((t0Bc1NtSW))) - you can rank even if you don't have authority by winning on content, engagement, UX, conversion.

Generally at BOFU (product names, features, etc.), but you should calculate your topical authority.

{{[[video-timestamp]]: 00:36:04}} Calculate your topical authority with GSC and look at top branded queries. Also look at anchor text in backlinks, which pages are shared the most.

Or use [this sheet](https://docs.google.com/spreadsheets/d/1rj_BnEBmmU3cE5gTAt_Y4pvCYncY2Aq6BKX2FPrarg0/edit#gid=352655222) to run an n-gram analysis.

How do you compare relative to competitors for their branded queries?

How to build topical authority?

{{[[video-timestamp]]: 00:29:38}} social shares, branded search, ads, backlinks, internal links, google queries that are " {{your brand name}} + keyword " all **build topical authority**

How to define topics?

Examples of topics and supporting keywords/subtopics 

The page that ranks for “butter lettuce” from masterclass __also addresses__ these subtopics/additional keywords: health benefits, recipes, vs other kinds of lettuce

The page that ranks for "5 year plan" from betterup __also addresses__ these subtopics/additional keywords:, examples, templates, personal vs business, 5 vs 10 vs 1 year

**Successful SEO strategies are built around topics, not keywords. Topics are thematic classifications of keywords that describe a particular subject in depth**. For example, the keywords “best animal shelters,” “how to foster a dog,” and “dog rescue near me” would all nest under the topic “adopt a dog.” You might say, isn’t “adopt a dog” also a keyword? And the answer is yes, topics can also be keywords. The difference is that keywords commonly have a specific search intent behind them, while topics are more generic and all-encompassing.

Start by brainstorming themes that your addressable market is interested in. Themes are very broad categories that many topics could fit within. While themes are important for this exercise, they will not be a great factor in your overall SEO strategy.

To identify these themes/topics look at SERPs for different keywords

if the results on the SERPs are different, that means the keywords are not part of the same theme/topic. In this case, you should make different pages.

If there is a lot of overlap in the results for these SERPs, it's likely these keywords __are__ part of the same theme/topic. In this case, you should have one page that targets these keywords

3. ## Define and design the right page type
[How do you assess the UX or pagetype for the intent?](((qByqKFiZ5))) [Screenshot top SERPs and spot patterns that correlate with rankings](((G8SYxBdEV)))

for each topic/theme, what type of pages rank?

look at what types of pages rank for your themes - are they articles? quizzes? do they have maps? etc.

for each given pagetype, what is the "product" strat (eg: components on page)?

using on page features (eg map) suss our user goals (eg find the biz) and think about other ways to help accomplish that goal

__take inspiration, don’t copy__

4. ## Create premium content
Tools:: Clearscope

{{[[video-timestamp]]: 00:38:00}} **Good content** is not subjective. It's algorithmically assessed, especially looking at comprehensiveness

{{[[video-timestamp]]: 00:40:20}} in order to adequately fulfill the intent, your content needs to comprehensively cover the head/target term __and also__ the related keywords/intents/secondary keywords (eg: assess the same piece of content against 2-5 keywords that represent different themes in clearscope)

To start, make like ~20 articles/pages, wait ~3-5 months to see if pages are getting into the top 5 or trending that way

At scale, produceroughly 10-25 articles per month

but based on topics in your addressable market 

and based on how fast you want to get there

if starting from zero, start with 10-25 to get leading indicators 

5. ## Engage & drive __towards__ conversion

{{[[video-timestamp]]: 00:46:06}} Build the intent of the user over time (it takes multiple times for someone to see your brand before they purchase) with things that fulfill their intent (ie not a newsletter pop up, but more engaging content like a video, quiz, tool, asset). In other words, map your conversion action to the stage of the funnel.

ergo, put things like videos on TOFU / awareness pages - even if it's a relatively broad video!

quizzes are good for things like "best {{product}}"

eg [[Aramark [[Uniforms]]]]

images with your logo

