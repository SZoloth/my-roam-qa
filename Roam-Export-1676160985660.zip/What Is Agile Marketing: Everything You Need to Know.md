Author:: [[agilesherpas.com]]

URL:: https://www.agilesherpas.com/blog/what-is-agile-marketing

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[October 4th, 2020]]

According to the manifesto, [[agile]] marketers value:

Validated learning over opinions and conventions
Customer-focused collaboration over silos and hierarchy
Adaptive and iterative campaigns over Big Bang campaigns
The process of customer discovery over static prediction
Flexible vs. rigid planning
Responding to change over following a plan
Many small experiments over a few large bets 

The principles remain up for debate, but these are the candidates for guiding work on an [[agile]] marketing team:

Our highest priority is to satisfy the customer through early and continuous delivery of marketing that solves problems.
We welcome and plan for change. We believe that our ability to quickly respond to change is a source of competitive advantage.
Deliver marketing programs frequently, from a couple of weeks to a couple of months, with a preference for the shorter timescale.
Great marketing requires close alignment with business people, sales, and development.
Build marketing programs around motivated individuals. Give them the environment and support they need, and trust them to get the job done.
Learning, through the build-measure-learn [[feedback]] loop, is the primary measure of progress.
Sustainable marketing requires you to keep a constant pace and pipeline.
Don’t be afraid to fail; just don’t fail the same way twice.
Continuous attention to marketing fundamentals and good design enhances agility.
Simplicity is essential. 

First we see the backlog, which is simply a [[prioritize]]d to-do list for the marketing team to use as the source of all their work. That's a nice simple explanation, but backlogs are shockingly difficult to maintain.
To be at their most useful they need to be constantly updated, and the work near the top needs to have enough detail that the [[agile]] marketing team could start working on it immediately without asking anybody any questions.  

At the start of each Sprint the marketing team pulls work from the comprehensive marketing backlog to form the smaller Sprint backlog. This is the amount of work they believe they can complete within their next Sprint. It's up to the team to make this call, not their manager or the director or the CMO. 

Generally you should plan to take an hour for each week of your sprint for planning, meaning a two week Sprint will take two hours to plan. If you're estimating the size of your work that should also happen during Sprint Planning.
You can assign points to each project to reflect their relative size 

After the Sprint Planning meeting the team is committed to a set amount of work and the Sprint begins. Ideally once they've started the Sprint the team is locked into to only the work they've chosen.
Nobody should be able to add anything new onto them.
In reality there are usually unplanned things that come up, so you can either negotiate these events by taking some work out to make room for the unplanned projects, or you can leave some of the team's time unplanned knowing that something will happen to fill that time. 

As the Sprint proceeds, the team meets everyday to share their individual updates on how things are going during the Daily Standup meeting, also known as the Daily Scrum. 

The traditional format for standup is to talk about only three things: what each team member did yesterday, what they plan to do today, and any road blocks they're experiencing. It's very easy for this meeting to devolve into a boring check in, but it should be more like a mini-strategy meeting or a football huddle. 

The Sprint review is like a show and tell. Any and all internal stakeholders attend, and the marketing team shows what they've completed during the previous Sprint. 

A [[[[retro]]spective]], on the other hand, is attended only by the Scrum team.
It's their opportunity to honestly discuss how the process is working for them and how they might make it better. Any suggestions for improvements that the team comes up with should be documented and added to the backlog to make sure they're acted on. There's nothing more frustrating than talking about the same things at every single [[[[retro]]spective]] because the problem isn't being addressed. 

As their name implies, the Scrum Master helps ensure the team is using Scrum in the best way possible. They facilitate meetings, help the team embrace the [[agile]] mindset, and provide suggestions for process improvement. 

As for the Product Owner, this Scrum role is designed to be the intermediary between the development team and the business. They keep the backlog current, communicate with stakeholders, and help the team make sure they're doing the right work at the right time.
Marketing teams typically find the best success when they give the Product Owner responsibilities to a marketing leader like a director or senior manager. 

### New highlights added [[November 2nd, 2020]] at 7:47 PM

First we see the backlog, which is simply a [[prioritize]]d to-do list for the marketing team to use as the source of all their work. That's a nice simple explanation, but backlogs are shockingly difficult to maintain.
To be at their most useful they need to be constantly updated, and the work near the top needs to have enough detail that the [[agile]] marketing team could start working on it immediately without asking anybody any questions. 

