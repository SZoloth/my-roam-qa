Author:: [[Richard Rumelt]]

Tags:: #[[[[strategy]] [[*]]]], #[[Grand Strategy]], #[[How to execute a strategy]], #[[How to execute a strategy]] #Books #Inbox

References::

[[Competitive Strategy]] by [[Michael Porter]]

Summary::

A good strategy helps you identify and [[prioritize]] the highest leverage inputs towards a goal.

Bad strategies overuse fluffy words, do not address the challenge specifically, just name the goals (instead of how to get there), or are impractical

Define the goal & why it's worth prioritizing

Goals vs. objectives

"Goal" = overall values and desires (eg - freedom, justice, peace, security)

"Objective" = operational targets (eg - defeat the taliban, rebuild infrastructure)

who are your buyers?

who do we compete with?

what opportunities exist?

what are the challenges

Be wary of mischaracterizing __results__ as __challenges__ (eg - underperformance is a result, where the challenge is the __cause of the underperformance__)

Define the highest leverage inputs that contribute to the goal

Create a framework to decide whether an opportunity should be [[prioritize]]d or not

Outline a plan to invest in those inputs

A strategy can be described as a #[[kernel[[*]]]] 

A [[diagnosis]]

Identify your most promising opportunities by having a small team look at: who your buyers are, who you compete with, and what opportunities exist.

Pay close attentions to changes in your business and industry

After reviewing, identify the 1-2 most attractive opportunities to channel the bulk of your energy #[[Pareto principle]]

Define the challenge in as simple and crystallized terms as possible

It links facts into patterns & classifies situations.

A [[guiding policy]]

The overall approach to overcoming the obstacles (challenges) identified by the [[diagnosis]]

Frameworks: they define a methodology of addressing the [[diagnosis]], while ruling out other methods

**They need to anticipate actions and reactions of others**, reduce complexity and ambiguity, concentrate on high leverage tactics, and ensure the actions are coordinating to build on each other

To anticipate: consider the habits, preferences, ad policies off others in context of the constraints on change

And a set of [[coherent actions]]

Defines how to execute the guiding policy

Coherence is created by actions that are consistent and coordinated

Why do business strategies change? Most commonly because of changes in the [[diagnosis]]

Literature notes::

p.2

Strategy can be boiled down to identifying the highest leverage inputs in a situation then focusing on them.

p.4

You have to honestly appraise challenges before coming up with a way to overcome them.

p.7

[[Richard Rumelt]] breaks strategy down into a [[kernel[[*]]]] with 3 parts: a [[diagnosis]], a [[guiding policy]], and a set of [[coherent actions]].

Where guiding policies define the approach, the actions are things like resource commitments and tactics coordinated to support the guiding policy.

p.20

As always, good strategy is more about saying "no" than saying "yes." 

Implicit but important: when you push resources towards one challenge or opportunity, you're necessarily pulling them away from another. 

p.24

Always consider the competition & competitive context.

p.33

A strategy is bad when it: overuses fluffy words, does not specifically address the challenge, stops at naming the [[Goals]] (instead of how to get there), or are impractical.

p.35

Strategies have to explain why a challenge is worth prioritizing.

p.47

For managing clients, make sure they agree to engage in a dialogue before you challenge their ideas. In other words, if they present something you take issue with you shouldn't necessarily challenge immediately.

p.49

In terms of a framework, [[Richard Rumelt]] lays it out like this:

Identify your most promising opportunities by having a small team look at: who your buyers are, who you compete with, and what opportunities exist.

Pay close attention to changes in your business/industry

After reviewing, identify the 1-2 most attractive opportunities to channel the bulk of your energy #[[Pareto principle]]

p.52

"Goal" = overall values and desires (eg - freedom, justice, peace, security)

"Objective" = operational targets (eg - defeat the taliban, rebuild infrastructure)

p.55

Be wary of mischaracterizing __results__ as __challenges__ (eg - underperformance is a result, where the challenge is the __cause of the underperformance__)

p.76

If the beginning of strategy is analysis, the beginning of analysis is considering what events may happen--positive or negative.

p.77

A diagnosis defines or explains the challenge in as simplified/crystallized terms as possible. 

It links facts into patterns & classifies situations.

Classification unlocks metaphors/analogies.

A guiding policy is the overall approach to overcoming the obstacles identified by the diagnosis.

A set of coherent actions define how to execute the guiding policy.

p.81

The diagnosis simplifies the situation into an easy to grasp [[model]] of reality.

The diagnosis needs to be addressable with policy.

p.83

Changes in diagnosis are the most common reason business strategies change.

p.84

Guiding policies are more like __frame__works: they define a methodology of addressing the diagnosis, and rule out others.

p.85

Guiding policies: anticipate actions and reactions of others, reduce complexity and ambiguity, concentrate on high leverage tactics, ensure the actions are coordinating to build on each other.

p.91

For actions to be coherent they need to be consistent and coordinated.

p.98

The most important things to anticipate are the behaviors others.

p.100

Anticipation should be done by considering the habits, preferences, and policies of others in context of the constraints on change. 

This is highly relevant to [[Superforecasting]]

p.103

One of the ways strategies are constrained are "threshold effects." These exist when there is a minimum level of effort necessary to have an effect. An example of this is brand advertising.

p.105

One of the things to focus on for __personal__ strategy is visibility: relatively low output with high visibility is usually more valuable than relatively high output with low visibility.

p.112

High leverage = the single feasible objective that has the biggest impact.

p.116

Chain-link systems occur when the quality of parts matter (are limiting factors).

p.128

Hannibal effectively anticipated the behaviors of the Romans by taking into account their history, traditions, doctrine, and training. He stoked this further by raiding their camp the night before to poke at their pride.

p.129

It's easy to confuse strategy with good decision making, but truly great strategy is not about choosing between alternatives. Rather, it requires the strategist to design or construct a novel response.

p.134

[Rumelt]([[Richard Rumelt]]) describes something called [[design-type [[[[strategy]] [[*]]]]]]

It basically means matching both resources and integration of those resources to the challenges in order to gain an advantage.

Resources and how you integrate them are partial substitutes: if the situation  forces less of one, you need more of the other.

It's also important to note that increasing tightness of integration comes at increasing costs

it's more difficult, narrow, fragile and less adaptable.

p.143

To [[identify a company's [[[[strategy]] [[*]]]]]], start first by looking at how their competitors make their money.

p.145

By how to  [[identify a company's strategy]]?

Look at their **policies**

Focus on the **policies** that are unique

Try to understand that those **policies** are intended to accomplish (what their targets are)

p.146

How to tackle **formless questions**

Replace general nouns with specific examples

p.149

In the Crown example, [Rumelt]([[Richard Rumelt]]) demonstrates how a company can win by capturing a higher percentage of the value it creates, compared to competitors who after larger volumes of business that provide a lower percentage.

In this example, it's because Crown has [[specialized]] and increased its bargaining power

p.163

[[Moats]] are not just advantages, but more importantly __how__ an advantage is sustained

The harder it is to replicate the advantage, the more effective moat you have

You make replication harder by possessing an "[[isolating mechanism]]"

Examples of [[isolating mechanism]]s:

patents

reputations or brand

[[nfx/network effects]]

economies of scale

unique knowledge or skills

p.169

To increase value, you need a strategy that moves any of the following forward:

deepening advantage

advantage = the gap between buyer value and cost

therefore, deepening your advantage means either increasing value, reducing costs, or both.

costs should include intangible things like the time/energy/opportunity cost of searching for a product, evaluating it, waiting for it to arrive, switching to it, learning how to use it, etc.

broadening the extent of advantages

Basically means "build on your strengths," but that's sneaky difficult. Most companies will cite things like "management" as a strength, but that ain't right.

More frequently, strengths reside in complex knowledge or [[earned secrets]]

creating higher demand for the products or services that have an [[isolating mechanism]]

This is similar to something [[chris baker]] mentioned around brand strategy as "creating new games" (his example was Drift and "conversational marketing").

Reinforced by "us vs. them" narratives (see Hey Email as a recent strong example)

strengthening the [[isolating mechanism]] 

p.179

Take advantage of a [[wave of change]] (where your industry is headed) by

Predicting the likely evolution of the landscape

Focusing resources and ideas towards positions that __will become__ "high ground" (both valuable and defensible) in the future.

p.184

In order to predict where a [[wave of change]] is going you need domain expertise

Eg - Teladoc and Livongo recently merged. Many believe it signals a shift in the telehealth landscape towards consolidation. 

p.193

[Rumelt]([[Richard Rumelt]]) references a set of fixed points of references, or guideposts, that are similar in concept to the [[Principles]] from [[Ray Dalio]]

[Rumelt]([[Richard Rumelt]])s [[Principles]] for understanding a [[wave of change]]

Escalating fixed costs

Increases in fixed costs - especially development costs - often force consolidation in an industry. Why? Because only the larger companies can cover these increased costs.

Therefore: when you see fixed costs increase, expect consolidation.

For telehealth, was there an increase in fixed costs?

Eg - Teladoc and Livongo recently merged. Many believe it signals a shift in the telehealth landscape towards consolidation. 

Deregulation

Shifts in government policy open and close opportunities.

Regulated prices almost always subsidize some buyers at the expense of others

This artificially inflates the value of a customer segment, such that when deregulation occurs companies that still go after the inflated customer segment suffer.

Predictable biases in forecasting

This relates to [[Superforecasting]]

An example bias: business or economic trends are rarely predicted to peak then decline. Instead, most people expect continued growth.

An example bias: during a [[wave of change]], the standard prediction is that incumbent leaders will duke it out, instead of a challenger sweeping in.

Another example: future winners will look current winners so you should follow the strategy of the current largest/most successful company.

Incumbent responses to change

You can generally expect incumbents to resist transitions that undermine the skills they've invested in or valuable positions they've accumulated over time.

Attractor states (p.199)

It's the maximal state of efficiency in an industry that describes how it should work despite technological forces, government intervention, and the structure of demand.

Movement towards an attractor state is largely governed by accelerants and impediments

 P.261

Being strategic is better using present facts and [[insight]]s to be less myopic than colleagues and competitors. 

P.264-267

We tend to latch onto our first [[insight]]s or theory and spend most of our energy defending it, rather than questioning it. 

P.268

Three essential skills or habits for strategic thinking:

Develop tools for fighting your own myopia and attention

Develop the ability to question your own judgments 

Cultivate the habit of recording and reviewing your judgments/predictions so you can improve them

 Highlights::



