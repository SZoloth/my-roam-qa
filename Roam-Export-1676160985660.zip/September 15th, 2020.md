[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} How do we test for [[React SEO]] websites? #/

[[SEO Launch plan]]

Questions to answer

How should a website be built for SEO?

What should happen when it's React / JS?

How do we test that a website was properly built for SEO?

What should happen when it's React / JS?

Things to check:

Robots.txt

Meta robots

X-robots

Canonical tags

Self-referential canonical tags should point to the version that has: HTTPS and `www.` and a trailing slash

One browsable version of URLs

301 redirects all non-canonical versions of URLs (examples below) to the canonical version: with HTTPs, `www.` and a trailing slash

http://yourdomain.com

http://www.yourdomain.com

https://yourdomain.com

https://www.yourdomain.com

HTTPS

HTTP versions should 301 redirect to HTTPs

How to check

Crawl via Screaming Frog and/or [[ahrefs]]

Page speed

Mobile indexing

Internal docs

https://docs.google.com/spreadsheets/d/1MEChKfobYm1Wxt0h_Dii0g-hDeMw9x-KMm7wEKeQBMc/edit#gid=2019172590

https://docs.google.com/spreadsheets/d/1kauSM1fm9AujDDazIZrcbcxYzTNcxosM2PL-K3yVoXk/edit#gid=0

All / general checklist

In a site migration

Before the migration

Crawl affected URLs with [[Screaming Frog]] and collect:

Links, traffic, rankings, relevance, internal linking, speed, indexability, crawlability

Make sure to include: GA, GSC, XML sitemaps, Log Files, and Backlinks in your crawl

Audit the pages:

Low quality content, no rankings, link or traffic? 404s? Don't bring these pages

If a rebrand, what pages (eg - rebrand announcements) need to be created to capture rankings with the old brand?

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FSyZrbK71x6.png?alt=media&token=1a0ae0f6-fa27-4475-87ec-65af5f4b95b4)

Download the XML sitemap

Test the new pages

Are all old pages redirecting properly?

[List crawl](((SCVl4LTaD))) old URLs with [[Screaming Frog]] 

List crawling means uploading the list of original URLs as a .csv 

Is site speed acceptable? 

Is the content indexable?

To crawl a staging site with [[Screaming Frog]] you'll likely need to ignore robots.txt

Configuration >> robots.txt >> settings >> ignore robots.txt but report status 

To crawl any site with [[Screaming Frog]] that has a webform authentication, you'll need to create a user with **read-only access** and use that info to [[Log in]]

Why read-only? [This post](https://www.screamingfrog.co.uk/crawling-[[password]]-protected-websites/) goes into more details, but basically [[Screaming Frog]] will click on __every__ link indiscriminately, meaning it can mess up the site. 

Look for URLs that might be blocked, no-indexed, linking to or canonicalizing old pages

Are the pages crawlable?

Are all URLS set up with HTTPS?

Set up profiles

Google Analytics, GSC, [[ahrefs]]

Structured data

Redirects have been mapped

301 redirects from old pages to relevant new pages

Sitemap created (XML and HTML)

Robots.txt configured

Rel=canonical configured

href lang configured

After every issue has been resolved, submit new and old URL XML sitemaps to be recrawled

For domain level migrations, use the Change of Address feature in GSC

[[React SEO]] checklist

Test with First step: mobile-friendliness test

Back up with Screaming Frog

{{{[[DONE]]}}}} Review [[Privafy]] [SEO strat doc](https://docs.google.com/document/d/1qPknj6bLmet37ewk8poTQ54CL8jhhF_U_63KHuzHeA0/edit) from [[darci nevitt]] #/

{{{[[DONE]]}}}} Follow up on [[[[mHealth]] app kit]] GTM #/

The current [designs](https://adkgroup.invisionapp.com/d/main?origin=v7#/console/19994884/425599330/preview?scrollOffset=4108) have not been updated with the latest [content recommendations](https://docs.google.com/document/d/1zVT97rcTsCSeRoWzOtz1llKBH1lU0AKEj2y6SIitapQ/edit#)

