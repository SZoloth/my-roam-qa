New [[ADK innovation chat]]


industries

healthcare

WFH

Maker economy

Twitch

Onlyfans

alternative/supplementary forms of income

Etsy

Multiple income streams

Edtech

Masterclass / Peloton

Restaurants

Ghost kitchens

Insurance and unemployment safety nets

For consultants?

Multiple income streams

Overall change with government

Real estate

Green houses

Ghost kitchens

Home office and home decorations

Shipping & delivery

privatization?

Finance

Community building

Biz - conferences

How do you simulate those random encounters?

That builds a relationship - how do you do that around a personal level?

Coffee chats + https://lunchclub.ai/

Strengthening alumni network

Local - nextdoor

SMB - collaboration

Figma

miro

Religion

Virtual/Augmented reality?

Automation

What jobs are getting eliminated? How will they get replaced (if they will)?

Legislation changes

How to track and take advantage

What rule changes and flexes are permanent v. not?

Unemployment safety nets and insurance

Vices - cigarette delivery

Trending upwards even though its especially bad for COVID

