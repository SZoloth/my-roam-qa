For Sam

Medicine + toiletries

Contacts

Contact solution

Face

Hair

Razor

Cologne

Glasses

Clothes

Exercise, mostly

Hat(s)

Slippers

New Balances

Kettlebells delivered to Ally's

Masks

Laptops

Chargers

Monitor

Xbox

Controllers

Batteries (coffee table)

Books

iphone chargers

airpods

longboard

notebook

General

Wine

Food

Olive oil

Coffee beans

Pepper

