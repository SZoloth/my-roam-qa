[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Positioning / messaging strat for [[Museum of Science]] #/

{{{[[DONE]]}}}} Question about report + conversion window from [[jess lopez mora]] for [[form health]] #/

[[flywheels]]

Good references

[[Lenny Rachitsky]] [on flywheels](https://www.lennyrachitsky.com/p/flywheels-flywheels-flywheels-issue)

Why [[model]] out #flywheels? 

They help with [[Focus[[*]]]] by making it clear which investments accelerate your flywheel most.

They help you understand [[competitive advantage]]

![archetypes.jpg](https://cdn.substack.com/image/fetch/w_1456,c_limit,f_auto,q_auto:good,fl_progressive:steep/https%3A%2F%2Fbucketeer-e05bbc84-baa3-437e-9518-adb32be77984.s3.amazonaws.com%2Fpublic%2Fimages%2F72244e3d-7140-4536-ac7b-613e4383f556_3296x2266.jpeg)

How to [[model]] #flywheels

Step 1: Start with a list

What are the core** assets** of your business? e.g. cars, content, hardware devices

What are the core** actions** users take? e.g. signing up, inviting friends, purchasing

What are the core **needs** of your users? e.g. something to watch, a ride, discounts

What are the natural **outputs** of your business? e.g. content, revenue, invention

What are the biggest **optimizations** to your business [[model]]? e.g. lower costs, better data

Step 2: Find items in your list that **directly drive** another item

See if you can create a loop that connects a handful of these

#movies Margin Call

#movies The Big Short

[[Personal Task Management]]

{{{[[DONE]]}}}} Find restaurant + wine + maybe picnic stuff for anniversary with [[Ally Portocarrero]] #/

wine = AP

https://www.foxandtheknife.com/

https://www.grayshall.com/menudinner on sunday?

http://publicoboston.com/

http://www.wordenhall.com/

https://moonshine152.com/menu/phase-3/

https://local149.com/menu/

{{{[[DONE]]}}}} Fix my fucking iphone #/

