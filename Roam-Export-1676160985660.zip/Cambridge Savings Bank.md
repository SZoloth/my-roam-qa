[[[[Cambridge Savings Bank]] [[[[growth]] [[practice]]]] Project]]

Background notes

[[ivy bank]]: digital first bank, going national

Wants more aggressive growth

Want to be thought leaders in a "new way" to do banking

vs. BoA or Citizens

More modern and personal

One way: financial education

Ideation

Trends in finance and fintech

Experimentation process

Innovation

Building a brand

Animation, interactive, experience

Paint picture of

Immediate, near term focus

Balance with longer term initiatives supported by research

Building an experimentation process

CSB brand

Respect

Human connections

Treat every customer like our only customer

Questions

Channel mix

Highest tofu?

Highest bofu?

Positioning?

Ivy vs. CSB

How and when do people switch banks?

How and when do people start banking?

Next steps

**Idea 1: SEO - Learning resources embedded into the site to prevent users from having to leave the site.**

SEO

Opportunity

Paint picture of opportunity (or loss...)

Keyword research (nonbranded traffic from top 1000 keywords)

CSB: 1328 nonbranded searches per month (327,580 total opportunity)

Middlesexbank: 1194 nonbranded searches per month

Cambridgetrust: 1317

Florencebank: 1515

Bankfive: 1618

Easternbank: 1186

The heavy hitters

Citizens: 38,425 nonbranded searches per month

CreditKarma: ~1m nonbranded searches per month from top 1000 keywords

NerdWallet: 4,345,565 nonbranded searches per month from top 1000 keywords

BoA: 1,273,542 nonbranded searches per month

Examples

illustrate what drives traffic, what drives engagement, what drives conversion, what drives virality?

CreditKarma, NerdWallet, https://bettermoneyhabits.bankofamerica.com/en

Current experience

[Lost rankings](https://docs.google.com/spreadsheets/d/1C09g_fHDgw5-Ztf0pp_n6M208tvHzNlv4RbOjRy-zgA/edit#gid=0)

12 keywords from first page representing possible 4,650 monthly searches

120 total keywords representing possible 65,350 monthly searches

Banzai driving 0 traffic

Offsite flow

https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2F8mstZQqe5J.mov?alt=media&token=50183961-823f-4d24-99ba-a267f5377cd8

Resolution

Pull from [[Wasabi]] site redesign pitch + principles

Create learning hubs on site to control experience, data, and conversion process

Opportunities:

Attract

SEO

Engage

Email courses

Convert

Real stories 

CTAs (email, website, etc.)

Differentiate

Create an academy with an experience similar to HubSpot and Duolingo (badges, progress, account, certifications, etc.)

Content to be supported

Pillars

Glossaries

Comparisons

Tools (quizzes, calculators, etc)

More global additions

Dynamic content recommendations (light [[personalization]])

Contextual CTAs

**Idea 2: Validate current experience and find optimization opportunity through heatmapping tool analysis and user tests of key conversion flows**

CRO

What does the conversion [[funnel]] look like?

How do we improve it?

What's the right cadence and process for rapid innovation through **experimentation**?

Experimentation is driven by hypotheses which are fueled by [[insight]]s and deep understanding of your customer

Testing

User testing 

Analytics audit

User surveys

Passive heatmap tracking (Microsoft Clarity)

Usability testing

See [[[[product]] [[strategy]] [[team]]]]

**Idea 3: Ivy bank + CSB topic**

How to promote ivy without cannibalizing?

Define target audience, use cases

Who is Ivy competing with?

Wealthfront

Ally.com

Better.com

SoFi

Marcus

What are the differences in customer/value prop/use cases between Ivy + CSB?

[[outcome]]s

Positioning and use cases

vs. CSB

vs. competition

Differentiated content strategy

**Idea 4: Long term**

Revealing Reality to Fuel Innovation & Differentiation

Research

Users

Market

Brand building (cibo)

Presentation flow

Intro

Timeline

Short term: Idea 1

Near term: Idea 2

Long term: Idea 3

Zoom in on: idea 1

Present ideas 2 & 3 and Questions

Next steps

Kick off idea 1 discovery

Set up cadence of [[insight]] mining --> hypotheses --> experimentation

Ivy Bank discovery

Discovery for experimentation architecture needs

