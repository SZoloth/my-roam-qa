[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} [[SBIR blog]] for [[ADK/blogging]]

{{[[DONE]]}} Review the [[form health]] dashboard from [[darci nevitt]]

{{[[DONE]]}} Write up the SEO glossary tactic post for [HubSpot guest posting](https://blog.hubspot.com/marketing-guest-blogging-guidelines) #///  | [[Finished]] at 18:20 [[November 9th, 2022]]

{{[[DONE]]}} Get a handle on ADK content

{{[[DONE]]}} Metadata for [[quest diagnostics]] via [[khj]]

{{[[DONE]]}} [[influencer marketing]] for [[Major Decision]]

{{[[DONE]]}} write out [[ADK Marketing Needs]] for CB (based on Roam notes and B2B matrix in Google Drive)

{{[[DONE]]}} get a grip on [all launched projects from ADK](https://docs.google.com/spreadsheets/d/1Aab1D0XnymboX2ojXkltSIzBg0GzcDPU8tUpOM4zusM/edit#gid=1398608892&fvid=580606445)

{{[[DONE]]}} Plan for keeping that db up to date and complete

Major Decision retargeting

ADK React blog

CEC Detroit tagging

Major Decision marketing strategy

ADK remote meetings blog

Sanjay

Form health analytics email

Wasabi SEO email

Wasabi glossary SEO

