[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} [[Major Decision]] [[scope]]

{{[[DONE]]}} [[SBIR blog]] for [[ADK/blogging]]

{{[[DONE]]}} [[ADK React Blog]]for [[ADK/blogging]]

{{[[DONE]]}} for [[CEC Detroit]], explain that we'll be providing a dashboard just like [[BSF]]

{{[[DONE]]}} Review the [[form health]] dashboard from [[darci nevitt]]

{{[[DONE]]}} Write up the SEO glossary tactic post for [HubSpot guest posting](https://blog.hubspot.com/marketing-guest-blogging-guidelines) #///  | [[Finished]] at 18:20 [[November 9th, 2022]]

{{[[DONE]]}} Get a handle on ADK content

Received an email from [[Justin Watts]] of [[Metalab]] about podcast and agency advertising (!)

Basic ideas as they relate to [[ADK Marketing Needs]] are:

For [[brand awareness]] smaller [[podcast]] that talk directly to our audience is much better than larger, more general audience

Otherwise, get case studies in front of the right audiences. To do this, use [[linkedin]] ads

Clear value props and CTAs at the end of case studies helps a ton

Focus on accruing social proof: get quotes and testimonials from clients to share publicly

[[Justin Watts]] found that it's better to focus on sharing the highest quality work that you can tell the best story about, instead of a large quantity 

For [[🏔ADK [[Task Management]]]]: what are the "hero" projects for each segment (Healthcare, Enterprise, University, Manufacturing, etc.)?

According to [[Justin Watts]], for agencies, [[twitter]] and [[linkedin]] are the best channels for acquisition, while [[instagram]] is great for recruitment

Overall, focus on standing out in terms of voice & tone

