[[🏔ADK [[Task Management]]]]

Positioning for [[Museum of Science]]

## **Personas**

^^Principal^^

behavior::

Discover EiE

Review case studies

Hear from peers

Compare alternatives

Motivation::

Increase access

Achieve standards

__High test scores__

Cross-department wins & *synergy*

Frustration::

Due diligence takes too much time

Bureaucratic approval process

Answering to many stakeholders

^^Superintendant^^

behavior::

Discover EiE

Review case studies

Hear from peers

Compare alternatives

__Evaluate cost__

Motivation::

__Create a success story for district__

Increase access

Achieve standards

High test scores

Cross-department wins & *synergy*

Frustration::

Finding money in budget

Most at risk for failure

**General**:

Matches up with NGSS standards

Built for programs with 250+ enrollees

Targeting NGSS science standards

Pain points

Orgs want better STEM [[outcome]]s

Professionals feel unprepared

Tech outpaces typical curricula

Schools have new standards to hit but not more time

## **About the product**

### **General**

has a carefully designed and content-rich online instructional pathway for teachers

Narrative + design challenge

Narrative encourages emotional connections

Group design challenges encourages social learning

Small group projects

Both combine to support the whole child

Design challenges foster unique solutions because there is no one right answer. 

__not__ input/output

__not__ dragging and dropping code

No one right answer, failure is encouraged.

Program is structured, not scripted

Activities that are proven to appeal to __all__ students, without expensive or complex materials.

### **Unique features**

Producing hybrid (digital + real life) and digital-only products

features online teacher experience paired with experiential hands-on design and computer challenges for the student

Integrated: engineering __plus__ comp sci

Built on core principles of equity and access of STEM for under-represented groups

Useable on-site, as well as distanced

Defines technology as something that's been created to be useful or improve something, which allows it to tie to both engineering __and__ comp sci

NSF-funded published programs

Transform the teacher [[model]] ❓

Shift from instructor to coach

Based on the "Habits of Mind": 16 thought patterns and principles that leaders in engineering use in their approach

Helps student understand the "why" and "how", not just the "what"

Go layers deeper to help students develop [[model]]s of thinking that apply to any subject.

Specific focus on engineering, not just a nod

Comp sci integration (1+1 = 3)

## **Focus**

What story can we tell that will be ^^intriguing^^ and ^^sticky^^?

Mission is to raise awareness, achievement, and access to STEM education for all

Change the mindset of how students see themselves

ELL support

Creating a generation of problem solvers

## **Notes**

Build the future builders of the future

Free the next generation of kids to be more creative, more independent, more successful, and more confident. 

Create a generation of curious, confident problem-solvers.

When it comes to learning, your students deserve more than input/output and drag-and-drop.

Mentor/encourage/nurture the next Musk

STEM as a gateway

It's our job to encourage the next Jobs

You're teaching the next hometown heroes

Create the next generation of __problem solvers__

Your students will come out of this being able to conduct controlled experiments, but passionate about 

Your students can master critical thinking and problem solving skills through fun and accessible comp sci/engineering design challenges. 

Learning that feels like play. Results that ^^___________^^

Set your students up for future success.

Not everyone will become an engineer, but giving your students critical thinking and problem solving skills will prepare them for anything.

Change trajectories

Go layers deeper to help students develop [[model]]s of thinking that apply to any subject.

### Proof

Adopted nationwide by over 44,000 educators and millions of students

How many districts?

Aligned with NGSS

NSF-funded published programs

The nation's leading engineering curriculum for grades 1-5, based on research and tested by teachers.

### Offers

Discount

Preview of curricula

Guided walk through

On-demand [[webinar]]?

Share with x people

Downloads

Guided walk through

Habits of Mind

Curricula preview

Sign up for limited access (free trial)

Case studies

How {{district}} {{improved STEM scores 3x}}

### **Outline notes**

Rough

Brain dart

Why comp sci + engineering?

Proof

Stories from educators like you

What it is

Showcase a lessons, starting with the story

What's included (a complete solution, new to CS and engineering)

[Components](https://eie.org/eie-curriculum/eie-curriculum-components)

Even if you're short on time

Because these areas strengthen core fundamentals, they support other subjects. A rising tide. 

See the unique Engineering Design Process in action! [video](https://eie.org/overview/engineering-design-process)

Proof

Stats

Any research like [amplify](https://amplify.com/programs/amplify-science/?state=US)?

 Children who use EiE perform significantly better than control group students on questions about engineering, technology, and science.

Students from groups historically underrepresented in engineering (women, racial and ethnic minorities, students with an IEP, students from low-income families, and English [[language]] learners) show enhanced interest, engagement, and performance after participating in EiE when compared to students participating in a science curriculum alone or in school in general.

Comparison

Price

Philosophy

Scalability

Ease of use / logistics / teacher training

How it fits in with the rest of your curriculum

Built-in Connections to Math, ELA, Science, Art, etc.

No need to hire specialists

A variety of professional development workshops that help level up your teachers for the next generation of education.

Comp sci is more reliant on [[language]] skills than math/numeracy skills

Even more important than math and [[language]] skills __combined__ are the problem-solving and learning aptitude skills applicable to __all__ subjects [source](https://www.nature.com/articles/s41598-020-60661-8)

Engineering as fulcrum for other learning areas

**research shows that connections and skills in engineering perform better**

Storybooks integrate with ELA and social studies lessons

FAQs

Khan

Mission statement

Create the next generation of {{or: problem solvers|scientists|engineers|entrepreneurs}}

Prepare __all__ of your students for success, with the only integrated comp sci and engineering curriculum.

Bring a combined curriculum of comp sci and engineering to your classrooms - help your students build the skills, experience, and confidence to succeed across subjects.

Description

EiE is 

CTA

Core features

Unlock huge learning gains

Report

Report

How does it support your team?

Easy set up, dedicated support

In-person, customized training

Quote from superintendent

[Primer](https://www.withprimer.com/)

Learning without limits.

STEM education with superpowers

Your students are remarkable, but have been let down by

Stereotypes, misunderstanding, etc.

EiE has designed a curriculum that turns an education in comp sci and engineering into a bedrock of core critical thinking and problem solving skills for primary school students. So you can meet standards while creating standouts.

Meet standards while creating stand out students. 

Education that is

Integrated

Hands-on

Engineering as a hands-on application of math and science concepts

Comp sci as a foundation for critical thinking, problem solving, and a second [[language]].

Built to help you achieve NGSS standards

Whether your teachers have experience or not, EiE helps them become coaches in comp sci and engineering. So your school achieves NGSS standards, without overloading teachers.

Achieve NGSS standards, without overloading teachers.

Unique combinations of narrative and design challenges engage the whole child in a way that input/output curricula cannot.

Dragging and dropping code supports a superficial understanding, but only open-ended, experiential challenges teach the "__why__" and the "__how__" that foster critical thinking, problem solving skills, and a passion for STEM among all your students.

1+1 = 3 with Comp Sci and Engineering

Integrate Comp Sci and Engineering with the subjects you're already teaching. 

Connects directly with State Science Standards across the nation, as well as Common Core, and NGSS.

## **Story arc**

Hero messages

About students

Create a generation of curious, confident problem-solvers.

Your students deserve more than multiple choice. 

{{or: Mentor|encourage|empower}} the next {{or: Katherine Johnson|Radia Perlman}}

Create the next generation of problem solvers, big thinkers, and role [[model]]s.

Create the next generation of {{or: problem solvers|scientists|engineers|entrepreneurs|role [[model]]s|big thinkers}}

Encourage the engineers and computer scientists in your classroom.

Your students have unlimited potential. EiE helps you unleash it. 

Broad

Life is not multiple choice.

About the product

"It also creates the optimism that every problem can be solved, which is relevant to any subject area."

The only integrated Computer Science and Engineering program for grades 1-5 designed so to help you achieve NGSS and state standards. 

The nation's leading engineering curriculum for grades 1-5.

About the audience

Improve student STEM scores by having them {{or: solve an oil spill}}

EiE helps districts improve STEM performance for __all__ students, without overloading teachers. 

Bring a combined curriculum of comp sci and engineering to your classrooms - help your students build the skills, experience, and confidence to succeed across subjects.

Improve STEM performance for __all__ students, without overloading teachers.

Prepare __all__ of your students, teachers, and district for success in STEM. Meet NGSS and state science standards without overloading your teachers. 

Proof

Adopted nationwide, used by over 44,000 educators and millions of students

Meets state science standards, as well as Common Core and NGSS. 

Based on over 3,000 hours of development, field tested and teacher-approved 

^^EiE's integrated curriculum helps your students excel in STEM^^

Children who use EiE perform significantly better than others on questions about engineering, technology, and science.

Groups historically underrepresented in engineering show more interest, engagement, and performance after participating in EiE than those that did not.  

Students from groups historically underrepresented in engineering (women, racial and ethnic minorities, students with an IEP, students from low-income families, and English [[language]] learners) show enhanced interest, engagement, and performance after participating in EiE when compared to students participating in a science curriculum alone or in school in general.

[Award](https://eie.org/engineering-elementary/eie-award-winning-curriculum-project)-winning curricula and videos

McGraw Prize in Education, 2017 K-12 Category Winner 

IEEE 2015 Educational Activities Board (EAB) Pre-University Educator Award

AASL 2015 “Best Website for Teaching and Learning”

District Administrator Magazine 2014 “Readers’ Choice Top 100 Product”



[Testimonials](https://eie.org/overview/testimonials)

Former Director of the NSF: "The [EiE] curriculum [developed by the Museum of Science] is a great tool to involve children in science and engineering at their own level so that they are excited about and enjoy learning.”

Co-directors of STEM Education Center, University of Minnesota: “EiE curricula provide socially and culturally relevant contexts for students through their well-designed storybooks and their engaging engineering design challenges. Students who experience EiE lessons continue to talk about the characters from the storybooks and the design challenges for a long time after the conclusion of the lessons." 

Former CEO, DuPont: "[EiE] literally starts in first grade, and it’s the greatest little modules at the appropriate level for the grade level. That’s what’s needed. Because by the time a kid gets to eighth grade, it’s almost too late.”

"Engineering is Elementary** teaches students the thinking and reasoning skills they need to be successful learners and workers**. It also creates the optimism that every problem can be solved, which is relevant to any subject area. These skills and attitudes are important for **our kids’ future**."

About the product

EiE's integration with Comp Sci update the materials that make it the leading engineering curriculum for grades 1-5.

After thousands of hours of development and research, EiE has designed a curriculum that turns an education in comp sci and engineering into a bedrock of core critical thinking and problem solving skills for primary school students. So you can meet standards while creating tomorrows standout students.

Based on a unique Engineering Design Process that encourages students to develop critical thinking and problem solving skills - applicable to all subjects. [video](https://eie.org/overview/engineering-design-process)

Unique combinations of narrative and design challenges engage the whole child in a way that input/output curricula cannot.

Dragging and dropping code supports a superficial understanding, but only open-ended, experiential challenges teach the "__why__" and the "__how__" that foster critical thinking, problem solving skills, and a passion for STEM among all your students.

What's included

A thoughtfully designed Teacher Guide that turn your teachers into coaches, even if they have no engineering experience. 

detailed **lesson plans**

useful tips for **lesson prep** and materials management

**background content** (engineering, science, AND social studies)

**learning [[Goals]]**

unit specific **vocabulary list**

classroom-tested **duplication masters **AND** student **planning worksheets****

**data-collection worksheets** AND **reflection worksheets**

research-tested **assessment sheets** to evaluate student progress.

EiE storybooks that integrate ELA and social studies into your engineering and science lessons, while building personal connections. 

Your students will create connections with characters that are just like them, solving a real-world problem with engineering and computer science.

EiE materials kits

Because the projects are hands-on, you'll get unit-specific Materials Kits (or be able to build your own using the lists in included in your Teacher Guide).

[Video about materials](https://eie.org/eie-curriculum/eie-curriculum-components)

We've worked tirelessly to make EiE one of the most affordable curricula packages, with flexible purchasing options so that we can help as many students as possible. 

EiE works to improve STEM scores, even if your teachers are short on time.

EiE is easy to set up and comes with dedicated support.

The curriculum integrates directly with your existing science curriculum so you won't have to compromise. 

With Comp Sci and Engineering, 1+1=3

Additionally, a diverse set of teaching methods, like the Storybook, make built-in connections to Math, ELA, Art and other curricula. 

__Did you know?__ Computer Science is more reliant on [[language]] skills than math/numeracy skills. But even more than math or [[language]] skills combined, are the core problem-solving and learning aptitude skills that all subjects rely on [citation](https://www.nature.com/articles/s41598-020-60661-8)

With a vast library of free resources and professional development workshops EiE gives your teachers everything they need to become the heroes your students deserve. 

About EiE

EiE is using research-backed methods to help districts raise awareness, achievement, and access to STEM education for historically underrepresented groups. 

Our goal is to create a generation of problem solvers and engaged citizens by changing how students see themselves and others.

We were born out of one of the most beloved science and technology institutions in the nation, Boston's Museum of Science. 

FAQs? Resources?

{{{[[DONE]]}}}} Emails for [[Museum of Science]] #/

Subject lines

New or any

STEM success demands more than multiple choice.

Improve STEM performance for ALL your students. 

Proven to create standout STEM students 

This curriculum is proven to improve STEM scores.

Meet STEM standards while creating STEM standouts. 

What do {{or: teachers|principals|superintendents}} think about EiE? 

The secret to STEM excellence? Start early.

Put your students on the fast track to STEM success

Give your students a head start in STEM

The research-backed curriculum for STEM success

The STEM curriculum endorsed by the director of the NSF

An NGSS-approved curriculum for teaching STEM remote

The STEM curriculum used in 50 states, by 5 million+ students

Proven to improve STEM scores, without overloading teachers

How computer science + engineering = STEM success

Warm or upsell

With Comp Sci and Engineering, 1+1=3

Quick stats about EiE and Computer Science.

Look inside the new EiE Computer Science curriculum

Get all the facts about the EiE + Comp Sci curriculum

Explore the new Engineering + Comp Sci curriculum from EiE

How to increase engagement, performance, & interest in STEM

Meet NGSS standards, without overloading teachers.

Final roster

Meet STEM standards while creating STEM standouts. 

Proven to improve STEM scores, without overloading teachers

The secret to STEM excellence? Start early.

The research-backed curriculum for STEM success

The STEM curriculum endorsed by the director of the NSF

The STEM curriculum used in 50 states, by 5 million+ students

Look inside the new EiE Computer Science curriculum

How to increase engagement, performance, & interest in STEM

Emails

Dear {{first name}},

We know how hard it can be to balance the stress of budgets, teacher availability, and standards. 

That's why we created the "Engineering & Computer Science Essentials" integrated curriculum for {{role}} like you. It's based on the same formula of thousands of hours of research and testing that made other EiE curricula so effective at improving STEM scores, adopted by school districts in all 50 states, and endorsed by the direct of the NSF. 

This modern, integrated curriculum:

Is remote-friendly, with both online and hands-on challenges

Fits into existing Math, ELA, Science, and Art curricula for teachers on tight schedules

Provides everything you need to meet NGSS standards

Uses the most cost-effective material kits available

With early exposure to engineering and computer science, you can change the trajectories of your students and build the next generation of problem solvers - especially among historically under represented groups.

To get a free guided tour of the new curriculum, or explore on your own, click below. 

 

[[Drawbridge]] background (formerly Tagzo)

Former product

a personalized advertising marketplace

Users curate tags about their interests

Then advertisers send messages and promotions based on the tags, without seeing personal information

Sounds vaguely like Jebbit, Sparktoro, pixel sharing

Set up your own advertising channel based on your interests

Tagzo is just facebook without the social network...?

Impulse app

Goal: take IP and reinvent their product

Get at the root of the patent and concept

Transform for current digital ecosystem

[[Meetings]]: about [[Drawbridge]]

Attendees:: [[Dan Tatar]], [[jayne hetherington]], [[alex fedorov]], [[mike ohara]], [[quinn]]

Time::

Notes::

Branding by [[Grist]] formerly [[Breakaway]]

How it used to work

Jayne signs up 

Goes into vault

Vault asks for an email address (to authenticate)

Jayne is invited to give other demographics

Jayne could opt-in to share information

Patent issued in 2014, until 2032

Patent is very broad

Content could be anything (text, video, etc.)

Includes:

The user needs to identify his/her interest

User identity is anonymous, unless the user decides otherwise

Anonymous to the promoter

Overarching element: this is a software system in which individuals pull ideas to them without giving up their identity

Social network

ecomm

**Discovery based on declared interests**

Ad efficiency, organization, identity protection

discovery process

Find new products + get exclusive deals

Audience

emerging consumer brands

DTC

Thinking about monetizing data

Two-sided marketplace: 

Promoters

Offers a promotion to the user

Users

Your guide to the new agency landscape [[Inspiration for ADK]]

Why this article

What they are

Design agencies

Digital agencies

How to pick

Quiz - what type of agency do you need?

Find the right type of agency for your challenge

Custom technology as a competitive advantage [[Inspiration for ADK]]

[[Meetings]]: [[Meetings with [[chris baker]]]]

Attendees:: [[chris baker]]

Time::

Notes::

ADK

Copywriter search

Content

Ads

[[refine labs]] is being kicked off

ADK is

version 1 product audience

often in a startup, clinician, enterprise founder

Be more proactive with [[darci nevitt]] and think about [[task relevant maturity]] (this was in regard to breakdown on [[Museum of Science]])

[[Personal Task Management]]

{{[[DONE]]}} [Nat Eliasons new effortless output for Roam course](https://learn.fortelabs.co/courses/enrolled/1097377) #// Completed at 09:59 [[November 26th, 2022]]

Capstone = [[personal [[brand]]]] = digital health marketing

[thread by @george__mack](https://twitter.com/@george__mack/status/1295079345732673540) ⬇︎ #twitter #[[twitter thread]]

"How to Operate" is one of my favorite lectures

[[Keith Rabois]] ([@rabois](https://twitter.com/rabois)) breaks down OPERATIONAL EXCELLENCE

The principles are taken from the experience helping build Square, LinkedIn and [[paypal]]

They are timeless

Here are 6 [[mental [[model]]]]s from the talk

THREAD...

RABOIS [[model]] 1 - BUILD A HIGH-PERFORMANCE MACHINE

"We used to joke that if Martians took over eBay, it would take 6 months for the world to notice." - Rabois

"Build a company that idiots could run - because eventually, they will." - Buffett

Rabois states that building a high functioning team or company is like building an engine.

It has 3 steps:

Step 1 - Build a beautiful conceptual whiteboard drawing of your engine at peak performance.

👆

This looks like the Ferrari engineering team making a systems diagram [pic.twitter.com/LQwvY8IgHP](https://twitter.com/george__mack/status/1295079348374994944/photo/1)

Step 2 - Take that theory into the real world to build the engine.

👆

This looks like an engineer's worst nightmare.

It takes heroic effort, duck tape and thinking on your feet to keep it together.

"In theory, theory and practice are the same. In practice, they are not." [pic.twitter.com/LuFzcYQeec](https://twitter.com/george__mack/status/1295079350270857216/photo/1)

Step 3 - Accelerate your idiot-proof high-performance machine

You have created systems and reduced all friction.

👆

This looks like a Ferrari on the left-hand lane of Germany's  Autobahn.

You have no speed limit. [pic.twitter.com/m2NTT3E4H4](https://twitter.com/george__mack/status/1295079352351240193/photo/1)

RABOIS [[model]] 2 - CLARIFY, SIMPLIFY &amp; ELIMINATE

"The more you simplify, the better people will perform." - Rabois

People cannot keep track of a complex set of initiatives.

Rabois says you need to distill it down to 2-3 things that they can repeat to themselves and friends.

Refuse to accept complexity.

People will argue that they or their company are different and are more complex than others.

Refuse this.

You can change the world, build the most important companies, and market great products in 30-140 characters. [pic.twitter.com/BhCwTNjrco](https://twitter.com/george__mack/status/1295079356562395136/photo/1)

"Force yourself to simplify every initiative, every product, every marketing - everything you do." - Rabois

He argues that you should see yourself as an EDITOR with a red pen:

1/ Cross out everything that is unnecessary

2/ Ask for clarification on anything unexplained

RABOIS [[model]] 3 - A+ PROBLEMS

"You need to spend a lot of time focusing people" - Rabois

He tells the story of how Peter Thiel "insisted at [[paypal]] that every single person did exactly ONE THING."

Thiel refused to talk to staff about anything other than that ONE THING.

"The [[insight]] behind this is that most people will solve problems they know how to solve." - Rabois

If given the option, people will solve B+ problems rather than A+ problems.

B+ problems are problems that we know how to solve and are in our comfort zone.

A+ problems are high impact problems

We don't wake up in the morning with a solution to A+ problems so we procrastinate with B+ problems

If you have an entire company focusing on B+ problems, this cascades and prevents growth

Thiel insisted on focusing on ONE A+ problem each

RABOIS [[model]] 4 - METRICS FOR SUCCESS

"You need to simplify the company's success metrics... and create something that is very intuitive for everyone to use" - Rabois

Rabois has 3 core principles for a dashboard:

1/ Output &gt; Inputs - Revenue is more important than time spent.

2/ Meta metric - The metric of success for your dashboard's metrics is what % of people check the dashboard per day.

If the dashboard doesn't get checked by the majority of the company, it's a failure.

3/ Have pairing indicators - Make sure you measure the effect &amp; counter effect.

If you give your risk team the metric of reducing the fraud rate.

Then your risk team starts treating EVERY user like a potential fraud.

You now have the worst customer satisfaction score.

You need pairing metrics to prevent this from happening:

Reduce fraud AND customer satisfaction

OR

Number of hires AND quality of hires

"You always want to create the opposite (metric)... and the people responsible need to be measured on both." - Rabois

RABOIS [[model]] 5 - LOOK FOR ANOMALIES IN YOUR DATA

"One [[insight]] I've had over my [[career]] is that you kinda wanna look for the anomalies. You don't want to look for the expected behavior" - Rabois

At LinkedIn, Keith was stunned by a stat that made absolutely no sense...

"25-30% of all clicks from the homepage was people going to their own profile"

👆

This made no sense in LinkedIn's UI at the time.

You had to go to an obscure part of your settings to find your own profile.

Keith couldn't wrap his head around what was going on.

After weeks and a meeting with Max Levchin he finally figured it out:

It was VANITY.

People were looking at themselves in the mirror.

"This really clarified what users of the product really wanted. And we wouldn't have found it without looking for anomalous data" - Rabois

RABOIS [[model]] 6 - CALENDAR-PRIORITY ALIGNMENT

When Keith meets with a new CEO that is struggling he asks 2 questions:

1/ "What are your priorities?" - He gets them to write this down

2/ "Can you show me your calendar?" - He contrasts the above priorities with their calendar

Often CEO's will tell him:

"My biggest priority is recruiting"

But when he looks at their calendar - the largest chunk of time is going to something that isn't recruiting

👆 This is falsification at it's finest

Reminds me of Munger on Mozart being miserable his whole life - because he overspent his income

"If Mozart can't get by with this kind of asinine conduct, I don't think you should try."

If elite CEO's fail the calendar-priority alignment test, I'm 99% sure we are (I am)

The talk is about building billion-dollar startups... but some of the principles are universal:

1/ Make systems idiot-proof

2/ Clarify, simplify and eliminate

3/ Focus on A+ problems

4/ Clear dashboard for KPI's

5/ Look for anomalies

6/ Calendar-priority audit

I highly recommend checking out the full talk by Keith Rabois

It has less than 130,000 views - it is criminally underrated

[Lecture 14 - How to Operate (Keith Rabois)](https://www.youtube.com/watch?v=6fQHLK1aIBs)

[thread by @GoodMarketingHQ](https://twitter.com/@GoodMarketingHQ/status/1293909400751505409) ⬇︎ #twitter #[[twitter thread]]

Conversational copy is writing how you talk.

No sales megaphone. No business speak.

But that's easier said than done. So I've put together my guide.

THREAD...

1/ Don't write AT the reader

Involve the reader in your copy [pic.twitter.com/Cv3RWvkgXZ](https://twitter.com/GoodMarketingHQ/status/1293909402412441608/photo/1)

2/ Use your customers' words

It's the easiest way to get the tone right [pic.twitter.com/p5WfJ3zVbv](https://twitter.com/GoodMarketingHQ/status/1293909404744482819/photo/1)

3/ Load up on personal pronouns

People pay attention when you talk directly to them [pic.twitter.com/7B85Jo1Lbf](https://twitter.com/GoodMarketingHQ/status/1293909406988419074/photo/1)

4/ Don't worry about grammar

If you break the rules you’ll sound human [pic.twitter.com/x7F2LswyFk](https://twitter.com/GoodMarketingHQ/status/1293909409735663620/photo/1)

5/ Start sentences with conjunctions

It flows better [pic.twitter.com/eNQHYoLUYO](https://twitter.com/GoodMarketingHQ/status/1293909411711221761/photo/1)

6/ Don't persuade

Let the reader be persuaded [pic.twitter.com/Fs9UTDRksb](https://twitter.com/GoodMarketingHQ/status/1293909413552508930/photo/1)

7/ Use contractions

Only academics say “you are”

h/t [@wordmancopy](https://twitter.com/wordmancopy) [pic.twitter.com/IhFBq1Siae](https://twitter.com/GoodMarketingHQ/status/1293909415561555969/photo/1)

8/ Don't imitate

“You're alive in inverse proportion to the density of cliches in your writing” — Nassim Taleb [pic.twitter.com/JcaEDxeW0e](https://twitter.com/GoodMarketingHQ/status/1293909417700651011/photo/1)

9/ Ditch the thesaurus

You're not impressing anyone [pic.twitter.com/SBFwa1KKIg](https://twitter.com/GoodMarketingHQ/status/1293909419604889601/photo/1)

10/ Empathise

Customers want to feel heard [pic.twitter.com/FY3XkM5lqW](https://twitter.com/GoodMarketingHQ/status/1293909421676834816/photo/1)

11/ Respect the competition

It reflects self-confidence [pic.twitter.com/yd4i11Wmmb](https://twitter.com/GoodMarketingHQ/status/1293909424545738757/photo/1)

12/ Don’t try too hard

Customers see through fake shit [pic.twitter.com/q2mCA8hTpp](https://twitter.com/GoodMarketingHQ/status/1293909426479312898/photo/1)

13/ Tell stories

They’re more memorable than facts and figures [pic.twitter.com/EIUHInWcIn](https://twitter.com/GoodMarketingHQ/status/1293909430539493376/photo/1)

14/ Read it aloud at the kitchen table

If your partner cringes, re-write it [pic.twitter.com/6qqEBIKR7O](https://twitter.com/GoodMarketingHQ/status/1293909432749834243/photo/1)

Anyhow, that's all I got!

Big credit to Dave Harland ([@wordmancopy](https://twitter.com/wordmancopy)). Took lots of inspiration from him.

[How to write conversational copy](https://marketingexamples.com/copywriting/conversational)

Not gonna lie, this took a while. Please do share it round.

I also write a new case study (like this one) in my weekly newsletter. Short, sweet and practical!

Over and out — Harry

[Join 27k marketers getting one practical case study each week](https://marketingexamples.com/subscribe)

