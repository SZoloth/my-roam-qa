Author:: [[George Mack]]

URL:: https://twitter.com/george__mack/status/1068238562443841538

Recommended By::

Tags:: #Articles #Inbox #Readwise #[[[[High Agency]][[*]]]]

# Notes

"When you’re told that something is impossible, is that the end of the conversation, or does that start a second dialogue in your mind, how to get around whoever it is that’s just told you that you can’t do something?" 

High Agency is a sense that the story given to you by other people about what you can/cannot do is just that - a story.  And that you have control over the story. 

Low agency person accepts the story that is given to them. They never question it. They are passive. They outsource all of their decision making to other people. 

"If you were stuck in a third world prison and had to call one person to try and bust you out of there - who would you call?" 

Everything around you that you call life was made up by people that were no smarter than you and you can change it, you can influence it, you can build your own things that other people can use. 

"How can you achieve your 10 year goal in 6 months?" 

@naval & @robinhanson call this "**Orthaganol Thinking**" You ask questions that look to give you a completely different angle to frame the problem through. You are thinking sideways, and you can see ridiculous ideas that the crowd missed. 

