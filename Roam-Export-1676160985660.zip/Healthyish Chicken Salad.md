Tags:: #Recipes #salad

Ingredients::

2 skinless, boneless [[chicken]] breasts (1–1½ lb. total)

3 Tbsp. kosher [[salt]], plus more

3 [[scallions]], thinly sliced on a deep diagonal

3 Persian [[cucumbers]]

½ cup toasted [[sesame seeds]], divided

2 Tbsp. fresh [[lime]] juice

2 Tbsp. [[tahini]]

1 Tbsp. [[soy sauce]]

1 tsp. [[honey]]

¼ tsp. crushed [[red pepper flakes]]

¼ head of romaine or green or red leaf [[lettuce]] or 1 head of Little Gem lettuce

Big handful of [[cilantro]] leaves with tender stems

½ [[lime]] (for serving)

Tools::

Source::  https://www.bonappetit.com/recipe/healthyish-chicken-salad

:hiccup [:hr]

Bring chicken, 3 Tbsp. kosher salt, and 5 cups water to a bare simmer in a medium pot over medium heat (chicken should be submerged). Be patient—this will take a little while. Once liquid begins to simmer, reduce heat to low and cook (water should not be simmering at all now) until juices run clear when thickest part of chicken is pierced, **8–10 minutes**. Transfer chicken to a medium bowl; discard poaching liquid. Let chicken cool slightly, then shred meat into big pieces; set aside.

Meanwhile, place scallions in a small bowl and pour in very cold water to cover;** let soak 10 minutes**. Drain scallions in a mesh sieve or colander, then rinse under cold running water, swishing vigorously to encourage them to curl up and to rinse off any scallion slime (ew). Shake off as much water as possible and place in a large bowl; set aside.

Working one at a time, slice cucumbers in half crosswise, then slice each piece in half lengthwise. Place quarters cut side down and slice in half lengthwise again to create 8 pieces total per cucumber. Add to bowl with reserved chicken.

Set 1 Tbsp. sesame seeds aside in a small bowl for serving. Crush remaining sesame seeds in a mortar and pestle until some of the seeds have turned to powder, but with plenty of whole seeds left. (Alternatively, if you’d rather spare yourself the elbow grease, pulse seeds a few times in a food processor or spice mill, then transfer to a medium bowl before proceeding). Add lime juice, tahini, soy sauce, honey, and red pepper flakes and mash to create a paste. Add ¼ cup water and whisk to combine (if you don’t have a small enough whisk, work in with the pestle). Taste and season with salt.

Add lettuce and cilantro to bowl with reserved scallions. Pour half of dressing over greens and toss to coat. Arrange on a platter. Pour remaining dressing over chicken and cucumbers, toss to coat, and arrange over greens. Top salad with reserved 1 Tbsp. sesame seeds and squeeze juice from lime half over.

