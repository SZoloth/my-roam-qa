[[ADK Drupal Campaigns]]

[[ADK Drupal Retargeting]]

Messaging

General

Focusing on the opportunity Drupal affords when paired with a sophisticated dev shop

Where

Google

Facebook/IG

Offer

Free consultation

Free audit offer

Do people interact with this?

Do we need to reposition this? Is "we'll look at your code" too invasive?

Submit website, email, and name and we'll get back to you

We give you a "report"

UX audit

Next steps

What can we do in terms of an audit or report? 

Can we create a template?

Talk to aaron about audit deliverable

Leads

Process

Comes into HubSpot as unqualifed

Apollo or whatever qualifies and scores

Daily stand

