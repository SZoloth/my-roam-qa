{{[[DONE]]}} We also need [[darci nevitt]] on [[Wasabi]] and [[Museum of Science]] #[[🏔ADK [[Task Management]]]] #/

[[Meetings]]: [[Meetings with [[chris baker]]]] for [[[[adk]] sales]] and marketing alignment

Attendees:: [[chris baker]]

Time:: 09:51

Notes::

{{[[DONE]]}}  Pump up marketing achievements in deck #[[🏔ADK [[Task Management]]]] #/

Understand and hear sales needs + pain points

What are they planning on focusing on?

Sales + marketing need to decide what initiatives to focus on

Tone of the meeting:

Q1 sales + marketing focus discussion

Based on prior conversations before your arrival, our marketing team has been focused on doubling down on digital health

looks like mHealth and digital health

But as we go into Q1 we need to know who our focus accounts are

Are there any specifics beyond "i need leads"? What would you be asking an agency?

{{[[DONE]]}} Case study requests from [[Dan Tatar]] #[[🏔ADK [[Task Management]]]] #/ #Delegated[[nick watkins]]

Remove

Globe

Unreal Candy

CAPA

Responsive website redesign "SMH"

Sleeping Dog

Reorder & Rename

Beefier first:

Firefly

**Transforming the patient experience with Firefly Health**

Creating a leading telemedicine startup with visionary MDs.

Span Tech 2

**Engineering better conveyor belts through software**

Optimizing manufacturing operations alongside SpanTech.

RecoupERAS

**Enhancing patient recovery after surgery with BWH**

Administering the ERAS protocol through a smartphone app.

HNRG

**Automating John Hancock's land leasing process**

Making leasing faster and more profitable with ecommerce.

Beyond Insurance

**Achieving an insurance entrepreneur's bold vision**

Going from big ideas to big results with Beyond Insurance.

Prostate Cancer Mobile App

**Studying lifestyle impacts on cancer therapy [[outcome]]s**

Clinical trial app with BWH and Prostate Cancer Foundation.

Cambridge Savings Bank

**Making banking more accessible and more human**

Enhancing website accessibility and performance for CSB.

Trade Hounds

**Creating the leading social network for the trades**

Partnering with Trade Hounds to scale their app and company.

Healthcare Video Analysis Smartphone App

SIKA

**Enabling a B2B leader to thrive in consumer retail**

Increasing big box sales of SIKA Corp’s superior products.

Smartphone App for Alzheimer's

**Assessing Alzheimer's risk via smartphone tests**

From proof of concept app to NIH-funded commercialization.

ALKU (__this also needs to be re-posted with Vic's work__)

**Driving culture and empowering remote work**

Increasing ALKU’s company value and performance with tech.

Digital Archiving Web Application

**Enabling multimedia research on disasters with Harvard**

Designing, building, & growing the Japan Disasters Archive.

TMHU

**Optimizing eCommerce for Toyota Industrial Equipment**

Developing an award-winning ecommerce experience.

Mercer

**Driving revenue through digital strategies with Mercer**

Using smart content and digital marketing to drive conversion.

MCOP

**Growing a specialty clinic into an international leader**

Building MCOP into a prosthetics leader with technology.

Wasabi

**Growing a website from day 1 to unicorn scale**

Disrupting cloud storage with the founding team at Wasabi.

Woodford Reserve

**Crafting a premium website for Woodford Reserve**

Shaking up the global digital presence for an American icon.

Sonoma

**Delivering an award-winning experience for Sonoma-Cutrer**

Creating a digital brand experience that drives revenue.

^^Titleist^^

**Driving Titleist’s global digital brand forward  **

Designing a universal digital design system primed for growth.

^^Broadridge^^

**Envisioning the future of finance with Broadridge**

Prototyping product experiences with a worldwide financial leader.

^^Cimpress^^

**Increasing design services revenue for Cimpress**

Rethinking how Vistaprint sells design to millions of customers.

^^Cengage^^

**Composing the future of the college textbook**

A new read on interactive content for Cengage Learning.

^^eClinical Works ^^

**Unifying operations for a leading cloud EHR software**

Designing a better data review process for eClinicalWorks.

^^JSTOR^^

**Modernizing the global scholastic library with JSTOR**

Building an intuitive educational content experience.

^^Wordstream^^

**Retaining more customers for WordStream through design**

Mapping a retention-focused onboarding for WordStream.

Integration Driven Drupal 8 Website

{{[[DONE]]}} Review [[[[Sleeping Dog Properties]] blog]] from [[nick watkins]] #[[🏔ADK [[Task Management]]]] #/

{{[[DONE]]}} Hours #[[🏔ADK [[Task Management]]]] #/

{{[[DONE]]}} Review [[[[ADK]] case studies]] from [[victor brown]] for [[span tech]] #/

{{[[DONE]]}} [[December 1st, 2020]] Follow up on [[Glenmede]] analytics #[[🏔ADK [[Task Management]]]]

Event map update

Content groups, custom dimensions, custom metrics

{{[[DONE]]}} Follow up with content plan for [[victor brown]] #[[🏔ADK [[Task Management]]]] [[December 1st, 2020]]

