[[gifts]] ideas:

{{[[DONE]]}} [offhours homecoat](https://offhours.co/)

Sephora

[Birite](https://biritestudio.com/collections/new)

[Wallpaper](https://store.wallpaper.com/en/sale/decorative-objects/?=) store

[Rhythm coffee set](https://store.wallpaper.com/en/tabletop/tea-and-coffee/rhythm-milk-jug-white-ROSE19LAT741WHI.html?cgid=tabletop-teaandcoffee#page=2&start=73)

[sugar bowl](https://store.wallpaper.com/en/tabletop/tea-and-coffee/rhythm-sugar-bowl-white-ROSE19ZUC789WHI.html?cgid=tabletop-teaandcoffee#page=2&start=74)

[mug](https://store.wallpaper.com/en/tabletop/tea-and-coffee/artmug-piet-multiple-SERA16ART180MUL.html?cgid=tabletop-teaandcoffee#page=3&start=163)

[candle holder](https://store.wallpaper.com/en/living/candlelight-and-scents/the-light-and-yellow-yellow-PAOC19THE990YEL.html)

just check instagram...

dusen dusen

snowe

[older brother](https://olderbrother.us/)

https://www.aarke-usa.com/

aurate jewelry

{{[[DONE]]}} gold necklace

Birthday:: 12/19/1996

