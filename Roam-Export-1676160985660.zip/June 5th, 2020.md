[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} #[[Sleeping Dog Properties]] plan #[[[[Sleeping Dog Properties]] Marketing Strategy]]

{{[[DONE]]}} #[[form health]] #facebook #ads

{{[[DONE]]}} [[Monday Marketing Memo]]

{{[[DONE]]}} [[National Speed]] meeting #Meetings

{{[[DONE]]}} [[ADK Marketing Project Management]]

{{[[DONE]]}} processes

{{[[DONE]]}} adk - content review

[[Topics to help white friends]] #[[charlie madden]]

https://youtu.be/fVa-HAsB-xQ #whiteprivilege

https://www.benjerry.com/about-us/media-center/dismantle-white-supremacy

For #weekend of [[June 6th, 2020]]

[[charlie madden]]

[[Adin Zussman]]

[[drew andre]]

[[Alex Seibel]]

Review [[June 5th, 2020]] on [[June 8th, 2020]]

