Tags: #positioning

General process from #Hubspot [resource](https://blog.hubspot.com/sales/gtm-strategy) largely for #B2B

Personas - who are you targeting?

For go to market, usually your __most hungry__ customers

For each persona, map

Pain points -> Product value/solution -> Message

Launch test ??

Channels

Audiences

Messages

Map content to buyer journey

[Go To Market from Lenny](((XDVFHBumr)))

What are the key elements you think a GTM plan must include?

What market?

What segment of the market? Why?

What audience are you selling to? Why?

Which demand generation channels (paid/earned/owned/influencer/etc.) and why?

Who are the most important competitors and why?

If the (1) key-value props and (2) reasons to believe are part of the product positioning doc then that has already been covered

#positioning, and consequently messaging ('narrative') are also very much part of the GTM plan, and constantly evolving.

Biz [[model]] and core value (not to be confused with positioning which is an output)

Summary:

Prior to developing any sort of marketing plan, and hiring of a Marketing / Growth leader, the company has identified:

Core value and Biz [[model]]

Magic (product/brand experience)

The Market (who the product is for)

Acquisition (how they acquire customers)

Upon having these agreed to (and ideally documented) by the founding team and investors, the company can develop;

Positioning

Messaging documentation

GTM plan (current thread, built upon positioning and messaging documentation)

Work plan (spreadsheet/work to be done/task management/etc. based upon GTM plan)

From [[caroline clark]]: [deck](https://docs.google.com/presentation/d/1-QAqhTzJYN2keOwhGtsEnHD2RGzCKuxE_65qPnBsAE0/edit#slide=id.ga6fcfd8bcf_2_26) and [blog](https://www.carolineclark.io/gtm-nirvana)

This is for B2B, likely SaaS

GTM answers

Who is the ideal customer? with [[buyer [[persona]]]]s

How are you going to reach them? with [[[[acquisition]] [[channel]]]]

How are you going to scale? with pricing, payment [[model]]s, LTV,CAC, and market size #monetization

Price is a bunch of work

Bottoms up market size = price per year * total target companies

[[buyer [[persona]]]]s

Helpful to figure out who matters

Should include

Job title

Stage of company

Daily activities

Pain points

Willingness to pay

Things to watch out for (how influential is this role)

example

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FRArz2gdduT.png?alt=media&token=d95b3157-2113-46d0-9013-a5781d0d1ee9)

How do you determine your [[buyer [[persona]]]]s?

Primary research

[[qualitative]]

**Customer interviews** to find patterns in roles and responsibilities

Panels/dinners - gather customers in a group and get them to talk about their jobs

Quantitative

Survey to user base

Survey to market

Secondary research

[[qualitative]]

Competitive analysis - what use cases and teams are competitors targeting on their websites?

Quantitative

Segment your lead data by attributes

[[[[acquisition]] [[channel]]]]

Example

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FpeD7u_c9Kf.png?alt=media&token=9eb8e350-8283-42fb-913a-4b6e4c12dc1f)

