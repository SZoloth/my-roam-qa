Author:: [[open.nytimes.com]]

URL:: https://open.nytimes.com/introducing-react-tracking-declarative-tracking-for-react-apps-2c76706bb79a

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

That is, we’d often use the DOM as the source of truth for the existence and interaction of various elements on the page. This was not only brittle, but it was very difficult to do without exposing non-semantic data necessary for the analytic modules to see and attach. In some cases, it was impossible and we had to put analytic-specific code at seemingly random places within our app. 

**Note**: This is exactly what we've been doing / moving towards!

We wanted to move away from the DOM as the source of truth and instead use the components themselves to signal interactions of interest. 

You decorate various components (pages, forms, buttons, links, etc) and any handlers or lifecycle methods within those components (onClick, componentDidMount, etc) with just the data that you have, when you have it. 

