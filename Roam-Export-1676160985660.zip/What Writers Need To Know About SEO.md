**Metadata**

**Tags:** #organic, #[[Growth marketing[[*]]]], #[[✍️ blog-post]], #[[✍️ blog-post]], [[Marketing ]], #SEO

**Status:** #published, [[to update]]

[CAPA Presentation](https://docs.google.com/presentation/d/1IKbSS9y2rlssbWaGrMZ548EbaoGFkaUKLuJGJ0jnRFw/edit?usp=sharing)

If you're a writer, you want to make sure the #content you're creating gets found. In this post, you'll learn how you can best contribute to the #organic #[[Growth marketing[[*]]]] of your company.

This post is adapted from part of a #presentation I give to our agency partners and clients to help copywriters crystallize the concept and value of SEO and learn how to write for SEO effectively. This part is general advice, what isn't shared here specific recommendations and technical guides better suited for developers.

# First: What SEO is Not

SEO, or search engine optimization, used to be defined by brute force tactics[1]:

Make your target #keyword the same color as the background

Toss that sucker in the footer of your website about 100 times

Watch your rank skyrocket

Because of the early limited technology that resulted in shady tactics, many writers still look at SEO with suspicion. Now, most people know that doing this is akin to SEO suicide. But you can still see shades of it in the way SEO is misunderstood.

The most common misconception is that SEO now works by:

Find a keyword you want

Toss that sucker in your meta data (page title, meta description, H1)

Rank

While this is a (simplified) tactic that __helps__ with SEO, it does not capture what SEO is and how closely it is intertwined with #content strategy.

## What SEO is

Many definitions look at SEO through the lens of the __purpose__: increasing the quality and quantity of traffic coming to your website from search engines.

However, it can be more helpful to approach SEO from the __process__: aligning the content on your website with what is useful to your intended audience.

Nailing that is key. If you can conceptualize what your audience is looking for and then provide that, you're in good shape.[2]

At this point in the presentation, I can tell the writers are relieved. They're understanding that SEO is less about awkwardly forcing keywords into their writing and more about crafting engaging content.

## Technical SEO

The best writing in the world won't get found by Google if the website it's on is not optimized. This is why technical performance plays such a big role in SEO; to be truly competitive good writing must be complemented with good design and development. Make sure the developers on your team are comfortable with the ins and outs of website optimization.

# SEO for Writers

SEO can be broken down into three phases: Researching, Activating, and Measuring that act as a content-generation loop.

## Research: How to Target Keywords

Find the keywords and themes that are most engaging, popular, relevant, and attainable. This process is a data-driven form of brainstorming topics for your articles. For generating keyword ideas, there a few methods that I have had success with:

**Who-What-Where-When-How** Method of [[keyword research]]

This method comes from [[Casey Winters]][(Link)](https://caseyaccidental.com/a-primer-on-startup-seo/), who has led growth at Apartments.com, Pinterest, and GrubHub. Answer these questions for your business and combine them to come up with relevant keyword combinations. Here's his example for GrubHub:

**Who:** GrubHub, restaurant names we represent

**What:** food, delivery, menus, pizza, thai, indian, chinese

**When:** breakfast, lunch, dinner, late night

**Where:** every city, neighborhood, zip code, college covered

**How:** online ordering, mobile app, iphone app, android app

Combining these in excel will result in terms like "thai delivery near Boston College," or "Felipes online ordering."

**AnswerThePublic** method of [[keyword research]]

A quicker (and easier) method is to enter a topic into [AnswerThePublic.com](https://answerthepublic.com/), which scrapes Google for all the related things people search for. You can then simply export this as a .csv.

Now that you have huge lists of keywords how do you know if it's worth targeting? A keyword is worth targeting if you answer "yes" to these questions:

Will owning this keyword drive traffic?

Is this traffic valuable?

Can we rank for this?

**Will owning this #keyword drive traffic?**

This is a simple process and there are many paid and free tools that can you help you do this. I use a business plan at [Moz](https://moz.com/) for ADK Group clients, but the free version should do fine in most cases. Other options are: [Google Ads Keyword Planner](https://adwords.google.com/KeywordPlanner) and [SEMRush](https://www.semrush.com/). The lower the monthly search traffic, the more valuable that traffic must be for your business.

Update with keyword research method from [[ahrefs]]

**Is this traffic valuable?**

Assessing whether or not traffic is valuable is more of a soft-science. You have to decide if the types of people who search for and click on results on your target topic will be interested in your product or service. Assuming the keyword is not wildly off-brand or off-topic, how do you assess searcher interest with relative confidence?

Take a quick look at the search engine's results page (SERP). Do the top results come from competitors? That's a good sign that this is a good keyword for your business to own. If none of the results are related to your business, move on. You may think this keyword is relevant to your company — and it may be — __but you are unlikely to convince Google of that__.

**Can we rank for this?**

Your ability to rank for this depends on that quality of your content, the health of your website and the competition for the keywords. I trust that, as a writer, you have a good idea of what makes content high-quality. I also hope that you can trust your developers and/or a SEO expert to ensure the health and performance of your website.

With those taken care of, what you need to know is how competitive a keyword is. Many services I listed above give you a ranking of competitiveness ranking for each keyword. Generally, low volume keywords will also have low competition while high volume keywords will be very competitive.

You should have a balance of both competitive and non-competitive keywords in your portfolio of targets.

Keyword competition is defined by 2 factors: how much domain authority[3] the ranking websites have, and what is on the SERP.

Competitive SERPs have a high number of enhanced results on them. These include results with images and special designs that call more attention to them and result in a higher share of clicks for that result.

If you want to see a competitive SERP on mobile, search for "[Avengers](https://www.google.com/search?q=avengers&rlz=1CDGOYI_enUS756US756&oq=avengers&aqs=chrome..69i57j0l3.1757j0j9&hl=en-US&sourceid=chrome-mobile&ie=UTF-8)" and see if there is anything __not__ answered directly on the results page.

# Activating

I spend the least amount of time here when presenting SEO to writers. Why? Because this is their job! Activating is primarily about the writing high-quality content, which I'm sure you're well practiced in.

Some rules of thumbs are below (make sure you don't skip competitive research!):

Your content must accomplish the same thing that whatever ranks first for the keyword does, only better. This may mean adding more detail and creating a longer piece. It may mean writing multiple pieces on a topic or presenting it in a different format (video, podcast, etc.)

The more volume & competition a keyword has, the higher quality the content has to be.

You need to have a similar or better [[domain authority]] ranking as the top-ranking websites.

Once you've nailed a truly engaging and unique blog post, it's time to promote it. The goal of promotion is two-fold: increase engagement & increase backlinks. If you are writer-cum-marketer, here are two quick and dirty ways to do this for yourself.

**Share on all your [[social media]] accounts using a tool like [HootSuite](https://hootsuite.com/).** Get an edge by re-posting this multiple times across a month with different images and titles, and at different times. This ensures you reach different segments of your audience.

**Collaborate with others.** Work with established experts in the topic areas to get their opinions or quotations for the pieces. After they're involved, they're more likely to share the finished result with their own audience.

Ultimately, if you're writing kick-ass content and doing at least some promotional work you're likely to see __some__ traction.

# Measuring

How do you know if your content is working? What KPIs should you track and how do you avoid vanity metrics? All you need from your posts are high engagement and strong organic growth, which are measured with the following metrics.

**Engagement**

Average time spent on page site

Repeat visit to unique visit ratio

A low number of unsubscribes if you're promoting via a newsletter

**Organic growth & #virality**

Shares

Net Promoter Score (#NPS)

Quality / quantity of links to the post

High #CTR, ranking, and traffic are all results of the above—not causes—and are what I would call vanity metrics. Keep an eye on these, but not at the expense of the above.

**A note about [[Domain Authority]] (DA)**

**Why it’s important:** It’s one of the best measurements of your potential ability to rank for keywords. The higher your DA, the higher likelihood there is that you will be able to rank for increasingly competitive keywords.

**How it’s calculated:** Known contributing factors include number of linking websites, number of total links, quality of both of those sources of links, technical health, and engagement metrics.

**How writers can increase:** Create as much unique, engaging, and share-able content as possible, include links to high DA websites, and work with your marketing team to promote your content.

**Example of a high authority website:** The New York Times (DA: 95 / 100)

Why specifically the NYT has a high domain authority: Effective internal linking structure, high number of links to the website from external sources, technical optimizations, a short linking distance between other trusted websites, high domain age, strong engagement metrics, and a wide diversity of links.

So — if you want to increase the value of your writing for your business, you can either opt to write for the New York Times or follow this guideline:

**Target valuable keywords**: These are words that are high traffic, low competition, and very relevant to the problem your service or product solves.

**Write high quality content:** Present a new idea, or an existing idea in a new way. Map the content that you write to the perceived intent of the search based on the results.

**Promote your content**: Get influencers to share it by incorporating them in the creation process. Share and re-share it on your [[social media]] channels.

**Track the right metrics:** Look at engagement and organic growth rather than vanity metrics.

[1] In a class at Stanford, Facebook's VP of growth admitted to using this tactic to dominate organic searches for paper airplanes.

[2] As part of my interview for ADK Group, I was asked to provide a definition of SEO in 3 sentences or less. Happily, I was able to dig that up and find that my definition still holds true: "__SEO is the process of ensuring that your website and content are as easy to find by crawlers and people as possible. Ultimately, it involves taking advantage of the way that search engines index and rank pages to increase your ranking on SERPS for specific keywords. Factors that affect SEO are both on page (including content, architecture, and HTML) and off page (how many reputable links are sending people to your content, your impact on [[social media]], etc.).__"

[3] For all intents and purposes, "domain authority" is a measure of the quality and quantity of other websites linking to your website.

