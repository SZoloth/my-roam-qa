Create [[playbook]]s in roam using [[template]]s

Meta: 

title with link to topic and playbook page

files and links to actual templates that can be plugged in to, eg, Miro and Decks

Things to build playbooks for

Roadmaps

User Stories

Workshops

North Star Framework

Pitch approaches

Decks

Pitch decks

Data-specific content

