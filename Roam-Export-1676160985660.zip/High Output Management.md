**Meta:**

**Author:** [[andy grove]]

**Title:** [[High Output [[management]]]]

**Tags:** #intel, #[[management]][[*]]

# Notes



