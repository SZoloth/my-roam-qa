Author:: [[Ben Thompson]]

URL:: https://stratechery.com/2016/the-fang-playbook/

Recommended By::

Tags:: #Articles #Inbox #Readwise #[[Aggregation Theory]]

### Highlights first synced by #Readwise [[September 30th, 2020]]

The vast majority of those sales are actually from 3rd-party merchants using Amazon as a discovery and fulfillment platform, but these merchants’ market power relative to Amazon is not unlike publishers relative to Facebook, because Amazon.com is where the buyers are. 

**Note**: Control demand to control supply.

There is a clear pattern for all four companies: each controls, to varying degrees, the entry point for customers to the category in which they compete. This control of the customer entry point, by extension, gives each company power over the companies actually supplying what each company “sells”, whether that be content, goods, video, or life insurance. 

None of the FANG companies created what most considered the most valuable pieces of their respective ecosystems; they simply made those pieces easier for consumers to access, so consumers increasingly discovered said pieces via the FANG home pages. 

By owning the consumer entry point — the primary choke point — in each of their respective industries the FANG companies have been able to modularize and commoditize their suppliers 

they are “aggregators” who start with the best customers and don’t really compete with incumbent companies, at least in the beginning. In fact, incumbents nearly universally benefit from the presence of aggregators, at least at first (publishers benefited from Facebook, merchants from Amazon, content makers from Netflix, web businesses of all types from Google). It is only when the aggregators’ consumer base becomes dominant that the inevitable squeeze on incumbents — specifically, on their profit margins — begins, and it is in the long-run irreversible. 

