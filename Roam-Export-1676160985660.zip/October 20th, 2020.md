[[Meetings]]: [[Museum of Science]] EiE Campaign Update (no [[darci nevitt]])

Attendees:: [[chris baker]] [[melissa rousselle]] [[Lauren McDonough]]

Time:: 15:59

Notes::

Campaign

google display

linkedin

Specific focus on senior-level (admin, superintendent)

next steps for the campaign

facebook broken - huge black eye

Hubspot Proposal

Need more detail and what's included

**Deliverables**

Number felt low

Table: behavioral emails

Replace with customer nurture drip

Next steps:: #[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} Update HubSpot proposal with more tangible deliverables #/

Table the behavioral emails and replace with customer nurture drip

{{[[DONE]]}} Google Display v. LinkedIn? #/

No YouTube

Demonstrated success on Display network - low projected conversions on LinkedIn

Incredibly cheap project CPC

{{[[DONE]]}} Marketing team overview #[[🏔ADK [[Task Management]]]]

Notes

The marketing team helps our clients get the new products ADK builds into the eager arms of their target audience. We do this to help clients earn more money so they can reinvest in future development. 

[[gtm/Go To Market]] strategy

We help produce target personas, conduct competitor research, and define launch strategies* for our clients.

*What's a launch strategy? This is basically defining marketing channel mix (eg - Google Ads, Facebook, & SEO) that should be used and how they should be used (eg - retargeting on Facebook, brand searches on Google Ads, and thought leadership content).

Analytics

We help clients understand what's working on their product (or isn't) and why. Part of this involves actually defining __what__ to track, part of it is __how__  to track it, and the other part is explaining __why__ the metrics matter. 

For websites, we use tools like Google Analytics (data platform), Google Tag Manager (data collection), and Google Data Studios (flexible data viz).

For apps/products, we use tools like Segment (data collection) and [[Amplitude]] (data platform).

Technical SEO

Making sure the sites we build don't upset Google using tools like [[ahrefs]] and Screaming Frog to conduct technical audits & [[prioritize]] fixes. 

Content

Using tools like [[ahrefs]] to conduct keyword research and help write things like blog posts to rank for those keywords.

Paid

Set up and optimize ad campaigns on Facebook, Instagram, LinkedIn, and Google.

CRO

Turn [[qualitative]] and quantitative information into hypotheses about ways to improve product. Turn hypotheses into tests. Turn tests into information or product changes. 

Hi everyone! We were working on some high-level overviews of what each of our dev teams does well and we decided it would be good to get the same overviews from every team in the company ![:slightly_smiling_face:](https://a.slack-edge.com/production-standard-emoji-assets/10.2/apple-medium/1f642.png)Our goal is to educate teammates across departments about what makes each team successful in what they do:

Why do we use the technologies/processes that we do? (think tech: google analytics, jira, sketch, AWS, etc | think processes: analytics google sheet, sprint plans, wireframing, backups, etc)

What makes your team/department successful at what it does?

Rough draft example of what Skoglund and I have written up for the CMS Dev department attached:

#[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} Review [[Ohad Cohen]] second draft

{{[[DONE]]}} Review [[victor brown]] second draft

