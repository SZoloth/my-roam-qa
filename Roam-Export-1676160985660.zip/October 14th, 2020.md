[[🏔ADK [[Task Management]]]]

{{[[DONE]]}} [[darci nevitt]] coverage doc #//

{{[[DONE]]}} Updated dash for [[Museum of Science]] #/

{{[[DONE]]}} follow up with [[chris baker]] on [publishing internal resources for selling mHealth App Kit](https://adkgroup.atlassian.net/browse/MOKR-19) and on [agile with kirsten](https://adkgroup.atlassian.net/browse/MOKR-31)

