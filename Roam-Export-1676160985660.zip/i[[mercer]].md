[Email thread on analytics](https://mail.google.com/mail/u/1/#inbox/FMfcgxwJZJdCSJkrqmgdBrMpPsPdXnvf)

