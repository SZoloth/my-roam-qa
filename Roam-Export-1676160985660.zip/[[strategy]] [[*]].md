Books:: [[Good Strategy Bad Strategy]], [[Grand Strategy]], [[Superforecasting]], [[7 Habits of Highly Effective People]], [[Principles]]

Quotes

“One skillset that becomes really valuable is knowing the right questions to ask to be able to discover and flag potential problems even if you are not familiar with running a particular channel. Knowing how to ask your IC good questions, scrutinize the specific channel strategy, and reverse engineer its potential are all things you need to lean into.”

- [[Brittany Bingham]] from Reforge[article](http://www.reforge.com/blog/crossing-the-canyon-leading-your-first-marketing-team)  #Reforge

__Start by answering how your specific OKRs or metrics contribute to business [[outcome]]s, and what needs to be true for you to deliver on them? What are the drivers, both [[qualitative]]ly and quantitatively, what__ [[assumption]]s __were made when forecasting targets, and more - you run the risk of optimizing metrics that don't matter. Should you be driving account registrations, or working towards a 7-day retained user that can be monetized? Scrutinize the metrics and build your strategy around meaningful metrics.__

- [[Brittany Bingham]] from [[[[Reforge]].com]] [article](http://www.reforge.com/blog/crossing-the-canyon-leading-your-first-marketing-team) 

Start by answering how your specific [[OKR]]s or metrics contribute to business [[outcome]]s, and what needs to be true for you to deliver on them? What are the drivers, both [[qualitative]]ly and quantitatively, what [[assumption]]s were made when forecasting targets, and more - you run the risk of optimizing metrics that don't matter. Should you be driving account registrations, or working towards a 7-day retained user that can be monetized? Scrutinize the metrics and build your strategy around meaningful metrics 

