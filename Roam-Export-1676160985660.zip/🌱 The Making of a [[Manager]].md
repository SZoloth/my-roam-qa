**Meta:**

**Author:** [[Julie Zhuo]]

**Title:** [[🌱 The Making of a [[Manager]]]]

**Tags:** #facebook, #[[management]], #[[LMT Managing]]

## What is [[management]]?

Managers do these things...

Meet with teammates to help solve problems

share [[feedback]] about whats going well or not

figure out promotions and firings

build a team that works well together

support members in reaching [[career]] [[Goals]]

create processes to get work done efficiently

...in order to **get better [[outcome]]s from a group of people working together**

[[management]] is: the belief that a team of people can achieve more than single person going it alone

You don't have to do/know/be the best at everything yourself

Help your team achieve great [[outcome]]s - because **you're responsible for the [[outcome]]s of your team**, you need to address problems effectively

__Your role is not to do the work yourself even if you're the best at it__

Your role in #[[management]][[*]] is to improve the **purpose**, **people**, and **process** of your team to get as high a multiplier effect on your collective [[outcome]] as you can

Eg - analytics standards & guides allow __everyone__ to do incrementally better jobs using analytics for our clients, which means my output on the guides & standards is a multiplier

If your team is lacking key skills --> hire or train

If someone is creating problems --> get them to stop

If people don't know what they should be doing --> construct a plan

You need to understand your former peers' [[career]] [[Goals]], what kinds of projects are well suited to their strengths and interests, what they need help with, and how they are doing relative to expectations

^^**DON'T AVOID AWKWARD CONVERSATIONS**^^

What gets in the way of good work? there are only two possibilities. The first is that __people don't know how to do good work.__ The second is that they know how, but __they aren't motivated.__ #[[andy grove]]

Your job as a manager isn't to dole out advice or "save the day" -- it's to empower your report to find the answer herself. #[[♾️ Mantras]]

Great management comes from playing to your strengths rather than from fixing your weaknesses

## Measuring [[management]]

How to measure [[management]]? Look at output rather than activity.

one should look at "the output of the work unit and not simply the activity involved. Obviously, you measure a salesman by the orders he gets (output), not by the calls he makes (activity)" - [[andy grove]]

Manager's Output = 1/2 team's results + 1/2 strength and satisfaction of the team #[[chris cox]]

Questions to ask: 

Did we achieve our aspirations in creating valuable, easy-to-use, and well crafted results?

Did you do a good job hiring and developing individuals and was your team happy and working well together?

Your individual output as a manager should be multiplicative vs. additive

## [[What determines the success of a team]]

Teams **underperform** when **coordination** and **motivation** are **low**

**Five conditions** that increase a team's odds of success according to [[J. Richard Hackman]] are having:

A real team with clear boundaries and stable membership

A compelling direction

An enabling structure

A supportive organizational context

Expert coaching

First big part of a manager's job is: ^^ensuring that your team knows what success looks like and cares about achieving it^^

## Will you be a great manager? #[[management]][[*]]

Do you find it more motivating to achieve a particular **[[outcome]]** or play a specific **role?**

Manager = [[outcome]]

Do you like talking to people?

Can you provide stability for an emotionally challenging situation?

## [[How to Manage Others]] Well

### When you first become a manager

### Questions to ask when you first become a manager

What to ask your manager/mentor **__for__** if you're **being promoted**:

A small group of reports that they feel you can successfully manage

Support building a strong relationship

What to ask your manager **__about__** if you're **being promoted** into an existing team:

What will be my [[scope]] to start and how do you expect to change over time?

How will my transition be communicated?

What do I need to know about the people that I'll be managing?

What important team [[Goals]] or process should I be aware of and help push forward?

What does success look like in my first 3 and 6 months?

How can we stay aligned on who does what between us?

What to ask your (new) manager about expectations:

What does it mean to do a great job versus an average or poor job? Can you give me some examples?

Can you share your impressions of how you think Project X or Meeting Y went? Why do you think that?

I noticed Z happened the other day..Is that normal or should I be concerned?

What keeps you up at night? Why?

How do you determine which things to [[prioritize]]?

Ask **your manager** to calibrate yourself through the following two questions:

What to ask yourself if you're **creating a team**:

How do I make decisions?

What do I consider a job well done?

What are all the responsibilities I took care of when it was just me?

What's easy or hard about working in this function?

What new processes are needed now that this team is growing?

What qualities do I want in a team member?

What skills does our team need to __complement my own?__

### How to run [[1:1s]] #[[How to Manage Others]]

Frequency and types:

Once a week, at least 30m

Devote a single 1:1 every month to __just__ discuss behavioral [[feedback]] and [[career]] [[Goals]]

Try to understand what motivates him, what his long-term [[career]] aspirations are, how he's feeling about his work **not** a status update on his work

You're trying to: remove a barrier, provide a valuable perspective, increase their confidence, or just empathize.

^^How to prepare for [[1:1s]]^^

**Discuss top priorities:** What are the one, two, or three most critical [[outcome]]s for your report and how can you help her tackle these challenges?

**Calibrate what "great" looks like:** Do you have a shared vision of what you're working toward? Are you in sync about [[Goals]] or expectations?

**Share [[feedback]]:** What [[feedback]] can you give that will help your report, and what can your report tell you that will make you a more effective manager?

**Reflect on how things are going:** Once in a while ask things like -- how are you feeling on the whole? What's making you satisfied or dissatisfied? Have any of your [[Goals]] changed? What have you learned recently and what do you want to learn going forward?

^^[[Questions for [[1:1s]]]]^^

**Identify:** These questions focus on what really matters for your report and what topics are worth spending more time on:

What's top of mind for you right now?

What priorities are you thinking about this week?

What's the best use of our time today?

**Understand:** These get at the root of any problems of the decided topic:

What does your ideal [[outcome]] look like?

What's hard for you getting to that [[outcome]]?

What do you really care about?

What do you think is the best course of action?

What's the worst-case scenario you're worried about?

**Support:** These zero in on how you can be of service to your report:

How can I help you?

What can I do to make you more successful?

What was the most/least useful part of our conversation today?

Mini, immediate [[debrief]] s

### How to give [[feedback]]:

What is** good [[feedback]]**?

It inspires the recipient to change their behavior, which resulted in their life getting better.

Does my [[feedback]] lead to the change I'm hoping for?

Praise is a form of [[feedback]]. This is easy to forget.

How to **inspire a change in behavior**:

**Set clear expectations** at the beginning

Agree with your report on what success looks like. Get ahead of any expected issues.

What to address:

What a great job looks like for your report, compared to a mediocre or bad job

What advice you have to help yur report get started on the right foot

Common pitfalls your report should avoid

**Give task-specific [[feedback]]** as frequently as you can

Be as precise and detailed as you can

A note via email or slack in the same day is great unless the task is hugely important

**Share behavioral [[feedback]]** thoughtfully and regularly

This is looking at task-specific [[feedback]] in aggregate over time for your report to notice any behavioral trends

This is making a statement about how you perceive that person so (like all [[feedback]]) it must be supported with specific examples

Roam may be a good way to keep track of this?

**Collect 360-degree** [[feedback]] for maximum objectivity

How to collect: Every quarter, send a short email to handful of your reports closest collaborators asking: a) What is X doing especially well that they should do more of? b) What should X change or stop doing?

Then: Set up a meeting with your report to discuss the [[feedback]] in person and document learnings in writing

**Make the listener feel safe**

Show that you're giving [[feedback]] because you care about them and want them to succeed

How to **give critical [[feedback]]:**

**Make the listener feel safe**

Understand your report's perspective on the [[feedback]] they just received

Deliver the [[feedback]] directly and dispassionately

If you are delivering bad news about a decision, make sure the decision is the first thing our of your mouth when you both sit down

Eg - You've just had a tense 1-1 with a direct report

Template:

When I [heard/observed/reflected on] your [action/behavior/output], I felt concerned because...I'd like to understand your perspective and talk about how we can resolve this.

How to **make sure your [[feedback]] was heard**

Follow up with: "Does this [[feedback]] resonate with you? Why or why not?"

At the end: "Let's make sure we're on the same page - what are your takeaways and next steps?"

Help the person hear the [[feedback]] many times and via many sources

Summarize via email what was discussed

How to **make [[feedback]] lead to positive action**:

Make it as specific as possible by using clear examples that explain the __why__

Clarify what success looks and feels like

Suggest next steps

Be clear about whether you're setting an expectation or merely offering a suggestion

This can be overdone

A softer approach is asking, "so what do you think next steps should be?" then letting them guide the discussion

**When** to give [[feedback]]

In general - in the moment is more effective, but depends on many factors:

How big is the [[feedback]] (minor vs major)

If the person you're saying it to is in a position to **hear** it (are they overwhelmed with other things, are they in an appropriate mood)

how many other times have you provided [[feedback]] recently? If there's a lot in a short time it likely won't be well received.

The goal, in my mind, is not just to provide [[feedback]] to make the end result better, but make them want to do it better next time. Whatever method best supports this is my fav - but it varies by person/day. 

Also worth noting this goes for positive [[feedback]]!!! Don't just give negative

Providing [[feedback]] meetings

### How to **get** [[feedback]] #self-development

Questions to ask when you first become a manager

What to ask your peers

Pick 3-7 people whom you work closely with and ask if they'd be willing to share some [[feedback]] to help you improve:

Ask **your manager** to calibrate yourself through the following two questions:

Ask for task-specific [[feedback]] to calibrate yourself on specific skills

Ask for [[feedback]] to maximize learning

Ask for [[feedback]] from other people __all the time__ -- you can never ask too frequently

Can you be humble and self-aware enough to hear it openly and then respond with real change?

Ask for both **task-specific** and **behavioral** [[feedback]]

Probe at specifics and __make it easy for someone to tell you something actionable__

Treat your manager as a coach

Your own growth is in your hands, so if you feel you aren't learning from your manager, ask yourself what you can do to get the relationship you want

Ask, "What skills do you think I should work on in order to have more impact?"

Share your personal goal and enlist their help

Tell them your hard problems so he can help you work through them

Use [[1:1s]] as opportunities for focused learnings

Ask open-ended questions like:

How do you decide which meetings to attend?

How do you approach selling a candidate?

How do you prep for candidate interviews?

What do you do differently for your direct reports now that you didn't before?

Make a mentor out of everyone

Ask for __specific advice__

Find people you admire and ask, "Hey, I'm really impressed with the way you [do X]. I'd love to learn from you. Would you be willing to grab a coffee with me and share your approach?"

How to get [[feedback]] about your meeting

Always ask for [[feedback]], especially on recurring meetings with larger audiences

"How useful do you think this meeting is? My goal is [x], but I wonder if [challenge] is an issue. What do you think?"

### How to's #[[How to Manage Others]]

How to assess your team & situation: [[team-development]]

Are processes efficient?

Are people getting along?

Is your team known for rigorous and high-quality work?

Is your team cagey about deadlines?

Are priorities always shifting?

Are there any inefficient meetings?

Is anyone on your team an asshole (even if they're a brilliant top IC)?

How to ^^build trust & relationships^^:

Don't avoid awkward conversations about their strengths, weaknesses, [[career]] [[Goals]], etc.

Strive for 1:1s to feel a __little__ awkward

Ensure that your team knows what success looks like and cares about achieving it

Give your new team a blank slate in terms of reputation

Talk openly and frankly early on about the kind of relationship you'd like to build and the kind of manager you want to be

Ask your reports the following questions about their dream manager

What did you and your past manager discuss that was most helpful to you?

What are the ways in which you'd like to be supported?

How do you like to be recognized for great work?

What kind of [[feedback]] is most useful for you?

Imagine that you and I had an amazing relationship - what would that look like?

Demonstrate vulnerability to create a safe space for it - start with a story of your own failure. Sharing shortcomings and relating to others is powerful (being empathetic rather than dictatorial.)

Some shortcomings

LDPD SEO

Wasabi (GTM)

BrainSell [[scope]]

EiE

ADK marketing

Ways to be open when you don't know the answer/take ownership:

I don't know the answer. What do you think?

I want to come clean and apologize for what I did/said the other day...

One of my personal growth areas this quarter is...

I'm afraid I don't know enough to help you with that problem. Here's someone you should talk to instead...

__"It takes repeated good experiences to build up to a level of trust where you can be vulnerable and compassionately critical with each other"__

Genuinely respect and care about your report: "**managing is caring**"

Do your best to help your report be successful and fulfilled in her work

Taking the time to learn what she cares about

Understanding that we are not separate people at work and at home - sometimes the personal blends into the professional and that's 👌 

Respect and care unconditionally - not just when they do something well

Be honest and transparent about your reports' performance - as often as they need to hear it.

How to build motivation: #team-development

Recognize and manage to the unique strengths of each report

**Specific and genuine recognition for hard work, valuable skills, helpful advice, or good values can be hugely motivating** #[[feedback]]

How to know when your reports trust you:

They regularly bring their biggest challenges to your attention

You and they regularly give each other critical [[feedback]] and it isn't taken personally

Your reports would gladly work for you again

How to find balance & prioritization: #team-development

When your team becomes 4-5 people, you should have a plan to scale back individual contributor work so you can better manage your team

Don't let the worst performers dominate your time -- try to diagnose, address, and resolve their issues as swiftly as you can

Oftentimes, incremental gains with top performers have larger impacts and are easier to achieve (therefore are more efficient) than larger impacts for bottom performers

IE - double down on what's working rather than putting resources behind failing projects in an attempt to get them to "not failing"

How to identify & deal with underperformers:

If you don't believe someone is set up to succeed in his current role, the kindest thing you can do is be honest and support him in moving on

^^A good question to ask yourself is: __"If this person were not already at the organization, would I recommend that another team hire him or her knowing what I know?"__^^

How to **get** [[feedback]] #self-development

How to **give critical [[feedback]]:**

How to run [[1:1s]] #[[How to Manage Others]]

How to **inspire a change in behavior**:

How to **make [[feedback]] lead to positive action**:

How to **make sure your [[feedback]] was heard**

How to **deal with imposter syndrome**

How to **understand your strengths and weaknesses**

How to **develop a growth mindset** #[[[[High Agency]][[*]]]]

How to **optimize habits for best possible performance**

How to **take care of yourself when you're feeling down**

How to **get 2x as good at something**

How to get [[feedback]] about your meeting

### Situations & Responses #[[How to Manage Others]]

When there are concerns about lackluster work

Diagnose the people issues behind it - is it a problem of motivation or skill?

Does "great work" mean the same thing for you and your report?

Do they understand the purpose of the work?

Does it energize them?

If the answers to the above are all "yes," then it's likely an issue with skill

Sign that everything is not ok: When someone says "everything is fine" at every check in without details ➡️ You should prod deeper

Your report wants a promotion that you don't think is likely to happen

Say ASAP: "I understand you'd like to work towards a promotion, but here are the gaps I'm seeing..." 

Show that you want to help them reach their goal

Spell out your promotion criteria

You've just assigned a challenging new project to your report and you'd like to keep a close eye on it 

At the beginning, let your report know how you're planning on being involved

Be explicit that you'd like to review the work 2x/week and talk through the most important problems together

Your team has a time-boxed goal and you want to know of any roadblocks as soon as possible 

Set expectations up front that you'd like to hear about any concerns with the launch date as soon as possible

Make sure they understand it's safe to talk about problems, even in early phases

### Artifacts

Weekly meeting that's different than the current marketing meeting in that it should allow people to present their work and get [[feedback]] (instead of running through tasks and status?)

### [[insight]]s about [[human nature under [[management]]]] #[[♾️ Mantras]]

People don't like to complain or be a failure in the eyes of their manager. Therefore, they will default to not proactively highlighting issues.

"When we are going through tough times, the thing that's often the most helpful isn't advice or answers but empathy."

"Every major disappointment is a failure to set expectations"

"[[feedback]] is a gift"

Picture yourself at eighty, sitting on a beach and looking back on your life. What do you want to remember?

Every manager feels like an imposter sometimes.

You can't do your best work unless you physically feel your best, so take care of yourself. It's always worth it.

## [[How to Manage Yourself]] #self-development

How to **deal with imposter syndrome**

Remember: __every__ **body** feels like an imposter sometime

A quick outline for How to **deal with imposter syndrome**:

Identify growth areas in that environment that you feel weak in

Spend time honing those skills

How to **understand your strengths and weaknesses**

Self-evals

Quick exercise 1: ask yourself the following questions and jot down the first thing that comes to mind about your **strengths**

How would people who know and like me best (family, significant other, close friends) describe me in 3 words?

Eg - thoughtful, enthusiastic, driven

What 3 qualities do I possess that I am the proudest of?

Eg - curious, reflective, optimistic

When I look back on something I did that was successful, what personal traits do I give credit to?

Eg - vision, determination, humility

What are the top 3 most common pieces of positive [[feedback]] that I've received from my manager of peers?

Eg - principled, fast learner, long-term thinker

Quick exercise 2: ask yourself the following questions and jot down the first thing that comes to mind about your **weaknesses**

Whenever my worst inner critic sits on my shoulder, what does she yell at me for?

Eg - getting distracted, worrying too much about what others think, not voicing what I believe

If a magical fairy were to come and bestow on me three gifts I don't yet have, what would they be?

Eg - bottomless well of self confidence, clarity of thought, incredible persuasion

What are three things that trigger me (get me more worked up than it should)?

Eg - sense of injustice, idea that someone else thinks I'm incompetent, people with inflated egos

What are the top three most common pieces of [[feedback]] from my manager of peers on how I could be more effective?

Eg - be more direct, take more risks, explain things simply

Peer-evals [[feedback]]

Ask **your manager** to calibrate yourself through the following two questions:

What opportunities do you see for me to do more of what I do well? What do you think are the biggest things holding me back from having greater impact?

What skills do you think a hypothetical perfect person in my role would have? For each skill, how would you rate me against that ideal on a scale of 1-5?

Pick 3-7 people whom you work closely with and ask if they'd be willing to share some [[feedback]] to help you improve:

Example request

Hey, I value your [[feedback]] and I'd like to be a more effective team member. Would you be willing to answer the questions below? Please be as honest as you can because that's what will help me the most -- I promise nothing you say will offend me. [[feedback]] is a gift, and I'm grateful for your taking the time.

Specific asks

On our last project together together, in what ways did you see me having impact? What do you think I could have done to have more impact?

With my team, what am I doing well that you'd like to see me do more of? What should I stop doing?

One of the things I'm working on is (being more decisive). How do you think I'm doing on that? Any suggestions on how I can do better here?

Ask for task-specific [[feedback]] to calibrate yourself on specific skills

Eg - if you're not sure how good of a public speaker you are, follow up with a few people after you give a presentation and say, "I'm hoping to improve my speaking skills. What do you think went well with my presentation. What would have made it 2x as good?

How to **optimize habits for best possible performance**

Understand what helps you perform at your best

Examples

At least 8 hours of sleep the night before

Something productive early in the day, which motivates me to keep momentum going

Knowing what the desired [[outcome]] looks like before I start

Having trust and camaraderie with the people I work with

Able to process information alone (and through writing) before big discussions or decisions

Feeling like I'm learning and growing

How to Understand what helps you perform at your best

Which 6-mo period of my life did I feel the most energetic and productive? What gave me that energy?

In the past month, what moments stand out as highlights? What conditions enabled those moments to happen, and are they re-creatable?

In the past week, when was I in a state of deep focus? How did I get there?

Understand what gets in the way or triggers you

What are the things that push your buttons, but maybe not someone else's?

When was the last time someone said something that annoyed me more than it did others around me? Why did I feel so strongly about it?

What would my closest friends say my pet peeves are?

Who have I met that I've immediately been wary of What made me feel that way?

What's an example of a time when I've overreacted and later regretted it? What made me so worked up in that moment?

Set up habits that make it easier to operate in that ideal environment

Set a rigid nightly routine so you can fall asleep and wake up at about the same time

Set sacred, consistent exercise time early in the day

Schedule 30m of "daily prep" into my calendar so I can study my day and visualize how I want each meeting or work task to go

Use the Roam daily notes for this!

Schedule "thinking time" blocks on my calendar so I sort through and write down my thoughts on big problems

Chunk similar tasks on my calendar

How to **develop a growth mindset** #[[[[High Agency]][[*]]]]

Approach challenges with the belief that you can get better at anything by putting in the effort

Re-frame your reaction to scenarios

Eg - Getting suggestions for improvement

Fixed mindset: I messed up and my manager thinks I'm dumb

Growth mindset: I'm thankful my manager gave me those tips. Now I can make my future assignments better

Eg - Asked to take on a risky and challenging new project

Fixed mindset: I should say no - I don't want to fail and embarrass myself.

Growth mindset: This is a great opportunity to stretch, learn something new, and gain the experience needed to lead more big projects.

Eg - You've just had a tense 1-1 with a direct report

Fixed mindset: I should act as if that went well so I come off like I know what I'm doing.

Growth mindset: I should ask Alice how she felt about that conversation and how we might have more productive discussion in the future.

Eg - You're in the middle of working on a proposal, and your manager asks to see your progress.

Fixed mindset: I don't want to show anything right now b/c the proposal is in rough shape. It'll make me look bad.

Growth mindset: The [[feedback]] will be really helpful. In fact, I should share my early thinking with even more people so I can get ahead of any potential issues.

How to **take care of yourself when you're feeling down**

Recognize that everyone in the world goes through hard times, and give yourself permission to worry. 

Conjure up a public figure you admire and google "[person's name] struggle"

Admit you're feeling bad. Take out a post-it note and write, "I am super stressed out about X." 

When a negative story takes hold of you, step back and question whether your interpretation is correct. Are there alternative views you're not considering? What can you do to seek out the truth?

Confront reality by asking about what's causing doubt (eg - "Why wasn't I invited to that meeting?")

Visualize

Imagine the anxiety, fear, and confusion you're feeling as not being personal to you, but universal things that everyone faces.

Imagine yourself succeeding wildly at something you're nervous about. Be as specific as possible.

Imagine a time in the past when you took on a hard challenge and knocked it out of the park. Be as detailed as possible.

Imagine a room full of your favorite people telling you what they love about you.

Imagine what your day would feel like if you were out of the Pit.

Ask for help from people you can be real with

Create a check in meeting with peers that you can discuss what you're struggling with. Meet for ~1 hour every month.

Celebrate little wins

Every day, jot down something you did that you were proud of, even if it was small. 

Set clear boundaries

Schedule a 15m activity at the beginning and end of the day that isn't related to work.

How to **get 2x as good at something**

Set a lofty goal for yourself (get 2x as good at something), then maximize your learning through the following:

Ask for [[feedback]] to maximize learning

Ask for [[feedback]] from other people __all the time__ -- you can never ask too frequently

Can you be humble and self-aware enough to hear it openly and then respond with real change?

Ask for both **task-specific** and **behavioral** [[feedback]]

Probe at specifics and __make it easy for someone to tell you something actionable__

Treat your manager as a coach

^^Your own growth is in your hands, so if you feel you aren't learning from your manager, ask yourself what you can do to get the relationship you want^^

Ask, "What skills do you think I should work on in order to have more impact?"

Share your personal goal and enlist their help

Tell him your hard problems so he can help you work through them

Use [[1:1s]] as opportunities for focused learnings

Ask open-ended questions like:

How do you decide which meetings to attend?

How do you approach selling a candidate?

How do you prep for candidate interviews?

What do you do differently for your direct reports now that you didn't before?

Make a mentor out of everyone

Ask for __specific advice__

Find people you admire and ask, "Hey, I'm really impressed with the way you [do X]. I'd love to learn from you. Would you be willing to grab a coffee with me and share your approach?"

Set aside time to reflect and set [[Goals]] #self-development

Schedule an hour on my calendar at the end of every week to think about what I accomplished, what I'm satisfied or dissatisfied with, and what I'm taking away for next week. Then jot down some notes in an email to my team.

Examples

Recent [[feedback]] I heard

Recruiting for next year

Strategy for Project X

Understanding research needs

Set personal [[Goals]] and do bigger look-backs every six months.

Examples

Build out my bench

Evolve processes

Become an expert in hiring great team members

Don't bring work home with me

Reflect by asking

If you didn't succeed: Why? Was it a tactical or communication failure?

If you did succeed: What allowed me to be successful? What would you allow me to make this an even more ambitious goal? What tips might I give to someone else looking to do the same thing?

## How to Have [[Better Meetings]] #[[How to Manage Others]]

Clearly define what the [[outcome]] for the meeting should be

Meetings generally have these [[Goals]]: making decisions, sharing information, providing [[feedback]], generating ideas, and strengthening relationships

Decision meetings: 

Framing the different options on the table and asking a decision-maker to make a call

Success = both getting to a clear decision **and** everyone leaving with a feeling of trust in the process

Requirements:

Gets the decision made

Includes the people most directly affected by the decision

Includes a clearly designated decision maker

Presents all reasonable options objectively and fairly 

Gives equal airtime to dissenting opinions

Sharing information meetings

Requirements:

The group feels like they learned something valuable

The meeting conveys key messages clearly and memorably

Keeps the audience's attention

Evokes an intended emotion, like: inspiration, trust, pride, courage, empathy, etc.

Providing [[feedback]] meetings

Requirements:

Gets everyone on the same page about what success for the project looks like

Honestly represents the current status of work: how are things going, any changes since the last check-in, and what future plans are

Clearly frames open questions, key decisions, or known concerns to get the most helpful [[feedback]]

Results in agreed-upon next steps, including the date for the next milestone or check-in

Generating ideas meetings

Needed for generating ideas both: time to think alone __and__ time to engage with others

Requirements

Produces diverse, nonobvious solutions by ensuring each participant has quiet alone time to think of ideas and write them down

Considers everyone's ideas (not just loudest voices)

Uses discussion to evolve and build ideas off of each other

Ends with clear plans to turn ideas into action

Strengthening relationships meetings

Examples: team lunches, dinners, and other social purposes

Requirements

Creates better understanding and trust between participants

Encourages people to be open and authentic

Makes people feel cared for

Inviting the right people: based on what the goal [[outcome]] is, who is necessary to make that [[outcome]] happen?

Help everyone come prepared to the metings

Ask the organizer to send out any presentations or documents the day before so that everyone could process the info in advance

Wrapping up: at the end of every meeting ask, "So before we break, let's make sure we agree on next steps..."

After meetings: send out a recap to attendees with a summary of the discussion, list of specific action items and who is responsible for each, and when the next check-in will be

Ensure everyone gets a voice

Be explicit up front that you want participation from everyone

Go around the room and ask each individual for their thoughts

How to get [[feedback]] about your meeting

Always ask for [[feedback]], especially on recurring meetings with larger audiences

"How useful do you think this meeting is? My goal is [x], but I wonder if [challenge] is an issue. What do you think?"

When you want to stay in the loop about relevant decisions, ask organizers to include me on pre- and post-meeting notes

## [[How to Hire Well]] #[[How to Manage Others]]

Remember: hiring is not a problem to be solved, but an opportunity to build the future of your organization

### How to design your team #team-development

Exercise: Every January, map out where you hope your team will be by the end of the year. 

Create a future org chart

Analyze gaps in skills, strengths, experience

Make a list of all open roles to hire yourself

Ask yourself:

How many new people will I add to our team this year based on growth, attrition, budget, priorities, etc.?

For each new hire, what level of experience am I looking for?

What skills or strengths do we need in our team (eg - creative thinking, operational excellence, expertise in XYZ, etc.)?

Which skills and strengths does our team already have that new hires can stand to be weaker in?

What traits, past experiences, or personalities would strengthen the diversity of our team?

**How to own** [[hiring]]

Describe your ideal candidate with as much detail as possible

Write the [[job description]] yourself and be specific about the skills or experiences you are looking for

Develop a sourcing strategy

What titles or orgs should you look for on LinkedIn?

Who should you ping for recommendations?

What conferences should you attend?

Send out the intro email yourself instead of the recruiter

Deliver an amazing interview experience

Ensure you know:

If all the interviewers have the backgrounds notes

Who is assessing which skills

Do we have interviewers well matched with the interviewee?

Who will follow up?

Show candidates how much you want them

Paint a vivid picture for how you see the person having impact. Help them understand why the role is exciting and why they're perfect for tackling the big problems

**How to make smart bets on interviewees**

Examine past examples of similar work 

Ask for examples of similar work they've done in the past

Seek out trusted recommendations

As soon as a new role is open, ask your team: "who is your __dream__ candidate for this position?"

Across these recommended people are there patterns in skills, companies, experiences we should dig into?

Ask for references

But keep in mind two things: people typically improve skills over time, so slightly discount that negative [[feedback]] & don't __only__ source from our existing network (this breed homogeneity)

Get multiple interviewers involved

Have each interviewer ask different questions to result in a 360 degree view of the candidate

Look for passionate advocates rather than consensus 

Avoid the "weak hire": when someone gets hired only because no one can find a reason __not__ to hire them

Hiring is a bet. Bet on someone that has a passionate advocate behind them. 

Even if a candidate gets mixed reviews, as long as the people behind them are adamant its usually a sign they're valuable

Prepare your **[[interview [[question]]s for [[discovery]]]]** ahead of time

If multiple candidates are interviewing for the same role, ask them the same things 

Example questions

Can you walk me through how you set [[Goals]] on a particular project?

Can you describe the most difficult challenge you'd encountered at your past job and how you tackled it?

What kinds of challenges are interesting to you and why? Can you describe a favorite project?

What do you consider your greatest strengths? What would your peers agree are your areas of growth?

Imagine yourself in 3 years. What do you hope will be different about you then vs now?

What was the hardest conflict you've had in the past year? How did it end, and what did you learn from it?

Whats something that's inspired your work recently?

Avoid toxic behavior

Bad mouthing past employers

Blaming failures on others

Insulting other groups of people

Asking what the company can do for them vs. the reverse

Coming across with high arrogance or low self awareness

Hiring for large companies

What would you do differently if hiring was the only thing that mattered?

Hiring leaders 

Don't rush - ensure you know what an ideal applicant looks like

Do that by talking to as many prospective candidates as you can, even those who may not want the job but know the role inside and out

Ask these people: what they look for in a resume? what questions do they ask in interviews and what kinds of answers are they looking for? do they have recommendations on where to look for strong candidates?

Recruiting top talent is all about building strong, long-term relationships

As soon as a new role is open, ask your team: "who is your __dream__ candidate for this position?"

## [[How to get shit done]] #[[How to Manage Others]] #[[How to Manage Yourself]]

General process: Purpose -> Start -> Milestones

[[How to define a purpose]] #[[How to Manage Others]] #team-development #OKR

The purpose should be a **tangible** vision that your team is collectively trying to achieve #[[How to define a purpose]]

From [Fortune article](https://www.instapaper.com/read/1313304971/13148894) on [[charisma]] applied to your vision:

No doublespeak or jargon #[[orit gadiesh]]

Make it emotional and brief

Use symbols, analogies, metaphors, and stories

It should be measurable

It doesn't describe __how__, instead it describes the end state, the goal

Assume everything your team does goes perfectly. What will be different in 2-3 years compared to now?

How would you want someone who works on another team to describe what your team does?

What do you hope will be your teams reputation in a few years? How far off is that from today?

What unique superpowers does your team have? What would it look like for your team to be 2x as good? 5x as good?

What is a quick litmus test that anyone could use to assess whether your team was doing a poor, mediocre, or kick-ass job?

[[How to create a strategy]] #[[How to Manage Others]] #[[[[strategy]] [[*]]]] #team-development #[[OKR]]

What is a good Strategy[[*]][[*]] ?

It must have a realistic chance of working

It focuses a team's unique strengths, resources, and energy on what matters the most **in achieving its [[Goals]]**

It acknowledges your teams' relative strengths and weaknesses

Understand the big picture - or primary goal - first

What problems are you hoping to solve with what you're doing?

How do you imagine people will get value out of your work?

Based on that, what are the most important priorities for the team now?

Focus on doing a few things well #prioritization and #[[Focus[[*]]]] #[[Pareto principle]]

"Few people...put...superior thought and effort into a few important things. People who achieve the most are selective as well as determined." - [[Richard Koch]]

[[prioritization]]: builders need to focus on the features that are essential, managers need to focus on hiring the leaders or "anchors" before the group

Triage, triage, triage - ruthlessly

How to practice [[prioritization]] #[[How to Manage Yourself]] [[Focus[[*]]]]

The best way to practice prioritization is to **order any list you make by importance**

Follow that order

If you have 3 [[Goals]] for your team this half, force yourself to answer: "If I could only achieve one goal, what would it be?"

**Effort doesn't count; results are what matter** #[[♾️ Mantras]]

Is this antithetical to [[growth mindset]]?

Is more of a warning: if you put a ton of resources behind the wrong task, it's wasted. So make sure your effort is going into a high-leverage task

[[Steve Jobs]] on #innovation "It means saying no the hundred other good ideas that there are...Innovation is saying no to 1,000 things"

Define who is responsible for what

Define who has decision-making authority

Break down big [[Goals]] into smaller milestones

Chunk and [[prioritize]]

Treat big projects like a bunch of smaller projects

Then, only worry about what's in front of you, not months or years ahead

Work with your team to set realistic and ambitious target dates for each milestone

Keep in mind the [[planning fallacy]]: the natural bias to predict that things will take less time and resources than they do; the tendency to underestimate

Allot a buffer for dealing with unexpected issues

From your target dates, work backwards and figure out who needs to do what every week

To **create accountability:** ask people to set and publicly commit to their weekly [[Goals]]

Host check-ins to review progress, discuss urgent priorities, and strategize around blockers

If your team is juggling a number of different tasks, order those by what matters most 

[[How to execute a strategy]] #[[How to Manage Others]] #[[[[strategy]] [[*]]]]

You will come up with multiple ideas or possible solutions

The goal is **not** to figure out in abstract which ideas are best, but it __should be__ to **build simple, conclusive tests to understand which ideas should be doubled down on and which ideas should be cut**

This is similar concept to the book, [[Sprint]]

Executing well means you:

pick a reasonable direction

move quickly to learn what works and what doesn't 

make adjustments to get desired [[outcome]]

How to tell if your team is executing well #[[How to Manage Others]]

List of projects are [[prioritize]]d from most to least important and tackled in that order

There is an efficient decision-making process that everyone understands and trusts

The team moves quickly, esp. with decisions that are reversible

After a decision is made, everyone commits to make it happen efficiently 

There is an expedient process to process new information and decide if and how current plans should be adjusted

Every task has a __who__ and a __by when__

Owners set and reliably deliver on commitments

Every failure makes the team stronger because they don't make the same mistake twice

Don't get myopic **__or__** paralyzed by long-term thinking:

Create a "portfolio" of [[Goals]] by making sure that: 1/3 of your team works on projects that are completed in weeks, 1/3 on projects that may take months, and 1/3 on innovative projects that may take years

Connect every task, project, decision or goal with the organizations higher-level purpose

Don't optimize to local maximum that hurts your overall goal

**How to run debriefs** #[[How to Manage Others]] #team-development

Invite the team to connect for 1-2 hours over what went well, what didn't go well, and what the team would do differently next time

Rather than judgment, the goal is to mine the experience for future lessons

To reduce judgment + increase safety:

Present the facts as objectively as possible

Use [[language]] that takes collective accountability instead of pointing fingers

After the [[[[retro]]spective]], write down the learnings and share them widely

How to create #playbook #[[How to Manage Others]]

Common managerial ones: running a meeting, closing a new hire, completing a project on time and on budget

If you find yourself doing a similar thing over and over again (eg - giving the same [[feedback]]), it can probably be codified into an instruction manual or checklist

## [[How to lead a growing team]] #[[How to Manage Others]]

On small teams, you should be able to understand details about each individual personality on your team

Your goal should be to consistently put yourself out of a job: You should try to double your leadership capacity every year

As your team grows, context switching becomes the job. To get better:

Review your calendar every morning to prep for any meetings

Develop robust note-taking and task management systems [[effortless output]] [[nat eliason]]

Find pockets for reflection at the end of each week

[[how to delegate]] #[[How to Manage Others]] #prioritization

Knowing when to dive in yourself and when to step back and entrust/empower others

[[task relevant maturity]] from #[[andy grove]]

Part of delegating well is recognizing that your reports - like you - will make mistakes and doubt themselves, but often the best thing you can do is believe in them

Delegate anything your report can do just as well or better than you

For the things that you do better than your reports: still try to delegate **unless**: it falls into a "most important priorities" bucket or you don't believe they are set up to succeed

When else should you not delegate? When the [[outcome]] gets measurable improved thanks to your unique strengths. These are often things like:

Identifying and communicating what matters thanks to the broader view you have

Hiring top talent because prospective candidates generally want to speak to leadership

Resolving conflicts within your group by making sure your reports know to quickly escalate to you whenever 2 [[Goals]] come into conflict or priorities aren't clear

**The best work comes from those who have the time to live and breathe a problem so they can dedicate themselves to finding the best solution**

"There is no greater sign of trust than handing your report an intricately tangled knot that you believe she can pull apart, even if you're not sure how."

How to create a shared vision #[[How to define a purpose]]

What are the biggest priorities right now for our team?

Discuss those with your reports and how they might play a role

Are we aligned in how we think about people, purpose, and process?

"If you want to build a ship...teach [the men] to yearn for the vast and endless sea."

## [[How to nurture culture]] #[[How to Manage Others]]

`Culture` = the norms and values that govern how things get done

Eg - `Nothing at Facebook is someone else's problem`

[[How to define your team's culture]]

Take about 60m to answer the following questions

**Understanding your current team**

What are the first 3 adjectives that come to mind when describing the personality of your team?

What moments made you feel most proud to be a part of your team? Why?

What does your team do better than the majority of other teams out there?

If you picked five random members of your team and individually asked each person, "What does our team value?" what would you hear?

How similar is your team's culture to the broader organizations culture?

Imagine a journalist scrutinizing your team. What would she say your team does well or not well?

When people complain about how things work, what are the top three things that they bring up?

**Understanding your aspirations**

Describing the top 5 adjectives you'd want an external observer to use to describe your team's culture. Why those?

Now imagine those five adjectives sitting on a double-edged sword. What do you imagine are the pitfalls that come from ruthless adherence to those qualities? Are those acceptable to you?

Make a list of the aspects of culture that you admire about other teams or organizations. Why do you admire them? What downsides does that team tolerate as a result?

Make a list of the aspects of culture that you wouldn't want to emulate from other teams or companies. Why not?

**Understanding the difference**

On a scale from 1-9, with 9 being "we're 100% there" and one being "this is the opposite of our team," how close is your current team from your aspirations?

What shows up as both a strength of your team as well as a quality you value highly?

What are the biggest gaps between your current team culture and your aspirations?

What are the obstacles that might get in the way of reaching your aspirations? How will you address them?

Imagine how you want your team to work in a year's time. How would you describe to a report what you hope will be different then compared to now?

Once you understand where your team stands, the next step is executing

Never stop explicitly talking about the values you want to stick in different ways

Include why

include any of your own missteps and what you learned

Ensure you act in ways that align with your values

instead of incentivizing adherence, have frank discussions about why adherence is valuable

## Applications / Homework

[[ADK Knowledge Project]] Google form with 1 monthly anonymous question

Questions

How do you prep for interviews?

What is the hardest part of your job?

How frequently do you check in with your team?

Preparing and Goal Setting #prompts from [[🌱 The Making of a [[Manager]]]]

