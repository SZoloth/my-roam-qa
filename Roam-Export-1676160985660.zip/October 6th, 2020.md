{{[[DONE]]}} Review [[nick watkins]] questions for [[Sleeping Dog Properties]] [[🏔ADK [[Task Management]]]] #/

[[Meetings]]: [[i[[mercer]]]] analytics

Attendees:: [[jordan daly]] [[aaron crootof]]

Time:: 11:00

Notes::

[[October 6th, 2020]] added SSO pages to referral exclusion page #[[i[[mercer]]]]

[[October 6th, 2020]] set up search tracking for main search #[[i[[mercer]]]]

Questions from client?

Why is traffic in GA dropping?

Organic search took a big hit starting May 2020, but has been steadily declining since March 2019

^^May to June 2020 Organic traffic dropped 50%^^

Referral dropping from October 2019

^^Oct to Dec 2019 Referral traffic dropped 50%^^ and began dropping further April 2020

Direct traffic followed this dropped but then began rebounding

Why is revenue dropping?Î

Why is new/returning split different from brounceXchange?

Challenges

Site search

legacy code

ecommerce

cookiebot

SSO / external [[Log in]]s

VPN users / remote

IP filtering

wishlist

logged in/not 

user id tracking

Notes from [[aaron crootof]]

// Expectation Management

Adblockers, firewalls, browsers, and tools all behave uniquely. Different analytic systems will never be 1:1

// Concerns

Legacy Codebase

eCommerce

Site Search Tracking

Compliance / Cookie Bar (intentional)

SSO / External

Internal VPN/Remote Users

External VPN/Remote Users

eBlasts, Functional Emails, and UTMs

// Wishlist

User ID Tracking

Custom Events

// Steps

Move analytics into GTM

Ensure cross-domain tracking is configured

Ensure SSO tracking works

Analytic Validation (Once per page, proper data)

Does GA fire on homepage?

Does GA fire on a list page?

Does GA fire on a Product page?

Does GA fire on a detail page?

BRIEFLY: try to evaluate why WebTrends data is inaccurate

// Followups

How do all external users [[Log in]]to iMercer?

Can they bring specific data on specific days/times as needed for data comparisons?

Would we be able to add code if needed to SSO portal(s)?

// Client Concerns

New/Returning User data is inaccurate?

Existing analytic data is inaccurate?

// SSO Portals

https://emeamsso1.mercer.com/

https://emeaidentity1.mercer.com/

{{[[DONE]]}} How will we promote/support [[refine labs]] project? #/

[[Meetings]]: [[Museum of Science]]

Attendees:: [[Lauren McDonough]] [[melissa rousselle]] [[darci nevitt]] [[chris baker]]

Time:: 16:05

Notes::

Test Facebook lead gen ads

