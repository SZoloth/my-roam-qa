**Metadata**

Company:: Visualize Value

Role:: Founder, Designer

Bio:: Designer by trade, Jack retired from a short [[career]] in corporate advertising to spend most of the day on Twitter, building design studio & media brand Visualize Value.

If you love the illustrations by [[Jack Butcher]], you can find more of his illustrations of Naval’s ideas on Navalmanack.com and more of his work at [VisualizeValue.com](https://www.visualizevalue.com/).

