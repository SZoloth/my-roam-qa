Bottom-of-[[funnel]] content—the stuff that speaks directly to buying, integrating, budgeting, purchasing, etc.—is sorely underutilized.

We’ll focus on BOFU content first, and move our way up the [[funnel]] over time. That way we [[prioritize]] SEO efforts that are most likely to lead to revenue.

