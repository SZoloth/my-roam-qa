Author:: [[emailmastery.org]]

URL:: https://emailmastery.org/articles/message-audience-fit/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

Step #1: Determine Your Target Market’s Beliefs, Attitude, and Communication Style 

What are you hoping to get out of [BUSINESS NAME]?
Why did you sign up for this email list?
What is the most pressing issue in your life right now? 

In particular, make sure that anything you offer in return for opting into your email list — ebooks, whitepapers, courses, giveaway items, etc — is going to attract the right people… your target market. 

Step #2: Find The Common Phrases Your Target Market Uses 

Talk with your target market, get to know them, notice how they talk, try to identify their values, ask about their fundamental beliefs, and learn everything you can. The better you understand them, the more you can create a brand that attracts them. 

