#whiteprivilege and #BLM

[[Trevor Noah]] discussing #whiteprivilege

https://youtu.be/fVa-HAsB-xQ

[[Michael Che]] set about #BLM

https://www.instagram.com/tv/CBAD0uyDgyo/?igshid=13bk003mht4o5

Longform perspectives

The Daily Podcast

Showdown at Lafayette Square

https://podcasts.apple.com/us/podcast/the-daily/id1200361736?i=1000476776842

History will Judge the Complicity ([[the atlantic]])

https://www.theatlantic.com/magazine/archive/2020/07/trumps-collaborators/612250/

#Anti-racist resources

https://docs.google.com/document/d/1BRlF2_zhNe86SGgHa6-VlBO-QgirITwCTugSfKie5Fs/mobilebasic

https://docs.google.com/document/d/1PrAq4iBNb4nVIcTsLcNlW8zjaQXBLkWayL8EaPlh0bc/mobilebasic

Examples of #whiteprivilege #racism and [[systemic racism]]

Cop kindly asking white anti-protestors with guns to go inside so they can beat protestors with impunity  #[[police brutality]]

https://twitter.com/satellit3heart/status/1268863536299675648?s=21

[[Fox News]]

Defends Drew Brees but condemns LeBron and KD for 

https://twitter.com/ComplexSports/status/1268551040074383361?s=20

Examples of policies that are #anti-democratic and that go against the #constitution #rights #amendments

New York State judge holding anyone for over 24 hours without seeing a judge

https://twitter.com/BryanLlenas/status/1268637787881975809?s=20

LA county sheriff saying curfew will continue until the **organized protests are gone**

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2Fcprjta9kT7.png?alt=media&token=13aee30a-d173-4673-9688-ecba28985489)

The curfew was removed because LA was sued and BLM won (law is on their side)

An officer accused of pushing a teenager has **71** use of force cases on file (why violence in #protests is actually Ok) #[[police brutality]]

https://twitter.com/ArielDumas/status/1268878472816066560

This story of a peaceful protestors experience with the LAPD

https://www.instagram.com/p/CBBNXXkJs0a/?igshid=1fdk0yvxb6v8h

**Examples of** #[[police brutality]]

Officers in Buffalo NY

Shove older man

https://twitter.com/sikhprof/status/1268717861641564160?s=21

Resign en masse in solidarity with those who were suspended

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2Fu_e0kLSWVl.png?alt=media&token=ce3681a2-30af-4bdc-ae88-2dc37a25cafa)

DC police joking about "hunting" protestors

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2Fio9v2axaIE.png?alt=media&token=d165ab7e-30eb-4d05-b942-145ff7641d46)

Black people killed without justice

https://www.instagram.com/p/CBCDW1AA03z/?igshid=szqvlpitxiac

"But not all cops are bad" #[[charlie madden]] #[[charlie madden]] (why violence in #protests is actually ok)

Participation: employment as a cop (even with good intentions) is directly participating in a racist and corrupt system

Bystander effect: cops that fail to intervene during acts of police brutality are just as bad. Complicity is murder. In civilian life, we call this being an accessory to murder

Origin story: The police was not created to protect human life. Police forces were organized to police & capture human bodies (runaway slaves) that were considered stolen property.

**Ask**: Why are you choosing this specific instance to focus on those who do good?

**Ask**: Who polices the police?

"ACAB" is an attack on the job, not the people.

What happens at the curfew? We start beating the fuck out of you

https://www.instagram.com/p/CA8VQtQJ8mt/?igshid=8q2lt1ewr3in

"Police are brutalizing everyone just to maintain their ability to brutalize black people"

"The footage and photographs are disturbing. These lawless rioters are out of control. They have [driven an SUV](https://www.usatoday.com/story/news/nation/2020/05/31/new-york-city-george-floyd-protests-nypd-suvs-[[BK/Brooklyn]]-crowd/5299746002/) into a crowd, [tossed journalists](https://twitter.com/MichaelAdams317/status/1266945268567678976?ref_src=twsrc%5Etfw%7Ctwcamp%5Etweetembed&ref_url=https%3A%2F%2Fd-28501046472714434459.ampproject.net%2F2005150002001%2Fframe.html) to the ground and pepper-sprayed them, [beaten people](https://twitter.com/MattMcGorry/status/1267217360894562306) with batons and even [blinded a woman in one eye](https://www.dailymail.co.uk/news/article-8373001/Journalist-left-blind-one-eye-shot-rubber-bullet-Minneapolis-protest.html). They have been launching [unprovoked attacks](https://www.vox.com/2020/5/31/21275994/police-violence-peaceful-protesters-images) on peaceful, law-abiding citizens exercising their constitutional rights. The violent behavior of these mobs should be condemned by all. We need to restore order: someone must stop the police."

https://www.theguardian.com/commentisfree/2020/jun/01/george-floyd-violent-rioters-america-police-officers

Why violence in #protests is actually OK

Comics

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FhcBV8aYICL.png?alt=media&token=88d8a601-b53c-483e-be9d-2e287b0f096b)

Historical precedence

Sit ins were illegal. Sitting at the front of the bus was illegal. Running away as a slave was a crime. Just b/c it's a **crime** doesn't mean it's **wrong.** In this case, protesting.

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FUfqTj5THdW.png?alt=media&token=8fb4eb0c-b784-4dbc-8f28-196a227e3ddd)

As a response to "looting/destruction of property is never acceptable" #[[charlie madden]] #[[charlie madden]]

The majority of protests stay non-violent.

Riots are anguished __symptoms__ of white supremacy and police brutality. They will go away, but state-sanctioned violence does not. 

We do not get to decide what are acceptable forms of grieving/resistance and what are not

Kaepernick kneeled for this. Beyonce performed for this. Kendrick rapped for this. Parks sat for this. Because they had been voting for hundreds of years and nothing changed. We told them to stop. There will __never be an acceptable way to challenge a system because the system defines what is acceptable__

As MLK Jr. said, "A riot is the [[language]] of the unheard."

Many major corporations being targeted by protestors are those that profit via **wage theft** 

Additionally, I did not hear a peep when it was revealed that many companies had unlawfully appropriated relief funds

"Working-class people pilfering convenience-store goods is deemed "looting." By contrast, rich folk and corporations stealing billions of dollars during their class war is considered good and bad and necessary "public police" -- aided and abetted by arsonist politicians in Washington lighting the crime scene on fire to try to cover everything up."  - David Sirota

**Ask**: Why do we allow destructive rioting in some instances, like after a college football game?

**Ask**: Are you more enraged about property being damaged or the loss of human life?

As a response to "the police were wrong, but this is an overreaction." #[[charlie madden]] #[[charlie madden]] #[[police brutality]]

Police **are** wrong and continue to be as long as the systems supporting their racist workforce are in place and their squads exist

There is **no overreaction** to 400+ years of second class citizenship and dehumanizing treatment #whiteprivilege

If you're sourcing your opinions from the media, you're missing peaceful attempts of protests because the media follows whats incendiary 

Kaepernick kneeled for this. Beyonce performed for this. Kendrick rapped for this. Parks sat for this. Because they had been voting for hundreds of years and nothing changed. We told them to stop. There will __never be an acceptable way to challenge a system because the system defines what is acceptable__

Ask: What are you defending right now?

But if they had just complied with the police, the #[[police brutality]] would not have happened

No one deserves to die regardless if they comply or not. Police brutality is unacceptable no matter what happened before the camera started filming. Regardless: countless black people have been killed by police while complying, unarmed, and not attacking police.

Why is it important to question the narrative of focusing on rioting/looting and property damage?

"If you can't attack the message, attack the intent. If you delegitimize the speaker, you delegitimize the message." That's why they focus on property damage

The Boston Massacre

https://www.instagram.com/p/CA-cnW6jjKQ/?igshid=11tln60ds8766

What should the police have done instead?

Response to #[[charlie madden]] #[[charlie madden]]

Honestly, I don't have strong ideas off the top of my head. But I'm happy to do some research and get back to you. A place to start, off the top of my head, would be whatever the police did during any of the riots after sports games.

Ultimately, though, I think police brutality is NEVER acceptable no matter what happened before the camera started filming or whatever. Additionally, the majority of protests stay non-violent, but the media that you've listed specifically will focus on property damage and violence. It’s important to ask ourselves why that is?

It's interesting that you focus on buildings lost. It's definitely not good, but I don't really think it's an overreaction to 400+ years of second class citizenship and dehumanization. Is that more important to you than things like freedom of speech, miranda rights, police brutality? What are you defending right now? 

What bothers you more - property damage or infringement on rights and loss of life? 

Does the fact that a response was necessary mean that any response was right?

And if you think loss of property and income is such an injustice that it causes you to - even potentially - weigh it against loss of life or rights why do you focus on it now? 

To think about

How police handle riots after sports game

The 538 piece about de-escalation

Punishing people for what you think they might do is a very slippery slope

I understand that Minneapolis got out of hand - and may have happened unilaterally by rioters. But that excuses nothing. 

What is the plan / demands?

[[Defund the police]]

NYPD police budget

In 2019 the NYPD had a budget of $5,668,823,00.

Other services had significantly less. The following 5 services have a combined budget of $5,309,929,000

Homeless services: $2,061,776,000

Housing preservation and development: $1,142,480,000

Youth and community development: $872,141,000

Health and hospitals: $699,460,000

Parks and rec: $534,072,000

Since 2004, the number of active officers has substantially decreased while the budget increased

Active officers: 45,000 to 36,000

Budget: $3.4bn (x1.36 for inflation) or $4.6bn to $5.6bn

So when you hear "defund the police," one of the primary meanings is "divest and invest"

Like scaling back the huge NYPD budget and invest in community resources (mental health and social services, for example)

"The safest communities don't have the most cops; they have the most resources." - Jillian Johnson Durham Mayor Pro Tempore

US police budget

$100bn+ annually on policing from local budgets

Additional $80bn+ on incarceration 

But it would cost about $20bn to eliminate homelessness in the US

And $34bn to ensure free college for every American

"But what if there are no police?"

Who will go after the rapists? 

https://twitter.com/andizeisler/status/1268713465322987521?s=12

"But my participation will not help anything"

As a white person, your participation is essential

You can and should: 

attend protests led by POC and BLM leaders

listen to their requests

do not incite violence or initiate looting

Avoid white silence by:

Educating yourself so POC don't have to

Donate (bail funds, black owned nonprofits)

Sign petitions

Engage in conversations with family & friends

Spread information about upcoming protests/gatherings

[[Abolish the police]] (related to #[[Defund the police]])

"I'm sick of all this"

Why are you prioritizing your desire for the "way things were" right now over the need for systemic change?

What about [[black on black crime]]?

"No one has said that crime between African Americans isn't a problem. The point is that blackness has nothing to do with it" - Jamelle Bouie, The Atlantic

We've had hundreds of years of forced ghettos and racial segregation. Kin lives with kin.

The vast majority of crimes are committed by a person the same race as the victim. White folks, especially poor white folks, commit violence against other white folks at equal or even greater rates than black folks

