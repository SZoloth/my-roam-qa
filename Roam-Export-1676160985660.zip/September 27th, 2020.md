[[Museum of Science]] [[Google Ads]] tracking issue

Resources

https://support.google.com/google-ads/answer/6331304?hl=en

`gtag_report_conversion`

It looks like the click listener may not have been installed directly on the button and was installed In the `<footer>` - though am not sure this is an issue.

On Google Ads, it __appears__ that conversions are working because there is one working example from [[September 22nd, 2020]]. However, one is lower than would be expected at this point.

Testing

Can't generate an ad to test right now (12:44)

It also kind of looks like the submission form isn't working anymore?

Nevermind, needed to update my email. It doesn't work if you've already submitted, though. 

The google tag assistant report is below

{{pdf: https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2F2CYCakoOaN.pdf?alt=media&token=830d4498-c0df-4640-ae0c-fa1a240f3ee5}}

Conversion ID: `AW-950831746`

Conversion label: `0hHACOTixqgBEIKVssUD`

The [landing page](https://info.eie.org/integrated-stem) has:

According to Tag Assistant:

Two gtag.js snippets

AW-950831746

One Google Ads Remarketing Tag

One Google Analytics tag

On the HubSpot CMS:

 In the `<head>`

```javascript
<!-- Global site tag (gtag.js) - Google Ads: 950831746 -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-950831746"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-950831746');
</script>

<!-- Event snippet for Google Ads - Website Leads conversion page
In your html page, add the snippet and call gtag_report_conversion when someone clicks on the chosen link or button. -->
<script>
  function gtag_report_conversion(url) {
    var callback = function () {
      if (typeof(url) != 'undefined') {
        window.location = url;
      }
    };
    gtag('event', 'conversion', {
      'send_to': 'AW-950831746/0hHACOTixqgBEIKVssUD',
      'event_callback': callback
    });
    return false;
  }
</script>
```

In the `<footer>`

```javascript
<script>
  document.onreadystatechange = () => {
    if (document.readyState === 'complete') {
      const submit = document.querySelector('input[type="submit"]')

      submit.addEventListener('click', function () {
        gtag_report_conversion('https://info.eie.org/integrated-stem')
      })
    }
  };
</script>```

[[gtm/Go To Market]] notes from [[Lenny Rachitsky]] #positioning

What are the key elements you think a GTM plan must include?

What market?

What segment of the market? Why?

What audience are you selling to? Why?

Which demand generation channels (paid/earned/owned/influencer/etc.) and why?

Who are the most important competitors and why?

If the (1) key-value props and (2) reasons to believe are part of the product positioning doc then that has already been covered

#positioning, and consequently messaging ('narrative') are also very much part of the GTM plan, and constantly evolving.

Biz [[model]] and core value (not to be confused with positioning which is an output)

Summary:

Prior to developing any sort of marketing plan, and hiring of a Marketing / Growth leader, the company has identified:

Core value and Biz [[model]]

Magic (product/brand experience)

The Market (who the product is for)

Acquisition (how they acquire customers)

Upon having these agreed to (and ideally documented) by the founding team and investors, the company can develop;

Positioning

Messaging documentation

GTM plan (current thread, built upon positioning and messaging documentation)

Work plan (spreadsheet/work to be done/task management/etc. based upon GTM plan)

[Today]([[September 28th, 2020]]) I will #[[🏔ADK [[Task Management]]]]

Work

{{[[DONE]]}} Resolve the **Museum of Science** tracking issue with [[darci nevitt]] and [[santiago correa]]

{{[[DONE]]}} Finalize the **Wasabi keywords** and send to client [[Wasabi]] #//

cloud storage pricing

Vol: 6700

Pos: 8

Target: 5

amazon s3 pricing

Vol: 3500

Pos: 15

Target: 10

cloud object storage

Vol: 250

Pos: 12

Target: 7

cloud storage

Vol: 5300

Pos: 57

Target: 10

cloud backup

Vol: 10000

Pos: >100

Target: 10

hybrid cloud

Vol: 5900

Pos: 89

Target: 10

multicloud

Vol: 6400

Pos: >100

Target: 10

{{[[DONE]]}} Meet around the [[Glenmede]] ecosystem with [[darci nevitt]] and [[Michelle Smith]]

{{[[DONE]]}} Edit [[Sleeping Dog Properties]] blogs from [[nick watkins]]



{{[[DONE]]}} Prepare for [[Meetings with [[chris baker]]]]

Personal

Run in the morning

Meditate in the morning

Exercise during the day

Preparing and Goal Setting #prompts from [[🌱 The Making of a [[Manager]]]]

How to assess your team & situation: [[team-development]]

Are processes efficient?

Are people getting along?

Is your team known for rigorous and high-quality work?

Is your team cagey about deadlines?

Are priorities always shifting?

Are there any inefficient meetings?

Is anyone on your team an asshole (even if they're a brilliant top IC)?

A quick outline for How to **deal with imposter syndrome**:

Identify growth areas in that environment that you feel weak in

Spend time honing those skills

To understand your own strengths and weaknesses

Self-evals

Quick exercise 1: ask yourself the following questions and jot down the first thing that comes to mind about your **strengths**

How would people who know and like me best (family, significant other, close friends) describe me in 3 words?

Eg - thoughtful, enthusiastic, driven

What 3 qualities do I possess that I am the proudest of?

Eg - curious, reflective, optimistic

When I look back on something I did that was successful, what personal traits do I give credit to?

Eg - vision, determination, humility

What are the top 3 most common pieces of positive [[feedback]] that I've received from my manager of peers?

Eg - principled, fast learner, long-term thinker

Quick exercise 2: ask yourself the following questions and jot down the first thing that comes to mind about your **weaknesses**

Whenever my worst inner critic sits on my shoulder, what does she yell at me for?

Eg - getting distracted, worrying too much about what others think, not voicing what I believe

If a magical fairy were to come and bestow on me three gifts I don't yet have, what would they be?

Eg - bottomless well of self confidence, clarity of thought, incredible persuasion

What are three things that trigger me (get me more worked up than it should)?

Eg - sense of injustice, idea that someone else thinks I'm incompetent, people with inflated egos

What are the top three most common pieces of [[feedback]] from my manager of peers on how I could be more effective?

Eg - be more direct, take more risks, explain things simply

How to Understand what helps you perform at your best

Which 6-mo period of my life did I feel the most energetic and productive? What gave me that energy?

In the past month, what moments stand out as highlights? What conditions enabled those moments to happen, and are they re-creatable?

In the past week, when was I in a state of deep focus? How did I get there?

Understand what gets in the way or triggers you

Set up habits that make it easier to operate in that ideal environment

How to **take care of yourself when you're feeling down**

Recognize that everyone in the world goes through hard times, and give yourself permission to worry. 

Conjure up a public figure you admire and google "[person's name] struggle"

Admit you're feeling bad. Take out a post-it note and write, "I am super stressed out about X." 

When a negative story takes hold of you, step back and question whether your interpretation is correct. Are there alternative views you're not considering? What can you do to seek out the truth?

Confront reality by asking about what's causing doubt (eg - "Why wasn't I invited to that meeting?")

Visualize

Imagine the anxiety, fear, and confusion you're feeling as not being personal to you, but universal things that everyone faces.

Imagine yourself succeeding wildly at something you're nervous about. Be as specific as possible.

Imagine a time in the past when you took on a hard challenge and knocked it out of the park. Be as detailed as possible.

Imagine a room full of your favorite people telling you what they love about you.

Imagine what your day would feel like if you were out of the Pit.

Ask for help from people you can be real with

Create a check in meeting with peers that you can discuss what you're struggling with. Meet for ~1 hour every month.

Celebrate little wins

Every day, jot down something you did that you were proud of, even if it was small. 

Set clear boundaries

Schedule a 15m activity at the beginning and end of the day that isn't related to work.

How to **develop a growth mindset** #[[[[High Agency]][[*]]]]

Approach challenges with the belief that you can get better at anything by putting in the effort

Re-frame your reaction to scenarios

Eg - Getting suggestions for improvement

Fixed mindset: I messed up and my manager thinks I'm dumb

Growth mindset: I'm thankful my manager gave me those tips. Now I can make my future assignments better

Eg - Asked to take on a risky and challenging new project

Fixed mindset: I should say no - I don't want to fail and embarrass myself.

Growth mindset: This is a great opportunity to stretch, learn something new, and gain the experience needed to lead more big projects.

Eg - You've just had a tense 1-1 with a direct report

Fixed mindset: I should act as if that went well so I come off like I know what I'm doing.

Growth mindset: I should ask Alice how she felt about that conversation and how we might have more productive discussion in the future.

Eg - You're in the middle of working on a proposal, and your manager asks to see your progress.

Fixed mindset: I don't want to show anything right now b/c the proposal is in rough shape. It'll make me look bad.

Growth mindset: The [[feedback]] will be really helpful. In fact, I should share my early thinking with even more people so I can get ahead of any potential issues.

Set aside time to reflect and set [[Goals]] #self-development

Schedule an hour on my calendar at the end of every week to think about what I accomplished, what I'm satisfied or dissatisfied with, and what I'm taking away for next week. Then jot down some notes in an email to my team.

Examples

Recent [[feedback]] I heard

Recruiting for next year

Strategy for Project X

Understanding research needs

Set personal [[Goals]] and do bigger look-backs every six months.

Examples

Build out my bench

Evolve processes

Become an expert in hiring great team members

Don't bring work home with me

Reflect by asking

If you didn't succeed: Why? Was it a tactical or communication failure?

If you did succeed: What allowed me to be successful? What would you allow me to make this an even more ambitious goal? What tips might I give to someone else looking to do the same thing?

Exercise: Every January, map out where you hope your team will be by the end of the year. 

Create a future org chart

Analyze gaps in skills, strengths, experience

Make a list of all open roles to hire yourself

Ask yourself:

How many new people will I add to our team this year based on growth, attrition, budget, priorities, etc.?

For each new hire, what level of experience am I looking for?

What skills or strengths do we need in our team (eg - creative thinking, operational excellence, expertise in XYZ, etc.)?

Which skills and strengths does our team already have that new hires can stand to be weaker in?

What traits, past experiences, or personalities would strengthen the diversity of our team?

[[How to define a purpose]] #[[How to Manage Others]] #team-development #OKR

The purpose should be a **tangible** vision that your team is collectively trying to achieve #[[How to define a purpose]]

From [Fortune article](https://www.instapaper.com/read/1313304971/13148894) on [[charisma]] applied to your vision:

No doublespeak or jargon #[[orit gadiesh]]

Make it emotional and brief

Use symbols, analogies, metaphors, and stories

It should be measurable

It doesn't describe __how__, instead it describes the end state, the goal

Assume everything your team does goes perfectly. What will be different in 2-3 years compared to now?

How would you want someone who works on another team to describe what your team does?

What do you hope will be your teams reputation in a few years? How far off is that from today?

What unique superpowers does your team have? What would it look like for your team to be 2x as good? 5x as good?

What is a quick litmus test that anyone could use to assess whether your team was doing a poor, mediocre, or kick-ass job?

If you have 3 [[Goals]] for your team this half, force yourself to answer: "If I could only achieve one goal, what would it be?"

How to tell if your team is executing well #[[How to Manage Others]]

List of projects are [[prioritize]]d from most to least important and tackled in that order

There is an efficient decision-making process that everyone understands and trusts

The team moves quickly, esp. with decisions that are reversible

After a decision is made, everyone commits to make it happen efficiently 

There is an expedient process to process new information and decide if and how current plans should be adjusted

Every task has a __who__ and a __by when__

Owners set and reliably deliver on commitments

Every failure makes the team stronger because they don't make the same mistake twice

[[How to define your team's culture]]

Take about 60m to answer the following questions

**Understanding your current team**

What are the first 3 adjectives that come to mind when describing the personality of your team?

What moments made you feel most proud to be a part of your team? Why?

What does your team do better than the majority of other teams out there?

If you picked five random members of your team and individually asked each person, "What does our team value?" what would you hear?

How similar is your team's culture to the broader organizations culture?

Imagine a journalist scrutinizing your team. What would she say your team does well or not well?

When people complain about how things work, what are the top three things that they bring up?

**Understanding your aspirations**

Describing the top 5 adjectives you'd want an external observer to use to describe your team's culture. Why those?

Now imagine those five adjectives sitting on a double-edged sword. What do you imagine are the pitfalls that come from ruthless adherence to those qualities? Are those acceptable to you?

Make a list of the aspects of culture that you admire about other teams or organizations. Why do you admire them? What downsides does that team tolerate as a result?

Make a list of the aspects of culture that you wouldn't want to emulate from other teams or companies. Why not?

**Understanding the difference**

On a scale from 1-9, with 9 being "we're 100% there" and one being "this is the opposite of our team," how close is your current team from your aspirations?

What shows up as both a strength of your team as well as a quality you value highly?

What are the biggest gaps between your current team culture and your aspirations?

What are the obstacles that might get in the way of reaching your aspirations? How will you address them?

Imagine how you want your team to work in a year's time. How would you describe to a report what you hope will be different then compared to now?

