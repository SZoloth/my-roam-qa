Author:: [[singular.net]]

URL:: https://www.singular.net/blog/skadnetwork-support/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

If SKAdNetwork is enabled in an app, the App Store will now receive attribution parameters when it’s opened due to a click on an ad. Then, if this click results in a conversion — an app download — iOS itself will send a postback accompanied by those attribution parameters. 

(And, potentially, some important post-install conversion data, which we’ll cover later.) 

This may sound somewhat similar to Google’s Play Referral mechanism, but what makes SKAdNetwork privacy-preserving is the fact that the attribution parameters cannot contain any device IDs or personally-identifying information. 

In addition, the install postback is sent by the operating system itself, and not by the installed app. As such advertisers will know that an install has happened, but they won’t be able to connect a specific install with a specific device, thus preserving privacy. 

In other words, marketers can now get data on which publisher drove which install. That’s critical: now we can provide publisher-level [[insight]]s to marketers. 

In addition, Apple also added limited support for post-install tracking with their new updateConversionValue and registerAppForAdNetworkAttribution methods. 

Currently, marketers have two main sources of data for measuring marketing campaigns:

From MMPs: metrics on installs and post-install cohorted metrics
From ad networks: metrics on impressions, clicks, video-views, spend 

Instead of apps sending postbacks to Singular, now Apple will be sending install postbacks to ad networks whose ads caused the app install. These postbacks include information about the install that is cryptographically signed by Apple, and can be verified using Apple’s public key. 

Whereas previously MMPs collected all the data they needed, now iOS advertisers will need to collect all install postbacks (and any post-install conversion data) from every ad network they run campaigns with. Plus, advertisers will need to validate these postbacks, store them, [[translate]] the attribution parameters to human readable data, and then connect it to campaign spend data to determine return on ad spend. 

