[[Meetings]]: Agenda for [[ADK marketing summit]]

Attendees:: [[chris baker]]

Time:: 10:09

Notes::

State of the state - 

Positioning, Revenue

Ultimate goal: find ways to increase the marketing 

We couldn't be a product company without these skill sets and areas

What are these skill sets and areas

[Agenda](https://docs.google.com/document/d/1mExjqfgXSFfJgxOhVH6kazirZDmfky-22HvH_07l72I/edit?ts=5f621d97)

[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} For [[Drawbridge]], begin to jot down notes on user personas #/

Demographics/ethnographics, behaviors, motivations

[Example](https://docs.google.com/presentation/d/1vgZhLI01i3au2lAAJq1MYNsF1clwVv_RPwa19iog_gc/edit#slide=id.g6f55e8001e_0_125)

{{{[[DONE]]}}}} How do we test for [[React SEO]] websites? #/

[[International SEO]]

{{[[DONE]]}} Audit marketing team and self in prep for [[ADK marketing summit]] #/ #team-development #self-development

# Questions from Chris

## **What are we best at as a marketing team? **

Marketing

**SEO**: audits, strategy, keyword research, technical SEO

**Content**: audits, strategy, information architecture

**Analytics**: audits, strategy, implementation, reporting

**CRO**: setting up a/b tests on websites

## **What are we worst at?**

**Creative**: Copy, concepts, and strategy

**PPC engagements**: 

But this may just also be: non-focused or ambiguous engagements. Meaning, ones where the client hasn't defined the channels, investment, or creative strategy. 

**Process**: Making sure we don't repeat mistakes, capturing repeatable processes, setting up systematic [[feedback]], possibly team learning. 

## **How can we as a marketing team best contribute to the growth of ADK as a whole?**

### **Ensure existing processes are meeting standards**: (not an OKR)

All websites/web apps will meet a high standard of SEO and Analytics performance as defined, enabled, and tested by the marketing team.

All apps will follow a standardized implementation of Analytics.

These processes will be memorialized, maintained, and presented by the marketing team.

**What does this look/feel like?**

Every website or app SEO/analytics engagement will be as smooth and "high margin" as a Quest Diagnostics Metadata report

Everyone on the team knows exactly what needs to be done and can execute it quickly.

Example deliverables:

Finalized SEO and Analytics launch checklists

Ticket templates

Estimating framework

**Areas of focus:**

Nail down basics, document process, work into PM flow

Basics = what's included in boilerplate SOW and testing

Define approaches for SEO & Analytics with React

**How does this help the growth of ADK? **

Ensures our websites and apps fulfill the promises our sales assets make, delights customers with a truly one-stop-shop for every part of creating a new or updating an old web site/app.

Reduces errors, makes projects more efficient.

### **Develop the A/B Testing / CRO package**: (potential OKR)

What tools, investment, and steps are involved? What is the strategy/focus and when is it appropriate?

**What does this look/feel like?**

Sales/project managers know when/how to pitch this (and when not to)

Team knows how to set up tests and present findings

A truly agile testing process that is more efficient than just building the product/feature

Example deliverables

Pitch deck

Estimating framework

Step-by-step process captured in Confluence

www.thesistesting.com 

**How does this help with the growth of ADK?**

Provides a framework where clients basically pay us to come up with and test new work (that hopefully we'll need to implement)

Helps extend engagements

### **Develop the new product GTM plan**: (potential OKR)

A bundle of tools and process that can be sold to bring new products to market.

We set up scalable systems for growth, launch your product, then set up your marketing team for continued growth

A framework for what the goal should be how we should meet it.

Metrics for each stage of AAARRR, how we meet them, how we measure them

Set up martech stack, and launch strategy, where to spend $50k

Pricing

Services?

Research? What do we **need** to know to effectively launch?

Define who we're doing this for, what their needs/pain points are

Look at: Firefly, Form Health

### **Develop and promote thought leadership ** (not an OKR)

Ensure we're steadily producing and promoting strategic content that positions ADK as the premier end-to-end digital product shop.

Examples:

Mirror the design blog output with dev, analytics, SEO, strategy, etc.

## **Why should clients hire ADK for marketing vs. other firms? Let's each write an aspirational 2 sentence elevator pitch.**

ADK is the best place to go to launch your new product to market. Our process gives you an early-stage marketing team in a box, with everything you need to start getting new users, hitting milestones, and scaling.

## **How can I personally best impact the marketing team's ability to grow ADK?  **

[[translate]] SEO/analytics info from inside my head into processes

Go deeper on product analytics

Go deeper on product / growth strategy

The marketing team will be better able to grow ADK if:

I can help make our current SEO and analytics process more complete and efficient.

I can help define our GTM/Launch offering so that we have profitable marketing engagements.

I can apply our SEO/content expertise to our own site so that we can escape founder-led growth.

## **What are my biggest personal opportunities for growth?**

Process

Focus/prioritization

Increase my leverage by focusing on strategic decisions and direction setting

Define a repeatable GTM/launch process for new products

Increase cross-functional understanding and skill around SEO/analytics

## About [[OKR]]s

## **What are OKRs?**

In a nutshell: A high-level **objective** that is aligned to both team and company [[Goals]] and the 3-5 **key results** that help achieve that goal that get set and reviewed every quarter

You can think of it as shorthand for the phrase "We will achieve __X objective__ this quarter as measured by the following __key results__..."

They are stretch [[Goals]].

**They have to be a stretch.** Most people wouldn’t consider 70% to be a good grade, but for OKRs that’s just about perfect, Davis says. You want your objectives to be ambitious enough to push you beyond your limits. When everyone does this, it forces the tough conversations about what's truly needed to beat expectations." [12](https://firstround.com/review/How-to-Make-OKRs-Actually-Work-at-Your-Startup/)

History

[[John Doerr]] worked at [[Intel]] and learned the framework from [[andy grove]] and then tweaked it.

Intel pivoted in the 80s from memory using OKRs

[[John Doerr]] works as one of the most prominent VCs at the firm Kleiner Perkins

He took Grove's system and refined it into OKRs, which were tailored to meet (and adopted by) portfolio companies like Amazon, Intuit, and Google.

### **What are** __objectives__?

The objective helps define __what__ we will achieve.

Objectives should be FAST: Frequently discussed, Ambitious in [[scope]], measured by Specific metrics or milestones (key results), and Transparent for everyone in our organization.

Objectives should be ambitious but achievable

If you achieve less than 70% of your key results, it may not have been acheiveable.

If you're achieving 100% of your key results, your [[Goals]] may not be ambitious enough.

They help define the [[North Star]] metric/OMTM/KPI.

They are, well, __objective__ (rather than subjective)

They align with ADK's Values (as tested by asking, "Is this objective supportive, neutral, or contradictory to our values?")

Be humble

Always with integrity

Team first

Better everyday

Embrace diversity

Commit to quality

Have fun

Show grit

### **What are** __key results__?

The key results define __how__ we'll measure success of the objective.

### **What OKRs are** __not__:

A source for performance [[feedback]] or compensation review.

KPIs 

KPIs should happen consistently every quarter, where OKRs are initiatives that are being focused on this quarter, specifically.

## **Why are we using OKRs?**

They have four super powers: focus, alignment, tracking, and stretch.

They are a [repeatable system that helps you create a focused hypothesis, measure progress towards it, set a forcing function, and feed learnings back into the first step](((7YO1W9OmF))).

They let you track results on a quantitative basis 

**The ability to track results on a quantitative basis.** Key results are not general or subjective actions you plan to take. They should always include numbers to make it clear how much has been achieved. For example, if Mary’s objective is to improve her sales prospecting skills, one key result might be to spend two hours a week shadowing Jennifer, the team member who demonstrates the most prospecting success.

They help build the muscles of:

Setting ambitious [[Goals]]

Setting measurable results

Aligning with other groups

Accountability

They discourage [sandbagging](((pf6nMPtrs)))

sandbagging (setting [[Goals]] intentionally low so you can hit them easily)

They help connect __motion__ to actual __business objectives__

## **How do we use OKRs?**

The should be looked at every quarter, every week, every day. 

**Make it something people look at, every quarter, every week, every day.** This consistency turns goal-setting into a habit and changes how people think about their work and approach their everyday to-dos. “It puts in place natural milestones that make you think about what you need to do next and aim high.”

Consistently and right or not at all.

### **How should we [[prioritize]] OKRs?**

OKRs don't replace or supersede core responsibilities or performance indicators.

They are expected to be completed unless you have higher priority work that is surfaced and agreed to by leadership.

Functionally, we can use JIRA where epics = objectives and issues = key results.

### **What's the process like?** ^^WIP^^ 🚧

**Five Mondays** before the start of a new fiscal quarter, the OKR process is kicked off with two meetings.

In the first meeting, the Marketing Team meets to generate the OKRs for the Marketing Team in the upcoming quarter. The team should aim for a maximum of 3 Objectives, and each Objective should have between 1-3 Key Results

In the second meeting, the Marketing Team presents the team's OKRs to the VP of Strategy.

The following week, **four Mondays** before the start of the fiscal quarter, the Marketing Team meets to tie individual Objectives to each team Key Result



### **What happens during the quarter?**

During 1:1s with your manager you should go over the following for the team and individual OKRs:

Completion status

Health score

Key achievements

Risks or dependencies in need of discussion

## **How do we set an **__objective__**?**

**Brainstorm:** Based on our team or company's [[North Star]]t or Mission of _____, what are the most important things to get done?

What do we need to start doing or changing?

What does success look like?

**[[prioritize]]:** If we've ended up with more than 3, we need to [[prioritize]] down to the top 3.

**Review:** See if you can confidently say these statements are true about all the objectives you wrote:

My objective describes meaningful change from where we are now. 

My objective is concise and uses simple [[language]]. It will inspire my team.

It will be obvious to anyone in our org whether an objective has been achieved.

### Tips for setting **objectives**: #OKR 

**Pick just three to five objectives** - more can lead to over-extended teams and a diffusion of effort.

**Avoid expressions that don’t push for new achievements**, e.g., “keep hiring,” “maintain market position,” “continue doing X.”

Use expressions that **convey [[endpoint]]s and states**, e.g., “climb the mountain,” “eat 5 pies,” “ship feature Y.”

Use tangible, objective, and unambiguous terms. **It should be obvious to an observer whether or not an objective has been achieved**. Research shows more specific [[Goals]] can result in higher performance and goal attainment. 

## **How do we set** __key results__**?**

**Review:** See if you can confidently say these statements are true about all the key results you wrote:

They express measurable milestones, which, if achieved will advance objective(s)

They describe the [[outcome]] __not the activity__.

Rather than using words like "consult," "help," "analyze," or "participate," describe the end-use impact of those activities.

They must include evidence of completion that is available, credible, and easily discoverable.

Eg - change lists, links to docs, notes, and published metrics reports.

Achieving each KR 100% most likely results in the Objective being achieved.

Key results need to be quantifiable and tied to a specific [DRI](((cUWm01U4H)))

Directly Responsible Individual

## Draft [[OKR]]s

### **Team**

O: By the end of Q4, all Marketing engagements are profitable

KR: 

### **Self**

O: Sell the GTM/Launch process to at least one new client

KR: Publish strategy and offering in Confluence

KR: Publish sales/marketing materials (pitch deck, "battlecard," landing page)

KR: Pitch services in a new engagement 

## Other questions to consider

How to assess your team & situation: [[team-development]]

Are processes efficient?

No

Are people getting along?

Yes

Is your team known for rigorous and high-quality work?

No

Is your team cagey about deadlines?

A little bit

Are priorities always shifting?

Yes

Are there any inefficient meetings?

Yes

Is anyone on your team an asshole (even if they're a brilliant top IC)?

No

This sounds obvious but can be hard to do in practice. As a litmus test, ask yourself this: Imagine that your team is wildly successful in three years. What does that look like? Write down your answer. Now, turn to your neighbor and ask him or her the same question. When you compare your answers, how similar or different are they? #team-development

[[How to define a purpose]] #[[How to Manage Others]] #team-development #OKR

The purpose should be a **tangible** vision that your team is collectively trying to achieve #[[How to define a purpose]]

From [Fortune article](https://www.instapaper.com/read/1313304971/13148894) on [[charisma]] applied to your vision:

No doublespeak or jargon #[[orit gadiesh]]

Make it emotional and brief

Use symbols, analogies, metaphors, and stories

It should be measurable

It doesn't describe __how__, instead it describes the end state, the goal

Assume everything your team does goes perfectly. What will be different in 2-3 years compared to now?

How would you want someone who works on another team to describe what your team does?

What do you hope will be your teams reputation in a few years? How far off is that from today?

What unique superpowers does your team have? What would it look like for your team to be 2x as good? 5x as good?

What is a quick litmus test that anyone could use to assess whether your team was doing a poor, mediocre, or kick-ass job?

