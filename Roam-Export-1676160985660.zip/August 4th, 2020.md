[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Remove Liberty Mutual from website and ads

{{{[[DONE]]}}}} Update [[Dan Tatar]] on [[Google Ads]] #ADK

Drupal lead in email, conversions

[[[[Google Ads]] for #ADK]]

{{{[[DONE]]}}}} Finding a writer

General notes

Rejection letter

Hey {{Name}}
I really appreciate you reaching out about writing for us and for your patience. After reviewing the samples, the team felt there wasn't a strong enough overlap with what we're looking for. I hope {{personal note}}

Tasks for finding a writer revisit [[August 5th, 2020]]

{{{[[DONE]]}}}} Growth Machine response

{{{[[DONE]]}}}} Review [[Emma Westley]]s writing for ADK writer position

{{{[[DONE]]}}}} Review [[Seb Abecasis]]s writing for ADK writer position

{{{[[DONE]]}}}} Send rejection slacks [[August 5th, 2020]]

{{{[[DONE]]}}}} Post on LinkedIn

Quick favor to ask - If you know of anyone who is a strong writer please shoot me a message!

We're looking for someone to work with our content team and help tell the story of ADK, our team, and our partners. 

{{{[[DONE]]}}}} Ask [[heather mccormmack]]

Hey Heather - We're still looking to bring in a writer (on a contract basis for now) to help ramp up ADK content production. I've never sourced/recruited/hired before and I'm wondering if you'd be able to help -- if you were trying to do this what would you do? 

{{{[[DONE]]}}}} Ask the ADK team

Hey all! We're looking for a writer to help our team ramp up ADK content production and tell the story of ADK, our teammates, and our partners. If you know anyone that could be a good fit, **please** send them my way! 

Ideation session with Chris: {{{[[DONE]]}}}} Find some time with [[chris baker]] in [[August 3rd, 2020]] to brainstorm on broader [[ADK Marketing Strategy]] #///

{{{[[DONE]]}}}} Create cadence for ideating-testing-learning in Google Ads [[Google Ads Optimization]]

{{{[[DONE]]}}}} Every two weeks present on ADK Google Ads: [[[[Google Ads Optimization]] Log]] [[[[Google Ads Optimization]] Log]]

{{[[DONE]]}} Build the marketing team and process #///

{{[[DONE]]}} Define the team #///

Content

Google Ads

Retargeting

{{{[[DONE]]}}}} Set up the PM process #[[ADK Marketing Project Management]] #//

{{{[[DONE]]}}}} Review Matter PR email #[[email inbox]]

{{{[[DONE]]}}}} Schedule time for HBS [[[[ADK]] case studies]] with [[Tim Lupo]] and [[Jill Starett]]

