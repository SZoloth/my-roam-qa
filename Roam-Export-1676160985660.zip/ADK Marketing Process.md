Sources:: [Demand Curve docs](https://drive.google.com/drive/u/1/folders/1rZxZSdNGam2An5bzFoJU3QA_9_kjqZRU),[ Dropbox paper notes](https://paper.dropbox.com/folder/show/Demand-Curve-e.1gg8YzoPEhbTkrhvQwJ2zznJMj9BglL7IdANqy1XGfbxHVaEs8Qq)

Tags:: #[[Inspiration for ADK]] #[[Selling ADK Group]]

Processes

Need definition::

{{[[DONE]]}} E-A-T https://trello.com/b/FiHXRDxe/e-a-t-factor-checklist-template

[[ADK Marketing Process]] with [[Project Management Process]] #[[ADK To Do]]

{{[[DONE]]}} Need ticket templates #///

{{[[DONE]]}} React SEO checklist #///

{{[[DONE]]}} React analytics checklist #///

{{[[TODO]]}} #[[writing ad copy]] -- is this in confluence already?

[[ADK SEO Process]]

[[ADK A/B Testing Process]]

https://uploads-ssl.webflow.com/5e18e3e9778ad828555e0ee1/5e4ab2faccb4f200a5a11b4a_Optimization-and-Innovation-eBook-FINAL.pdf

https://docs.google.com/document/d/1EHjWBDp1FVhvcW2PSGZ05AwA7jDaLWbcykSeRbi1WvM/edit#heading=h.g0i4f5k0v7vc

https://docs.google.com/document/d/1czawJmSOf4bqny16Ga5wO0hx3AmP5UUAQLDdVtJyTio/edit

Reading from [[Demand Curve]]

{{[[TODO]]}} Surveys

{{[[TODO]]}} Conversion

How do we loop in a PM?

{{[[DONE]]}} [[ben kaplan]], coming out of this, our goal is that you can create a project plan for this campaign with inputs from Sam who will be leading strategy and implementation [[May 21st, 2020]] 



