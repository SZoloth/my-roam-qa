# **Metadata**

**Author:** [[andrew chen]]

**Source:** https://growth.segment.com/videos/0/

# **Notes**

[[Dropbox]]

Grew bottoms up (relates to [[Consumer SaaS Growth: Clockwise]])

Wasn't growing organically in the early stages

Had amazing retention b/c the product was good, but it was single player

Until they added folder sharing, which helped explode it

Folder sharing + [[referral]] program = growth

[[Growth marketing[[*]]]] is about: having a strong hypothesis about the growth in your product happens

mapping it out

measuring and optimizing

It's [[[[system]] thinking]]

[[Growth marketing[[*]]]] at [[uber]]

Scale: signing up about 3% of the population / year and spending >$2bn

don't look at [[KPI]]s until you've focused on a strategy or system

Manage $2bn in spend

Key to [[Growth marketing[[*]]]] is understanding the quantitative [[insight]]s ([[tactics]]) and [[qualitative]] strategies

Understand the steps from low engagement to high engagement then create growth teams at each step

[[a/b test]]ing at [[B2B]] companies for the product, should be at account level

[[atrium]] #[[Growth marketing[[*]]]]

[[justin kan]]

marketing like [[Segment]] - #content marketing, events, publishing books

[[viral loop]]

the steps a user goes through between entering the site to inviting the next set of new users

