Author:: [[medium.com]]

URL:: https://medium.com/@HubSpot/an-inside-look-at-hubspots-enterprise-marketing-playbook-5bce78be586d

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

within our content strategy, we have two sub-strategies — one that is all about getting found through search (our “SEO strategy”), and another that aims to change minds through opinionated content that spreads through word-of-mouth and social engagement (our “POV strategy”) 

One team is focused on optimizing informational content to spread through search, and the other is tasked with creating influential content to spread through word of mouth. 

To perform well across all of these areas, we have adopted a diversified search-geared content strategy that comprises long-form educational content, shorter content optimized for snippets, pillar pages, YouTube optimization, and audio courses. 

Breaking through with a strong point of view starts with having a clear brand identity, sharpening that identity through thoughtful product positioning, and then bringing it to life with strong messaging and complementary creative execution. 

When a message strikes a chord with an audience organically and earns above-average social engagement, we catch it early and amplify it through ad spend. 

Transactional ads — these ads generate HubSpot software users
Informational ads — these ads grow our content leads
Awareness ads — these ads drive content views and website visits 

For established products that already have some search demand, we spend most of our digital ad budget on transactional ads, but we have thresholds for both direct and assisted returns on ad spend 

For new launches and lesser-known products, we flip that playbook. New products have lower brand recognition in the market, so the cost of transactional ads is far higher. So, we first invest in brand awareness, and as our direct and assisted returns on these ads begin to reach our thresholds, we put that budget behind transactional ads. 

Empower customer advocates to talk about our business on review sites and through word-of-mouth 

Today on our pricing page visitors are given multiple ways to connect — they can book meetings, email, call, or chat. 

We’ve united marketing, sales, and service under a single chief customer officer, run UX sessions to find friction in our product and sign-up process, and released the customer code. 

we are intentional about finding and empowering our most successful customers to advocate on our behalf through reference programs, review sites, and event participation. 

HubSpot: No surprises here, we have built our entire system on the HubSpot platform. That includes everything from CRM and marketing automation to data enrichment and helpdesk. All HubSpot. We also take advantage of many of the powerful integrations available with HubSpot to customize our strategy.
Advocately: for enabling customer advocacy
[[ahrefs]]: for advanced SEO tools
[[airtable]]: for content tracking and tagging
Bizzabo: for event management
Canva: for scaling design globally
GitHub: for developer project management
Invoca: for inbound call tracking
Memoq: for [[translation]] and localization
MoveableInk: for dynamic email content
OneTrust: for privacy and compliance
PieSync (acquired by HubSpot): for two-way data syncing across our platform
Usability Hub: for UX
Vidyard: for video marketing 

