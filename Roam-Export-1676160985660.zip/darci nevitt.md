Tags:: #[[management]][[*]] #[[LMT Managing]] #[[🌱 The Making of a [[Manager]]]]

# OKRs

# Goals

# Wins

[[[[wins]] in [[2022]]]] for [[darci nevitt]] #hype

# Managing Darci

For Darci

{{[[DONE]]}} **Share [[feedback]] about what's going well or not**

Eg - time to produce [[ADK Drupal Campaigns]] report and letting me know when it's done

Own up to not expressing clear expectations earlier - that's what I need to work on

Share that this is a great opportunity to work on that - being more clear in my expectations. What I hope from you is that if you feel like you won't be able to complete something in the time given, you'll reach out to me so we can make necessary adjustments and keep people updated

Did this resonate with you, seem to come out of left-field, or something else?

Link back to [[National Speed]] tasks

{{[[DONE]]}} Check in on [[career]] [[Goals]]

{{[[TODO]]}} Ask about processes / tasks she's completing that feel inefficient or confusing

{{[[TODO]]}} Ask about strengths and weaknesses - has that changed?

# Strengths

Thoughtful approaches 

Determined learner

# Weaknesses & Challenges

Building confidence to connect with and manage up people more senior

Working with new people

Ambiguity

Staying productive

# Motivations

Solving problems

# [[[[1:1s]] with [[darci nevitt]]]]

Feels good to

Dig into reports

Set up events and test them

Site audits + then adjusting CMS

learn new things and problem solve

## [[Goals]]

Become a "go to" expert for analytics

# [[annual review]]s

for [[2020]]

Agenda

15 mins - What went well this year and what didn't (in your words)

15 mins - Peer [[feedback]] and performance review discussion

15 mins - 2021 Company OKR discussion and personal OKR setting

Gathered [[feedback]]

[[Peer [[feedback]]]] from [[Bridget O'Brien]]

I'm so sorry I'm late with this! I outlined my responses on Darci below. I just wanted to say in addition to what I wrote below, Darci is so great to work with. I truly love working with her, and she works incredibly hard on any task I pass her way. When I get an opportunity to collaborate with her on a project I always look forward to it because I know she's great to bounce ideas off of, and will always execute above expectations. High level summary, I'm a big Darci fan.

1. What are 2-3 things Darci should start doing? Why?

**One thing I think Darci could start doing is not holding back when a client doesn't have the best idea for a campaign, SEO related initiative, etc. This is an area I think everyone has to work on including myself, but often we get requests from clients that don't always make the most sense or they think it will benefit them. **However, it's our jobs to be the source of knowledge and step in and respectfully recommend a different alternative that will bring them more success in the long run vs. a quick immediate win. For example Yottaa keeps coming back to LinkedIn campaigns, and the most recent one would truly succeed a lot more as a Google AdWords campaign vs. LinkedIn but I think Darci wasn't sure if she should speak up and say that to the client when we were reviewing how limited the targeting was on LinkedIn. We eventually brought it up on the call, and they did like the idea of starting an Adwords campaign around this initiative but I think if we had expressed that upfront before showing them available audiences for LinkedIn they may have wanted to throw all their budget elsewhere. This is something I need to work on as well, but I think **reassuring Darci in her judgement and knowledge to build her confidence level some more would help her feel more open to making these suggestions to a client.**

2. What are 2-3 things Darci should continue doing? Why?

One thing Darci does that always wows me is **how she presents herself, and the data on client calls. She is always calm, cool, and collected and if she is ever thrown something she doesn't know the answer to she handles it gracefully, and always follows up.** Clients love her as well, she does a great job of breaking things down in a way the client will understand. SEO can often be a foreign subject for some clients, but the way she explains it makes them understand, and feel more confident in the process. I always look forward to jumping on client calls with her, because she knows where to pick up where I left off, and we're always able to keep a flowing conversation going with the client. I appreciate all of Darci's teamwork, she is great to collaborate with!

3. What are 2-3 things Darci should stop doing? Why?

I don't think I have any [[feedback]] here, Darci always does a great job. The only thing I could maybe apply here is similar to my **suggestion in #1 to not take client requests exactly as they come**, and feel free to customize it in a way that makes sense for both the client's [[Goals]] and success of the campaign/site.

[[Peer [[feedback]]]] from [[nick watkins]]

**What's one thing this person should keep doing more of?**

Learning.

Darci is one of the quickest learners I've ever worked with, and she has a genuine desire to always learn more, do better, and expand her skillsets.

She also takes initiative to learn - that is, she doesn't just wait until she's pulled into a new project and given a random task.

She's proactive and wants to learn more about every aspect of digital marketing that she can, often asking me questions about my content-writing process even though she doesn't write content herself.

She's just genuinely curious and passionate about learning more, and that is an admirable trait she should definitely keep doing more of.

**What's one thing this person could do differently to have more impact?**

Knowing when to ask for help.

I feel like this is almost the flipside of Darci's constant desire to learn more, as it can lead to her being overwhelmed with work and in need of assistance, but reluctant to ask for it.

There have been several times when I've talked to Darci well after regular work hours to find that she's still trying to get something finished, and I feel like that stresses her out and, as a result, might impact the ultimate quality of her work.

I learned a long time ago that there's no shame in asking for help or raising your voice when you feel overwhelmed - after all, we're all a team and we're all here to support each other. I think Darci could have a more positive impact as a team member by not being so shy about speaking up and reaching out for some aid when she needs it.

[[Peer [[feedback]]]] from [[jordan daly]]

**What's one thing this person should keep doing more of?**

Keep Learning and Growing - This has been her biggest strength of the last year and I would love to see her continue her growth. She learns things pretty comprehensively, and quickly.

**What's one thing this person could do differently to have more impact?**

Have confidence in her output. She is producing stellar work, and I think if she recognized that or was reminded of that more, then she would be super effective. Trust herself, trust her instincts. I trust her.

[[self evaluation]]

Called out EiE + MIT PEL

Proud of

Framework creation and process definition

Work on

Reporting - translating data into a story

Values

Embodied: always with integrity + team first

Agree - worked late hours to ensure your deliverables were met, don't make excuses, etc.

Work on: better every day + have fun

Agree with have fun. Not necessarily better every day - I see a desire and progress jamming 

Template

Current role:: Digital Marketing Associate

Rating:: Meets expectations

Accomplishments::

MIT PEL analytics ownership

iMercer analytics ownership

Earned more business from MoS

Defined Clear[[scope]] process 

GTM for Major Decision

Peer [[feedback]]::

One thing Darci does that always wows me is **how she presents herself, and the data on client calls. She is always calm, cool, and collected and if she is ever thrown something she doesn't know the answer to she handles it gracefully, and always follows up.** Clients love her as well, she does a great job of breaking things down in a way the client will understand. SEO can often be a foreign subject for some clients, but the way she explains it makes them understand, and feel more confident in the process. I always look forward to jumping on client calls with her, because she knows where to pick up where I left off, and we're always able to keep a flowing conversation going with the client. I appreciate all of Darci's teamwork, she is great to collaborate with!

Learning and growing

Superpower::

^^Learning^^?

She had struggled with this a lot early on. But she did end up picking things up. 

Embrace it - accept the messy beginnings. 

You're trying something new. Have you ever skiied before? How do you expect it to go?

Thinking about processes?

Eh

Resilience

High-level [[feedback]]::

You joined full time about a year ago. And even though I tried to describe what it'd be like, there was no way for me to do it justice because it was so vague. We're a growing company and where we are today is radically different from where we were when you got hired. And I think that's an incredibly difficult environment for a first working experience - it's similar to a startup, and those are stressful. 

But you've been able to learn about analytics enough to set up a complicated use case for MIT, and work to fix a behemoth consulting agency's analytics (Mercer). You picked up best practices for content creation and produced our playbook for developing content that performs using a new tool. And you went from 0-60 on client presentations.

This cycle you've had those highs, but also some poignant times of struggle that held you back from truly excelling. For 2021, thematically, we need to work together to help you overcome self-doubt + trust yourself more. 

Development area 1:: Learning / leaning on others

Summary::

Concrete examples and peer [[feedback]]::

Concrete suggestions::

What wild success in this area looks like::

Development area 2:: Beyond execution

Summary:: Example: executing reporting would be listing the numbers. Going beyond would be painting the story + providing recommendations. 

Concrete examples and peer [[feedback]]:: MoS

Concrete suggestions::

What wild success in this area looks like::

Potential next role:: eh

Potential timeline:: eh 

for [[2021]]

Gathered [[feedback]]::

[[Peer [[feedback]]]] from [[jordan daly]]

Keep

Keep steamrolling when you see something to fix/do/create.

Start

Calm down - don't stress yourself out if you don't have the answer.

Rating

Exceeds Expectations

Other comments

Darci is a valuable asset to our team, and watching her growth has been amazing and motivating. She is truly taking more ownership, accomplishing more, and learning at a really fast pace.

[[Peer [[feedback]]]] from [[chris skoglund]]

Keep

Darci and I worked on a few analytics projects and even though they were challenging, she was wonderful to work with. Her and I both have very different areas of expertise. I learned a lot from her, she was patient, and we were able to bridge the gap and solve some difficult problems. She's excellent at communication -- both internally and with clients. She has a great attitude, and she was as excited to learn about the dev side of things as I was to learn about the analytics.

Start

She's very good at explaining analytics in ways that are both developer and client friendly. I was fortunate enough to have the opportunity to work with her this year, but I'd love to see her take that to larger dev org. Whether it's a presentation, workshop... typically, for devs, the only way we interact with analytics is adding a snippet to a codebase. This is an area I think could benefit from some cross-department training, and I feel Darci would do a great job leading this initiative.

Rating

Exceeds Expectations

Other

Exceeds expectations -- took on some very challenging projects this year (Mercer, Glenmede) and was a strong leader even on the parts she was less familiar with (i.e. the dev updates) and had limited visibility into (i.e. iMercer).

[[self evaluation]]

Worked on imercer enhanced ecomm

Because this was a project we'd never taken on before, I spent a lot of time learning how to set up **enhanced ecommerce** and comparing any best practices I could find online (Things like Simo Ahava & Analytics Mania's guides; official GA documentation & Google's Developer resources). I collaborated with iMercer's marketing team to define their checkout steps & key metrics. I worked with developers (at ADK and at iMercer) to configure, test, and debug the implementation. I built a custom report so iMercer's team could easily interpret the data.

Cookie consent manager for iMercer

I made all updates to iMercer's tag management system so that their data collection complies with **GDPR**. I organized tags into the appropriate "bucket" (tracking for analytics purposes; tracking for advertising purposes; etc.) and applied the appropriate triggers so that each tag is only fired if the user consents to it. I collaborated with iMercer's developers to debug the implementation and worked with Trust Arc (iMercer's Cookie Consent partner) to verify the set up. I continue to deploy tags for iMercer based on this framework.

Did well

I put new skills into practice as soon as I learn them...when possible. This year I took a course on GTM and was able to use course concepts to improve iMercer's analytics architecture. After the lesson on GTM environments, I updated iMercer's container and resolved an issue causing double pageviews / low bounce rate on product pages.

I've also created templates, guides, and presentations on Analytics strategies to share with my team. I'm really proud of the resources I've added to ADK Knowledgebase the past few months, and I will definitely keep building that up as I continue learning!

More impact?

I think I could have split my time between home & office more to be more productive.

Rating

Exceeds Expectations

Current role:: Digital Marketing Associate

Salary: $37,000

Rating::

Exceeds expectations of current role

Accomplishments::

Led net-new analytics processess/specialties (ecomm + privacy)

Worked on imercer enhanced ecomm

Cookie consent manager for iMercer

JS, GA4

Ops & culture

Building an excellent reference library

Consistently acting as a strong and positive ambassador for/representation of the marketing team to external teams

Superpower::

External coordination: communication, attitude, knowledge

Knowledge creation (internally, operationally, externally)

High-level [[feedback]]::

Over the last year I've seen a clear evolution in your work. By the end of the previous year you were comfortable owning analytics engagements like MIT PEL and iMercer. You've become significantly more independent and this year saw you go deeper into different analytics specialities, like ecommerce and privacy management. This year hasn't been without it's challenges, though, and that's resulted in some rare instances of stress and demotivation. However, it's fair to say that your impact has been significantly larger than what was initially [[scope]]d for your role when you were hired full time. 

All that being said, there are some key opportunities to focus on for continuing to exceed expectations.

**Storytelling/strategy:** How can our reporting go beyond contextual framing of data and into thoughtful recommendations?

Tactical -> Strategic

Development area 1:: Problem-solving proactively

Summary:: Personal observations as well as some (generalized) peer [[feedback]] have shown that there are still instances where roadblocks and "wicked" problems (ill-defined ones) cause significant loss of momentum.

Concrete examples and peer [[feedback]]::

A recent example would be Wasabi

One person's positive and constructive [[feedback]] reflected this:

Keep

Keep steamrolling when you see something to fix/do/create.

Start

Calm down - don't stress yourself out if you don't have the answer.

Concrete suggestions::

Asking questions to prod at other ways to solve problems.

Ensure you understand the question/problem before [[[[solution]]ing]].

Explore: ESI strategies for problem framing + questioning.

What wild success in this area looks like::

Comfort asking any teammate questions

Addressing more problems proactively; presenting proposed solutions for [[feedback]] (rather than problems for help answering)

Development area 2:: Strategy (storytelling)

Summary::

Leveling up reporting to turn into recommendations that take into account business/product/customer context. How can we turn analytics into a [[[[product]] [[strategy]]]] tool?

Concrete examples and peer [[feedback]]::

Generally, all of our reports (mine too!) are too tactical - this is by far __the norm__. Most agencies will provide clear descriptions of what happened and sometimes draw a direct line to what can be done. I'd like to see us excel beyond that. 

Concrete suggestions::

Empathize with client: what would be important to you in their shoes? 

Zoom out from the previous reporting period to look at longer term goals/trends.

What wild success in this area looks like::

Analytics driven roadmap items or even engagements

Potential next role:: Digital [[insight]]s Analyst, Analytics Specialist, Analytics Strategist, Digital Analyst, Analytics & [[insight]]s Manager

**Continuing to upskill:** in general, mobile app analytics. specifically, working with ESI org to identify what you can do and when to add value to our [[[[product]] [[strategy]]]] service. 

[Supporting](https://adkgroup.atlassian.net/wiki/spaces/ADK/pages/3267297326/Book+Notes+Continuous+Discovery+Habits#Assessing-a-Set-of-Opportunities) prioritization

Constructing tests

Connecting & [[model]]ing business impact

**Analytics leadership:** multiply the value of what you've learned by sharing on a broader scale internally (eg - lunch and learns) and externally (eg - blogs or webinars).

Potential timeline::

40k? 8% today

3-6 month check in to try and get more and the way that happens is more billable work and/or higher rate

10k

for [[2022]] [[annual review]] for [[darci nevitt]]

Notes:

Changes from [[2021]]

Problem-solving proactively got better

Demonstrating strategic value of analytics were slightly improved

Look to:

help ensure prioritization decisions are driven by data by (1) aligning on goals up front (2) working to quantify them

Storytelling is still an opportunity for improvement

When providing [[feedback]], structure as positives. If something needs to be critical, structure it as "you could be more X by doing Y"



