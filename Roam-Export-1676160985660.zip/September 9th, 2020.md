[[🏔ADK [[Task Management]]]]

{{{[[DONE]]}}}} Big question/decision: is ADK marketing it's own service or is it an add-on for projects? #/

{{{[[DONE]]}}}} Plan for next [[Wasabi]] #[[a/b test]]: contact form changes #/

{{{[[DONE]]}}}} Edit questions for SDP blogs for nick

Principles

ask for specific examples

open-ended

minimal, but enough to get at stuff that isn't google-able

review previous meeting

{{{[[DONE]]}}}} draft new marketing emails for [[Museum of Science]] #/

{{{[[DONE]]}}}} Review copywriter freelancer interview notes #//

[vic brown](https://docs.google.com/document/d/1mWCpbrrce6tsHXBjDK258awJeGGosPvQcTxzh9aHkrk/edit)

[ohad cohen](https://docs.google.com/document/d/1ZoniXYamP5Td-PZjchB4gVjE1wnHl4703nwY_GW58cU/edit#heading=h.icvcdo84jupc)

[sam ellison](https://docs.google.com/document/d/1e-S9yWUuSuS7pddaPnXf1HgQs8WIcsO92HVlg4GUTZw/edit)

[deborah huso](https://docs.google.com/document/d/1dTTED7NZepIVcZmxkPoX8mH29FtUmXLQVq0aj4sjb7E/edit#heading=h.icvcdo84jupc)

{{{[[DONE]]}}}} Come up with title ideas for the lunch and learn podcast in partnership with Microsoft's Future of Work Initiative

Focus: how to move from legacy systems to more technologically advanced systems (and why it doesn't have to happen all at once). 

Basically, this: https://www.adkgroup.com/blog/expert-opinion-promise-and-reality-manufacturing-iot/

Options:

Be a Part of Manufacturing's Leading Edge

On the Leading (not bleeding) Edge of Tech

Cutting Through the Hype of Advanced Manufacturing

A Practical Guide to Upgrading Your Tech

Making the Latest Tech Work For You

From Legacy to Leading Edge

Define the Future 

Getting to the Ground Truth

The Blueprint for Digital Transformation

Beyond the Hype of Manufacturing Automation

A Manageable Guide to Digital Transformation

An actionable 

{{{[[DONE]]}}}} For SDP: best way to deal with difficulty around gathering content & how to learn SEO for padnprotect

{{{[[DONE]]}}}} [[Wasabi]] and cookiebot information from [[andrew creek]]: [slack](https://adkgroup.slack.com/archives/G01AKENTBA8/p1599684487000100)

{{{[[DONE]]}}}} Export quarter to date keyword data about [[Wasabi]] for [[adam freides]]

[[Meetings]]: [[Drawbridge]] user stories

Attendees:: [[mike ohara]] [[quin o'hara]] [[sean riley]] [[alex fedorov]] [[jayne hetherington]] [[patrick o'quinn]] [[Carolina Escobar]]

Time:: 09:30

Notes::

Envisioned as a messaging platform

"interests" are not just brands

Can put in interests for other people

Allow for broad interest but narrow down

What's a good User ID? Email? Phone number?

Tags = self-identified interests

But tags need to be categorized as well

Problems this solves:

Better matching ads + people

Consumers give [[feedback]]

A way to organize non-work and non-family/friends

VCs recommended a super narrow niche (athletes in florida)

Consensus Advisors has consumer ecomm company portfolio

Thesis: start with elite/affluent/early-adopter consumers

Competitor/alternatives

Honey

Groupon

Thing Testing

Testflight / AirPort

Ad blocker

Hey.com screener

Subscription boxes

Wanelo, Wish, Fancy, Svpply’s Want, Polyvore

Features

My Mind - browsing through the site, like/save something

Bulk Export of newsletters to Drawbridge

Ad blocker

[[Meetings]]:  ADK Team Meeting

Attendees::

Time::

Notes::

ADK's Values

Be humble

Always with integrity

Team first

Better everyday

Embrace diversity

Commit to quality

Have fun

Show grit

One measurable thing to help accelerate performance

This seems like OKR-lite

[[Meetings]]: Search team meeting for [[Wasabi]]

Attendees:: [[mary mccarthy]] [[adam freides]]

Time:: 15:59

Notes::

 Glossary section focused on informational keywords

Pillar pages for use cases needing a revamp

Comparison pages in the works

^^question^^: about sharing data in GA

From the presentation

Keywords back and forth

Put together 

Prepare for third quarter review in October

Date range quarter to date

[[Meetings]]: [[[[hiring]] a copywriter]]

Attendees:: [[chris baker]]

Time:: 17:36

Notes::

 how to use [[Ohad Cohen]] in a trial engagement

he is a more creative side

about [[sam ellison]]

great background

Options for assessing

Case studies:

ALKU

[[victor brown]]

Form Health

[[sam ellison]]

BSF

For [[Ohad Cohen]]

Review Grow and Convert blogger price & pricing from [[airtable]] in DemandCurve 

{{{[[DONE]]}}}} Teach ADK React team SEO best practices 

#[[Quick Capture]]

what are we best at? what does each [[outcome]] look like? 

deodorant, retainer, AirPods, talk to dad about VH

what it is, what type it is, when to use it, what’s required, estimated time, success stories, resources, example [[outcome]]s

