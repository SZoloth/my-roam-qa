For [[personal [[brand]]]]: create and own [[B2H]] and [[DTP/B2P]] [[Articles]]

Write about: healthcare company marketing strategies

Inspiration: [Panacea](https://www.panacea.digital/articles/), [Out of Pocket](https://outofpocket.health/)

Examples: [[Parsley Health]], [[One Medical]], [[Firefly Health]], [[form health]], [[AmWell]]

What are common themes?

Insurance coverage

Chat and availability (on-demand)

Care teams led by an expert but supported by coaches

[[swipe file/digital health marketing inspiration]]

[Display ad](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FFpgTD3AEre.mov?alt=media&token=db73f6dd-6b93-4354-bb7b-05fa8b932add) from [[Firefly]] showing:

A text convo

Insurance coverage

[[management]]: Review process for ADK

360 reviews

Process:

Self-evals

Peer [[feedback]]

HM takes [[feedback]] and pulls together

Managers meet for a calibration meeting

Set up meeting with reports to talk about performance

Following that -> Separate meetings to talk about compensation

Start pulling together [[annual review]] for [[darci nevitt]]

Timeline

Make sure these are done by [[November 30th, 2020]] at the latest

{{[[DONE]]}} OKR notes to management team #/ [[🏔ADK [[Task Management]]]]

And then lunch and learn

