# Options

## Drafts

Objective:: Define our marketing service for digital health clients.

Key results::

Publish consumer/telemed/telehealth GTM strategy and offering in Confluence

Publish patient recruitment strategy and offering in Confluence

Notes:

GTM / patient recruitment strategies to include:

Pitch deck for clients

Pricing estimates (publish in Proposify?)

Analytics process

Martech-stack

Google Ads best practices + strategy

Facebook best practices + strategy

Analytics process

CRM architecture?

Asset templates (eg, for: landing page + blog, onboarding email, dashboard)

Objective:: Create a world-class product analytics service

Key results::

Publish analytics and attribution stack for apps/products

Publish process for React analytics with dev evangelist

Pitch 3 clients on our A/B testing framework

Objective:: 3 new leads for ADK mHealth App Kit

Key results::

Launch landing page with analytics

Launch awareness campaign around top 3 target hospitals

Publish an email course on patient recruitment

Create an [Atlas](https://stripe.com/atlas) or [Growth Masters](https://growth.segment.com/) for digital health

Objective:: Adopt [[agile marketing]] at ADK

Key results::

Notes:

Sprints and bi-weekly

Daily stand - 5m

Sam to set up agile artifacts/processes

Project kick off on [[October 7th, 2020]]: present individual OKRs

{{[[DONE]]}} [[[[mHealth]] app kit]] GTM plan #/

landing page

[[product analytics]] and CRO

Metrics for each stage of AAARRR, how we meet them, how we measure them

3 clients using our A/B testing framework

Analytics for React

[[Segment]] + [[Amplitude]]?

Personal: produce a 1-5 year plan for self + team

Marketing ADK

{{[[DONE]]}} How will we promote/support [[refine labs]] project? #/

ADK content marketing - case studies + blogs?

# Notes

[[Meetings]]: [[Meetings with [[chris baker]]]]

Attendees:: [[chris baker]]

Time:: [[October 6th, 2020]] 10:31

Notes::

 

# Q42020 OKRs

## [[Objective/Define our marketing service for digital health clients]]

[[Key results/Publish consumer telemed GTM strategy and offering in Confluence]]

[[Key results/Publish patient recruitment strategy and offering in Confluence]]

[[Key results/Publish an email course on patient recruitment]]

## [[Objective/Create a world-class product analytics service & team]]

[[Key results/Publish analytics and attribution stack for apps & products]]

[[Key results/Publish process for React analytics with dev evangelist]]

[[Key results/Pitch 3 clients on our AB testing framework]]

## [[Objective/Sales team has everything they need to sell mHealth App Kit]]

[[Key results/Launch landing page v.1]]

[[Key results/Publish internal resources (positioning, pricing, etc.)]]

[[Key results/Publish external resources (polished deck, product demos, and other go to market content).]]

