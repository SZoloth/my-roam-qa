Due [[May 21st, 2020]]: event taxonomy for:

Web app tracking

Key interactions as defined by [[jayne hetherington]]

{{[[TODO]]}} ‘Lets get started’

{{[[TODO]]}} ‘Play Video’

{{[[DONE]]}} ‘[[language]] change’

{{[[TODO]]}} ‘Ok, i’ve got it’

