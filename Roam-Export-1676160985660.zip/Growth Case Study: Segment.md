# **Metadata**

**Author:** [[juliann shapiro]] of [[Demand Curve]] and [[calvin french-owen]] co-founder of Segment

**Source:**

**Keywords:** #Segment, #[[Demand Curve]], #[[Growth marketing[[*]]]]

# Notes

# What were the initial turning points that kicked off growth?

Originally started with an education product. Landed on Segment v.0 1 year in to building that product to solve their own problem of using and integrating all the different analytics platform

Started with a small, core niche -- developers

Wrote an engineering-focused blog

About the challenges they were facing and how they solved them

Put up "analytics academy"

## Early Process:

Launch and validate on hacker news (or: microcosm of twitter, growthhackers, product hunt, newsletters run by tech folk)

Helped build brand recognition

Set up content

Analytics Academy

Set a bar to have every post actionable - the content has to teach the reader something they didn't know before and that they can apply immediately

Engineering-focused blog and content

Talked about what engineering problems they're facing and how they're solving it

Open source projects

Matched a niche audience (devs interested in new/customizable tools) with a unique offer

This is similar to [growth masters](https://growth.segment.com/) (matches early stage product managers with the offer of free interviews with experts)

Drove crazy [[word of mouth]]

Find a niche and make 10 customers __wildly__ happy

Listen to people and build the products people ask for

Building something seemingly trivial that's badly needed can be a beachhead into an audience trusting you

Measure [[word of mouth]] result

How do you apply [[attribution]] to WOM?

Ask people where they came from

# What's changed at scale?

Their initial audience just __got__ the product and solution intuitively

Newer, bigger audience doesn't quite get it without more information, SO

Shifted to paid acquisition

Ramping SEO up a little bit

investing in inbound now, looking into outbound

# Biggest bombs - waste of resources

One of the highest intent actions is requesting a demo

small companies can start a product and get into value very quickly

bigger companies need the demo

Drove paid traffic to gated landing pages

Would follow up with a request for Segment demo, but these people were not really high intent

Basically: drove a BOFU offer at TOFU/MOFU audience

# Thoughts on personal vs. company branding?

Start with whatever's stronger already

# Partner marketing strategy

Two ways to think about partnerships

1) technical partners are tools they integrate with (zendesk, customer.io, GA, etc.)

Work closely with them to define use cases that user can accomplish by combining the tools

Put on events and put out content about how you can use the two tools together - spans multiple media 

Most active with Braze and [[Amplitude]]

Companies are breaking up big suites and replacing with best-in-class tools. Segment is the glue

2) channel partners

Partner with small consultants and vendors who help people get Segment set up in the first place

Commission / revenue-share agreement

Staying up to date on growth

demand curve, hacker news, behavioral economics books (nudge, misbehaving, influence, thinking fast and slow, hacking growth)

little known tools for growth

mutiny = [[personalization]]

what does growth team look like

cross functional growth team

