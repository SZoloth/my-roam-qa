#[[✍️ blog-post]]

# Nat's format

About company

Low traffic from #ahrefs

211 / month in [[ahrefs]]

Video walk thru

https://www.youtube.com/watch?v=ANWbRsQ_h2s&feature=youtu.be

#UX review of blog

Subscribe is only via chatbot

Tables as inline images vs. HTML

Content topics - are any based on a useful goal?

Reminder of uses for content

search traffic

conversions

sharing

link building

Dive into an example article

length

compare to SERP

Recommendations

Optimize old content

Optimize content production guidelines

Optimize content production schedule

Keyword strategy

Final diagnosis

shallow content

no keyword strategy

irregular publishing

old content that's not doing anything

# About company

#Hometap helps families that are "house rich, cash poor" by investing in the future value of their homes.

## Digital channels / Tech

Remarketing

[[Google Ads]]

[[facebook]]

#analytics

Gtag, Google Analytics, GTM (2x)

#Amplitude

#Segment

#PPC keywords

Heloc credit score

financing a re[[model]]

interest only home equity line of credit

unison down payment

Competitor

guaranteed home equity loans

equity home mortgage

figure home equity loans reviews

Competitor

## Competitors

Unison

Point

Figure

## "Competitive Analysis"

[[**Value props**]]

They offer you 5-15% of your homes current value pretty immediately, with no monthly payments

When you sell your house 1-10 years down the road, they receive a percentage of that

[[**Copy**]]

**[[onboarding]] flow**

# [[SEO]]

subscribe only via chatbot

tables should be HTML vs. images

Optimize fit quiz?

[fit quiz](https://www.hometap.com/fit-quiz)

Use sub-header tags

Category pages could be optimized by updating the H1 and blurb

Content ranking

Top

House rich cash poor

start saving retirement at 50

[optimize/supplement for more broad term: when is the best time to start saving for retirement?](https://[[ahrefs]].com/v3-keywords-explorer/google/us/overview?keyword=when%20might%20be%20the%20best%20time%20to%20start%20saving%20for%20retirement%3F)

Off first page

[renovation consultant](https://www.hometap.com/blog/what-is-a-home-renovation-consultant)

[refinance vs. home equity](https://www.hometap.com/blog/cash-out-refinance-vs-a-home-equity-loan)

[involuntary lien](https://www.hometap.com/blog/how-to-eliminate-liens-on-your-home)

[when can i stop paying pmi](https://www.hometap.com/blog/how-to-eliminate-pmi)

Finance is a __highly__ competitive space

Need to invest heavily in content marketing

[Organic Keywords + Competitors (from Moz)](https://docs.google.com/spreadsheets/d/1z8HbYuWeePXwJQUAvXorqwiNoRwLQzVzHjRs-61x7JM/edit#gid=1625621528)

PPC keywords - no overlap?

Heloc credit score

financing a re[[model]]

interest only home equity line of credit

unison down payment

Competitor

guaranteed home equity loans

equity home mortgage

figure home equity loans reviews

Competitor

Example: HELOCs

Heloc credit score = PPC w/ CPC of $12

Must be valuable

High difficulty though, not necessarily great to target out of the gates

Better to build up authority around it with long-tail keywords like....

their only article ranking for heloc-related terms = [](https://www.hometap.com/blog/the-difference-between-a-heloc-and-a-home-equity-loan/)https://www.hometap.com/blog/the-difference-between-a-heloc-and-a-home-equity-loan/

Ranking 29th for "difference between heloc and home equity loan" —> [0 traffic](https://[[ahrefs]].com/site-explorer/overview/v2/exact/live?target=https%3A%2F%2Fwww.hometap.com%2Fblog%2Fthe-difference-between-a-heloc-and-a-home-equity-loan)

Presumably the target kw since it's in the title and slug

Why poorly?

Short at only 522 words

Top ranking is [NerdWallet](https://www.nerdwallet.com/blog/mortgages/home-equity-loan-line-credit-pros-cons/) with almost double at 994

Also: tables, interactive quizzes embedded

