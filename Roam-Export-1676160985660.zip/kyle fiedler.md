Phone Number::

Email::

Company:: [[thoughtbot]]

Role:: Chief Design Officer

Location::

How We Met::

Birthday::

Tags:: #People

