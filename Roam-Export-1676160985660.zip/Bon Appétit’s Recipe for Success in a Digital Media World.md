Author:: [[jerrylu.substack.com]]

URL:: https://jerrylu.substack.com/p/bon-apptits-recipe-for-success-in-20-05-21

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

some of the most popular Bon Appétit videos average anywhere from 15 to 25 minutes in length 

longer videos enabled them to experiment with new styles, introducing more narratives and opportunities to get to know the personalities of the hosts. 

**Note**: Longer videos = more flexibility = more narrative = more personality = more fandom/influencer

rather than relying on the brand equity of their legacy print publication to power all the content on the new platforms. 

**Note**: They didn't just recycle their print content, they created new native content.

Perhaps surprisingly, it also helped to drive subscriptions to its magazine: an impressive 64% increase in subscriptions generated from digitally native channels year over year. 

**Note**: Will need to read linked article, but wonder how the subscription package has changed -- is it now more digital? Relates to WSJ tiers. Would also be interested in looking at their conversion [[funnel]].

But what made that audience truly attach to the brand was the strength of their personalities, their test kitchen hosts. 

unlike those channels, they were quick to double down on their unique strategy: having their hosts launch their own respective shows (i.e., individual web series within the broader channel). 

unpredictable, raw, extemporaneous 

how much better their content performed when the original content was positioned around the host rather than the food 

**Note**: Personality driven / human driven video is more interesting than product driven. We watch interesting people doing cool things - take away the people and you take away the popularity.

Relate to casting? Why does one one streamer perform better than another? It's likely that skill isn't that much of a differentiator at a certain point.

Successful channels on YouTube are typically personality and talent-driven, where the face of the channel is a single person. 

Wendy’s and Burger King have unsuccessfully tried to behave like real people on Twitter and other channels 

**Note**: Would these have done better making their brand persona more (literally) human?

Clearly the success of their videos is not so much about the finished product as the engaging personality and relatability of each host and their ability to bring the viewer along on their journey. 

And watch they do: the Bon Appétit brand currently boasts 13.7M social followers, 122M video views, and 11M digital uniques across all their social platforms. 

**Note**: Important to note that this also take 2-5 years of experimenting, etc.

Bon Appétit‘s strategic response to this fandom has been to lean into its passionate community, having their hosts recognize and embrace the creativity of their fans’ memes. 

**Note**: Antithetical to Quibi or Disney

either you create a powerful meme that grows organically, powering free customer acquisition, or you are doomed to pay all your gross margin to Facebook and Google ads. 

When asked to describe Bon Appétit, editor in chief Adam Rapoport said it best: “It’s whatever you want it to be. Even a magazine.” 

