Author:: [[segment.com]]

URL:: https://segment.com/blog/lessons-learned-95000-landing-pages/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

When you’re a cash-strapped nonprofit competing for attention against multi-billion dollar public companies, you have to focus on your mechanism for growth, and then become world-class at it. 

There were two ways we could tackle SEO:

Editorial SEO. High quality, editorial, long-form landing pages, focused on topics related to our audience. Hubspot is the canonical example here.

Programmatic SEO. High volume landing pages produced at scale, often created automatically or user-generated, that rank for transactional intent. Pinterest and Zillow are the canonical examples here. 

During one of our office hours, he discussed his time leading Growth at Airbnb. To measure the impact of their work, his team had tracked the first interaction someone had with the Airbnb site and the last interaction before they hit the signup flow. 

