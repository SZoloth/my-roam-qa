**Meta**

**author:** [[hannah hudson]]

**source:** https://growth.segment.com/videos/1/

**tags:** [[[[user]] [[research]]]], #survey, [[[[data]] analysis]] [[Segment]] [[[[Segment]] [[growth]] Talks]]

# Notes



