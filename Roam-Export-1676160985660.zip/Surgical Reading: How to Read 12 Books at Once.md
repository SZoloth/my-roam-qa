Author:: [[superorganizers.substack.com]]

URL:: https://superorganizers.substack.com/p/surgical-reading-how-to-read-12-books

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

It’s a process I’ve developed called surgical reading and it means that when I’m reading a non-fiction book, I focus on locating and removing the most valuable pieces of information from it quickly as possible 

This allows me to read many different books across a single topic at once, so I can look at it from multiple perspectives 

Go pull some book off the shelf that’s been sitting there for a while, hopefully one that you haven’t read. Follow along with me, and see for yourself what it’s like to read surgically. 

Look through the index, notice what topics are covered, and more importantly, at what depth. If an author is spending a good deal of pages on something, make a note of that topic. (You might try Dan’s fourfold index approach for this!) 

ny time something in the index interests me, I’ll write it down. I do this on a physical notecard or in a document. So, by the end of reading the index I’ll have all of the most interesting and relevant pieces of information in one place. 

I typically list page numbers when I plan on jumping to that topic. 

I like to take the topic card and set it next to the table of contents to see if I can get a sense of the author’s point(s). 

All of the above takes 5-15 minutes and is really a simplified version of “inspectional reading,” popularized by Adler and van Doren, which is just a more methodological skimming or “pre-reading” process. 

I’ll get through a preface in about 5 minutes. Skimming is my friend—I don’t need to memorize or meditate too deeply on it. It’s mostly just to make sure my mental map is on the money. 

break free of the author's structure, and delve into the book to find the pieces I need or that I want to know. 

I suggest following a topic over multiple chapters, so if the author starts talking about something on page 2, picks it up again on pages 25-29, and then again at 101-105, read those pages in sequence. 

Other interesting topics might be mentioned along the way. If so, add those to your map and find their places in the index. 

I continue to loop through pieces of the book from the index until I either lose interest or feel like I’ve gotten all that I need for now. 

Also, I will put any truly useful information from the book into Readwise to reference/search later, Anki if I want to remember it, or a playbook / to-do list to act upon. 

The biggest return on time I’ve found is to review key points from the previous chapters before starting a new chapter. I’ve found that Anki is well suited for this, but you can use notes to yourself as well. 

