Author:: [[collaborativefund.com]]

URL:: http://www.collaborativefund.com/blog/ideas-that-changed-my-life/

Recommended By::

Tags:: #Articles #Inbox #Readwise

### Highlights first synced by #Readwise [[September 20th, 2020]]

Same stuff that guides today, and will guide tomorrow. History is abused when specific events are used as a guide to the future. It’s way more useful as a benchmark for how people react to risk and incentives, which is pretty stable over time. 

There’s as much to learn about your field from other fields than there is within your field. 

Understanding how people respond to incentives, how to convincingly solve their problems, and how to work with others who are difficult to communicate with and/or disagree with you. 

self-interest is a freight train of persuasion. 

Since the biggest gains occur the most infrequently – either because they don’t happen often or because they take time to compound – the person with enough room for error in part of their strategy to let them endure hardship in the other part of their strategy has an edge over the person who gets wiped out, game over, insert more tokens, at the first hiccup. 

The only truly sustainable sources of competitive advantage I know of are:

Learn faster than your competition.

Empathize with customers more than your competition.

Communicate more effectively than your competition.

Be willing to fail more than your competition.

Wait longer than your competition. 

People believe what they’ve seen happen exponentially more than what they read about has happened to other people, if they read about other people at all. We’re all biased to our own personal history. Everyone. 

