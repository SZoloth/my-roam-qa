# Introduction: [[Ad Copy]]

# **Questions answered in this module**

How do I write ads that people actually click on and buy through?

Does punctuation matter?

How do I know what to write about in my ads?

How do I choose the right type of creative to complement my copy?

**Note:** **The following applies primarily to #[[paid social media]] ads (rather than, for example #[[Google Ads]]).**

# **Overview**

#[[paid social media]] ads are one of the most effective ways to find new customers __and__ connect with people already familiar with your company. But there's a big hurdle you have to overcome if you want to make money off your ads: __user intent.__

Someone on Facebook is not actively searching for a product or service. It's not like [[Google Ads]], where they __want__ to find results related to their search. With Google, the right type of ad can speak directly to their needs. That's not the [[paid social media]] ads. People go to Facebook, Instagram, and Pinterest (to name a few) to be entertained. Or to catch up with friends. And to discover new things.

No matter your niche, you can be certain your target audience spends a considerable amount of time on sites like Facebook. It'd be an incredibly large missed opportunity to not advertise to these folks where they spend hours each day.

But how do you do that?

If you want to connect with your audience and get them to convert when they're not deliberately looking for something to buy, you have to know how to speak to them — while at the same time conveying your core message.

At ADK Group we spend a considerable amount of time not only crafting ad copy, but continually refining it.

It's this cyclical process that will allow us notch wins for our clients with social ads.

# **References for **[[paid social media]] **ads**

## **The basic template**

Body copy = Primary text that appears above an ad's image

Creative copy = Words that appear on the ad's image

Headline copy = Text that appears in big, bold letters below an ad's image

Social proof = Text that appears below the headline

![](https://lh3.googleusercontent.com/G-VC6QknJQf-rk1_8CskpL93PCyQlHd2zCezhXHk1Egh6Nb9tzOJrj_m3AOl45oVIHTxDkg3Bj4X2CR4qzi4NtnR8FKVysCV4oFxi2Lz6Ki-RA2R75ji99S3P-nicYpTpZtwSye6)

We have two social ad templates in Google Sheets for drafting copy with character counts

## **Character Limits**

Every channel has its own character limits.

When we write ad copy across channels, we save time by writing copy for the platform with the most restrictions. For example, 150 characters max for the body copy, so it can be used for both Facebook and LinkedIn.

## **LinkedIn — Sponsored Content**

Headline: 70 characters

Body: 150 characters

## **LinkedIn — Text-Ads**

Headline: 25 characters

Body: 75 characters

## **Facebook:**

Headline: 40 characters

Body:

We keep the character count to 140 if we intend to use the same copy for LinkedIn & Twitter

We get 90 characters before it displays "...more"

Newsfeed description: We get 30 characters before it displays "...more"

## **Quora**

Headline: 65 characters

Body: 105 characters

## **Twitter**

Headline: 70 characters maximum. 50 characters before it gets truncated

## [[Google Ads]]

Headlines: 30 characters

Description: 80 characters

__Note: AdWords has very different ad copy requirements in terms of usage. You always want to match ad copy to the keywords the ad is targeting. So the ad copy is constantly shifting to match the targeted keyword. But we use the templates below as guidance__

## **Copy examples and breakdowns**

