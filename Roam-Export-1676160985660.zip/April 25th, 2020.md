#[[Quick Capture]]

In [[[[wall street journal]], parallel to [[brian mullen]]s thought about health tech startups being thrown into deep end (example is drone delivery)

