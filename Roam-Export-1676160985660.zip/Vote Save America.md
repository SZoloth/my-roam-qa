**Worksheets & homework**

[[storytelling]] prompts

What brought you here today?

Think about once more - what really brought you here today?

What was the moment you knew you had to take action?

What was the choice you made to get started taking action?

What about your life circumstances has pushed you to have the values you do?

{{[[TODO]]}} Practice storytelling with someone in your life

[[storytelling]] **for organizing**

Guest speaker: [[jon favreau]], [[jay ellis]]

Goal shouldn't necessarily be to change someone's mind, but you do want them to think about something new or differently

Advice for sticking with organizing

Congratulate yourself

Know that this can get hard, but will be rewarding

Have a support group

What is "[[storytelling]]"?

We all have stories that shape us

What doe #storytelling achieve?

Let's others get to know you

Explains your values and motivations

Opportunity for connection

Creates a sense of urgency

It's effective

Components of #storytelling

**Story of self**: communicates your values and motivations

I care about X so I'm going to do Y

Personal: share personal details about your life that demonstrate your "values"

**Story of us:** communicates the values of others in this fight yet to join

Communal: Clearly connects personal details in your story to the values important in your community

**Story of now:** communicates urgency - include specific CTA explains why it is so important

To craft your story #storytelling

Start with your values

Be vulnerable

Connect to your community

Meet the moment

CTA

#storytelling questions

What values do you have that motivate you to take action?

The belief that fundamentally we're all human and deserve equal treatment and respect

Love

Empathy

What issues matter to the community I'm organizing?

Community

Police reform

Racism

What is happening right now in your community that reinforces the importance of your story?

Police funding

Voting rights

How to share your story #storytelling

Specificity: include details about the moments included in your story: what did you see?

When to share your story?

1:1 with another volunteer

~1 minute

Community meeting

~3 minutes

On phone with a voter

Before or after a canvass shift

~1 minute

Kicking off an event

~3 minutes

At the door with a voter

~30 seconds

Example structure

Intro + gratitude + story of self + story of us + story of now + what I'm doing + why + CTA

