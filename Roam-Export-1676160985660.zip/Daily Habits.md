Habits

Meditate

Cold shower

Lift or run

Write down 3 things you did well today

#hobbies

Learn piano

{{[[TODO]]}} Look up pianos

{{[[TODO]]}} Look up lessons

Bike

{{[[TODO]]}} Buy a bike

Learn [[DeFi]]

https://learn.nateliason.com/p/defi-orientation

{{[[DONE]]}} Metamask #[[Personal Task Management]] #//

from [[charlie madden]]

{{[[DONE]]}} https://www.nateliason.com/blog/learn-solidity solidity #[[Personal Task Management]] #// Completed at 09:59 [[November 26th, 2022]]

