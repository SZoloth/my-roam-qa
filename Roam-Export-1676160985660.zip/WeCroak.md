Tags: #Stoicism, #[[Leap Prompt]]

#[[Leap Prompt]] Write a list of three things you can focus on that matter to you and that you can easily spend time on within the limits of this moment as they are for you

Family

Friends

Learning

