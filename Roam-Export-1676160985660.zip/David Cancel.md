[[♾️ Mantras]]

* Read every day. It doesn't matter what. It doesn't matter if you "finish the book". Just read.

* Find mentors who have achieved success in what I want (love, happiness, community, parenting, financial)

* Double down on what's working and don't stop until it stops working

* Avoid shiny new distractions. AKA Focus. AKA see above.

* [[prioritize]] learning from history. AKA you aren't special. Cheat code = read books that have lasted the test of time AKA old books.

* [[prioritize]] the biggest rocks each day. Feel no guilt if you never get to the small rocks.

* Momentum is all the things. Keep the streak going. Search for the perfect wave and ride it as long as you can.

* Great opportunities are much rarer than you think. Go all-in when you find the few in your lifetime.

* Psychology. Study it and restudy it. Understanding Social Psychology, human decision making, and cognitive biases is worth more than all the leadership, business, and self-help books in the world. Seriously.

* Be patient. A few great actions/bets repeated is worth a million tiny actions.

* Seek arbitrage opportunities. Invest when others won't, hold back when others are greedy.

