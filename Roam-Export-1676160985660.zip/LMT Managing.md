Tags:: #[[darci nevitt]], #[[management]][[*]], #[[management]][[*]], #[[🌱 The Making of a [[Manager]]]] #[[feedback]] #[[feedback]] #1:1s #[[Meetings with [[chris baker]]]]

Pomos::

{{[[POMO]]}}

{{[[POMO]]}}

# For Darci

{{[[DONE]]}} **Share [[feedback]] about what's going well or not**

Eg - time to produce [[ADK Drupal Campaigns]] report and letting me know when it's done

Own up to not expressing clear expectations earlier - that's what I need to work on

Share that this is a great opportunity to work on that - being more clear in my expectations. What I hope from you is that if you feel like you won't be able to complete something in the time given, you'll reach out to me so we can make necessary adjustments and keep people updated

Did this resonate with you, seem to come out of left-field, or something else?

Link back to [[National Speed]] tasks

{{[[DONE]]}} Check in on [[career]] [[Goals]]

{{[[TODO]]}} Ask about processes / tasks she's completing that feel inefficient or confusing

{{[[TODO]]}} Ask about strengths and weaknesses - has that changed?

{{[[DONE]]}} Set up 1:1s #1:1s

1/week for 30m

1/month for behavioral [[feedback]] and [[career]] [[Goals]]

# Preparing and reflecting on my own expectations, style, etc. Assessing my team

How do I make decisions?

What do I consider a job well done?

What are all the responsibilities I took care of when it was just me?

What's easy or hard about working in this function?

What new processes are needed now that this team is growing?

What qualities do I want in a team member?

What skills does our team need to __complement my own?__

What should my team be known for?

{{[[TODO]]}} Assess my team:

Are processes efficient?

Are people getting along?

Is your team known for rigorous and high-quality work?

Is your team cagey about deadlines?

Are priorities always shifting?

Are there any inefficient meetings?

Is anyone on your team an asshole (even if they're a brilliant top IC)?

Using the below [[model]], categorize people. Get [[chris baker]]s POV as well

![](https://firebasestorage.googleapis.com/v0/b/firescript-577a2.appspot.com/o/imgs%2Fapp%2FMaster_DB%2FhhakJUnZt4.png?alt=media&token=1beaa7a9-4c7a-43f8-b5f0-c8352b565f98)

# Major [[Goals]]

{{[[TODO]]}} Define what success looks like

{{[[TODO]]}} Get others to care about it

{{[[TODO]]}} Create a [[feedback]] machine for #[[darci nevitt]]

How to collect: Every quarter, send a short email to handful of your reports closest collaborators asking: a) What is X doing especially well that they should do more of? b) What should X change or stop doing?

{{[[TODO]]}} Create a feedback machine for #[[sam zoloth]] #[[feedback]]

Questions for [[chris baker]] [[feedback]]

{{[[DONE]]}} How do you think the Drupal campaign went?

{{[[TODO]]}} Whats keeping you up at night? Why?

{{[[TODO]]}} How do you determine which things to [[prioritize]]

{{[[TODO]]}} What opportunities do you see for me to do more of what I do well? What do you think are the biggest things holding me back from having greater impact?

{{[[TODO]]}} What skills do you think a hypothetical perfect person in my role would have? For each skill, how would you rate me against that ideal on a scale of 1-5?

# Managing myself to improve managing others

Questions for [[chris baker]] [[feedback]]

{{[[DONE]]}} How do you think the Drupal campaign went?

{{[[TODO]]}} Whats keeping you up at night? Why?

{{[[TODO]]}} How do you determine which things to [[prioritize]]

{{[[TODO]]}} What opportunities do you see for me to do more of what I do well? What do you think are the biggest things holding me back from having greater impact?

{{[[TODO]]}} What skills do you think a hypothetical perfect person in my role would have? For each skill, how would you rate me against that ideal on a scale of 1-5?

