**Tags**: #mHealth [[[[mHealth]] app kit]] #positioning [[my [[OKR]]s]]

# Notes

Sources:

Documentation

Confluence

Google Drive

For inspo:

look at proposify

Stripe Atlas

People

Dan

Miranda

Brian

Ben

What is mHealth app kit?

A SaaS product

Tool used for clinical data collection

["80% of what is needed in a digital health app to meet hospital standards"](https://docs.google.com/presentation/d/16hbzAvm_DZrfqrvzrd9btqkRIhqtHU6o084WymKkttE/edit#slide=id.g6e8d6ba930_1_6)

Who is it for?

Clinical researchers

About

Want to be able to bring to IT team without making them made (security/compliance/architecture)

Want to be able to use it easily (quick set up, intuitive management, training, and best-in-class UX/UI)

Want patients to be able to use this easily (best-in-class UX/UI, experience building for patients)

Physicians

Care managers

Are we doing anything with clients on legacy versions like trying to upsell? #question

Why was it made?

Most clinical data collection apps rely on the same core set of features.

Yet researchers have had to repeatedly buy this new or custom, starting from scratch.

We built scalable/customizable versions of the core set of features that researchers can get a discount and then use money to customize the rest of what they need. 

Because the cost of setting up and customizing an instance is significantly less than building from scratch, all of the 20+ projects built on mHealth App Kit would not have been possible without mHealth App Kit.

Months --> weeks of development

Why not fully or more out of the box?

As a researcher, you need to ask and answer questions that haven't been done before. To win a grant you need to do something novel. Which means most true "out of the box" solutions won't provide your needs. Our platform takes care of the majority of needs, in addition to FLEXIBILITY for novel. Because the basics are taken care of, more of your budget can go towards what makes your project unique. You get a level of customization others don't have.

How much does it cost?

Total cost by phase:

Discovery: $10,000-$25,000

Alpha: $50,000-$150,000

Beta: $100,000-$200,000

MVP limited to PI clinical use: $250,000

Product V1: $150,000-$500,000

Product V2: $300,000-$1,000,000

Scale (eg: new company): $500,000-$1,000,000+

What are the key benefits?

Modular / customizable

Consistently meets IRB standards

What are the key features?

HIPAA compliant

Security

Dashboard is [[password]] protected 

2FA? OAuth? #question

Authentication

For dashboard: email

For mobile app: 2FA

[[password]] requirements

[[password]] [[expiration]]s every 90 days

Login lockouts (IP address blocked for up to one hour after 5 failed attempts within 5 minutes)

Permissioning

Platform

White labeled

Research standards

Cloud based

## Core features available out of the box

### Study management dashboard

Patient registration and onboarding

Admins can [add new patients](https://docs.google.com/presentation/d/16hbzAvm_DZrfqrvzrd9btqkRIhqtHU6o084WymKkttE/edit#slide=id.g6ef225ebf7_0_31)

Patients can also register autonomously 

Admin/permissioning

User creation and management

Creation of key user roles and permissions: Patient, Researcher, Care Manager, Physician, Admin and Super Admin

Ability for admins to create new patients and trigger registration process (text message notification)

Ability for admins to create new study team members and trigger the registration process (email [[notifications]])

[[password]] protected

All registration [[notifications]] handled via text message

[Study team information and management](https://docs.google.com/presentation/d/16hbzAvm_DZrfqrvzrd9btqkRIhqtHU6o084WymKkttE/edit#slide=id.g6ef225ebf7_0_70)

[Add new study team member](https://docs.google.com/presentation/d/16hbzAvm_DZrfqrvzrd9btqkRIhqtHU6o084WymKkttE/edit#slide=id.g6ef225ebf7_0_38)

Includes default Study Team management information such as: name, email, role, Cohort and status

Other table features include pagination, column filtering and column sorting.

Study team [[notifications]] (via email)

New user registration, Study team registration, account registration verification, email verification, forgot [[password]], [[password]] [[expiration]], [[password]] reset confirmation, account deactivation, and account reactivation

[Active patient information](https://docs.google.com/presentation/d/16hbzAvm_DZrfqrvzrd9btqkRIhqtHU6o084WymKkttE/edit#slide=id.g6e8d6ba930_1_207)

[Patient data management](https://docs.google.com/presentation/d/16hbzAvm_DZrfqrvzrd9btqkRIhqtHU6o084WymKkttE/edit#slide=id.g6ef225ebf7_0_45)

Includes default patient information such as: name, unique user id (UUID), phone number and status.

Configurable columns to display additional patient data upon request.

Additional patient data includes: MRN, Sex, DOB, Cohort, Physician and Care Manager

Quick filters to easily see patient status (active, pending and deactivated)

Other table features include pagination, column filtering and column sorting.

Care providers can view patient responses by clicking on the patient's name from the patient management table.

Care providers can filter and sort patient responses.

Patient notification system (via text message)

Account creation status, Account status, Account registration verification, account deactivation and account reactivation

### Misc?

Survey Creation

How/where does this happen? #question

Ability to use a bash script to generate a json with all survey details.

Surveys can be queried for different types of data

Supports 4 question types including: Basic Text, Information, Image + Text, Audio + Text

Supports 7 response types including: Yes/No, Checklist, Scale, Multiple Choice, Free Text Response, Wheel and No Response

Question linking

What is this? How/where does this happen? #question

Documentation

What is this? #question

API documentation

Frontend documentation

Modular, library based approach for both the backend and frontend feature list

Resource library

Ability to upload resources for patients to view within the mobile app

### Mobile app

Customization / white label

Background colors, fonts and logos are configurable on a per app basis

Navigation? #question

Action screens? #question ([source](https://docs.google.com/presentation/d/1u9T2CK5EsLXScODbdk6TXvEV31WsZ2JCVpj6Fjk1vQw/edit#slide=id.g7584fa8678_0_7))

### Data collection: Surveys

[Handles multiple response types](https://docs.google.com/presentation/d/16hbzAvm_DZrfqrvzrd9btqkRIhqtHU6o084WymKkttE/edit#slide=id.g6e8d6ba930_1_164) (types below)

Yes/No 

Checklist

Scale (with images/icons)

Multiple choice (same as checklist?)

Free text

Wheel / dropdown

No response

Multimedia

Image

Date/time

[For Survey: "adaptive survey"](https://docs.google.com/presentation/d/16hbzAvm_DZrfqrvzrd9btqkRIhqtHU6o084WymKkttE/edit#slide=id.g6e8d6ba930_1_170)

Means: The questions shown to a user can be dependent on their response.

Patient can go back and change responses while a survey is still active (has the status of in progress). This might change their question tree structure.

Example:

Q: Are you pregnant?

If yes, move on to follow up pregnancy question

If no, skip all questions related to pregnancy

Alternative phrases: if/then logic, branching logic

For inspiration, see workflow tools (like HubSpot)

Patient can see progress bar at top of survey to know how many questions are left to be answered.

Survey creation

Use a bash script to generate a json file with all survey details

Query surveys for different types of data

Supports 4 question types including: 

text

information (no response)

image + text

audio + text

### Services

Discovery, design, and dev for customization

Grant writing support

Consistent points of contact and world-class agile project management

Dedicated help desk

We're with you all the way

What's on our roadmap?

Is the below still accurate? #question

Study team and patient profile (for app and dashboard)

Patient and study team member export

In-app resource library

EHR integration

Additional question/response types

Response types

Touch tracking (eg - simon says/bop it)

Free drawing

Voice

Video

Video/motion tracking

Voice quality tracking

NLP

Where are AR and IoT? #question

What is the social proof?

Logos

BWH

MGH

Dana Farber

Boston Childrens

Mass Eye/Ear

Case studies / examples (There are between 12 and 24 projects??)

STAMP

For: Dana Farber Cancer Institute

[Slide](https://docs.google.com/presentation/d/1M4En1lEKSLKkZpfP1J77y_Iw3LxNaH_vruJs7pm8Ak4/edit#slide=id.g87e01e0167_0_253)

Saved the project more than $100k and months of development

ImPROVE

For: BWH

[Slide](https://docs.google.com/presentation/d/1M4En1lEKSLKkZpfP1J77y_Iw3LxNaH_vruJs7pm8Ak4/edit#slide=id.g87e01e0167_0_294)

Saved the project more than $100k

COVID

For: MGH

[Slide](https://docs.google.com/presentation/d/1M4En1lEKSLKkZpfP1J77y_Iw3LxNaH_vruJs7pm8Ak4/edit#slide=id.g87e01e0167_0_302)

Built V.1 in one week

myPROHealth

For: BWH

[Case study](https://www.adkgroup.com/case-studies/prostate-cancer-patient-mobile-application/)

ERAS

For: BWH

[Case study](https://www.adkgroup.com/case-studies/mobile-health-app-surgical-patients/)

ALZ

For: BWH & Harvard Medical School

[Case study](https://www.adkgroup.com/case-studies/smartphone-app-alzheimers-research/)

Asthma

For: BWH

AVID

Arthritis

Home Health

National Association

National Pancreas Foundation

National Association

Has COVID affected anything about the sales process / purchase decisions? #question

## #positioning and #[[gtm/Go To Market]]

Classic positioning statement

For **clinical researchers** who must **launch a research app on a limited budget and timeframe**, mHealth App Kit is a new **SaaS platform** that provides **80% of what's needed out of the box and the experience to customize the remaining 20% so you save hundreds of thousands of dollars and turn months into weeks.** Unlike **completely custom or completely out of the box solutions,** we have **the balance between customization and templatization that can support any need and almost any budget.**

What market are we in?

Digital health, telehealth, telemedicine

SaaS

B2B

B2H

What segment of the market are we targeting? Why?

Clinical research at leading hospitals. We have unique experience, [[insight]], and capabilities that make our service/product especially valuable to this historically underserved population. 

"According to [Premier Research](https://premier-research.com/perspectivesmobile-clinical-research-theres-app/), a life sciences consulting firm, only several hundred of the more than 150,000 mobile health applications published as of December 2016 focus on clinical trials."

What audience are we selling to? Why?

The project lead, oftentimes the clinical research lead. They have the direct pain point that we address and make or heavily influence the final purchase decision.

Who else are we selling to? #question

What demand generation channels are we exploring and why?

Definitely:

Sales

Content

Organic social

ABM

Maybe:

Influencer/event

Paid

Social

Google Ads

Partnerships

Who are the most important competitors and why?

This is a #question -- [[brian mullen]] had an answer for this one time but I've lost it

REDCap?

in-house alternatives?

at [Mount Sinai](https://clinicalresearch-apps.com/)

[Dynamicaly](https://dynamicly.com/healthcare)

[Bioclinica CTMS](https://www.bioclinica.com/what-we-do/clinical-trial-management-system)

[ResearchKit](https://www.apple.com/researchkit/) from Apple?

https://www.researchandcare.org/

From [this o'reilly article](https://www.oreilly.com/content/clinical-trial-theres-an-app-for-that/)

[clinical ink](https://www.clinicalink.com/)

[mpower](https://parkinsonmpower.org/your-story)

[developer portal](https://sagebionetworks.org/research-projects/mpower-researcher-portal/)

[github repo](https://github.com/ResearchKit/mPower)

[science 37](https://www.science37.com/)

Other agencies

[Code & Theory Health](https://health.codeandtheory.com/)

[Upstatement](https://www.upstatement.com/)

[Clutch list](https://clutch.co/developers/healthcare)

[HTD](https://htdhealth.com/)

[Spire Digital](https://www.spiredigital.com/industries/healthcare-biotech/)

What are the key value props? (2x2 of speed/price and customization)

We're cheaper and faster than fully custom

You launch faster with more budget saved / to spend on customization

We're more flexible than full out of the box

You have more control than an out of the box solution

We're proven - in use in over 20 research projects at organizations like BWH, MGH, Dana Farber, Boston Childrens Hospital, Mass Eye and Ear

We meet IRB standards for: HIPAA compliance, security, and other research standards.

We offer best-in-class UX/UI for superior study team and patient experience

What is our business [[model]]?

Subscription + agency services? #question

