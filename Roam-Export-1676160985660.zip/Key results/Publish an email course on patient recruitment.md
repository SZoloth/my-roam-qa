## Notes

Take what we do for [[Key results/Publish patient recruitment strategy and offering in Confluence]] and format into a series of emails

