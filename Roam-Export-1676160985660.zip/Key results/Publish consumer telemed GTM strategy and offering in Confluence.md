^^**This is the strategy  pitch to clients like Form Health to help them spend their first ~$5k in marketing**^^

More internal than [[Key results/Publish patient recruitment strategy and offering in Confluence]]

## Notes

Present to team: here’s how and why we can take telehealth and telemed companies to market.

B2B sales - **here’s how we position our services to Evan Richardson.**

Here’s what we do, here’s what we don’t. Includes:

tech stack

Answers to things like: is HubSpot HIPAA compliant?

email marketing

analytics

etc.

Go To Market plan or framework for consumer digital health clients

List of relevant services we provide to consumer digital health clients

One of the services = patient recruitment

Previous clients (Form Health, Firefly Health) have just wanted to spend X amount of money efficiently

Not, SEO

"Why not SEO? We're firm believes in the power of organic growth and content loops. However, in early stages you need rapid results so you can learn what's going on. SEO is a long-term game that we're happy to help you win, but you should likely focus on rapid iteration instead __unless__ your app has built in organic growth loops (usually requires users to generate and share their own content online, but we're happy to discuss in more detail).

Rough sketch of what we do

Who you're targeting

Persona / audience definition

Channel strategy

What you're saying

Value prop + messaging

Where you're sending them

Landing page design

Quizzes

Content

listicle

comparisons

Squeeze forms

Hero

Optimization

A/B testing

User testing

How you're converting leads to customers

Onboarding + offers

Remarketing + nurture

(where/when something) about your performance

Analytics

Surveys

Reporting

What tools we use (needs to be healthcare specific, so HIPAA compliant)

Webflow + subdomain for landing page testing

Weak spots

Creative

PPC..

Value props

Questions

Should we include homepage?

Do we set up CRMs?
Should we use WYSIWYG landing page builders?

Do we need chatbots?

^^What is the simplest [[funnel]] we could create that drives the most value?^^

Ad + LP

If I were to re-do Form Health

Landing page

Conversion [[funnel]]

Tech and budget

## Tasks

Define the strategy

What's involved in [[gtm/Go To Market]] in general?

#positioning and #[[gtm/Go To Market]]

Classic positioning statement

For **clinical researchers** who must **launch a research app on a limited budget and timeframe**, mHealth App Kit is a new **SaaS platform** that provides **80% of what's needed out of the box and the experience to customize the remaining 20% so you save hundreds of thousands of dollars and turn months into weeks.** Unlike **completely custom or completely out of the box solutions,** we have **the balance between customization and templatization that can support any need and almost any budget.**

What market are we in?

Digital health, telehealth, telemedicine

SaaS

B2B

B2H

What segment of the market are we targeting? Why?

Clinical research at leading hospitals. We have unique experience, [[insight]], and capabilities that make our service/product especially valuable to this historically underserved population. 

"According to [Premier Research](https://premier-research.com/perspectivesmobile-clinical-research-theres-app/), a life sciences consulting firm, only several hundred of the more than 150,000 mobile health applications published as of December 2016 focus on clinical trials."

What audience are we selling to? Why?

The project lead, oftentimes the clinical research lead. They have the direct pain point that we address and make or heavily influence the final purchase decision.

Who else are we selling to? #question

What demand generation channels are we exploring and why?

Definitely:

Sales

Content

Organic social

ABM

Maybe:

Influencer/event

Paid

Social

Google Ads

Partnerships

Who are the most important competitors and why?

This is a #question -- [[brian mullen]] had an answer for this one time but I've lost it

REDCap?

in-house alternatives?

at [Mount Sinai](https://clinicalresearch-apps.com/)

[Dynamicaly](https://dynamicly.com/healthcare)

[Bioclinica CTMS](https://www.bioclinica.com/what-we-do/clinical-trial-management-system)

[ResearchKit](https://www.apple.com/researchkit/) from Apple?

https://www.researchandcare.org/

From [this o'reilly article](https://www.oreilly.com/content/clinical-trial-theres-an-app-for-that/)

[clinical ink](https://www.clinicalink.com/)

[mpower](https://parkinsonmpower.org/your-story)

[developer portal](https://sagebionetworks.org/research-projects/mpower-researcher-portal/)

[github repo](https://github.com/ResearchKit/mPower)

[science 37](https://www.science37.com/)

Other agencies

[Code & Theory Health](https://health.codeandtheory.com/)

[Upstatement](https://www.upstatement.com/)

[Clutch list](https://clutch.co/developers/healthcare)

[HTD](https://htdhealth.com/)

[Spire Digital](https://www.spiredigital.com/industries/healthcare-biotech/)

What are the key value props? (2x2 of speed/price and customization)

We're cheaper and faster than fully custom

You launch faster with more budget saved / to spend on customization

We're more flexible than full out of the box

You have more control than an out of the box solution

We're proven - in use in over 20 research projects at organizations like BWH, MGH, Dana Farber, Boston Childrens Hospital, Mass Eye and Ear

We meet IRB standards for: HIPAA compliance, security, and other research standards.

We offer best-in-class UX/UI for superior study team and patient experience

What is our business [[model]]?

Subscription + agency services? #question

What are the **services** we provide?

What is our recommended **tech stack** and why?

Define the pitch

How do we frame this as a valuable offering for consumer digital health clients?

