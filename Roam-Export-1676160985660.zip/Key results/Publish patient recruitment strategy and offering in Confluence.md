## Notes

Whitespace opportunity?

PR right now is clinical trial patient recruitment b/c that is non telehealth/telemed space. For: “I need to source 500 patients with disease X for MGH study on hearing loss”

we want to be about telehealth and telemedicine patient recruitment. NOT clinical trials.

Eg - Evan Richardson trying to attract bariatric weight loss; Firefly trying to attract primary care patients

Instead of “marketing” we appear specialized

The specific channels, ad tactics, and messaging strategy.

How we work within limitations like hearing loss?

How we engage patients in a conversation around their healthcare

A LOT of overlap with [[Key results/Publish consumer telemed GTM strategy and offering in Confluence]] & should feed into [[Key results/Publish an email course on patient recruitment]]

## Tasks

What are the best channels for doing this?

What is the best messaging strategy?

What are the best offers / lead magnets?

What other assets are needed?

