Author:: [[Patricia Sellers]]

URL:: https://fortune.com/1996/01/15/what-exactly-is-charisma-its-real-it-matters-and-it-can-be-dangerous-fortune-classic-1996/

Recommended By::

Tags:: #Articles #Inbox #Readwise #charisma

# Notes

They communicate by using symbols, analogies, metaphors, and stories. 

Remember Jack Welch redirecting GE—going on the road to tirelessly preach his “No. 1 or No. 2” strategy requiring managers to “fix, close, or sell” any business that wasn’t first or second in worldwide market share. 

Jim views his mission in life as boiling everything down to a few basic principles that motivate people 

His message to employees: Netscape is like a rocket. If it fails to reach escape velocity, it will crash back to earth. 

“We’ve gotta go full speed,” he says. “We’ve got low barriers to entry and incredible competitors. If we can’t establish presence and a brand name, we’ll die.” 

**Note**: Blitzscale?

Inside Netscape, Barksdale promotes the strategy in two words: “Netscape everywhere.” 

Charismatic leaders relish risk 

Great optimists, charismatic people long to do things that haven’t been done before 

Charismatic people speak emotionally about putting themselves on the line. They work on hearts as well as on minds. 

“I started by explaining why I took the job,” he says. Then he told them: “This is one of the greatest adventures in business history. Retailers don’t turn around. A major retailer never has. There’s no [[model]] for what we’re gonna do. It’s very risky. You have to be courageous, filled with self-confidence. If we do it, we’ll be wealthier, yes. But more than that, we’ll have incredible psychic gratification. How can you not do it?” 

Charismatics are rebels who fight convention. They may seem idiosyncratic, but their oddball image augments their charisma. 

“The way she listened made my energy level go up. She asked the most thoughtful, original questions. There was nothing boilerplate about her.” 

Business, to Gadiesh, is not systematic. Success comes from pulling emotional levers. 

Gadiesh abhors bureaucratic doublespeak—and the unthinking conservatism it usually reflects. She flashes her wit to kill it. 

Charismatic people are able to see things from another person’s perspective. 

“I constantly try to think, ‘If I were the client, how would I feel about this?’ That’s step No. 1 if you’re going to find common ground.” 

“Orit has that talent for making you feel you’re the most important person in the room. She bleeds your blood.” 

“If you admit you made a mistake,” says Barksdale, “the customer will always cut you slack.” 

Charismatic leaders goad and challenge, prod and poke. They test your courage and intellectual mettle. 

“The most important thing a leader can have is true north,” Gadiesh says. “It’s a set of [[Principles[[*]]]] that directs him or her to what’s virtuous and right. Charisma can be a positive or negative force. It all depends on whether it’s anchored by true north.” 

