Tags:: #[[SEO Teardown: Hometap]], #[[NOTES for SEO tactic: Glossaries]], #[[What Writers Need To Know About SEO]], #[[Blogging for business]], #keyword, #[[keyword research]], #Drafts

Intro

After we design, build, and launch a custom website we help our clients focus on SEO in a variety of ways…

We're current launching this with one of our clients, Wasabi. 

Examples

[[Hometap]] is a potential example of company that could use a Glossary for SEO

How could Hometap win HELOC? 

Example: HELOCs

Heloc credit score = PPC w/ CPC of $12

Must be valuable

High difficulty though, not necessarily great to target out of the gates

Better to build up authority around it with long-tail keywords like....

their only article ranking for heloc-related terms = [](https://www.hometap.com/blog/the-difference-between-a-heloc-and-a-home-equity-loan/)https://www.hometap.com/blog/the-difference-between-a-heloc-and-a-home-equity-loan/

Ranking 29th for "difference between heloc and home equity loan" —> [0 traffic](https://[[ahrefs]].com/site-explorer/overview/v2/exact/live?target=https%3A%2F%2Fwww.hometap.com%2Fblog%2Fthe-difference-between-a-heloc-and-a-home-equity-loan)

Presumably the target kw since it's in the title and slug

Why poorly?

Short at only 522 words

Top ranking is [NerdWallet](https://www.nerdwallet.com/blog/mortgages/home-equity-loan-line-credit-pros-cons/) with almost double at 994

Also: tables, interactive quizzes embedded

DataRobot

Flexport

https://www.optimizely.com/optimization-glossary/web-analytics

another example of an optimized main/list page - https://pathmind.com/wiki/

How to execute

Finding terms

Use **AnswerThePublic** method of [[keyword research]]

Setting it up

Design is simple, can likely essentially copy+paste your blog

some sites have their glossary as a continuously-updated blog post (https://www.outbrain.com/blog/digital-advertising-glossary/) and others have it as separate webpage (such as the examples you sent over). the main negatives i can think of for putting glossary on blog is having to work within the confines of a blog post (i.e. difficult to link to sub-pages dedicated to specific glossary terms, and not able to organize terms in any helpful way)

architecture

What should you call it?

Depends on traffic largely, but glossary better than wiki

Although you shouldn’t use wiki since that’s going to put you in competition with wikipedia.

unless, of course, ~3rd place for wiki is > ~1st place for glossary

the key things that page would __need__ are:

nice to haves that __could__ help:

things that would only really help your biz, not the type of audience looking for definitions

yeah on your list/main page you’ll want to have links to all the terms

Can't I just make a continuously updated blog post?

Cite [[bernard huang]] from clear[[scope]] - "Death of pillar pages"

Page length doesn't really matter anymore - Google is more focused on matching search intent with to your content

so if the glossary term is like click through rate a page that’s optimized for that term (eg - [domain.com/click-through-rate](http://domain.com/click-through-rate) ) that has CTR in the title, headers, has images for it, etc. and directly resolves search intent will likely outrank a broader, longer page that may be something like "Marketing Metrics To Track" for __that specific term__ (click through rate)

flexport is a great example of this

this is their glossary page https://www.flexport.com/glossary/. it doesn’t really rank for anything

this (relatively short) page ranks #1 for eccn number https://www.flexport.com/glossary/export-control-classification-number

eccn number has ~2,300 monthly searches

flexport ranks because it efficiently satisfies the users need of understanding what an eccn number is

the other benefit of doing that is that it gives you a sort of “foot in the door” - datarobot ranks #9 for what is data science (10k monthly searches, but also an order of magnitude more difficult that eccn number). Now they have a solid page to optimize if they wanted to

this is the page that ranks - relatively short (https://www.datarobot.com/wiki/data-science/)

Creating that page likely took little effort, and now that they see they rank 9th for that term they can decide to put more effort (or not) into optimizing that page further

Also: worse UX (see https://www.outbrain.com/blog/digital-advertising-glossary/ vs. datarobot or flexport)

Performance of that vs. datarobot/flexport - though industries are differnet

the outbrain page ranks very highly for digital advertising glossary and nothing else.the flexport example i sent contains multiple pages that rank #1 for 197 keywords, some with 5k+ search volume

Less targeted, worse internal linking

the one advantage a single page glossary (like outbrain) has is if you’re targeting [industry name] glossary but you’re doing so at the expense of optimizing for all the other glossary terms (edited)

Why do this?

Easy

Valuable

Is this valuable? Isn't the traffic low-intent?

Point: Focus on bringing highly targeted audience from [[Tim Soulos]]' [[Blogging for business]] & definitions aren't high purchase intent

Counterpoint: highly targeted to your audience. 

Example: [[flexport]] bidding on search terms driving towards it's glossary page 

{{[[TODO]]}} Add screenshot of flexport SERP

SEO traffic from [[Tim Soulos]] [[Blogging for business]]

Warning

also note that ranking really well for keyword definitions will sometimes land you in the featured snippet, and may actually __reduce__ traffic to your site..

as a heads up - you may end up capturing featured snippets (example attached), which may actually result in __less__ traffic because people can see the whole answer right in the SERP & your link won’t appear on the rest of the SERP if you have the featured snippet. i dont think this is necessarily a bad thing (has benefits like brand awareness + trust, may not actually impact your CTR that much etc.) - more something to be aware of.

Also, because this is accessible and valuable it might be overdone. 

